# 🚀 Cesar Template - CMS Profesional hecho con Next.js (v1.7)

[![Next.js](https://img.shields.io/badge/Next.js-15.1.7-black?style=for-the-badge&logo=next.js)](https://nextjs.org/)
[![React](https://img.shields.io/badge/React-19-blue?style=for-the-badge&logo=react)](https://react.dev/)
[![Prisma](https://img.shields.io/badge/Prisma-6.4.1-2D3748?style=for-the-badge&logo=prisma)](https://www.prisma.io/)
[![MySQL](https://img.shields.io/badge/MySQL-AWS_RDS-4479A1?style=for-the-badge&logo=mysql)](https://aws.amazon.com/rds/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind-3.4-38B2AC?style=for-the-badge&logo=tailwind-css)](https://tailwindcss.com/)
[![Version](https://img.shields.io/badge/Version-1.7.0-16c96f?style=for-the-badge)](https://github.com/PhillCodex/cesar)

**Cesar Template** es una plataforma web y sistema de administración de contenido (CMS) empresarial de alto rendimiento **creado para Cesar por [codeyfix.com](https://codeyfix.com) (CEO Phill)**. Desarrollado con **Next.js 15**, **React 19**, **Tailwind CSS** y **MySQL en AWS RDS**, cuenta con estética moderna Dark Cyber Neon / Light Mode, arquitectura modular, constructor visual **Elementor**, editor estilo Gutenberg, generador de sitemaps multi-índice, módulo de copias de seguridad y **Biblioteca de Medios (Media Library)** estilo WordPress.

---

## 📋 Novedades y Changelog (Versión 1.7)

### 🎨 1. Constructor Visual en Vivo Elementor (`/dashboard/elementor`)
* **Lienzo a Pantalla Completa sin Distracciones:** Interfaz dedicada 100vw / 100vh para diseñar y maquetar páginas web en tiempo real con vista previa Responsive (*Escritorio*, *Tablet*, *Móvil*).
* **Sistema de Estructuras Flexbox & Columnas:**
  - Selector de estructuras con 12 presets prediseñados (1 columna, 2 columnas iguales, 3 columnas, 4 columnas, columnas asimétricas 1/3 + 2/3, 2/3 + 1/3, etc.).
  - Reordenamiento visual de secciones: arrastra los 6 puntitos (`::`) en la barra superior fucsia para mover contenedores arriba o abajo con guías magnéticas luminosas.
  - Controles de dirección (*Fila / Columna*), alineación (*Justify Content / Align Items*), gaps, relleno (padding) y color de fondo con selector visual.
* **Biblioteca de Widgets Drag & Drop:**
  - **Encabezado (Heading):** Tipografía completa, etiquetas semánticas (`H1` a `H6`, `p`, `div`), 4 botones de alineación (*Izquierda*, *Centro*, *Derecha*, *Justificado*) y barra de acento neón `#16c96f` auto-centrada.
  - **Editor de Texto:** Formato de texto enriquecido, colores, interlineado y espaciado de márgenes.
  - **Imagen:** Ancho personalizable (100%, 75%, 50%, px), radio de bordes, sombra y enlace opcional.
  - **Botón:** Alineación (incluye ancho completo justificado), tamaños, radios y estilos visuales (*Neón TechLab*, *Outline*, *Dark*).
  - **Video & YouTube Embed:** Reproductor con contenedor responsive 16:9 y alineación centrada.
  - **Separador:** Línea divisoria con ancho ajustable (25%, 50%, 75%, 100%), grosor y color.
  - **Hero Banner:** Sección de impacto con badge neón, título grande, descripción y botones de llamado a la acción.
  - **Widgets Dinámicos Vinculados a MySQL:** *Servicios Destacados*, *Testimonios de Clientes*, *Artículos y Recursos* y *Galería de Proyectos* con carga de datos en vivo.
* **Panel Lateral de Edición Estilo Elementor Pro:**
  - `[ General ]`: Edición de contenido, textos, enlaces y botonera de 4 alineaciones.
  - `[ Estilo ]`: Tipografía avanzada (selector de color, tamaño en px, peso 300-900, transformación MAYÚSCULAS/minúsculas, espaciado de letras).
  - `[ Disposición ]`: Modos de visualización (*Bloque*, *Flex*, *Grid*, *En línea*), distribución flexbox, márgenes y padding.
* **Motor de Renderizado Público (`lib/elementor-renderer.ts`):** Convierte el árbol JSON de Elementor en código HTML limpio y estilizado en `/paginas/[slug]` y páginas canvas.

### 🪄 2. Integración Inteligente con el Editor de Páginas (`/dashboard/paginas/nuevo`)
* **Detección Automática de Páginas de Elementor:**
  - En lugar de mostrar código JSON plano en el editor de bloques, se muestra una tarjeta limpia con el logo de Elementor.
  - Botón principal de acceso rápido: **`[E] Editar con Elementor`**.
  - Botón `[E] Editar con Elementor` en la barra superior del editor y en la barra flotante pública `AdminTopBar`.
  - Opción para alternar al editor estándar de bloques si se requiere.

### ☁️ 3. Compatibilidad Universal con Vercel Serverless (Uploads & Media)
* **Respaldo Directo en Base de Datos MySQL:** Columna `fileData LONGTEXT` en la tabla `media` para almacenar imágenes sin depender del sistema de archivos local de solo lectura.
* **Ruta Dinámica `/uploads/[...path]`:** Manejador dinámico en Next.js para servir imágenes subidas en producción con caché optimizado y soporte de tipos MIME.
* **Eliminación de Errores `ENOENT`:** Las APIs `/api/upload` y `/api/media` ahora operan fluidamente en Vercel Serverless y en desarrollo local.

---

## 📋 Novedades de Versiones Anteriores (v1.6)

### 🖼️ 1. Módulo Biblioteca de Medios estilo WordPress (`/dashboard/medios`)
* **Ubicación en Barra Lateral:** Ubicado estratégicamente justo después de **Páginas** (`/dashboard/paginas`).
* **Subida Drag & Drop (Arrastrar y Soltar):**
  - Arrastra imágenes o archivos directamente sobre cualquier parte de la ventana o sobre la zona de subida punteada.
  - Barra de progreso interactiva durante la subida con cálculo automático de dimensiones y tamaño en disco.
* **Vistas Duales (Cuadrícula y Lista):**
  - ⊞ **Vista de Cuadrícula:** Miniaturas cuadradas 1:1 con etiquetas de nombre de archivo y badges de selección.
  - ☰ **Vista de Lista:** Tabla con miniatura, nombre de archivo, autor, fecha de subida, tamaño en disco y enlaces de acción rápida.
* **Filtros Avanzados y Búsqueda en Tiempo Real:**
  - Selector de tipos de medios (*Todos los medios*, *Imágenes*, *Audio*, *Video*, *Documentos / PDFs*).
  - Selector cronológico por mes y año (*Todas las fechas*, *Agosto 2026*, etc.).
  - Buscador predictivo en tiempo real por nombre, título, descripción o texto alternativo.
  - Modo **Selección en lotes** para eliminar múltiples archivos simultáneamente.
* **Modal "Detalles del adjunto" (Attachment Details):**
  - Navegación fluida con flechas (`<`, `>`) y teclado (`←`, `→`, `Esc`) para examinar la galería sin cerrar el modal.
  - Vista previa a gran escala del archivo con enlace para abrir el archivo original.
  - Ficha técnica completa: fecha, autor, nombre de archivo, tipo MIME, tamaño y dimensiones en píxeles.
  - Formulario de metadatos con auto-guardado en MySQL:
    - **Texto alternativo (Alt text):** Para optimización SEO y accesibilidad.
    - **Título:** Encabezado descriptivo del archivo.
    - **Leyenda de la imagen (Caption):** Pie de foto editable.
    - **Descripción:** Texto explicativo detallado.
    - **URL del archivo:** Enlace directo con botón *Copiar la URL al portapapeles*.
  - Enlaces de acción: *Ver archivo de medios*, *Descargar archivo* y *Borrar permanentemente*.

### 📐 2. Editor Horizontal Panorámico de Footer en Ajustes (`/dashboard/ajustes`)
* Nueva pestaña **Pie de Página (Footer)** con diseño horizontal panorámico (*"tipo mayormente ancho que largo"*).
* Personalización de Slogan institucional, Copyright dinámico (`%year%`, `%sitename%`) y enlaces legales.
* Grid horizontal de 4 columnas para datos de contacto (Email, Teléfono/WhatsApp, Dirección, Horario) con switch de visibilidad.
* Grid horizontal de 6 columnas para redes sociales (Facebook, Twitter/X, Instagram, LinkedIn, YouTube, GitHub).
* Grid horizontal de 3 columnas para encabezados de columnas de enlaces.
* Vista previa interactiva en vivo del pie de página público a pantalla completa.

### 🧭 3. Barra Superior de Administración estilo WordPress (`AdminTopBar`)
* Barra fija superior visible en todas las páginas públicas exclusivamente para usuarios con rol `ADMIN`.
* Menú del sitio con enlaces directos al Escritorio, Menús, Ajustes y Copias de Seguridad.
* Botón contextual dinámico: *Editar Entrada* (en posts), *Editar Página* (en páginas institucionales) o *Editar el sitio*.
* Badge con conteo en vivo de comentarios pendientes de moderación en MySQL.
* Menú desplegable **+ Añadir** (Post, Medio, Página, Proyecto, Servicio, Usuario).
* Menú de usuario con avatar, nombre de perfil y botón de cierre de sesión seguro.

---

## 📋 Novedades de Versiones Anteriores (v1.5)

### 💾 1. Módulo Backups & Restore (`/dashboard/backups`)
* **Ubicación en Barra Lateral:** Acceso directo desde el menú principal del panel de administración ubicado junto a *Ajustes*.
* **Pestaña 1: Básico (Gestión, Descargas y Restauración):**
  - **Métricas del Sistema en Tiempo Real:** Total de backups generados, espacio total ocupado en disco, estado de la base de datos MySQL (conteo de registros) y estado de la carpeta de archivos multimedia `/public/uploads`.
  - **Generación de Backups Manuales:** Permite crear respaldos en caliente seleccionando el tipo:
    - 🗄️ *Completo:* Base de Datos MySQL + Archivos multimedia (`/uploads`).
    - 💾 *Solo Base de Datos:* Volcado completo de todas las tablas de MySQL (usuarios, posts, páginas, menús, comentarios, settings, proyectos, servicios, testimonios).
    - 🖼️ *Solo Archivos Multimedia:* Archivos e imágenes cargadas en `/public/uploads`.
  - **Descarga Local Directa:** Botón para descargar el archivo de respaldo (`.json`, `.sql`, `.zip`) directamente a tu ordenador para almacenamiento seguro offline.
  - **Subida de Copias Externas:** Drag & Drop o selector de archivos para cargar copias de seguridad previas directamente al servidor.
  - **Restauración Segura con Modal de Confirmación:** Sistema de restauración con comprobación de integridad, resumen detallado de los datos a restaurar y casilla de aceptación de riesgo.
* **Pestaña 2: Configuración (Programación Automática / Cron):**
  - **Programador Autónomo:** Habilita o deshabilita la generación automática de respaldos.
  - **Frecuencia Personalizable:**
    - ⏱️ *Por Hora:* Copias cada 60 minutos para sitios de alto volumen.
    - 📅 *Por Día (Diario):* Ejecución diaria con selector de hora de bajo tráfico (ej. `03:00 AM`).
    - 🗓️ *Por Semana (Semanal):* Selección del día exacto de la semana (ej. Domingo) y la hora.
    - 📆 *Mensual:* Selección del día del mes (ej. día 1) y la hora programada.
  - **Filtros de Contenido:** Selecciona si incluir Base de Datos, Medios y/o Ajustes del Sitio.
  - **Política de Retención Inteligente:** Conserva automáticamente las últimas 5, 10, 20 o 30 copias, purgando las más antiguas para optimizar el almacenamiento del servidor.
  - **Destinos de Almacenamiento:** Servidor Local (`/backups`), Google Drive / Cloud Storage, AWS S3 o envío automático por Correo Electrónico.
  - **Alertas y Notificaciones:** Envío de reportes por email al completarse con éxito o alertas inmediatas ante incidencias.

---

## 📖 Guía: Cómo Utilizar el Módulo de Backups & Restore

### 🔹 A. Cómo Crear una Copia de Seguridad Manual
1. Inicia sesión en el panel de control y dirígete a **Backups** en la barra lateral (`/dashboard/backups`).
2. En la pestaña **Básico**, haz clic en el botón verde **`+ Crear Copia de Seguridad`**.
3. Selecciona el tipo de respaldo deseado:
   - *Respaldo Completo (Recomendado)*
   - *Solo Base de Datos*
   - *Solo Archivos Multimedia*
4. Opcionalmente, escribe una nota de referencia (ej. *"Previo a actualización"*).
5. Haz clic en **`Generar Respaldo Ahora`**. El sistema procesará las tablas y generará el archivo en cuestión de segundos.

### 🔹 B. Cómo Descargar una Copia a tu Computadora
1. En la tabla de copias de seguridad de la pestaña **Básico**, localiza el archivo que deseas guardar.
2. Haz clic en el icono azul **📥 Descargar** en la columna de acciones.
3. El archivo se descargará automáticamente en tu navegador.

### 🔹 C. Cómo Restaurar una Copia de Seguridad
1. Si tienes el archivo en tu computadora y no en el servidor, haz clic en **`Subir Copia`** para cargarlo.
2. En la lista de copias disponibles, haz clic en el icono naranja **🔄 Restaurar**.
3. Revisa el resumen de la copia y lee la advertencia de seguridad.
4. Marca la casilla *"Entiendo los riesgos y confirmo que deseo restaurar..."*.
5. Haz clic en **`Restaurar Ahora`**. El sistema restaurará las tablas de la base de datos y los archivos multimedia automáticamente.

### 🔹 D. Cómo Configurar Copias de Seguridad Automáticas
1. Dirígete a la pestaña **Configuración** en el módulo de Backups.
2. Activa el interruptor **`Programación Automática de Respaldos`**.
3. Selecciona la **Frecuencia** (Por hora, Diario, Semanal o Mensual) y define la **Hora de Ejecución**.
4. Ajusta el **Límite de Retención** (ej. *Conservar últimas 10 copias*).
5. Ingresa tu correo electrónico de notificación.
6. Haz clic en **`Guardar Configuración de Backups`**.

---

## 📋 Novedades de Versiones Anteriores (v1.4)

### 🌟 1. Gutenberg 2.0 en Posts & Páginas
* **Auto-Guardado Inteligente como Borrador:** Debounce de 1.5s que guarda automáticamente en MySQL con animación interactiva (*Guardando...* -> *Guardado como borrador*).
* **Botón `[+]` Alineado a la Derecha:** Menú contextual rápido para insertar bloques sin filas inferiores duplicadas.
* **Creación de Bloques con Enter:** Generación limpia de párrafos al presionar la tecla Enter.
* **Arrastrar y Soltar (Drag & Drop):** Bloques arrastrables directamente desde el cajón lateral al lienzo.
* **Título sin bordes:** Campo de título 100% limpio y minimalista.

### 💬 2. Gestión del Botón Flotante de WhatsApp
* Activación/Desactivación, número internacional y mensaje predeterminado configurables desde `/dashboard/ajustes`.

### 🗺️ 3. Arquitectura Multi-Sitemap XML 2.0 & Explorador SEO
* Generación dinámica de índice `/sitemap.xml`, `/post.xml`, `/page.xml`, `/categoria.xml`, `/proyecto.xml` y `/servicio.xml`.

---

## 🛠️ Pila Tecnológica

| Componente | Tecnología |
| :--- | :--- |
| **Framework Fullstack** | Next.js 15 (App Router, Server Components & Route Handlers) |
| **Biblioteca UI** | React 19 con Hooks (`useState`, `useEffect`, `useCallback`, `useRef`, `Suspense`) |
| **Estilos & Diseño** | Tailwind CSS + CSS Modules + Dark Cyber Neon & Light Theme |
| **Iconografía** | Lucide React |
| **ORM & Modelado** | Prisma 6.4.1 |
| **Base de Datos** | MySQL 8.0 alojado en AWS RDS (`database-1...rds.amazonaws.com`) |
| **Sistema de Backups** | Motor nativo de volcados JSON/SQL, compresión y programador automático |
| **Autenticación** | JWT / Cookies seguras con `bcryptjs` |
| **Tipado** | TypeScript 5 (Modo estricto) |

---

## 📁 Estructura del Proyecto

```text
├── app/
│   ├── api/                     # Endpoints REST (backups, settings, posts, pages, categories, sitemap)
│   │   └── backups/             # Gestión de copias, restauración y descargas
│   ├── dashboard/               # Panel de administración protegido
│   │   ├── backups/             # Módulo Backups & Restore (Básico | Configuración)
│   │   ├── ajustes/             # Configuración general, WhatsApp y personalización
│   │   ├── posts/               # Gestión y editor Gutenberg de posts
│   │   ├── paginas/             # Gestión y editor de páginas
│   │   ├── seo/                 # Configuración de metadatos, robots.txt y sitemaps
│   │   ├── categorias/          # Jerarquía de categorías
│   │   ├── proyectos/           # Gestión de portafolio
│   │   ├── servicios/           # Gestión de servicios
│   │   └── testimonios/         # Reseñas y testimonios
│   ├── posts/                   # Lector de posts público (/posts y /posts/[slug])
│   ├── sitemap.xml/             # Sitemap Index central
│   ├── layout.tsx               # Layout raíz
│   └── page.tsx                 # Portal público de inicio
├── backups/                     # Almacenamiento local de archivos de copias de seguridad
├── components/
│   ├── dashboard/               # Header, Sidebar, Popover de notificaciones
│   ├── home/                    # Hero, Servicios, Proyectos, Testimonios, Artículos, CTA
│   ├── layout/                  # Header público, Footer
│   └── ui/                      # Contenedores, Títulos de sección
├── prisma/
│   ├── schema.prisma            # Esquema y modelos de base de datos MySQL
│   └── seed.ts                  # Script de inicialización de administrador
└── public/                      # Recursos estáticos, iconos y uploads
```

---

## ⚡ Instalación y Puesta en Marcha Local

### 1. Clonar el repositorio:
```bash
git clone git@github.com:PhillCodex/cesar.git
cd cesar
```

### 2. Instalar dependencias:
```bash
npm install
```

### 3. Configurar variables de entorno (`.env`):
Crea un archivo `.env` en la raíz del proyecto con la cadena de conexión a la base de datos MySQL:
```env
DATABASE_URL="mysql://usuario:password@host:3306/cesar_1"
SESSION_SECRET="tu_clave_secreta_jwt"
```

### 4. Sincronizar esquema con Prisma:
```bash
npx prisma db push
```

### 5. Iniciar servidor de desarrollo:
```bash
npm run dev
```

Abre [http://localhost:3000](http://localhost:3000) en tu navegador para ver el sitio web o [http://localhost:3000/dashboard](http://localhost:3000/dashboard) para ingresar al panel de control.

---

## 🔒 Licencia & Créditos
Proyecto privado desarrollado para **Cesar** (**Cesar Template** - CMS hecho con Next.js). Todos los derechos reservados.

Desarrollado y creado por **[codeyfix.com](https://codeyfix.com)** — CEO Phill.
