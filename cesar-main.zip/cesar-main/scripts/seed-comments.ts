import { prisma } from "../lib/prisma";

async function main() {
  const posts = await prisma.post.findMany({ take: 3, select: { id: true, title: true, slug: true } });
  console.log("Found posts:", posts.length);
  if (posts.length > 0) {
    const existingComments = await prisma.comment.count();
    if (existingComments === 0) {
      await prisma.comment.createMany({
        data: [
          {
            postId: posts[0].id,
            authorName: "Alex Ramos",
            authorEmail: "alex.ramos@gmail.com",
            content: "Excelente artículo. La recomendación sobre el doble factor de autenticación (2FA) me sirvió mucho para blindar mi tienda virtual.",
            status: "APROBADO",
            authorUrl: "https://alextech.pe",
          },
          {
            postId: posts[0].id,
            authorName: "Camila Salazar",
            authorEmail: "camila.salazar@outlook.com",
            content: "¿Recomiendan algún plugin específico para realizar los backups automatizados a AWS S3 o Google Cloud Storage?",
            status: "PENDIENTE",
          },
          {
            postId: posts[0].id,
            authorName: "Bot Publicitario",
            authorEmail: "promo@free-traffic-generator.xyz",
            content: "Consigue 10,000 visitas diarias con nuestro software automático aquí: http://spam-link.xyz",
            status: "RECHAZADO",
          },
        ],
      });
      console.log("Created 3 sample comments!");
    } else {
      console.log("Comments already exist:", existingComments);
    }
  }
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
