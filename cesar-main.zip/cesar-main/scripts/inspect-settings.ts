import { prisma } from "../lib/prisma";

async function main() {
  const settings = await prisma.siteSetting.findMany();
  console.log("SiteSettings in DB:", JSON.stringify(settings, null, 2));
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
