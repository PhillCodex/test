import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  try {
    await prisma.$executeRawUnsafe("ALTER TABLE media ADD COLUMN fileData LONGTEXT NULL");
    console.log("✅ Columna fileData LONGTEXT añadida exitosamente a la tabla media.");
  } catch (err: any) {
    if (err.message?.includes("Duplicate column name") || err.message?.includes("already exists")) {
      console.log("ℹ️ La columna fileData ya existía.");
    } else {
      console.error("Error al alterar tabla:", err.message);
    }
  }
}

main().finally(() => prisma.$disconnect());
