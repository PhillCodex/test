import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const admin = await prisma.user.findFirst({ where: { role: "ADMIN" } });
  if (!admin) {
    console.error("No se encontró usuario administrador.");
    return;
  }

  // Obtener categorías existentes
  const categories = await prisma.category.findMany();
  const catMap = new Map(categories.map((c) => [c.slug, c.id]));

  const realArticles = [
    {
      title: "5 prácticas esenciales para proteger tu sitio WordPress",
      slug: "5-practicas-esenciales-para-proteger-tu-sitio-wordpress",
      excerpt: "Descubre cómo blindar tu instalación de WordPress contra ataques de fuerza bruta, inyecciones SQL y vulnerabilidades críticas en plugins.",
      content: `<h2>La seguridad web no es opcional</h2>
<p>WordPress alimenta más del 40% de la web mundial, lo que lo convierte en el objetivo favorito de bots automatizados y ciberdelincuentes. Proteger tu infraestructura requiere medidas preventivas rigurosas.</p>

<h3>1. Autenticación de Dos Factores (2FA)</h3>
<p>Implementar 2FA reduce en más de un 99% el riesgo de accesos no autorizados mediante ataques de diccionario o fuerza bruta en <code>/wp-admin</code>.</p>

<h3>2. Restricción de permisos en wp-config.php</h3>
<p>Asegúrate de que los permisos de lectura de tu archivo de configuración estén fijados en <code>chmod 400</code> o <code>440</code> para evitar lectura indebida por otros usuarios del servidor.</p>

<h3>3. Deshabilitar la edición de archivos desde el panel</h3>
<p>Añade la siguiente directiva a tu <code>wp-config.php</code>:</p>
<pre><code>define('DISALLOW_FILE_EDIT', true);</code></pre>

<h3>4. Firewall de Aplicaciones Web (WAF)</h3>
<p>Filtrar el tráfico malicioso en el borde de la red con soluciones como Cloudflare o WAF a nivel de servidor detiene exploits antes de que toquen tu base de datos.</p>

<h3>5. Copias de seguridad automáticas externas</h3>
<p>Nunca almacenes tus backups en el mismo servidor donde corre la aplicación. Utiliza almacenamiento de objetos S3 cifrado.</p>`,
      featuredImage: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&auto=format&fit=crop&q=80",
      seoTitle: "5 Prácticas Esenciales para Proteger WordPress | Cesar Template",
      seoDescription: "Guía técnica de ciberseguridad para sitios web y tiendas en WordPress. Protege tu servidor y datos confidenciales.",
      focusKeyword: "proteger wordpress seguridad",
      seoScore: 92,
      status: "Publicado",
      tags: "WordPress, Seguridad, Ciberseguridad, WAF",
      categoryId: catMap.get("seguridad") || catMap.get("wordpress") || null,
      authorId: admin.id,
    },
    {
      title: "¿Next.js o WordPress? Cuándo usar cada uno para tu negocio",
      slug: "nextjs-o-wordpress-cuando-usar-cada-uno",
      excerpt: "Analizamos a fondo rendimiento, escalabilidad, costos de infraestructura y SEO para ayudarte a tomar la mejor decisión técnica.",
      content: `<h2>El dilema de la arquitectura web moderna</h2>
<p>Elegir la pila tecnológica adecuada es una de las decisiones más estratégicas para cualquier empresa digital. ¿Cuándo conviene la velocidad y flexibilidad de Next.js y cuándo la rapidez de entrega de WordPress?</p>

<h3>Next.js: Rendimiento extremo y escalabilidad</h3>
<p>Next.js es la solución predilecta cuando necesitas:</p>
<ul>
  <li>Arquitecturas SaaS y paneles de administración dinámicos.</li>
  <li>Puntuaciones perfectas de 100/100 en Core Web Vitals y renderizado híbrido (SSR / SSG).</li>
  <li>Seguridad total sin riesgo de ataques a CMS tradicionales.</li>
</ul>

<h3>WordPress: Autonomía editorial y bajo tiempo al mercado</h3>
<p>WordPress sigue siendo una excelente opción para portales de noticias, blogs corporativos o sitios web donde el equipo de marketing necesita publicar contenido diariamente sin intervención de desarrolladores.</p>

<h3>Enfoque Híbrido: Headless WordPress + Next.js</h3>
<p>Combinar WordPress como gestor de contenido (Headless API) y Next.js como frontend garantiza lo mejor de ambos mundos: facilidad de edición y velocidad ultrarrápida.</p>`,
      featuredImage: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&auto=format&fit=crop&q=80",
      seoTitle: "Next.js vs WordPress: Comparativa de Rendimiento y Costos",
      seoDescription: "Descubre qué tecnología elegir entre Next.js y WordPress según los objetivos de tu empresa.",
      focusKeyword: "nextjs vs wordpress",
      seoScore: 95,
      status: "Publicado",
      tags: "Next.js, WordPress, Desarrollo Web, Arquitectura",
      categoryId: catMap.get("desarrollo") || null,
      authorId: admin.id,
    },
    {
      title: "Guía básica de backups y recuperación ante desastres en Cloud",
      slug: "guia-basica-backups-recuperacion-desastres-cloud",
      excerpt: "Estrategia 3-2-1 para copias de seguridad automáticas, snapshots en AWS/Google Cloud y tiempos de recuperación RTO/RPO mínimos.",
      content: `<h2>Plan de Continuidad del Negocio</h2>
<p>Los desastres ocurren: fallos de hardware, borrados accidentales, corrupciones de base de datos o ataques de ransomware. Tener un plan de Disaster Recovery probado es vital.</p>

<h3>La Regla de Oro del Respaldo: 3-2-1</h3>
<ul>
  <li><strong>3 copias de los datos:</strong> La primaria y dos respaldos.</li>
  <li><strong>2 medios distintos:</strong> Almacenamiento local en bloque y almacenamiento de objetos cloud.</li>
  <li><strong>1 copia fuera de la sede:</strong> En otra región geográfica o proveedor de nube independiente.</li>
</ul>

<h3>RTO y RPO: Las dos métricas indispensables</h3>
<p><strong>RTO (Recovery Time Objective):</strong> El tiempo máximo tolerable que el sistema puede permanecer fuera de línea.</p>
<p><strong>RPO (Recovery Point Objective):</strong> La cantidad máxima de datos que tu negocio puede permitirse perder medida en tiempo.</p>`,
      featuredImage: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&auto=format&fit=crop&q=80",
      seoTitle: "Guía de Backups y Recuperación ante Desastres en la Nube",
      seoDescription: "Aprende a estructurar una política de respaldos 3-2-1 en la nube con snapshots automatizados.",
      focusKeyword: "backups cloud disaster recovery",
      seoScore: 88,
      status: "Publicado",
      tags: "DevOps, Cloud, AWS, Backups",
      categoryId: catMap.get("devops") || null,
      authorId: admin.id,
    },
    {
      title: "Mejora el rendimiento y reduce latencia en tu servidor Linux",
      slug: "mejora-rendimiento-servidor-linux",
      excerpt: "Optimización de Nginx, compresión Brotli, caché en Redis y ajustes sysctl del kernel para soportar miles de peticiones por segundo.",
      content: `<h2>Optimización de Alto Rendimiento en Servidores Linux</h2>
<p>Un servidor bien configurado puede procesar hasta 10 veces más tráfico con los mismos recursos de hardware. A continuación revisamos los ajustes de mayor impacto.</p>

<h3>1. Ajustes del Kernel Linux (sysctl.conf)</h3>
<p>Aumenta el límite de conexiones concurrentes y optimiza los búferes TCP agregando a <code>/etc/sysctl.conf</code>:</p>
<pre><code>net.core.somaxconn = 65535
net.ipv4.tcp_max_syn_backlog = 65535
vm.swappiness = 10</code></pre>

<h3>2. Compresión Brotli en Nginx</h3>
<p>Brotli ofrece hasta un 25% mejor compresión que Gzip en archivos JavaScript, CSS y HTML, reduciendo drásticamente el peso de la transferencia de red.</p>

<h3>3. Implementación de Redis para Object Cache</h3>
<p>Almacenar en memoria RAM las consultas frecuentes a la base de datos reduce la carga del motor MySQL a casi cero y acelera el Time to First Byte (TTFB).</p>`,
      featuredImage: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=80",
      seoTitle: "Optimización y Rendimiento Extremo en Servidores Linux",
      seoDescription: "Guía avanzada de sysadmin para acelerar servidores Linux, Nginx, Redis y caché HTTP.",
      focusKeyword: "rendimiento servidor linux nginx",
      seoScore: 90,
      status: "Publicado",
      tags: "Linux, Nginx, Redis, Optimización, Sysadmin",
      categoryId: catMap.get("optimizacion") || null,
      authorId: admin.id,
    },
  ];

  for (const art of realArticles) {
    const post = await prisma.post.upsert({
      where: { slug: art.slug },
      update: { ...art },
      create: { ...art },
    });
    console.log(`✅ Post guardado en MySQL: "${post.title}" (ID: ${post.id})`);
  }
}

main()
  .catch((err) => {
    console.error("Error al poblar artículos:", err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
