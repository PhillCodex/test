import { PrismaClient, Role } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const email = "cesar@ingcesarco.com";
  const plainPassword = "@cesar12345";
  const hashedPassword = await bcrypt.hash(plainPassword, 10);

  console.log(`Buscando o actualizando usuario: ${email}...`);

  const user = await prisma.user.upsert({
    where: { email },
    update: {
      password: hashedPassword,
      role: Role.ADMIN,
    },
    create: {
      email,
      name: "César",
      lastName: "Admin",
      password: hashedPassword,
      role: Role.ADMIN,
    },
  });

  console.log(" Usuario actualizado con éxito:");
  console.log({
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
  });

  // Mostrar todos los usuarios administradores en la BD
  const allAdmins = await prisma.user.findMany({
    where: { role: Role.ADMIN },
    select: { id: true, email: true, name: true, role: true },
  });
  console.log("Usuarios Administradores en la base de datos:", allAdmins);
}

main()
  .catch((e) => {
    console.error("❌ Error actualizando la contraseña:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
