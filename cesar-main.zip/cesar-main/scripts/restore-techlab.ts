import { prisma } from "../lib/prisma";

async function main() {
  const s = await prisma.siteSetting.upsert({
    where: { id: "general" },
    update: {
      siteTitle: "TechLab",
      siteDescription:
        "Laboratorio de innovación tecnológica, desarrollo de software a medida, aplicaciones web y servicios en la nube de alta disponibilidad.",
      slogan: "Tecnología que impulsa tu mundo.",
      seoHomeTitle: "%sitename% - Innovación y Desarrollo Web",
      seoTwitterHandle: "@techlab",
      whatsappMessage: "Hola! Deseo cotizar un proyecto tecnológico con TechLab.",
    },
    create: {
      id: "general",
      siteTitle: "TechLab",
      siteDescription:
        "Laboratorio de innovación tecnológica, desarrollo de software a medida, aplicaciones web y servicios en la nube de alta disponibilidad.",
      slogan: "Tecnología que impulsa tu mundo.",
      seoHomeTitle: "%sitename% - Innovación y Desarrollo Web",
      seoTwitterHandle: "@techlab",
      whatsappMessage: "Hola! Deseo cotizar un proyecto tecnológico con TechLab.",
    },
  });

  console.log("✅ SiteSettings restored to TechLab in MySQL RDS:");
  console.log("   siteTitle:", s.siteTitle);
  console.log("   slogan:", s.slogan);
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
