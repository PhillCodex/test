import { prisma } from "../lib/prisma";

async function main() {
  const cat = await prisma.category.findFirst({ where: { slug: "seguridad" } });
  const admin = await prisma.user.findFirst({ where: { role: "ADMIN" } });

  if (cat && admin) {
    const post = await prisma.post.upsert({
      where: { slug: "guia-seguridad-wordpress-2026" },
      update: {},
      create: {
        title: "Guía de Seguridad para WordPress en 2026",
        slug: "guia-seguridad-wordpress-2026",
        excerpt: "Aprende las mejores prácticas de ciberseguridad para proteger tu WordPress contra amenazas.",
        content: "<p>Contenido de seguridad avanzado y optimizado para SEO...</p>",
        status: "Publicado",
        seoScore: 92,
        categoryId: cat.id,
        authorId: admin.id,
        tags: "#WordPress,#Seguridad",
      },
      include: {
        category: true,
        author: true,
      },
    });

    console.log("==========================================");
    console.log("POST CREADO EN MYSQL RDS (AWS):");
    console.log("Título:", post.title);
    console.log("Categoría vinculada:", post.category?.name);
    console.log("Autor:", post.author?.name);
    console.log("==========================================");
  }

  const allPosts = await prisma.post.findMany({
    include: { category: true },
  });
  console.log("TOTAL POSTS EN MYSQL RDS:", allPosts.length);
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
