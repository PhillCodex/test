// ============================================================================
// ELEMENTOR RENDERER ENGINE (TechLab Pro)
// Renderiza el árbol JSON o HTML de Elementor en páginas públicas y canvas
// ============================================================================

export interface ElementorWidget {
  id: string;
  type: string;
  title?: string;
  settings?: Record<string, any>;
}

export interface ElementorColumn {
  id: string;
  width?: string;
  widgets: ElementorWidget[];
}

export interface ElementorContainer {
  id: string;
  layoutType?: "flexbox" | "grid";
  direction?: "row" | "column";
  structurePreset?: number | string;
  columns: ElementorColumn[];
  styles?: {
    paddingTop?: number;
    paddingBottom?: number;
    paddingLeft?: number;
    paddingRight?: number;
    gap?: number;
    backgroundColor?: string;
    borderRadius?: number;
    justifyContent?: string;
  };
}

export function renderElementorContent(content: string | null | undefined): string {
  if (!content) return "";
  const trimmed = content.trim();

  // 1. Si es un JSON array de contenedores
  if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].id) {
        return renderContainersToHtml(parsed);
      }
    } catch {
      // Ignorar si no es JSON válido
    }
  }

  // 2. Si contiene el bloque de datos serializado <!-- ELEMENTOR_DATA_START -->
  if (trimmed.includes("<!-- ELEMENTOR_DATA_START -->")) {
    const htmlPart = trimmed.split("<!-- ELEMENTOR_DATA_START -->")[0].trim();
    if (htmlPart && htmlPart.length > 20) {
      return htmlPart;
    }
    // Si la parte HTML está vacía, regenerar desde el JSON comentado
    const match = trimmed.match(/<!-- ELEMENTOR_DATA_START -->([\s\S]*?)<!-- ELEMENTOR_DATA_END -->/);
    if (match && match[1]) {
      try {
        const parsed = JSON.parse(match[1]);
        if (Array.isArray(parsed)) {
          return renderContainersToHtml(parsed);
        }
      } catch {
        // Fallback
      }
    }
  }

  // 3. Contenido HTML estándar
  return content;
}

export function renderContainersToHtml(containers: ElementorContainer[]): string {
  if (!containers || containers.length === 0) return "";
  let html = `<div class="elementor-rendered-root" style="font-family: inherit; color: #cbd5e1; width: 100%;">`;

  containers.forEach((cont) => {
    const isRow = cont.direction === "row";
    const st = cont.styles || {};
    const contStyles = `display: flex; flex-direction: ${cont.direction || "column"}; flex-wrap: wrap; gap: ${st.gap ?? 20}px; padding: ${st.paddingTop ?? 30}px ${st.paddingRight ?? 20}px ${st.paddingBottom ?? 30}px ${st.paddingLeft ?? 20}px; background-color: ${st.backgroundColor || "transparent"}; border-radius: ${st.borderRadius ?? 0}px; justify-content: ${st.justifyContent || "flex-start"};`.replace(/\s+/g, " ");

    html += `<div class="elementor-container-block" style="${contStyles}">`;
    (cont.columns || []).forEach((col) => {
      const colWidth = col.width || (isRow ? `${100 / (cont.columns?.length || 1)}%` : "100%");
      html += `<div class="elementor-col-block" style="flex: 1 1 ${colWidth}; max-width: ${colWidth}; display: flex; flex-direction: column; gap: 16px;">`;
      (col.widgets || []).forEach((wid) => {
        html += renderSingleWidget(wid);
      });
      html += `</div>`;
    });
    html += `</div>`;
  });

  html += `</div>`;
  return html;
}

export function renderSingleWidget(wid: ElementorWidget): string {
  const s = wid.settings || {};

  switch (wid.type) {
    case "heading": {
      const align = s.align || "left";
      const tag = s.tag || "h2";
      const color = s.textColor || "#ffffff";
      const size = s.fontSize || 32;
      const weight = s.fontWeight || "800";
      const transform = s.textTransform || "none";
      const spacing = s.letterSpacing ? `${s.letterSpacing}px` : "normal";
      const mTop = s.marginTop ?? 0;
      const mBottom = s.marginBottom ?? 12;
      const pTop = s.paddingTop ?? 0;
      const pBottom = s.paddingBottom ?? 0;
      const barMargin = align === "center" ? "6px auto 0" : (align === "right" ? "6px 0 0 auto" : "6px 0 0 0");

      let innerTitle = `<${tag} style="color: ${color}; font-size: ${size}px; font-weight: ${weight}; text-transform: ${transform}; letter-spacing: ${spacing}; line-height: 1.25; margin: 0;">${s.title || "Tu Encabezado Principal"}</${tag}>`;
      if (s.linkUrl) {
        innerTitle = `<a href="${s.linkUrl}" style="text-decoration: none; color: inherit; display: inline-block;">${innerTitle}</a>`;
      }

      return `
        <div class="elementor-heading-widget" style="text-align: ${align}; margin-top: ${mTop}px; margin-bottom: ${mBottom}px; padding-top: ${pTop}px; padding-bottom: ${pBottom}px; width: 100%;">
          ${innerTitle}
          ${s.hasAccentBar ? `<div style="width: 44px; height: 3px; background: #16c96f; border-radius: 2px; margin: ${barMargin};"></div>` : ""}
        </div>
      `;
    }

    case "text": {
      const align = s.align || "left";
      const color = s.textColor || "#94a3b8";
      const size = s.fontSize || 16;
      const weight = s.fontWeight || "400";
      const transform = s.textTransform || "none";
      const mTop = s.marginTop ?? 0;
      const mBottom = s.marginBottom ?? 12;
      const pTop = s.paddingTop ?? 0;
      const pBottom = s.paddingBottom ?? 0;
      return `
        <div class="elementor-text-widget" style="text-align: ${align}; font-size: ${size}px; font-weight: ${weight}; text-transform: ${transform}; line-height: 1.8; color: ${color}; margin-top: ${mTop}px; margin-bottom: ${mBottom}px; padding-top: ${pTop}px; padding-bottom: ${pBottom}px; width: 100%;">
          ${s.content || "<p>Escribe tu contenido aquí con texto enriquecido.</p>"}
        </div>
      `;
    }

    case "image": {
      const align = s.align || "center";
      const width = s.width || "100%";
      const radius = s.borderRadius ?? 8;
      const mTop = s.marginTop ?? 12;
      const mBottom = s.marginBottom ?? 12;
      const imgTag = `<img src="${s.imageUrl || "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=80"}" alt="${s.imageAlt || ""}" style="max-width: ${width}; width: 100%; border-radius: ${radius}px; box-shadow: 0 10px 30px rgba(0,0,0,0.5); display: inline-block;" />`;
      return `
        <div class="elementor-image-widget" style="text-align: ${align}; margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%;">
          ${s.linkUrl ? `<a href="${s.linkUrl}" style="display: inline-block; max-width: ${width}; width: 100%;">${imgTag}</a>` : imgTag}
        </div>
      `;
    }

    case "button": {
      const align = s.buttonAlign || "left";
      const mTop = s.marginTop ?? 14;
      const mBottom = s.marginBottom ?? 14;
      const radius = s.buttonRadius ?? 8;
      const isFull = align === "justify";
      const btnAlignStyle = isFull ? "width: 100%;" : (align === "center" ? "margin: 0 auto;" : (align === "right" ? "margin-left: auto;" : "margin-right: auto;"));

      let bgGradient = "linear-gradient(110deg, #16c96f, #38bdf8)";
      let textColor = "#000000";
      let borderStyle = "none";

      if (s.buttonVariant === "outline") {
        bgGradient = "transparent";
        textColor = "#16c96f";
        borderStyle = "1px solid #16c96f";
      } else if (s.buttonVariant === "dark") {
        bgGradient = "#1e293b";
        textColor = "#ffffff";
        borderStyle = "1px solid rgba(255,255,255,0.15)";
      }

      let padding = "12px 24px";
      let fontSize = "14px";
      if (s.buttonSize === "small") {
        padding = "8px 16px";
        fontSize = "12px";
      } else if (s.buttonSize === "large") {
        padding = "16px 32px";
        fontSize = "16px";
      }

      return `
        <div class="elementor-button-widget" style="text-align: ${isFull ? "center" : align}; margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%;">
          <a href="${s.buttonLink || "#"}" style="display: ${isFull ? "flex" : "inline-flex"}; justify-content: center; align-items: center; gap: 8px; padding: ${padding}; background: ${bgGradient}; color: ${textColor}; font-weight: 800; font-size: ${fontSize}; border-radius: ${radius}px; border: ${borderStyle}; text-decoration: none; box-shadow: 0 4px 14px rgba(22,201,111,0.3); ${btnAlignStyle}">
            ${s.buttonText || "Comenzar Ahora"} →
          </a>
        </div>
      `;
    }

    case "youtube":
    case "video": {
      const align = s.align || "center";
      const maxWidth = s.maxWidth || "100%";
      return `
        <div style="text-align: ${align}; width: 100%; margin: 16px 0;">
          <div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; border-radius: 12px; max-width: ${maxWidth}; margin: 0 auto; border: 1px solid rgba(255,255,255,0.1);">
            <iframe src="${s.videoUrl || "https://www.youtube.com/embed/dQw4w9WgXcQ"}" style="position: absolute; top:0; left: 0; width: 100%; height: 100%; border:0;" allowfullscreen></iframe>
          </div>
        </div>
      `;
    }

    case "separator": {
      const align = s.align || "center";
      const width = s.width || "100%";
      const thickness = s.thickness || 1;
      const color = s.color || "rgba(255,255,255,0.12)";
      const margin = s.margin ?? 24;
      const alignMargin = align === "center" ? "0 auto" : (align === "right" ? "0 0 0 auto" : "0 auto 0 0");
      return `
        <div style="width: 100%; padding: ${margin}px 0;">
          <hr style="border: none; border-top: ${thickness}px solid ${color}; width: ${width}; margin: ${alignMargin};" />
        </div>
      `;
    }

    case "hero": {
      const align = s.align || "center";
      const justify = align === "center" ? "center" : (align === "right" ? "flex-end" : "flex-start");
      return `
        <div style="width: 100%; text-align: ${align}; padding: 50px 20px; background: radial-gradient(circle at center, rgba(22,201,111,0.15), rgba(7,21,34,0.8) 70%); border: 1px solid rgba(56,189,248,0.15); border-radius: 12px; box-shadow: 0 10px 40px rgba(0,0,0,0.5); margin: 12px 0;">
          <div style="display: inline-flex; align-items: center; gap: 6px; padding: 4px 12px; background: rgba(22,201,111,0.12); border: 1px solid rgba(22,201,111,0.3); border-radius: 20px; color: #16c96f; font-size: 11px; font-weight: 700; margin-bottom: 16px; text-transform: uppercase; letter-spacing: 0.5px;">
            ${s.badge || "✨ TECNOLOGÍA & INNOVACIÓN"}
          </div>
          <h1 style="font-size: 38px; font-weight: 900; color: #ffffff; line-height: 1.2; margin: 0 0 14px; letter-spacing: -0.5px;">
            ${s.heroTitle || "Transforma tu Futuro Digital"}
          </h1>
          <p style="font-size: 16px; line-height: 1.7; color: #94a3b8; max-width: 650px; ${align === "center" ? "margin: 0 auto 24px;" : "margin: 0 0 24px;"}">
            ${s.heroSubtitle || "Soluciones a medida construidas con tecnología de última generación para máxima escalabilidad y rendimiento."}
          </p>
          <div style="display: flex; align-items: center; justify-content: ${justify}; gap: 12px; flex-wrap: wrap;">
            <a href="${s.primaryBtnLink || "#"}" style="display: inline-flex; align-items: center; gap: 8px; padding: 12px 24px; background: linear-gradient(110deg, #16c96f, #38bdf8); color: #000000; font-weight: 800; font-size: 14px; border-radius: 8px; text-decoration: none;">
              ${s.primaryBtnText || "Ver Servicios →"}
            </a>
            ${s.secondaryBtnText ? `
              <a href="${s.secondaryBtnLink || "#"}" style="display: inline-flex; align-items: center; gap: 8px; padding: 12px 24px; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.15); color: #ffffff; font-weight: 700; font-size: 14px; border-radius: 8px; text-decoration: none;">
                ${s.secondaryBtnText}
              </a>
            ` : ""}
          </div>
        </div>
      `;
    }

    case "services": {
      const items = s.items || [
        { icon: "⚡", title: "Desarrollo Web Next.js", desc: "Aplicaciones ultrarrápidas con Server Components y bases de datos escalables.", link: "/servicios" },
        { icon: "🛡️", title: "Ciberseguridad & Cloud", desc: "Auditorías de seguridad, protección de datos y configuración en la nube.", link: "/servicios" },
        { icon: "🤖", title: "Automatización & IA", desc: "Integración de modelos inteligentes y optimización de flujos de trabajo.", link: "/servicios" },
      ];
      return `
        <div style="width: 100%; padding: 16px 0; margin: 12px 0;">
          <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 20px; border-bottom: 1px solid rgba(255,255,255,0.06); padding-bottom: 12px;">
            <div>
              <h3 style="font-size: 19px; font-weight: 800; color: #ffffff; text-transform: uppercase; letter-spacing: 0.5px; margin: 0 0 6px;">
                ${s.sectionTitle || "SERVICIOS DESTACADOS"}
              </h3>
              <div style="width: 44px; height: 3px; background: #16c96f; border-radius: 2px;"></div>
            </div>
            ${s.linkText ? `<a href="${s.linkUrl || "#"}" style="font-size: 13px; font-weight: 600; color: #94a3b8; text-decoration: none;">${s.linkText} →</a>` : ""}
          </div>

          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 16px;">
            ${items.map((item: any) => `
              <div style="background: #040e1a; border: 1px solid rgba(56, 189, 248, 0.15); border-radius: 10px; padding: 22px; display: flex; flex-direction: column; justify-content: space-between; gap: 14px; box-shadow: 0 8px 24px rgba(0,0,0,0.4);">
                <div>
                  <div style="display: inline-flex; align-items: center; justify-content: center; width: 42px; height: 42px; background: rgba(22, 201, 111, 0.15); border: 1px solid rgba(22, 201, 111, 0.3); border-radius: 8px; color: #16c96f; margin-bottom: 14px; font-size: 20px;">
                    ${item.icon || "⚡"}
                  </div>
                  <h4 style="font-size: 16px; font-weight: 700; color: #ffffff; margin: 0 0 8px;">${item.title}</h4>
                  <p style="font-size: 13px; line-height: 1.6; color: #94a3b8; margin: 0;">${item.desc}</p>
                </div>
                <a href="${item.link || "#"}" style="font-size: 12px; font-weight: 700; color: #16c96f; text-decoration: none;">Saber más →</a>
              </div>
            `).join("")}
          </div>
        </div>
      `;
    }

    case "testimonials": {
      const items = s.items || [
        { quote: "Increíble nivel de desarrollo y soporte. Superó todas las expectativas.", name: "Carlos Mendoza", role: "CEO @ InnoTech", initials: "CM" },
        { quote: "La plataforma es ultrarrápida y el diseño es moderno y profesional.", name: "Laura Sánchez", role: "Directora @ Apex Media", initials: "LS" },
      ];
      return `
        <div style="width: 100%; padding: 16px 0; margin: 12px 0;">
          <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 20px; border-bottom: 1px solid rgba(255,255,255,0.06); padding-bottom: 12px;">
            <div>
              <h3 style="font-size: 19px; font-weight: 800; color: #ffffff; text-transform: uppercase; letter-spacing: 0.5px; margin: 0 0 6px;">
                ${s.sectionTitle || "LO QUE DICEN MIS CLIENTES"}
              </h3>
              <div style="width: 44px; height: 3px; background: #16c96f; border-radius: 2px;"></div>
            </div>
            ${s.linkText ? `<a href="${s.linkUrl || "#"}" style="font-size: 13px; font-weight: 600; color: #94a3b8; text-decoration: none;">${s.linkText} →</a>` : ""}
          </div>

          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); gap: 16px;">
            ${items.map((item: any) => `
              <div style="background: #040e1a; border: 1px solid rgba(56, 189, 248, 0.15); border-radius: 10px; padding: 20px; display: flex; flex-direction: column; justify-content: space-between; gap: 16px; box-shadow: 0 8px 24px rgba(0,0,0,0.4);">
                <p style="font-size: 13px; line-height: 1.6; color: #e2e8f0; margin: 0; font-weight: 400;">
                  "${item.quote}"
                </p>
                <div>
                  <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                    <div style="width: 36px; height: 36px; border-radius: 50%; background: #10b981; color: #022c22; font-weight: 800; font-size: 13px; display: grid; place-items: center;">
                      ${item.initials || "CL"}
                    </div>
                    <div>
                      <div style="font-size: 13px; font-weight: 700; color: #ffffff; line-height: 1.2;">${item.name}</div>
                      <div style="font-size: 11px; color: #94a3b8; margin-top: 2px;">${item.role}</div>
                    </div>
                  </div>
                  <div style="color: #10b981; font-size: 12px; letter-spacing: 2px;">★★★★★</div>
                </div>
              </div>
            `).join("")}
          </div>
        </div>
      `;
    }

    case "articles": {
      const items = s.items || [
        { category: "TECNOLOGÍA", date: "24 AGO 2026", title: "Arquitectura moderna con Next.js 15", excerpt: "Aprende las mejores prácticas para construir plataformas web ultrarrápidas y optimizadas." },
        { category: "BASE DE DATOS", date: "20 AGO 2026", title: "Optimización de consultas y caché en MySQL", excerpt: "Guía completa de indexación y particionado para soportar millones de visitas." },
      ];
      return `
        <div style="width: 100%; padding: 16px 0; margin: 12px 0;">
          <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 20px; border-bottom: 1px solid rgba(255,255,255,0.06); padding-bottom: 12px;">
            <div>
              <h3 style="font-size: 19px; font-weight: 800; color: #ffffff; text-transform: uppercase; letter-spacing: 0.5px; margin: 0 0 6px;">
                ${s.sectionTitle || "ARTÍCULOS Y RECURSOS"}
              </h3>
              <div style="width: 44px; height: 3px; background: #16c96f; border-radius: 2px;"></div>
            </div>
            ${s.linkText ? `<a href="${s.linkUrl || "#"}" style="font-size: 13px; font-weight: 600; color: #94a3b8; text-decoration: none;">${s.linkText} →</a>` : ""}
          </div>

          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 16px;">
            ${items.map((item: any) => `
              <div style="background: #040e1a; border: 1px solid rgba(255,255,255,0.08); border-radius: 10px; overflow: hidden; display: flex; flex-direction: column; box-shadow: 0 8px 24px rgba(0,0,0,0.4);">
                <div style="height: 120px; background: linear-gradient(135deg, #071524, #0f2742); position: relative; padding: 12px; display: flex; align-items: flex-start;">
                  <span style="background: rgba(22, 201, 111, 0.2); color: #16c96f; border: 1px solid rgba(22, 201, 111, 0.4); font-size: 10px; font-weight: 800; padding: 3px 8px; border-radius: 4px; text-transform: uppercase;">
                    ${item.category}
                  </span>
                </div>
                <div style="padding: 18px; display: flex; flex-direction: column; justify-content: space-between; flex: 1; gap: 10px;">
                  <div>
                    <span style="font-size: 11px; color: #64748b; font-weight: 600;">${item.date}</span>
                    <h4 style="font-size: 15px; font-weight: 700; color: #ffffff; margin: 6px 0 8px; line-height: 1.4;">${item.title}</h4>
                    <p style="font-size: 12px; line-height: 1.5; color: #94a3b8; margin: 0;">${item.excerpt}</p>
                  </div>
                  <a href="#" style="font-size: 12px; font-weight: 700; color: #38bdf8; text-decoration: none;">Leer artículo →</a>
                </div>
              </div>
            `).join("")}
          </div>
        </div>
      `;
    }

    case "gallery": {
      const items = s.items || [
        { title: "Plataforma E-Commerce Tech", category: "TIENDA ONLINE", image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=600&q=80" },
        { title: "Dashboard de Métricas SaaS", category: "WEB APPLICATION", image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=600&q=80" },
      ];
      return `
        <div style="width: 100%; padding: 16px 0; margin: 12px 0;">
          <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 20px; border-bottom: 1px solid rgba(255,255,255,0.06); padding-bottom: 12px;">
            <div>
              <h3 style="font-size: 19px; font-weight: 800; color: #ffffff; text-transform: uppercase; letter-spacing: 0.5px; margin: 0 0 6px;">
                ${s.sectionTitle || "GALERÍA DE PROYECTOS"}
              </h3>
              <div style="width: 44px; height: 3px; background: #16c96f; border-radius: 2px;"></div>
            </div>
            ${s.linkText ? `<a href="${s.linkUrl || "#"}" style="font-size: 13px; font-weight: 600; color: #94a3b8; text-decoration: none;">${s.linkText} →</a>` : ""}
          </div>

          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 16px;">
            ${items.map((item: any) => `
              <div style="position: relative; border-radius: 10px; overflow: hidden; height: 180px; border: 1px solid rgba(56,189,248,0.2); box-shadow: 0 8px 24px rgba(0,0,0,0.4);">
                <img src="${item.image}" alt="${item.title}" style="width: 100%; height: 100%; object-fit: cover;" />
                <div style="position: absolute; inset: 0; background: linear-gradient(to top, rgba(2,11,20,0.95), transparent 60%); display: flex; flex-direction: column; justify-content: flex-end; padding: 14px;">
                  <span style="font-size: 10px; font-weight: 700; color: #16c96f; text-transform: uppercase;">${item.category}</span>
                  <h4 style="font-size: 14px; font-weight: 700; color: #ffffff; margin: 2px 0 0;">${item.title}</h4>
                </div>
              </div>
            `).join("")}
          </div>
        </div>
      `;
    }

    default:
      return `<div style="padding: 12px; border: 1px dashed #475569; color: #94a3b8; border-radius: 6px;">Widget ${wid.type}</div>`;
  }
}
