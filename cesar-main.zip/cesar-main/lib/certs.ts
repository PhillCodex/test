import fs from "fs";
import path from "path";
import os from "os";

// Lee el bundle de certificados de AWS RDS
export function getCertificatePath(): string {
  const cwd = process.cwd();
  const candidates = [
    path.join(cwd, "certs", "global-bundle.pem"),
    path.join(cwd, "prisma", "certs", "global-bundle.pem"),
    path.resolve("certs", "global-bundle.pem"),
    path.resolve("prisma", "certs", "global-bundle.pem"),
  ];

  for (const p of candidates) {
    try {
      if (fs.existsSync(p)) {
        return p.replace(/\\/g, "/");
      }
    } catch {}
  }

  // Fallback para entornos Serverless como Vercel Lambda:
  // Si no está en el filesystem relativo, buscar en tmp o crearlo si existe copia local
  const tmpPath = path.join(os.tmpdir(), "global-bundle.pem");
  if (fs.existsSync(tmpPath)) {
    return tmpPath.replace(/\\/g, "/");
  }

  return candidates[0].replace(/\\/g, "/");
}
