import { PrismaClient } from "@prisma/client";
import { getCertificatePath } from "./certs";

function resolveDatabaseUrl(): string | undefined {
  let url = process.env.DATABASE_URL;
  if (!url) return undefined;

  // Si la URL contiene comillas accidentales en variables de entorno, eliminarlas
  url = url.replace(/^["']|["']$/g, "").trim();

  // Si la URL usa sslcert, resolver la ruta absoluta al certificado
  if (url.includes("sslcert=")) {
    const certPath = getCertificatePath();
    url = url.replace(/sslcert=[^&]+/, `sslcert=${certPath}`);
  }

  // Optimización estricta para Serverless / Vercel:
  // Reemplazar o forzar connection_limit=1 para evitar ERROR 1040 (Too many connections)
  url = url.replace(/([?&])connection_limit=\d+/g, "");
  url = url.replace(/([?&])pool_timeout=\d+/g, "");
  url = url.replace(/([?&])connect_timeout=\d+/g, "");

  const separator = url.includes("?") ? "&" : "?";
  url = `${url}${separator}connection_limit=1&pool_timeout=5&connect_timeout=5`;

  return url;
}

const resolvedUrl = resolveDatabaseUrl();

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    ...(resolvedUrl
      ? {
          datasources: {
            db: {
              url: resolvedUrl,
            },
          },
        }
      : {}),
    log: ["error"],
  });

// Mantener la instancia singleton activa en todos los entornos (incluido producción / serverless)
globalForPrisma.prisma = prisma;

