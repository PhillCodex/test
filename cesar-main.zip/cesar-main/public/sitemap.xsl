<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="2.0"
  xmlns:html="http://www.w3.org/TR/REC-html40"
  xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"
  xmlns:sitemap="http://www.sitemaps.org/schemas/sitemap/0.9"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:output method="html" version="1.0" encoding="UTF-8" indent="yes"/>
  <xsl:template match="/">
    <html xmlns="http://www.w3.org/1999/xhtml" lang="es">
      <head>
        <title>Mapa del Sitio XML | XML Sitemap</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <style type="text/css">
          * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
          }
          body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
            color: #1e293b;
            background-color: #f8fafc;
            padding: 30px 20px;
            font-size: 14px;
            line-height: 1.6;
          }
          .container {
            max-width: 1080px;
            margin: 0 auto;
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 32px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.04);
          }
          .header {
            border-bottom: 1px solid #e2e8f0;
            padding-bottom: 20px;
            margin-bottom: 24px;
          }
          .badge-row {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: #e0f2fe;
            color: #0284c7;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
            margin-bottom: 12px;
            border: 1px solid #bae6fd;
          }
          h1 {
            font-size: 26px;
            font-weight: 800;
            color: #0f172a;
            margin-bottom: 8px;
          }
          p.desc {
            color: #64748b;
            font-size: 14px;
            margin-bottom: 12px;
          }
          p.desc a {
            color: #0284c7;
            text-decoration: none;
            font-weight: 600;
          }
          p.desc a:hover {
            text-decoration: underline;
          }
          .stats-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: #f1f5f9;
            padding: 12px 18px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            color: #334155;
            margin-bottom: 24px;
          }
          .stats-count {
            background: #10b981;
            color: #ffffff;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 700;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
          }
          th {
            background: #f8fafc;
            color: #475569;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            text-align: left;
            padding: 12px 14px;
            border-bottom: 2px solid #e2e8f0;
          }
          td {
            padding: 14px;
            border-bottom: 1px solid #f1f5f9;
            color: #334155;
            vertical-align: middle;
          }
          tr:hover td {
            background: #f8fafc;
          }
          a.loc-link {
            color: #0284c7;
            text-decoration: none;
            font-weight: 600;
            word-break: break-all;
          }
          a.loc-link:hover {
            color: #0369a1;
            text-decoration: underline;
          }
          .badge-type {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 700;
            background: #f1f5f9;
            color: #475569;
          }
          .badge-priority {
            display: inline-block;
            padding: 2px 7px;
            border-radius: 10px;
            font-size: 11px;
            font-weight: 700;
            background: #dcfce7;
            color: #15803d;
          }
          .footer {
            margin-top: 30px;
            padding-top: 16px;
            border-top: 1px solid #e2e8f0;
            text-align: center;
            font-size: 12px;
            color: #94a3b8;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="badge-row">
              <span>XML SITEMAP ENGINE</span>
            </div>
            <h1>Mapa del Sitio XML</h1>
            <p class="desc">
              Este mapa del sitio XML ha sido generado automáticamente para indexación en motores de búsqueda (Google, Bing, Yahoo). Más información en <a href="https://www.sitemaps.org" target="_blank" rel="noopener noreferrer">sitemaps.org</a>.
            </p>
          </div>

          <xsl:if test="count(sitemap:sitemapindex/sitemap:sitemap) &gt; 0">
            <div class="stats-bar">
              <span>Índice Principal de Sitemaps</span>
              <span class="stats-count"><xsl:value-of select="count(sitemap:sitemapindex/sitemap:sitemap)"/> sitemaps</span>
            </div>
            <table>
              <thead>
                <tr>
                  <th style="width: 70%;">Mapa del Sitio (Sitemap URL)</th>
                  <th style="width: 30%;">Última Modificación</th>
                </tr>
              </thead>
              <tbody>
                <xsl:for-each select="sitemap:sitemapindex/sitemap:sitemap">
                  <tr>
                    <td>
                      <a class="loc-link">
                        <xsl:attribute name="href">
                          <xsl:value-of select="sitemap:loc"/>
                        </xsl:attribute>
                        <xsl:value-of select="sitemap:loc"/>
                      </a>
                    </td>
                    <td>
                      <xsl:value-of select="concat(substring(sitemap:lastmod,0,11),concat(' ', substring(sitemap:lastmod,12,5)))"/>
                    </td>
                  </tr>
                </xsl:for-each>
              </tbody>
            </table>
          </xsl:if>

          <xsl:if test="count(sitemap:urlset/sitemap:url) &gt; 0">
            <div class="stats-bar">
              <span>Listado de URLs</span>
              <span class="stats-count"><xsl:value-of select="count(sitemap:urlset/sitemap:url)"/> páginas</span>
            </div>
            <table>
              <thead>
                <tr>
                  <th style="width: 60%;">URL</th>
                  <th style="width: 15%;">Prioridad</th>
                  <th style="width: 25%;">Última Modificación</th>
                </tr>
              </thead>
              <tbody>
                <xsl:for-each select="sitemap:urlset/sitemap:url">
                  <tr>
                    <td>
                      <a class="loc-link">
                        <xsl:attribute name="href">
                          <xsl:value-of select="sitemap:loc"/>
                        </xsl:attribute>
                        <xsl:value-of select="sitemap:loc"/>
                      </a>
                    </td>
                    <td>
                      <xsl:if test="sitemap:priority">
                        <span class="badge-priority"><xsl:value-of select="sitemap:priority"/></span>
                      </xsl:if>
                      <xsl:if test="not(sitemap:priority)">
                        <span style="color: #94a3b8;">-</span>
                      </xsl:if>
                    </td>
                    <td>
                      <xsl:value-of select="concat(substring(sitemap:lastmod,0,11),concat(' ', substring(sitemap:lastmod,12,5)))"/>
                    </td>
                  </tr>
                </xsl:for-each>
              </tbody>
            </table>
          </xsl:if>

          <div class="footer">
            Generado automáticamente por el motor web de <strong>Ing. Cesar Fuentes</strong>
          </div>
        </div>
      </body>
    </html>
  </xsl:template>
</xsl:stylesheet>
