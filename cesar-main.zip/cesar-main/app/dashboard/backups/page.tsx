"use client";

import { useState, useEffect, useRef } from "react";
import {
  DatabaseBackup,
  HardDriveDownload,
  UploadCloud,
  RotateCcw,
  Trash2,
  Download,
  Clock,
  CheckCircle2,
  AlertTriangle,
  FileCheck,
  Layers,
  Settings,
  HardDrive,
  Database,
  Image as ImageIcon,
  ShieldCheck,
  Calendar,
  Mail,
  Cloud,
  Server,
  RefreshCw,
  Search,
  Check,
  X,
  Loader2,
  Info,
  FileText,
  AlertCircle,
  FolderArchive,
  ArrowDownToLine,
  Sliders,
  Sparkles,
} from "lucide-react";

interface BackupItem {
  id: string;
  filename: string;
  type: "full" | "database" | "media";
  size: number;
  formattedSize: string;
  createdAt: string;
  tablesCount: number;
  note?: string;
  creator: string;
  status: string;
}

interface BackupConfig {
  autoBackupEnabled: boolean;
  frequency: "hourly" | "daily" | "weekly" | "monthly";
  executionTime: string;
  executionDay: string;
  executionDayOfMonth: number;
  includeDatabase: boolean;
  includeMedia: boolean;
  includeConfig: boolean;
  retentionLimit: number;
  storageLocation: "local" | "gdrive" | "s3" | "email";
  notificationEmail: string;
  notifyOnSuccess: boolean;
  notifyOnError: boolean;
}

interface StatsData {
  totalBackups: number;
  totalSizeBytes: number;
  formattedTotalSize: string;
  lastBackupDate: string | null;
  dbStatus: string;
  dbEntitiesTotal: number;
  uploadsCount: number;
  formattedUploadsSize: string;
}

export default function BackupsPage() {
  const [activeTab, setActiveTab] = useState<"basico" | "configuracion">("basico");
  const [loading, setLoading] = useState(true);
  const [backups, setBackups] = useState<BackupItem[]>([]);
  const [stats, setStats] = useState<StatsData>({
    totalBackups: 0,
    totalSizeBytes: 0,
    formattedTotalSize: "0 Bytes",
    lastBackupDate: null,
    dbStatus: "connected",
    dbEntitiesTotal: 0,
    uploadsCount: 0,
    formattedUploadsSize: "0 Bytes",
  });
  const [searchQuery, setSearchQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState<"all" | "full" | "database" | "media">("all");
  const [toast, setToast] = useState<{ message: string; type: "success" | "error" | "info" } | null>(null);

  // Modales
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [createType, setCreateType] = useState<"full" | "database" | "media">("full");
  const [createNote, setCreateNote] = useState("");
  const [isCreating, setIsCreating] = useState(false);

  const [showUploadModal, setShowUploadModal] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadDragOver, setUploadDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [showRestoreModal, setShowRestoreModal] = useState(false);
  const [selectedBackupToRestore, setSelectedBackupToRestore] = useState<BackupItem | null>(null);
  const [confirmRisk, setConfirmRisk] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);

  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedBackupToDelete, setSelectedBackupToDelete] = useState<BackupItem | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Formulario de Configuración Automática
  const [config, setConfig] = useState<BackupConfig>({
    autoBackupEnabled: true,
    frequency: "daily",
    executionTime: "03:00",
    executionDay: "sunday",
    executionDayOfMonth: 1,
    includeDatabase: true,
    includeMedia: true,
    includeConfig: true,
    retentionLimit: 10,
    storageLocation: "local",
    notificationEmail: "admin@techlab.com",
    notifyOnSuccess: true,
    notifyOnError: true,
  });
  const [isSavingConfig, setIsSavingConfig] = useState(false);

  const showNotification = (message: string, type: "success" | "error" | "info" = "success") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  // Cargar datos del servidor
  const fetchBackups = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/backups");
      const data = await res.json();
      if (data.success) {
        setBackups(data.backups || []);
        if (data.stats) setStats(data.stats);
        if (data.config) setConfig(data.config);
      } else {
        showNotification(data.error || "Error al cargar copias de seguridad.", "error");
      }
    } catch (e) {
      showNotification("Error de conexión al obtener backups.", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBackups();
  }, []);

  // Crear Copia de Seguridad Manual
  const handleCreateBackup = async () => {
    setIsCreating(true);
    try {
      const res = await fetch("/api/backups", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "create",
          type: createType,
          note: createNote.trim(),
        }),
      });
      const data = await res.json();
      if (data.success) {
        showNotification("¡Copia de seguridad generada con éxito!", "success");
        setShowCreateModal(false);
        setCreateNote("");
        fetchBackups();
      } else {
        showNotification(data.error || "Error al crear copia de seguridad.", "error");
      }
    } catch {
      showNotification("Error al procesar la creación del backup.", "error");
    } finally {
      setIsCreating(false);
    }
  };

  // Subir Archivo de Backup Externo
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processUploadFile(file);
  };

  const processUploadFile = (file: File) => {
    if (!file.name.endsWith(".json") && !file.name.endsWith(".sql") && !file.name.endsWith(".zip")) {
      showNotification("Formato no soportado. Sube un archivo .json, .sql o .zip.", "error");
      return;
    }

    setIsUploading(true);
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64String = (reader.result as string).split(",")[1] || (reader.result as string);
        const res = await fetch("/api/backups", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "upload",
            filename: file.name,
            contentBase64: base64String,
          }),
        });
        const data = await res.json();
        if (data.success) {
          showNotification("¡Archivo de copia de seguridad subido correctamente!", "success");
          setShowUploadModal(false);
          fetchBackups();
        } else {
          showNotification(data.error || "Error al subir el archivo.", "error");
        }
      } catch {
        showNotification("Error de red al subir la copia de seguridad.", "error");
      } finally {
        setIsUploading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  // Restaurar Copia de Seguridad
  const handleRestoreBackup = async () => {
    if (!selectedBackupToRestore || !confirmRisk) return;
    setIsRestoring(true);
    try {
      const res = await fetch("/api/backups", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "restore",
          filename: selectedBackupToRestore.filename,
        }),
      });
      const data = await res.json();
      if (data.success) {
        showNotification(data.message || "¡Restauración completada exitosamente!", "success");
        setShowRestoreModal(false);
        setConfirmRisk(false);
        setSelectedBackupToRestore(null);
        fetchBackups();
      } else {
        showNotification(data.error || "Error al restaurar los datos.", "error");
      }
    } catch {
      showNotification("Error crítico durante la restauración.", "error");
    } finally {
      setIsRestoring(false);
    }
  };

  // Eliminar Copia de Seguridad
  const handleDeleteBackup = async () => {
    if (!selectedBackupToDelete) return;
    setIsDeleting(true);
    try {
      const res = await fetch(`/api/backups?filename=${encodeURIComponent(selectedBackupToDelete.filename)}`, {
        method: "DELETE",
      });
      const data = await res.json();
      if (data.success) {
        showNotification("Copia de seguridad eliminada.", "success");
        setShowDeleteModal(false);
        setSelectedBackupToDelete(null);
        fetchBackups();
      } else {
        showNotification(data.error || "Error al eliminar backup.", "error");
      }
    } catch {
      showNotification("Error de conexión al eliminar archivo.", "error");
    } finally {
      setIsDeleting(false);
    }
  };

  // Guardar Configuración de Copias Automáticas
  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingConfig(true);
    try {
      const res = await fetch("/api/backups", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "save_config",
          config,
        }),
      });
      const data = await res.json();
      if (data.success) {
        showNotification("Configuración de copias de seguridad guardada correctamente.", "success");
      } else {
        showNotification(data.error || "Error al guardar la configuración.", "error");
      }
    } catch {
      showNotification("Error al conectar con el servidor.", "error");
    } finally {
      setIsSavingConfig(false);
    }
  };

  // Filtrado de backups
  const filteredBackups = backups.filter((b) => {
    const matchesSearch =
      b.filename.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (b.note && b.note.toLowerCase().includes(searchQuery.toLowerCase())) ||
      b.creator.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesType = typeFilter === "all" || b.type === typeFilter;

    return matchesSearch && matchesType;
  });

  return (
    <div className="backups-module-container">
      {/* Toast Notification */}
      {toast && (
        <div className={`techlab-toast ${toast.type}`}>
          {toast.type === "success" && <CheckCircle2 />}
          {toast.type === "error" && <AlertCircle />}
          {toast.type === "info" && <Info />}
          <span>{toast.message}</span>
        </div>
      )}

      {/* Header Principal del Módulo */}
      <div className="backups-header-area">
        <div className="header-titles">
          <div className="title-with-badge">
            <div className="header-icon-box">
              <DatabaseBackup />
            </div>
            <div>
              <h2>Copias de Seguridad & Restauración</h2>
              <p>Genera backups manuales, descarga archivos de recuperación y automatiza copias de seguridad de MySQL y Medios.</p>
            </div>
          </div>
        </div>

        {/* Pestañas: Básico | Configuración */}
        <div className="backups-tabs-nav">
          <button
            type="button"
            className={`tab-item-btn ${activeTab === "basico" ? "active" : ""}`}
            onClick={() => setActiveTab("basico")}
          >
            <Layers />
            <span>Básico</span>
            <span className="tab-pill-counter">{backups.length}</span>
          </button>
          <button
            type="button"
            className={`tab-item-btn ${activeTab === "configuracion" ? "active" : ""}`}
            onClick={() => setActiveTab("configuracion")}
          >
            <Sliders />
            <span>Configuración</span>
            {config.autoBackupEnabled && <span className="tab-pill-active-dot" title="Automático activo" />}
          </button>
        </div>
      </div>

      {/* =========================================================================
          PESTAÑA 1: BÁSICO (LISTADO, ACCIONES, DESCARGA Y RESTAURACIÓN)
          ========================================================================= */}
      {activeTab === "basico" && (
        <div className="tab-content-fade">
          {/* Métricas y Estado del Sistema */}
          <div className="backups-stats-grid">
            <div className="backup-stat-card">
              <div className="stat-icon-wrap cyan">
                <FolderArchive />
              </div>
              <div className="backup-stat-data">
                <span className="backup-stat-label">Total de Backups</span>
                <strong className="backup-stat-value">{stats.totalBackups}</strong>
                <small className="backup-stat-sub">Archivos en el servidor</small>
              </div>
            </div>

            <div className="backup-stat-card">
              <div className="stat-icon-wrap green">
                <HardDrive />
              </div>
              <div className="backup-stat-data">
                <span className="backup-stat-label">Espacio Ocupado</span>
                <strong className="backup-stat-value">{stats.formattedTotalSize}</strong>
                <small className="backup-stat-sub">Almacenamiento local</small>
              </div>
            </div>

            <div className="backup-stat-card">
              <div className="stat-icon-wrap purple">
                <Database />
              </div>
              <div className="backup-stat-data">
                <span className="backup-stat-label">Base de Datos</span>
                <strong className="backup-stat-value">
                  {stats.dbStatus === "connected" ? "MySQL Conectado" : "Desconectado"}
                </strong>
                <small className="backup-stat-sub">{stats.dbEntitiesTotal} registros auditados</small>
              </div>
            </div>

            <div className="backup-stat-card">
              <div className="stat-icon-wrap orange">
                <Clock />
              </div>
              <div className="backup-stat-data">
                <span className="backup-stat-label">Último Respaldo</span>
                <strong className="backup-stat-value">
                  {stats.lastBackupDate
                    ? new Date(stats.lastBackupDate).toLocaleDateString("es-ES", {
                        day: "2-digit",
                        month: "short",
                        hour: "2-digit",
                        minute: "2-digit",
                      })
                    : "Ninguno"}
                </strong>
                <small className="backup-stat-sub">
                  {stats.lastBackupDate ? "Completado con éxito" : "Crea tu primer backup"}
                </small>
              </div>
            </div>
          </div>

          {/* Barra de Acciones y Filtros */}
          <div className="actions-and-filters-bar">
            <div className="search-filter-group">
              <div className="search-input-wrap">
                <Search />
                <input
                  type="text"
                  placeholder="Buscar por archivo, nota o creador..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              <div className="type-filters-pill">
                <button
                  type="button"
                  className={typeFilter === "all" ? "active" : ""}
                  onClick={() => setTypeFilter("all")}
                >
                  Todos ({backups.length})
                </button>
                <button
                  type="button"
                  className={typeFilter === "full" ? "active" : ""}
                  onClick={() => setTypeFilter("full")}
                >
                  Completo
                </button>
                <button
                  type="button"
                  className={typeFilter === "database" ? "active" : ""}
                  onClick={() => setTypeFilter("database")}
                >
                  Base de Datos
                </button>
                <button
                  type="button"
                  className={typeFilter === "media" ? "active" : ""}
                  onClick={() => setTypeFilter("media")}
                >
                  Medios
                </button>
              </div>
            </div>

            <div className="action-buttons-group">
              <button
                type="button"
                className="btn-upload-backup"
                onClick={() => setShowUploadModal(true)}
              >
                <UploadCloud />
                <span>Subir Copia</span>
              </button>

              <button
                type="button"
                className="btn-create-backup-primary"
                onClick={() => setShowCreateModal(true)}
              >
                <DatabaseBackup />
                <span>+ Crear Copia de Seguridad</span>
              </button>
            </div>
          </div>

          {/* Tabla de Copias de Seguridad */}
          <div className="backups-table-card">
            {loading ? (
              <div className="loading-state-area">
                <Loader2 className="animate-spin" />
                <p>Cargando copias de seguridad del servidor...</p>
              </div>
            ) : filteredBackups.length === 0 ? (
              <div className="empty-state-area">
                <div className="empty-icon-wrap">
                  <DatabaseBackup />
                </div>
                <h3>No se encontraron copias de seguridad</h3>
                <p>
                  {searchQuery || typeFilter !== "all"
                    ? "No hay resultados para los filtros seleccionados."
                    : "Aún no has generado ninguna copia de seguridad en tu sistema."}
                </p>
                <div className="empty-actions">
                  <button
                    type="button"
                    className="btn-create-backup-primary"
                    onClick={() => setShowCreateModal(true)}
                  >
                    <DatabaseBackup />
                    <span>Crear Primera Copia de Seguridad</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="table-responsive">
                <table className="techlab-backups-table">
                  <thead>
                    <tr>
                      <th>NOMBRE DE ARCHIVO / TIPO</th>
                      <th>FECHA Y HORA</th>
                      <th>TAMAÑO</th>
                      <th>ORIGEN</th>
                      <th>NOTA / DETALLE</th>
                      <th>ESTADO</th>
                      <th className="th-actions">ACCIONES</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredBackups.map((b) => (
                      <tr key={b.id}>
                        <td>
                          <div className="filename-cell">
                            <div className={`type-badge-icon ${b.type}`}>
                              {b.type === "full" && <FolderArchive />}
                              {b.type === "database" && <Database />}
                              {b.type === "media" && <ImageIcon />}
                            </div>
                            <div>
                              <strong className="filename-text">{b.filename}</strong>
                              <span className={`type-tag ${b.type}`}>
                                {b.type === "full"
                                  ? "Completo (BD + Medios)"
                                  : b.type === "database"
                                  ? "Solo Base de Datos"
                                  : "Archivos / Medios"}
                              </span>
                            </div>
                          </div>
                        </td>
                        <td>
                          <div className="date-cell">
                            <Calendar />
                            <span>
                              {new Date(b.createdAt).toLocaleDateString("es-ES", {
                                day: "2-digit",
                                month: "short",
                                year: "numeric",
                                hour: "2-digit",
                                minute: "2-digit",
                              })}
                            </span>
                          </div>
                        </td>
                        <td>
                          <span className="size-badge">{b.formattedSize}</span>
                        </td>
                        <td>
                          <span className={`creator-badge ${b.creator.includes("Auto") ? "auto" : "manual"}`}>
                            {b.creator}
                          </span>
                        </td>
                        <td>
                          <span className="note-text">{b.note || "—"}</span>
                        </td>
                        <td>
                          <span className="status-pill completed">
                            <Check /> Completado
                          </span>
                        </td>
                        <td className="td-actions">
                          <div className="row-actions-wrap">
                            <a
                              href={`/api/backups/download/${encodeURIComponent(b.filename)}`}
                              className="btn-action-icon download"
                              title="Descargar al equipo local"
                              download
                            >
                              <Download />
                            </a>

                            <button
                              type="button"
                              className="btn-action-icon restore"
                              title="Restaurar en MySQL"
                              onClick={() => {
                                setSelectedBackupToRestore(b);
                                setConfirmRisk(false);
                                setShowRestoreModal(true);
                              }}
                            >
                              <RotateCcw />
                            </button>

                            <button
                              type="button"
                              className="btn-action-icon delete"
                              title="Eliminar archivo del servidor"
                              onClick={() => {
                                setSelectedBackupToDelete(b);
                                setShowDeleteModal(true);
                              }}
                            >
                              <Trash2 />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          PESTAÑA 2: CONFIGURACIÓN (PROGRAMACIÓN AUTOMÁTICA, FRECUENCIA, DESTINO)
          ========================================================================= */}
      {activeTab === "configuracion" && (
        <div className="tab-content-fade">
          <form onSubmit={handleSaveConfig} className="config-form-wrapper">
            {/* Tarjeta 1: Estado del Cron Automático */}
            <div className="config-section-card">
              <div className="card-header-flex">
                <div className="header-icon-title">
                  <div className="section-icon-box green">
                    <Clock />
                  </div>
                  <div>
                    <h3>Programación Automática de Respaldos</h3>
                    <p>Configura la frecuencia y los horarios en que el servidor realizará copias de seguridad de forma autónoma.</p>
                  </div>
                </div>

                <label className="techlab-toggle-switch">
                  <input
                    type="checkbox"
                    checked={config.autoBackupEnabled}
                    onChange={(e) => setConfig({ ...config, autoBackupEnabled: e.target.checked })}
                  />
                  <span className="toggle-slider round" />
                </label>
              </div>

              {config.autoBackupEnabled && (
                <div className="config-fields-grid mt-4">
                  <div className="form-field-item">
                    <label>Frecuencia de Ejecución</label>
                    <select
                      value={config.frequency}
                      onChange={(e: any) => setConfig({ ...config, frequency: e.target.value })}
                      className="techlab-select"
                    >
                      <option value="hourly">Cada hora (Por hora)</option>
                      <option value="daily">Una vez al día (Diario)</option>
                      <option value="weekly">Semanal (Por semana)</option>
                      <option value="monthly">Mensual (Por mes)</option>
                    </select>
                    <small>Define la periodicidad con la que se generará el archivo de respaldo.</small>
                  </div>

                  {config.frequency !== "hourly" && (
                    <div className="form-field-item">
                      <label>Hora de Ejecución (Servidor)</label>
                      <input
                        type="time"
                        value={config.executionTime}
                        onChange={(e) => setConfig({ ...config, executionTime: e.target.value })}
                        className="techlab-input"
                      />
                      <small>Horario de menor tráfico recomendado (ej. 03:00 AM).</small>
                    </div>
                  )}

                  {config.frequency === "weekly" && (
                    <div className="form-field-item">
                      <label>Día de la Semana</label>
                      <select
                        value={config.executionDay}
                        onChange={(e) => setConfig({ ...config, executionDay: e.target.value })}
                        className="techlab-select"
                      >
                        <option value="monday">Lunes</option>
                        <option value="tuesday">Martes</option>
                        <option value="wednesday">Miércoles</option>
                        <option value="thursday">Jueves</option>
                        <option value="friday">Viernes</option>
                        <option value="saturday">Sábado</option>
                        <option value="sunday">Domingo</option>
                      </select>
                    </div>
                  )}

                  {config.frequency === "monthly" && (
                    <div className="form-field-item">
                      <label>Día del Mes</label>
                      <select
                        value={config.executionDayOfMonth}
                        onChange={(e) => setConfig({ ...config, executionDayOfMonth: parseInt(e.target.value) })}
                        className="techlab-select"
                      >
                        {Array.from({ length: 28 }, (_, i) => i + 1).map((d) => (
                          <option key={d} value={d}>
                            Día {d} de cada mes
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Tarjeta 2: Contenido a Incluir y Retención */}
            <div className="config-section-card">
              <div className="header-icon-title">
                <div className="section-icon-box cyan">
                  <Layers />
                </div>
                <div>
                  <h3>Contenido del Respaldo y Política de Retención</h3>
                  <p>Selecciona qué elementos se incluirán en el archivo de backup y cuántas copias se mantendrán.</p>
                </div>
              </div>

              <div className="checkboxes-selection-list">
                <label className="checkbox-row-card">
                  <input
                    type="checkbox"
                    checked={config.includeDatabase}
                    onChange={(e) => setConfig({ ...config, includeDatabase: e.target.checked })}
                  />
                  <div className="checkbox-info">
                    <strong>Base de Datos MySQL Completa</strong>
                    <span>Respalda usuarios, posts, páginas, menús, comentarios, testimonios, proyectos y ajustes.</span>
                  </div>
                </label>

                <label className="checkbox-row-card">
                  <input
                    type="checkbox"
                    checked={config.includeMedia}
                    onChange={(e) => setConfig({ ...config, includeMedia: e.target.checked })}
                  />
                  <div className="checkbox-info">
                    <strong>Archivos Multimedia e Imágenes (/public/uploads)</strong>
                    <span>Incluye fotos destacadas, avatares y archivos multimedia subidos por los administradores.</span>
                  </div>
                </label>

                <label className="checkbox-row-card">
                  <input
                    type="checkbox"
                    checked={config.includeConfig}
                    onChange={(e) => setConfig({ ...config, includeConfig: e.target.checked })}
                  />
                  <div className="checkbox-info">
                    <strong>Ajustes del Sistema y Metadatos SEO</strong>
                    <span>Configuración general, variables de sitio, integración de WhatsApp y códigos de verificación.</span>
                  </div>
                </label>
              </div>

              <div className="form-field-item mt-4">
                <label>Límite de Retención de Copias</label>
                <div className="retention-input-group">
                  <select
                    value={config.retentionLimit}
                    onChange={(e) => setConfig({ ...config, retentionLimit: parseInt(e.target.value) })}
                    className="techlab-select"
                  >
                    <option value={5}>Conservar últimas 5 copias</option>
                    <option value={10}>Conservar últimas 10 copias (Recomendado)</option>
                    <option value={20}>Conservar últimas 20 copias</option>
                    <option value={30}>Conservar últimas 30 copias</option>
                  </select>
                </div>
                <small>Las copias automáticas más antiguas que excedan este límite se eliminarán para ahorrar espacio en disco.</small>
              </div>
            </div>

            {/* Tarjeta 3: Destino y Notificaciones por Correo */}
            <div className="config-section-card">
              <div className="header-icon-title">
                <div className="section-icon-box purple">
                  <Server />
                </div>
                <div>
                  <h3>Destino de Almacenamiento & Alertas por Correo</h3>
                  <p>Define dónde se guardarán las copias y si deseas recibir notificaciones al completarse o presentarse fallas.</p>
                </div>
              </div>

              <div className="storage-locations-grid">
                <label className={`storage-card ${config.storageLocation === "local" ? "selected" : ""}`}>
                  <input
                    type="radio"
                    name="storageLocation"
                    value="local"
                    checked={config.storageLocation === "local"}
                    onChange={() => setConfig({ ...config, storageLocation: "local" })}
                  />
                  <Server />
                  <strong>Servidor Local (/backups)</strong>
                  <span>Almacenamiento directo en disco de alta velocidad</span>
                  <span className="badge-active">Activo</span>
                </label>

                <label className={`storage-card ${config.storageLocation === "gdrive" ? "selected" : ""}`}>
                  <input
                    type="radio"
                    name="storageLocation"
                    value="gdrive"
                    checked={config.storageLocation === "gdrive"}
                    onChange={() => setConfig({ ...config, storageLocation: "gdrive" })}
                  />
                  <Cloud />
                  <strong>Google Drive / Cloud</strong>
                  <span>Sincronización en la nube externa</span>
                  <span className="badge-ready">Preparado</span>
                </label>

                <label className={`storage-card ${config.storageLocation === "email" ? "selected" : ""}`}>
                  <input
                    type="radio"
                    name="storageLocation"
                    value="email"
                    checked={config.storageLocation === "email"}
                    onChange={() => setConfig({ ...config, storageLocation: "email" })}
                  />
                  <Mail />
                  <strong>Envío por Correo</strong>
                  <span>Envía el archivo adjunto a tu email</span>
                  <span className="badge-ready">Preparado</span>
                </label>
              </div>

              <div className="config-fields-grid mt-4">
                <div className="form-field-item">
                  <label>Correo Electrónico para Notificaciones</label>
                  <input
                    type="email"
                    value={config.notificationEmail}
                    onChange={(e) => setConfig({ ...config, notificationEmail: e.target.value })}
                    className="techlab-input"
                    placeholder="admin@techlab.com"
                  />
                </div>

                <div className="notification-checkboxes">
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      checked={config.notifyOnSuccess}
                      onChange={(e) => setConfig({ ...config, notifyOnSuccess: e.target.checked })}
                    />
                    <span>Notificar cuando el backup se complete con éxito</span>
                  </label>
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      checked={config.notifyOnError}
                      onChange={(e) => setConfig({ ...config, notifyOnError: e.target.checked })}
                    />
                    <span>Enviar alerta inmediata si una copia de seguridad falla</span>
                  </label>
                </div>
              </div>
            </div>

            {/* Barra de Guardado */}
            <div className="config-save-bar">
              <button
                type="submit"
                className="btn-save-config-primary"
                disabled={isSavingConfig}
              >
                {isSavingConfig ? (
                  <>
                    <Loader2 className="animate-spin" />
                    <span>Guardando configuración...</span>
                  </>
                ) : (
                  <>
                    <Sparkles />
                    <span>Guardar Configuración de Backups</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* =========================================================================
          MODAL: CREAR COPIA DE SEGURIDAD MANUAL
          ========================================================================= */}
      {showCreateModal && (
        <div className="techlab-modal-backdrop" onClick={() => !isCreating && setShowCreateModal(false)}>
          <div className="techlab-modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="modal-top">
              <div className="modal-title-wrap">
                <DatabaseBackup />
                <h3>Crear Nueva Copia de Seguridad</h3>
              </div>
              <button
                type="button"
                className="btn-close-modal"
                onClick={() => !isCreating && setShowCreateModal(false)}
              >
                <X />
              </button>
            </div>

            <div className="modal-body-content">
              <p className="modal-desc">
                Selecciona el tipo de contenido que deseas empaquetar en el nuevo archivo de copia de seguridad:
              </p>

              <div className="type-options-cards">
                <div
                  className={`type-option-card ${createType === "full" ? "selected" : ""}`}
                  onClick={() => setCreateType("full")}
                >
                  <FolderArchive />
                  <div>
                    <strong>Respaldo Completo (Recomendado)</strong>
                    <span>Base de Datos MySQL + Archivos multimedia (/uploads)</span>
                  </div>
                </div>

                <div
                  className={`type-option-card ${createType === "database" ? "selected" : ""}`}
                  onClick={() => setCreateType("database")}
                >
                  <Database />
                  <div>
                    <strong>Solo Base de Datos (MySQL)</strong>
                    <span>Tablas, publicaciones, usuarios, menús, comentarios y ajustes</span>
                  </div>
                </div>

                <div
                  className={`type-option-card ${createType === "media" ? "selected" : ""}`}
                  onClick={() => setCreateType("media")}
                >
                  <ImageIcon />
                  <div>
                    <strong>Solo Archivos Multimedia</strong>
                    <span>Imágenes destacadas, avatares y archivos subidos</span>
                  </div>
                </div>
              </div>

              <div className="form-field-item mt-3">
                <label>Nota o Descripción (Opcional):</label>
                <input
                  type="text"
                  placeholder="ej. Previo a actualización de plugins / temas"
                  value={createNote}
                  onChange={(e) => setCreateNote(e.target.value)}
                  className="techlab-input"
                />
              </div>
            </div>

            <div className="modal-actions-bar">
              <button
                type="button"
                className="btn-modal-ghost"
                onClick={() => setShowCreateModal(false)}
                disabled={isCreating}
              >
                Cancelar
              </button>
              <button
                type="button"
                className="btn-modal-primary"
                onClick={handleCreateBackup}
                disabled={isCreating}
              >
                {isCreating ? (
                  <>
                    <Loader2 className="animate-spin" />
                    <span>Generando copia...</span>
                  </>
                ) : (
                  <>
                    <DatabaseBackup />
                    <span>Generar Respaldo Ahora</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL: SUBIR COPIA DE SEGURIDAD EXTERNA
          ========================================================================= */}
      {showUploadModal && (
        <div className="techlab-modal-backdrop" onClick={() => !isUploading && setShowUploadModal(false)}>
          <div className="techlab-modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="modal-top">
              <div className="modal-title-wrap">
                <UploadCloud />
                <h3>Subir Copia de Seguridad al Servidor</h3>
              </div>
              <button
                type="button"
                className="btn-close-modal"
                onClick={() => !isUploading && setShowUploadModal(false)}
              >
                <X />
              </button>
            </div>

            <div className="modal-body-content">
              <p className="modal-desc">
                Carga un archivo de respaldo generado previamente (formatos <code>.json</code>, <code>.sql</code> o <code>.zip</code>) para almacenarlo en el servidor y poder restaurarlo.
              </p>

              <input
                ref={fileInputRef}
                type="file"
                accept=".json,.sql,.zip"
                onChange={handleFileUpload}
                style={{ display: "none" }}
              />

              <div
                className={`dropzone-area ${uploadDragOver ? "drag-over" : ""}`}
                onDragOver={(e) => {
                  e.preventDefault();
                  setUploadDragOver(true);
                }}
                onDragLeave={() => setUploadDragOver(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setUploadDragOver(false);
                  const file = e.dataTransfer.files?.[0];
                  if (file) processUploadFile(file);
                }}
                onClick={() => fileInputRef.current?.click()}
              >
                {isUploading ? (
                  <div className="dropzone-uploading">
                    <Loader2 className="animate-spin" />
                    <strong>Subiendo archivo al servidor...</strong>
                    <small>Por favor espera unos momentos</small>
                  </div>
                ) : (
                  <div className="dropzone-prompt">
                    <UploadCloud />
                    <strong>Haz clic o arrastra tu archivo aquí</strong>
                    <small>Formatos aceptados: .json, .sql, .zip</small>
                  </div>
                )}
              </div>
            </div>

            <div className="modal-actions-bar">
              <button
                type="button"
                className="btn-modal-ghost"
                onClick={() => setShowUploadModal(false)}
                disabled={isUploading}
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL: CONFIRMAR RESTAURACIÓN
          ========================================================================= */}
      {showRestoreModal && selectedBackupToRestore && (
        <div className="techlab-modal-backdrop" onClick={() => !isRestoring && setShowRestoreModal(false)}>
          <div className="techlab-modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="modal-top">
              <div className="modal-title-wrap danger">
                <RotateCcw />
                <h3>Restaurar Copia de Seguridad</h3>
              </div>
              <button
                type="button"
                className="btn-close-modal"
                onClick={() => !isRestoring && setShowRestoreModal(false)}
              >
                <X />
              </button>
            </div>

            <div className="modal-body-content">
              <div className="warning-callout-box">
                <AlertTriangle />
                <div>
                  <strong>¡Atención: Acción destructiva e irreversible!</strong>
                  <p>
                    La restauración sobrescribirá los datos actuales de la base de datos MySQL y/o archivos multimedia con la información contenida en este respaldo.
                  </p>
                </div>
              </div>

              <div className="backup-restore-summary">
                <div className="summary-row">
                  <span>Archivo seleccionado:</span>
                  <strong>{selectedBackupToRestore.filename}</strong>
                </div>
                <div className="summary-row">
                  <span>Tipo de copia:</span>
                  <span className={`type-tag ${selectedBackupToRestore.type}`}>
                    {selectedBackupToRestore.type === "full"
                      ? "Completo (BD + Medios)"
                      : selectedBackupToRestore.type === "database"
                      ? "Base de Datos"
                      : "Medios"}
                  </span>
                </div>
                <div className="summary-row">
                  <span>Tamaño:</span>
                  <strong>{selectedBackupToRestore.formattedSize}</strong>
                </div>
                <div className="summary-row">
                  <span>Fecha de creación:</span>
                  <strong>
                    {new Date(selectedBackupToRestore.createdAt).toLocaleString("es-ES")}
                  </strong>
                </div>
              </div>

              <label className="risk-confirm-checkbox">
                <input
                  type="checkbox"
                  checked={confirmRisk}
                  onChange={(e) => setConfirmRisk(e.target.checked)}
                />
                <span>Entiendo los riesgos y confirmo que deseo restaurar esta copia de seguridad.</span>
              </label>
            </div>

            <div className="modal-actions-bar">
              <button
                type="button"
                className="btn-modal-ghost"
                onClick={() => setShowRestoreModal(false)}
                disabled={isRestoring}
              >
                Cancelar
              </button>
              <button
                type="button"
                className="btn-modal-danger"
                onClick={handleRestoreBackup}
                disabled={!confirmRisk || isRestoring}
              >
                {isRestoring ? (
                  <>
                    <Loader2 className="animate-spin" />
                    <span>Restaurando datos...</span>
                  </>
                ) : (
                  <>
                    <RotateCcw />
                    <span>Restaurar Ahora</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL: CONFIRMAR ELIMINACIÓN
          ========================================================================= */}
      {showDeleteModal && selectedBackupToDelete && (
        <div className="techlab-modal-backdrop" onClick={() => !isDeleting && setShowDeleteModal(false)}>
          <div className="techlab-modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="modal-top">
              <div className="modal-title-wrap danger">
                <Trash2 />
                <h3>Eliminar Copia de Seguridad</h3>
              </div>
              <button
                type="button"
                className="btn-close-modal"
                onClick={() => !isDeleting && setShowDeleteModal(false)}
              >
                <X />
              </button>
            </div>

            <div className="modal-body-content">
              <p className="modal-desc">
                ¿Estás seguro de que deseas eliminar permanentemente el archivo <strong>{selectedBackupToDelete.filename}</strong>? Esta acción liberará <strong>{selectedBackupToDelete.formattedSize}</strong> en el servidor.
              </p>
            </div>

            <div className="modal-actions-bar">
              <button
                type="button"
                className="btn-modal-ghost"
                onClick={() => setShowDeleteModal(false)}
                disabled={isDeleting}
              >
                Cancelar
              </button>
              <button
                type="button"
                className="btn-modal-danger"
                onClick={handleDeleteBackup}
                disabled={isDeleting}
              >
                {isDeleting ? (
                  <>
                    <Loader2 className="animate-spin" />
                    <span>Eliminando...</span>
                  </>
                ) : (
                  <>
                    <Trash2 />
                    <span>Eliminar Archivo</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
