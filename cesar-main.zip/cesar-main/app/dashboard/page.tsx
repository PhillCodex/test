import Link from "next/link";
import { ExternalLink, Plus, FileText, Folder, Files, MessageSquare, DatabaseBackup } from "lucide-react";
import StatCard from "@/components/dashboard/StatCard";
import DashboardChart from "@/components/dashboard/DashboardChart";
import RecentPosts from "@/components/dashboard/RecentPosts";
import { QuickSummary, RecentActivity, QuickStats } from "@/components/dashboard/BottomCards";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function Dashboard() {
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - 29);
  startDate.setHours(0, 0, 0, 0);

  // 1. Consultar métricas reales desde MySQL
  const [
    postsCount,
    postsPublished,
    categoriesCount,
    pagesCount,
    commentsCount,
    usersCount,
    projectsCount,
    servicesCount,
    recentPosts,
    siteSettings,
  ] = await Promise.all([
    prisma.post.count(),
    prisma.post.count({ where: { status: "Publicado" } }),
    prisma.category.count(),
    prisma.page.count(),
    prisma.comment.count(),
    prisma.user.count(),
    prisma.project.count(),
    prisma.service.count(),
    prisma.post.findMany({
      take: 5,
      orderBy: { createdAt: "desc" },
      include: { category: true, author: true },
    }),
    prisma.siteSetting.findUnique({ where: { id: "general" } }),
  ]);

  // 2. Consultar visitas reales por IP agrupadas por día para los últimos 30 días
  let visitsData: Array<{ date: string; fullDate: string; visits: number; uniqueIps: number }> = [];
  try {
    const rawVisits = await prisma.$queryRawUnsafe<Array<{ createdAt: Date | string; ipAddress: string | null }>>(
      `SELECT createdAt, ipAddress FROM site_visits WHERE createdAt >= ? ORDER BY createdAt ASC`,
      startDate
    );

    const dayMap = new Map<string, { visits: number; ips: Set<string> }>();
    for (let i = 0; i < 30; i++) {
      const d = new Date(startDate);
      d.setDate(d.getDate() + i);
      const dayKey = d.toISOString().split("T")[0];
      dayMap.set(dayKey, { visits: 0, ips: new Set() });
    }

    rawVisits.forEach((v) => {
      const dateObj = typeof v.createdAt === "string" ? new Date(v.createdAt) : v.createdAt;
      const dayKey = dateObj.toISOString().split("T")[0];
      if (dayMap.has(dayKey)) {
        const item = dayMap.get(dayKey)!;
        item.visits += 1;
        if (v.ipAddress) item.ips.add(v.ipAddress);
      }
    });

    const monthNames = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];
    visitsData = Array.from(dayMap.entries()).map(([dayKey, val]) => {
      const d = new Date(dayKey + "T12:00:00Z");
      return {
        date: `${d.getUTCDate()} ${monthNames[d.getUTCMonth()]}`,
        fullDate: dayKey,
        visits: val.visits,
        uniqueIps: val.ips.size,
      };
    });
  } catch (e) {
    console.error("Error al obtener visitas en Dashboard:", e);
  }

  const totalPeriodVisits = visitsData.reduce((acc, curr) => acc + curr.visits, 0);

  const summaryData = {
    usersCount,
    postsTotal: postsCount,
    postsPublished,
    pagesCount,
    commentsCount,
    categoriesCount,
    projectsCount,
    servicesCount,
  };

  const formattedRecentPosts = recentPosts.map((p) => ({
    id: p.id,
    title: p.title,
    slug: p.slug,
    category: p.category?.name || "General",
    featuredImage: p.featuredImage || "/images/hero-techlab.png",
    createdAt: p.createdAt,
    views: p.views || 0,
    status: p.status,
  }));

  return (
    <>
      <div className="dashboard-heading">
        <div>
          <h1>Panel de Administración</h1>
          <p>
            Bienvenido de nuevo, César. Aquí tienes el estado real y las métricas en vivo de tu sitio.
          </p>
        </div>
        <div className="dashboard-top-actions">
          <Link className="admin-btn ghost" href="/" target="_blank">
            <span>Vista del sitio</span>
            <ExternalLink />
          </Link>
          <Link className="admin-btn" href="/dashboard/posts/nuevo">
            <Plus /> Nuevo Post
          </Link>
        </div>
      </div>

      {/* Tarjetas de Estadísticas Reales de MySQL */}
      <div className="stat-grid">
        <StatCard
          label="TOTAL DE POSTS"
          value={postsCount.toString()}
          growth={`${postsPublished} publicados`}
          icon={FileText}
          tone="green"
        />
        <StatCard
          label="CATEGORÍAS"
          value={categoriesCount.toString()}
          growth="Taxonomías activas"
          icon={Folder}
          tone="blue"
        />
        <StatCard
          label="PÁGINAS"
          value={pagesCount.toString()}
          growth="Páginas creadas"
          icon={Files}
          tone="purple"
        />
        <StatCard
          label="COMENTARIOS"
          value={commentsCount.toString()}
          growth="Interacciones registradas"
          icon={MessageSquare}
          tone="green"
        />
      </div>

      {/* Gráfico de Visitas Reales por IP y Publicaciones Recientes */}
      <div className="dashboard-middle">
        <DashboardChart initialData={visitsData} totalPeriodVisits={totalPeriodVisits} />
        <RecentPosts posts={formattedRecentPosts} />
      </div>

      {/* Resumen, Actividad y Distribución de Contenidos Reales */}
      <div className="dashboard-bottom">
        <QuickSummary data={summaryData} />
        <RecentActivity data={summaryData} />
        <QuickStats data={summaryData} />
      </div>
    </>
  );
}
