"use client";

import { useState, useEffect, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import {
  Plus,
  X,
  Undo2,
  Redo2,
  Monitor,
  Tablet,
  Smartphone,
  Eye,
  Layers,
  Search,
  ChevronDown,
  ChevronLeft,
  Loader2,
  Trash2,
  GripVertical,
  Type,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  Image as ImageIcon,
  Box,
  LayoutGrid,
  Columns,
  Minus,
  Film,
  Video,
  Palette,
  Briefcase,
  MessageSquareQuote,
  Newspaper,
  PanelTop,
  Play,
  CheckCircle2,
  AlertTriangle,
  FolderKanban,
  FileCode,
  ExternalLink,
  ArrowLeft,
  ArrowUp,
  ArrowDown,
  Home,
  Files,
  Sliders,
  Sparkles,
  Star,
  MapPin,
  Award,
  ListChecks,
  Hash,
  MoveVertical,
  ToggleLeft,
  Share2,
  BarChart2,
  Headphones,
  Code2,
  Anchor,
  AlertCircle,
  Sidebar as SidebarIcon,
  PenTool,
  Globe,
  LayoutTemplate,
  Check,
  Radio,
  Clock,
  HelpCircle,
  SlidersHorizontal,
  Upload,
} from "lucide-react";

// ============================================================================
// TIPOS DE DATOS DE ELEMENTOR
// ============================================================================

export type WidgetType =
  | "heading"
  | "text"
  | "image"
  | "button"
  | "div"
  | "flexbox"
  | "grid"
  | "youtube"
  | "separator"
  | "video"
  | "services"
  | "testimonials"
  | "articles"
  | "gallery"
  | "hero"
  // Nuevos widgets oficiales de Elementor:
  | "star-rating"
  | "icon"
  | "image-box"
  | "icon-box"
  | "carousel"
  | "icon-list"
  | "counter"
  | "spacer"
  | "testimonial-card"
  | "tabs"
  | "accordion"
  | "toggle"
  | "social-icons"
  | "progress-bar"
  | "soundcloud"
  | "shortcode"
  | "html"
  | "menu-anchor"
  | "alert"
  | "sidebar-widget"
  | "text-path";

export interface WidgetItem {
  id: string;
  type: WidgetType;
  title?: string;
  settings: Record<string, any>;
}

export interface ColumnItem {
  id: string;
  width?: string;
  widgets: WidgetItem[];
  styles?: Record<string, any>;
}

export interface ContainerItem {
  id: string;
  layoutType: "flexbox" | "grid";
  direction: "column" | "row";
  structurePreset: number;
  columns: ColumnItem[];
  styles: {
    paddingTop?: number;
    paddingBottom?: number;
    paddingLeft?: number;
    paddingRight?: number;
    marginTop?: number;
    marginBottom?: number;
    minHeight?: number;
    backgroundColor?: string;
    borderRadius?: number;
    borderColor?: string;
    borderWidth?: number;
    boxShadow?: string;
    gap?: number;
    justifyContent?: string;
    alignItems?: string;
  };
}

const STRUCTURE_PRESETS = [
  { id: 1, label: "1 Columna Vertical", icon: "↓", columns: [{ width: "100%" }], direction: "column" as const },
  { id: 2, label: "1 Fila Horizontal", icon: "→", columns: [{ width: "100%" }], direction: "row" as const },
  { id: 3, label: "2 Columnas (50/50)", icon: "2c", columns: [{ width: "50%" }, { width: "50%" }], direction: "row" as const },
  { id: 4, label: "3 Columnas (33/33/33)", icon: "3c", columns: [{ width: "33.33%" }, { width: "33.33%" }, { width: "33.33%" }], direction: "row" as const },
  { id: 5, label: "4 Columnas (25x4)", icon: "4c", columns: [{ width: "25%" }, { width: "25%" }, { width: "25%" }, { width: "25%" }], direction: "row" as const },
  { id: 6, label: "3 Cols (Centro Ancho)", icon: "1-2-1", columns: [{ width: "20%" }, { width: "60%" }, { width: "20%" }], direction: "row" as const },
  { id: 7, label: "2 Columnas (33/66)", icon: "1-2", columns: [{ width: "33.33%" }, { width: "66.66%" }], direction: "row" as const },
  { id: 8, label: "2 Columnas (66/33)", icon: "2-1", columns: [{ width: "66.66%" }, { width: "33.33%" }], direction: "row" as const },
  { id: 9, label: "3 Columnas (25/50/25)", icon: "1-2-1b", columns: [{ width: "25%" }, { width: "50%" }, { width: "25%" }], direction: "row" as const },
  { id: 10, label: "5 Columnas (20x5)", icon: "5c", columns: [{ width: "20%" }, { width: "20%" }, { width: "20%" }, { width: "20%" }, { width: "20%" }], direction: "row" as const },
  { id: 11, label: "2 Filas Apiladas", icon: "2r", columns: [{ width: "100%" }, { width: "100%" }], direction: "column" as const },
  { id: 12, label: "Cuadrícula 2x2 Grid", icon: "2x2", columns: [{ width: "50%" }, { width: "50%" }, { width: "50%" }, { width: "50%" }], direction: "row" as const },
];

function ElementorBuilderContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const pageId = searchParams.get("id") || searchParams.get("edit") || searchParams.get("elementor");
  const querySlug = searchParams.get("slug");

  const [pageTitle, setPageTitle] = useState(querySlug ? `Página: ${querySlug}` : "Elementor #16");
  const [pageSlug, setPageSlug] = useState(querySlug || "");
  const [pageStatus, setPageStatus] = useState<"Borrador" | "Publicado">("Borrador");
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<"success" | "error" | "info">("success");
  const [responsiveMode, setResponsiveMode] = useState<"desktop" | "tablet" | "mobile">("desktop");
  const [containers, setContainers] = useState<ContainerItem[]>([]);
  const [selectedContainerId, setSelectedContainerId] = useState<string | null>(null);
  const [selectedColumnId, setSelectedColumnId] = useState<string | null>(null);
  const [selectedWidgetId, setSelectedWidgetId] = useState<string | null>(null);
  const [sidebarMode, setSidebarMode] = useState<"widgets" | "flexbox" | "widget">("widgets");
  const [sidebarTab, setSidebarTab] = useState<"general" | "estilo" | "interacciones">("estilo");
  const [widgetSearchQuery, setWidgetSearchQuery] = useState("");
  const [showStructureModal, setShowStructureModal] = useState(false);
  const [structureDesignType, setStructureDesignType] = useState<"choice" | "flexbox" | "grid">("choice");
  const [insertTargetIndex, setInsertTargetIndex] = useState<number | null>(null);
  const [showElementorMenu, setShowElementorMenu] = useState(false);

  // Estado de Drag & Drop para Contenedores (Secciones)
  const [draggedContainerId, setDraggedContainerId] = useState<string | null>(null);
  const [containerDropIndicator, setContainerDropIndicator] = useState<{
    targetContId: string;
    position: "before" | "after";
    targetIndex: number;
  } | null>(null);

  // Estado de Drag & Drop inteligente para Widgets
  const [draggedWidgetType, setDraggedWidgetType] = useState<WidgetType | null>(null);
  const [draggedExistingWidget, setDraggedExistingWidget] = useState<{
    widgetId: string;
    sourceContId: string;
    sourceColId: string;
  } | null>(null);
  const [dragOverColumnId, setDragOverColumnId] = useState<string | null>(null);
  const [dropIndicator, setDropIndicator] = useState<{
    contId: string;
    colId: string;
    targetWidgetId: string | null;
    position: "before" | "after";
    targetIndex: number;
  } | null>(null);
  const [isDropzoneHovered, setIsDropzoneHovered] = useState(false);

  // Estado de Datos Reales de la Base de Datos (Artículos, Servicios, Testimonios, Proyectos)
  const [dbData, setDbData] = useState<{
    posts: any[];
    services: any[];
    testimonials: any[];
    projects: any[];
  }>({ posts: [], services: [], testimonials: [], projects: [] });

  // Manejadores de Drag & Drop de CONTENEDORES (Mover por los puntitos)
  const handleContainerDragStart = (e: React.DragEvent, contId: string) => {
    e.stopPropagation();
    e.dataTransfer.setData("application/elementor-container", contId);
    e.dataTransfer.effectAllowed = "move";
    setDraggedContainerId(contId);
    setDraggedWidgetType(null);
    setDraggedExistingWidget(null);
    setDropIndicator(null);
  };

  const handleContainerDragEnd = () => {
    setDraggedContainerId(null);
    setContainerDropIndicator(null);
  };

  const handleContainerDragOver = (e: React.DragEvent, contId: string, cIndex: number) => {
    if (!draggedContainerId || draggedContainerId === contId) return;
    e.preventDefault();
    e.stopPropagation();
    e.dataTransfer.dropEffect = "move";

    const rect = e.currentTarget.getBoundingClientRect();
    const isTop = e.clientY - rect.top < rect.height / 2;
    setContainerDropIndicator({
      targetContId: contId,
      position: isTop ? "before" : "after",
      targetIndex: isTop ? cIndex : cIndex + 1,
    });
  };

  const handleContainerDrop = (e: React.DragEvent, targetContId: string, cIndex: number) => {
    if (!draggedContainerId) return;
    e.preventDefault();
    e.stopPropagation();

    if (draggedContainerId === targetContId) {
      setDraggedContainerId(null);
      setContainerDropIndicator(null);
      return;
    }

    const sourceIndex = containers.findIndex((c) => c.id === draggedContainerId);
    if (sourceIndex === -1) {
      setDraggedContainerId(null);
      setContainerDropIndicator(null);
      return;
    }

    const isTop = containerDropIndicator?.position === "before";
    let targetIdx = isTop ? cIndex : cIndex + 1;

    setContainers((prev) => {
      const copy = [...prev];
      const [movedCont] = copy.splice(sourceIndex, 1);
      const adjustedTarget = sourceIndex < targetIdx ? targetIdx - 1 : targetIdx;
      copy.splice(adjustedTarget, 0, movedCont);
      return copy;
    });

    setDraggedContainerId(null);
    setContainerDropIndicator(null);
    showToast("Contenedor reordenado con éxito.", "success");
  };

  const handleMoveContainerOrder = (contId: string, direction: "up" | "down", e?: React.MouseEvent) => {
    e?.stopPropagation();
    const idx = containers.findIndex((c) => c.id === contId);
    if (idx === -1) return;
    if (direction === "up" && idx === 0) return;
    if (direction === "down" && idx === containers.length - 1) return;

    const targetIdx = direction === "up" ? idx - 1 : idx + 1;
    setContainers((prev) => {
      const copy = [...prev];
      const [item] = copy.splice(idx, 1);
      copy.splice(targetIdx, 0, item);
      return copy;
    });
    showToast(`Contenedor movido hacia ${direction === "up" ? "arriba" : "abajo"}.`, "info");
  };

  // Manejadores de Drag & Drop desde la Barra Lateral
  const handleSidebarDragStart = (e: React.DragEvent, type: WidgetType) => {
    e.dataTransfer.setData("text/plain", type);
    e.dataTransfer.setData("application/elementor-new-widget", type);
    e.dataTransfer.effectAllowed = "copy";
    setDraggedWidgetType(type);
    setDraggedExistingWidget(null);
    setDraggedContainerId(null);
  };

  const handleSidebarDragEnd = () => {
    setDraggedWidgetType(null);
    setDragOverColumnId(null);
    setDropIndicator(null);
    setDraggedContainerId(null);
    setContainerDropIndicator(null);
    setIsDropzoneHovered(false);
  };

  // Drag start de un widget existente en el lienzo para reordenar
  const handleExistingWidgetDragStart = (
    e: React.DragEvent,
    widgetId: string,
    sourceContId: string,
    sourceColId: string
  ) => {
    e.stopPropagation();
    e.dataTransfer.setData("application/elementor-existing-widget", widgetId);
    e.dataTransfer.effectAllowed = "move";
    setDraggedExistingWidget({ widgetId, sourceContId, sourceColId });
    setDraggedWidgetType(null);
    setDraggedContainerId(null);
  };

  // Hover inteligente sobre un widget para detectar Arriba vs Abajo
  const handleWidgetDragOver = (
    e: React.DragEvent,
    contId: string,
    colId: string,
    widgetId: string,
    wIndex: number
  ) => {
    if (draggedContainerId) return; // Si se arrastra un contenedor, ignorar dragover de widget
    e.preventDefault();
    e.stopPropagation();
    e.dataTransfer.dropEffect = draggedExistingWidget ? "move" : "copy";
    const rect = e.currentTarget.getBoundingClientRect();
    const isTop = e.clientY - rect.top < rect.height / 2;
    setDropIndicator({
      contId,
      colId,
      targetWidgetId: widgetId,
      position: isTop ? "before" : "after",
      targetIndex: isTop ? wIndex : wIndex + 1,
    });
    setDragOverColumnId(colId);
  };

  const handleColumnDragOver = (e: React.DragEvent, colId: string, contId?: string, colWidgetsLength?: number) => {
    if (draggedContainerId) return;
    e.preventDefault();
    e.stopPropagation();
    e.dataTransfer.dropEffect = draggedExistingWidget ? "move" : "copy";
    if (dragOverColumnId !== colId) {
      setDragOverColumnId(colId);
    }
    if (colWidgetsLength === 0 && contId) {
      setDropIndicator({
        contId,
        colId,
        targetWidgetId: null,
        position: "after",
        targetIndex: 0,
      });
    }
  };

  const handleColumnDragLeave = (e: React.DragEvent, colId: string) => {
    e.stopPropagation();
    if (e.currentTarget.contains(e.relatedTarget as Node)) {
      return;
    }
    if (dragOverColumnId === colId) {
      setDragOverColumnId(null);
      setDropIndicator(null);
    }
  };

  const handleColumnDrop = (
    e: React.DragEvent,
    targetContId: string,
    targetColId: string,
    explicitIndex?: number
  ) => {
    e.preventDefault();
    e.stopPropagation();

    const finalTargetIndex =
      typeof explicitIndex === "number"
        ? explicitIndex
        : dropIndicator?.targetIndex;

    setDropIndicator(null);
    setDragOverColumnId(null);

    // Caso 1: Reordenar / Mover widget existente
    if (draggedExistingWidget) {
      const { widgetId, sourceContId, sourceColId } = draggedExistingWidget;
      let movingWidget: WidgetItem | null = null;

      setContainers((prev) => {
        const next = prev.map((c) => {
          if (c.id === sourceContId) {
            return {
              ...c,
              columns: c.columns.map((col) => {
                if (col.id === sourceColId) {
                  const found = col.widgets.find((w) => w.id === widgetId);
                  if (found) movingWidget = found;
                  return { ...col, widgets: col.widgets.filter((w) => w.id !== widgetId) };
                }
                return col;
              }),
            };
          }
          return c;
        });

        if (!movingWidget) return next;

        return next.map((c) => {
          if (c.id === targetContId) {
            return {
              ...c,
              columns: c.columns.map((col) => {
                if (col.id === targetColId) {
                  const copy = [...col.widgets];
                  if (typeof finalTargetIndex === "number") {
                    copy.splice(finalTargetIndex, 0, movingWidget!);
                  } else {
                    copy.push(movingWidget!);
                  }
                  return { ...col, widgets: copy };
                }
                return col;
              }),
            };
          }
          return c;
        });
      });

      setDraggedExistingWidget(null);
      showToast("Widget reubicado en la posición seleccionada.", "info");
      return;
    }

    // Caso 2: Insertar nuevo widget desde la barra lateral
    const widgetType = (e.dataTransfer.getData("application/elementor-new-widget") ||
      e.dataTransfer.getData("text/plain") ||
      draggedWidgetType) as WidgetType;

    if (!widgetType) return;

    const newWidget: WidgetItem = {
      id: `wid-${Date.now()}-${Math.round(Math.random() * 1e3)}`,
      type: widgetType,
      title: widgetType.toUpperCase(),
      settings: getDefaultWidgetSettings(widgetType),
    };

    setContainers((prev) =>
      prev.map((c) => {
        if (c.id === targetContId) {
          return {
            ...c,
            columns: c.columns.map((col) => {
              if (col.id === targetColId) {
                const copy = [...col.widgets];
                if (typeof finalTargetIndex === "number") {
                  copy.splice(finalTargetIndex, 0, newWidget);
                } else {
                  copy.push(newWidget);
                }
                return { ...col, widgets: copy };
              }
              return col;
            }),
          };
        }
        return c;
      })
    );

    setSelectedContainerId(targetContId);
    setSelectedColumnId(targetColId);
    setSelectedWidgetId(newWidget.id);
    setSidebarMode("widget");
    setDraggedWidgetType(null);
    showToast(`Widget ${widgetType} insertado correctamente.`, "success");
  };

  // Drop en el contenedor inferior vacío (crea contenedor automático con el widget)
  const handleDropOnEmptyArea = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDropzoneHovered(false);

    const widgetType = (e.dataTransfer.getData("application/elementor-new-widget") ||
      e.dataTransfer.getData("text/plain") ||
      draggedWidgetType) as WidgetType;

    if (!widgetType) return;

    const newColId = `col-${Date.now()}-0`;
    const newWidget: WidgetItem = {
      id: `wid-${Date.now()}`,
      type: widgetType,
      title: widgetType.toUpperCase(),
      settings: getDefaultWidgetSettings(widgetType),
    };

    const newCont: ContainerItem = {
      id: `cont-${Date.now()}`,
      layoutType: "flexbox",
      direction: "column",
      structurePreset: 1,
      columns: [{ id: newColId, width: "100%", widgets: [newWidget] }],
      styles: { paddingTop: 30, paddingBottom: 30, paddingLeft: 20, paddingRight: 20, borderRadius: 8, gap: 16 },
    };

    setContainers((prev) => [...prev, newCont]);
    setSelectedContainerId(newCont.id);
    setSelectedColumnId(newColId);
    setSelectedWidgetId(newWidget.id);
    setSidebarMode("widget");
    setDraggedWidgetType(null);
    showToast(`Nuevo contenedor creado con widget ${widgetType}.`, "success");
  };

  const showToast = (msg: string, type: "success" | "error" | "info" = "success") => {
    setToastMessage(msg);
    setToastType(type);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const getDefaultWidgetSettings = (type: WidgetType): Record<string, any> => {
    switch (type) {
      case "heading":
        return {
          title: "Tu Encabezado Principal",
          tag: "h2",
          align: "left",
          textColor: "#ffffff",
          fontSize: 32,
          hasAccentBar: false,
        };
      case "text":
        return {
          content: "<p>Escribe tu contenido aquí con texto enriquecido.</p>",
          textColor: "#94a3b8",
          fontSize: 16,
        };
      case "image":
        return {
          imageUrl: "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=80",
          imageAlt: "Imagen TechLab",
          borderRadius: 8,
          align: "center",
        };
      case "button":
        return {
          buttonText: "Comenzar Ahora",
          buttonLink: "#",
          buttonNewTab: false,
          buttonAlign: "left",
          buttonVariant: "primary",
          buttonTextColor: "#000000",
          buttonBgColor: "#16c96f",
          buttonBgType: "gradient",
          buttonGradientEnd: "#38bdf8",
          buttonBorderColor: "transparent",
          buttonBorderWidth: 0,
          buttonBorderStyle: "none",
          buttonRadius: 8,
          buttonFontSize: 14,
          buttonFontWeight: "800",
          buttonTextTransform: "none",
          buttonLetterSpacing: 0,
          buttonPaddingX: 24,
          buttonPaddingY: 12,
          buttonIcon: "arrow",
          buttonIconPos: "right",
          buttonIconGap: 8,
          buttonShadow: "neon",
        };
      case "youtube":
      case "video":
        return {
          videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
        };
      case "separator":
        return {
          color: "rgba(255,255,255,0.12)",
          margin: 24,
        };
      case "hero":
        return {
          badge: "✨ TECNOLOGÍA & INNOVACIÓN",
          badgeTextColor: "#16c96f",
          badgeBgColor: "rgba(22, 201, 111, 0.12)",
          badgeBorderColor: "rgba(22, 201, 111, 0.3)",
          showBadge: true,

          heroTitle: "Transforma tu Futuro Digital",
          heroTitleColor: "#ffffff",
          heroTitleSize: 38,
          heroTitleWeight: "900",
          heroTitleLineHeight: 1.2,

          heroSubtitle: "Soluciones a medida construidas con tecnología de última generación para máxima escalabilidad y rendimiento.",
          heroSubtitleColor: "#94a3b8",
          heroSubtitleSize: 16,
          heroSubtitleWeight: "400",
          heroSubtitleLineHeight: 1.7,
          heroSubtitleMaxWidth: 650,

          showPrimaryBtn: true,
          primaryBtnText: "Ver Servicios →",
          primaryBtnLink: "/servicios",
          primaryBtnNewTab: false,
          primaryBtnColor: "#000000",
          primaryBtnBg: "linear-gradient(110deg, #16c96f, #38bdf8)",
          primaryBtnBorder: "none",
          primaryBtnRadius: 8,
          primaryBtnFontSize: 14,
          primaryBtnWeight: "800",

          showSecondaryBtn: true,
          secondaryBtnText: "Contáctanos",
          secondaryBtnLink: "#contacto",
          secondaryBtnNewTab: false,
          secondaryBtnColor: "#ffffff",
          secondaryBtnBg: "rgba(255, 255, 255, 0.06)",
          secondaryBtnBorder: "1px solid rgba(255, 255, 255, 0.15)",
          secondaryBtnRadius: 8,
          secondaryBtnFontSize: 14,
          secondaryBtnWeight: "700",

          heroBg: "radial-gradient(circle at center, rgba(22,201,111,0.15), rgba(7,21,34,0.8) 70%)",
          heroBorderColor: "rgba(56,189,248,0.15)",
          heroBorderRadius: 12,
          heroPaddingY: 50,
          heroPaddingX: 20,
          align: "center",
        };
      case "services": {
        const liveServices = dbData.services.length > 0
          ? dbData.services.slice(0, 6).map((s: any) => ({
              icon: s.icon || "⚡",
              title: s.title || s.name || "Servicio",
              desc: s.description || s.shortDesc || "Descripción del servicio.",
              link: `/servicios/${s.slug || ""}`,
            }))
          : [
              {
                icon: "⚡",
                title: "Desarrollo Web & SaaS",
                desc: "Aplicaciones web modernas, ultra rápidas y escalables con Next.js y TypeScript.",
                link: "/servicios",
              },
              {
                icon: "☁️",
                title: "Cloud & DevOps",
                desc: "Arquitecturas cloud seguras, CI/CD automatizado y alta disponibilidad.",
                link: "/servicios",
              },
              {
                icon: "🎨",
                title: "Diseño UI/UX & Producto",
                desc: "Interfaces cautivadoras centradas en la conversión y experiencia del usuario.",
                link: "/servicios",
              },
            ];

        return {
          sectionTitle: "SERVICIOS DESTACADOS",
          linkText: "Ver todos los servicios",
          linkUrl: "/servicios",
          items: liveServices,
        };
      }
      case "testimonials": {
        const liveTestimonials = dbData.testimonials.length > 0
          ? dbData.testimonials.slice(0, 4).map((t: any) => ({
              quote: t.content || t.quote || "Excelente trabajo y gran profesionalismo.",
              name: t.name || "Cliente Satisfecho",
              role: t.role || t.company || "Cliente",
              initials: (t.name || "CL").split(" ").map((n: string) => n[0]).join("").slice(0, 2).toUpperCase(),
              stars: t.rating || 5,
            }))
          : [
              {
                quote: "Soporte inmediato y soluciones efectivas, 100% recomendado.",
                name: "Javier Rojas",
                role: "Gerente de TI",
                initials: "JR",
                stars: 5,
              },
              {
                quote: "Mi sitio web ahora es más rápido, seguro y fácil de administrar.",
                name: "María López",
                role: "Emprendedora",
                initials: "ML",
                stars: 5,
              },
              {
                quote: "Gran conocimiento en WordPress y servidores, un experto.",
                name: "Ana Torres",
                role: "Diseñadora Gráfica",
                initials: "AT",
                stars: 5,
              },
              {
                quote: "Excelente trabajo, muy profesional y cumplió con todo lo acordado.",
                name: "Carlos Méndez",
                role: "CEO, Importaciones CM",
                initials: "CM",
                stars: 5,
              },
            ];

        return {
          sectionTitle: "LO QUE DICEN MIS CLIENTES",
          linkText: "Ver más testimonios",
          linkUrl: "/testimonios",
          items: liveTestimonials,
        };
      }
      case "articles": {
        const livePosts = dbData.posts.length > 0
          ? dbData.posts.slice(0, 3).map((p: any) => ({
              category: p.category?.name?.toUpperCase() || "ARTÍCULO",
              date: new Date(p.createdAt || Date.now()).toLocaleDateString("es-ES", { day: "2-digit", month: "short", year: "numeric" }).toUpperCase(),
              title: p.title || "Artículo",
              excerpt: p.excerpt || (p.content ? p.content.replace(/<[^>]*>?/gm, "").slice(0, 110) + "..." : "Aprende las mejores prácticas en desarrollo y tecnología."),
              slug: p.slug,
            }))
          : [
              {
                category: "DESARROLLO",
                date: "24 AGO 2026",
                title: "Arquitectura moderna con Next.js 15",
                excerpt: "Aprende las mejores prácticas para construir plataformas web ultrarrápidas y optimizadas.",
              },
              {
                category: "BASE DE DATOS",
                date: "20 AGO 2026",
                title: "Optimización de consultas y caché en MySQL",
                excerpt: "Guía completa de indexación y particionado para soportar millones de visitas.",
              },
              {
                category: "INTELIGENCIA ARTIFICIAL",
                date: "15 AGO 2026",
                title: "Integración de IA generativa en aplicaciones SaaS",
                excerpt: "Descubre cómo acelerar flujos de trabajo integrando modelos de lenguaje.",
              },
            ];

        return {
          sectionTitle: "ARTÍCULOS Y RECURSOS",
          linkText: "Ver todos los artículos",
          linkUrl: "/posts",
          items: livePosts,
        };
      }
      case "gallery": {
        const liveProjects = dbData.projects.length > 0
          ? dbData.projects.slice(0, 3).map((proj: any) => ({
              title: proj.title || "Proyecto",
              category: proj.category?.name?.toUpperCase() || "PROYECTO",
              image: proj.image || proj.coverImage || "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=600&q=80",
            }))
          : [
              {
                title: "Plataforma E-Commerce Tech",
                category: "TIENDA ONLINE",
                image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=600&q=80",
              },
              {
                title: "Dashboard de Métricas SaaS",
                category: "WEB APPLICATION",
                image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=600&q=80",
              },
              {
                title: "App Móvil de Pagos",
                category: "FINTECH",
                image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=600&q=80",
              },
            ];

        return {
          sectionTitle: "GALERÍA DE PROYECTOS",
          linkText: "Ver proyectos",
          linkUrl: "/proyectos",
          items: liveProjects,
        };
      }
      case "star-rating":
        return {
          rating: 4.5,
          maxRating: 5,
          starColor: "#f59e0b",
          title: "Valoración Excelente",
          showScore: true,
          starSize: 18,
          align: "left",
        };
      case "icon":
        return {
          icon: "sparkles",
          iconColor: "#16c96f",
          iconBg: "rgba(22, 201, 111, 0.15)",
          iconSize: 28,
          shape: "circle",
          linkUrl: "",
          align: "left",
        };
      case "image-box":
        return {
          imageUrl: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80",
          title: "Infraestructura Cloud",
          description: "Despliegues automatizados y alta disponibilidad con arquitectura serverless y Kubernetes.",
          linkText: "Conocer más →",
          linkUrl: "#",
          align: "center",
          borderRadius: 8,
        };
      case "icon-box":
        return {
          icon: "⚡",
          title: "Velocidad Extrema",
          description: "Optimización de Core Web Vitals para tiempos de carga inferiores a 0.5 segundos.",
          linkText: "Ver benchmarks →",
          linkUrl: "#",
          iconColor: "#16c96f",
          align: "left",
        };
      case "carousel":
        return {
          height: 280,
          borderRadius: 10,
          autoplay: true,
          autoplaySpeed: 3000,
          pauseOnHover: true,
          slidesToShow: 3,
          showArrows: true,
          showDots: true,
          images: [
            { url: "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80", caption: "Tecnología de Punta" },
            { url: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80", caption: "Diseño & Estrategia" },
            { url: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80", caption: "Métricas & Resultados" },
          ],
        };
      case "icon-list":
        return {
          iconColor: "#16c96f",
          textColor: "#e2e8f0",
          align: "left",
          items: [
            { icon: "✓", text: "Desarrollo con Next.js 15 & React Server Components" },
            { icon: "✓", text: "Base de Datos Relacional MySQL RDS & Prisma ORM" },
            { icon: "✓", text: "Seguridad y Certificados SSL automáticos" },
            { icon: "✓", text: "Soporte y Garantía técnica personalizada" },
          ],
        };
      case "counter":
        return {
          startingNumber: 0,
          endingNumber: 150,
          prefix: "+",
          suffix: "K",
          title: "Usuarios Activos al Mes",
          numberColor: "#16c96f",
          numberSize: 42,
          titleColor: "#94a3b8",
          align: "center",
        };
      case "spacer":
        return {
          spaceHeight: 50,
        };
      case "testimonial-card":
        return {
          quote: "El mejor servicio de desarrollo que hemos contratado. Entregaron a tiempo y con una calidad técnica insuperable.",
          author: "María González",
          role: "CEO en FinTech Global",
          rating: 5,
          initials: "MG",
          cardBg: "#040e1a",
          borderColor: "rgba(56, 189, 248, 0.15)",
        };
      case "tabs":
        return {
          tabColor: "#16c96f",
          tabs: [
            { title: "Características", content: "Arquitectura moderna, escalable y optimizada para máxima velocidad y SEO técnico." },
            { title: "Especificaciones", content: "Desarrollado en TypeScript, Tailwind CSS, Next.js y persistencia en MySQL AWS." },
            { title: "Garantía", content: "Todos los desarrollos cuentan con soporte continuo, monitoreo y respaldo 24/7." },
          ],
        };
      case "accordion":
        return {
          items: [
            { title: "¿Cómo funciona el proceso de desarrollo?", content: "Analizamos tu visión, diseñamos la maqueta interactiva y construimos el software en iteraciones rápidas." },
            { title: "¿Qué tecnologías utilizan?", content: "Trabajamos con el stack líder del mercado: Next.js, React, Node.js, Prisma y AWS." },
            { title: "¿Ofrecen soporte y mantenimiento post-entrega?", content: "Sí, todos los proyectos cuentan con garantía técnica y planes de soporte prioritario." },
          ],
        };
      case "toggle":
        return {
          title: "¿Se puede migrar desde WordPress fácilmente?",
          content: "Sí, nuestro sistema permite importar todo tu contenido, URLs, slugs y optimizaciones SEO sin perder posicionamiento en Google.",
          isOpen: true,
        };
      case "social-icons":
        return {
          shape: "circle",
          size: 38,
          align: "center",
          networks: [
            { name: "LinkedIn", url: "https://linkedin.com", color: "#0077b5", icon: "💼" },
            { name: "GitHub", url: "https://github.com", color: "#24292e", icon: "🐙" },
            { name: "Twitter/X", url: "https://twitter.com", color: "#1da1f2", icon: "🐦" },
            { name: "WhatsApp", url: "https://wa.me/51999999999", color: "#25d366", icon: "💬" },
          ],
        };
      case "progress-bar":
        return {
          title: "Optimización de Rendimiento Web",
          percentage: 95,
          barColor: "#16c96f",
          showPercentage: true,
          height: 12,
        };
      case "soundcloud":
        return {
          audioUrl: "https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/293&color=%2316c96f&auto_play=false&hide_related=true&show_comments=false&show_user=true&show_reposts=false&show_teaser=false",
          title: "Audio Podcast TechLab",
          height: 140,
        };
      case "shortcode":
        return {
          shortcode: "[form_contacto id='principal']",
          fallbackText: "Formulario de Contacto Dinámico TechLab",
        };
      case "html":
        return {
          customHtml: `<div style="padding: 24px; text-align: center; background: rgba(56,189,248,0.06); border: 1px dashed rgba(56,189,248,0.3); border-radius: 8px;">\n  <h3 style="color: #38bdf8; margin: 0 0 8px;">Código HTML / CSS Embebido</h3>\n  <p style="color: #94a3b8; font-size: 13px; margin: 0;">Inserta cualquier etiqueta HTML, estilos en línea o scripts embebidos aquí.</p>\n</div>`,
        };
      case "menu-anchor":
        return {
          anchorId: "contacto",
          label: "Ancla: #contacto",
        };
      case "alert":
        return {
          alertType: "info",
          title: "¡Información Importante!",
          message: "Esta sección cuenta con certificado SSL de alta seguridad y respaldo en la nube.",
          dismissible: true,
        };
      case "sidebar-widget":
        return {
          title: "Navegación Rápida",
          links: [
            { text: "Inicio", url: "/" },
            { text: "Servicios Especializados", url: "/servicios" },
            { text: "Casos de Éxito & Portafolio", url: "/proyectos" },
            { text: "Artículos del Blog", url: "/posts" },
            { text: "Contáctanos", url: "#contacto" },
          ],
        };
      case "text-path":
        return {
          text: "✨ INGENIERÍA • TECNOLOGÍA • INNOVACIÓN • ESCALABILIDAD • RENDIMIENTO • ",
          textColor: "#38bdf8",
          fontSize: 16,
          fontWeight: "800",
        };
      default:
        return {};
    }
  };

  useEffect(() => {
    const loadPageData = async () => {
      setIsLoading(true);
      try {
        // 1. Cargar datos de la página (por ID o por Slug)
        let targetPage = null;
        if (pageId) {
          const res = await fetch(`/api/pages?id=${encodeURIComponent(pageId)}`);
          const data = await res.json();
          if (data.page) targetPage = data.page;
        } else if (querySlug) {
          const res = await fetch(`/api/pages?slug=${encodeURIComponent(querySlug)}`);
          const data = await res.json();
          if (data.page) targetPage = data.page;
        }

        if (targetPage) {
          setPageTitle(targetPage.title || `Elementor #${targetPage.id.slice(0, 4)}`);
          setPageSlug(targetPage.slug || "");
          setPageStatus((targetPage.status as "Borrador" | "Publicado") || "Borrador");

          // Restaurar estructura de contenedores guardados con Elementor
          if (targetPage.content) {
            const raw = targetPage.content.trim();
            if (raw.startsWith("[") && raw.endsWith("]")) {
              try {
                const parsed = JSON.parse(raw);
                if (Array.isArray(parsed) && parsed.length > 0) {
                  setContainers(parsed);
                }
              } catch (err) {
                console.warn("Error al parsear JSON puro:", err);
              }
            } else if (raw.includes("<!-- ELEMENTOR_DATA_START -->")) {
              try {
                const match = raw.match(/<!-- ELEMENTOR_DATA_START -->([\s\S]*?)<!-- ELEMENTOR_DATA_END -->/);
                if (match && match[1]) {
                  const parsed = JSON.parse(match[1]);
                  if (Array.isArray(parsed) && parsed.length > 0) {
                    setContainers(parsed);
                  }
                }
              } catch (err) {
                console.warn("No se pudo restaurar el árbol JSON de Elementor:", err);
              }
            }
          }
        }

        // 2. Cargar datos reales de la Base de Datos (Posts, Servicios, Testimonios, Proyectos)
        const [postsRes, servRes, testRes, projRes] = await Promise.allSettled([
          fetch("/api/posts").then((r) => r.json()),
          fetch("/api/services").then((r) => r.json()),
          fetch("/api/testimonials").then((r) => r.json()),
          fetch("/api/projects").then((r) => r.json()),
        ]);

        const posts = postsRes.status === "fulfilled" && postsRes.value?.posts ? postsRes.value.posts : [];
        const services = servRes.status === "fulfilled" && servRes.value?.services ? servRes.value.services : [];
        const testimonials = testRes.status === "fulfilled" && testRes.value?.testimonials ? testRes.value.testimonials : [];
        const projects = projRes.status === "fulfilled" && projRes.value?.projects ? projRes.value.projects : [];

        setDbData({ posts, services, testimonials, projects });
      } catch (err) {
        console.error("Error al cargar datos:", err);
      } finally {
        setIsLoading(false);
      }
    };
    loadPageData();
  }, [pageId, querySlug]);

  const generateCanvasHtml = (): string => {
    if (containers.length === 0) return "";
    let html = `<div class="elementor-rendered-root" style="font-family: inherit; color: #cbd5e1; width: 100%;">`;
    containers.forEach((cont) => {
      const isRow = cont.direction === "row";
      const contStyles = `display: flex; flex-direction: ${cont.direction}; flex-wrap: wrap; gap: ${cont.styles.gap || 20}px; padding: ${cont.styles.paddingTop || 30}px ${cont.styles.paddingRight || 20}px ${cont.styles.paddingBottom || 30}px ${cont.styles.paddingLeft || 20}px; background-color: ${cont.styles.backgroundColor || "transparent"}; border-radius: ${cont.styles.borderRadius || 0}px; justify-content: ${cont.styles.justifyContent || "flex-start"};`.replace(/\s+/g, " ");
      html += `<div class="elementor-container-block" style="${contStyles}">`;
      cont.columns.forEach((col) => {
        const colWidth = col.width || (isRow ? `${100 / cont.columns.length}%` : "100%");
        html += `<div class="elementor-col-block" style="flex: 1 1 ${colWidth}; max-width: ${colWidth}; display: flex; flex-direction: column; gap: 16px;">`;
        col.widgets.forEach((wid) => {
          html += renderWidgetToHtml(wid);
        });
        html += `</div>`;
      });
      html += `</div>`;
    });
    html += `</div>`;
    return html;
  };

  const renderWidgetToHtml = (wid: WidgetItem): string => {
    const s = wid.settings || {};

    switch (wid.type) {
      case "heading": {
        const align = s.align || "left";
        const tag = s.tag || "h2";
        const color = s.textColor || "#ffffff";
        const size = s.fontSize || 32;
        const weight = s.fontWeight || "800";
        const transform = s.textTransform || "none";
        const spacing = s.letterSpacing ? `${s.letterSpacing}px` : "normal";
        const mTop = s.marginTop ?? 0;
        const mBottom = s.marginBottom ?? 12;
        const pTop = s.paddingTop ?? 0;
        const pBottom = s.paddingBottom ?? 0;
        const barMargin = align === "center" ? "6px auto 0" : (align === "right" ? "6px 0 0 auto" : "6px 0 0 0");

        let innerTitle = `<${tag} style="color: ${color}; font-size: ${size}px; font-weight: ${weight}; text-transform: ${transform}; letter-spacing: ${spacing}; line-height: 1.25; margin: 0;">${s.title || "Tu Encabezado Principal"}</${tag}>`;
        if (s.linkUrl) {
          innerTitle = `<a href="${s.linkUrl}" style="text-decoration: none; color: inherit; display: inline-block;">${innerTitle}</a>`;
        }

        return `
          <div class="elementor-heading-widget" style="text-align: ${align}; margin-top: ${mTop}px; margin-bottom: ${mBottom}px; padding-top: ${pTop}px; padding-bottom: ${pBottom}px; width: 100%;">
            ${innerTitle}
            ${s.hasAccentBar ? `<div style="width: 44px; height: 3px; background: #16c96f; border-radius: 2px; margin: ${barMargin};"></div>` : ""}
          </div>
        `;
      }

      case "text": {
        const align = s.align || "left";
        const color = s.textColor || "#94a3b8";
        const size = s.fontSize || 16;
        const weight = s.fontWeight || "400";
        const transform = s.textTransform || "none";
        const mTop = s.marginTop ?? 0;
        const mBottom = s.marginBottom ?? 12;
        const pTop = s.paddingTop ?? 0;
        const pBottom = s.paddingBottom ?? 0;
        return `
          <div class="elementor-text-widget" style="text-align: ${align}; font-size: ${size}px; font-weight: ${weight}; text-transform: ${transform}; line-height: 1.8; color: ${color}; margin-top: ${mTop}px; margin-bottom: ${mBottom}px; padding-top: ${pTop}px; padding-bottom: ${pBottom}px; width: 100%;">
            ${s.content || "<p>Escribe tu contenido aquí con texto enriquecido.</p>"}
          </div>
        `;
      }

      case "image": {
        const align = s.align || "center";
        const width = s.width || "100%";
        const radius = s.borderRadius ?? 8;
        const mTop = s.marginTop ?? 12;
        const mBottom = s.marginBottom ?? 12;
        const imgTag = `<img src="${s.imageUrl || "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=80"}" alt="${s.imageAlt || ""}" style="max-width: ${width}; width: 100%; border-radius: ${radius}px; box-shadow: 0 10px 30px rgba(0,0,0,0.5); display: inline-block;" />`;
        return `
          <div class="elementor-image-widget" style="text-align: ${align}; margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%;">
            ${s.linkUrl ? `<a href="${s.linkUrl}" style="display: inline-block; max-width: ${width}; width: 100%;">${imgTag}</a>` : imgTag}
          </div>
        `;
      }

      case "button": {
        const align = s.buttonAlign || s.align || "left";
        const mTop = s.marginTop ?? 14;
        const mBottom = s.marginBottom ?? 14;
        const isFull = align === "justify";
        const btnAlignStyle = isFull ? "width: 100%;" : (align === "center" ? "margin: 0 auto;" : (align === "right" ? "margin-left: auto;" : "margin-right: auto;"));
        
        let textColor = s.buttonTextColor || s.textColor || "#000000";
        let bg = s.buttonBgColor || "#16c96f";
        
        if (s.buttonBgType === "gradient") {
          const gStart = s.buttonBgColor || "#16c96f";
          const gEnd = s.buttonGradientEnd || "#38bdf8";
          bg = `linear-gradient(110deg, ${gStart}, ${gEnd})`;
        } else if (s.buttonBgType === "transparent" || s.buttonVariant === "outline") {
          bg = "transparent";
          if (!s.buttonTextColor) textColor = s.buttonBorderColor || "#16c96f";
        } else if (s.buttonVariant === "dark") {
          bg = s.buttonBgColor || "#1e293b";
          textColor = s.buttonTextColor || "#ffffff";
        } else if (s.buttonVariant === "primary" && !s.buttonBgColor) {
          bg = "linear-gradient(110deg, #16c96f, #38bdf8)";
          textColor = "#000000";
        }

        let border = "none";
        if (s.buttonBorderWidth && s.buttonBorderWidth > 0) {
          border = `${s.buttonBorderWidth}px ${s.buttonBorderStyle || "solid"} ${s.buttonBorderColor || "#16c96f"}`;
        } else if (s.buttonVariant === "outline") {
          border = `1px solid ${s.buttonBorderColor || "#16c96f"}`;
        } else if (s.buttonBorderColor && s.buttonBorderColor !== "transparent") {
          border = `1px solid ${s.buttonBorderColor}`;
        }

        const radius = s.buttonRadius ?? s.borderRadius ?? 8;
        const padX = s.buttonPaddingX ?? 24;
        const padY = s.buttonPaddingY ?? 12;
        const fontSize = s.buttonFontSize ?? (s.buttonSize === "small" ? 12 : (s.buttonSize === "large" ? 16 : 14));
        const fontWeight = s.buttonFontWeight || "800";
        const textTransform = s.buttonTextTransform || "none";
        const letterSpacing = s.buttonLetterSpacing ?? 0;

        let shadow = "0 4px 14px rgba(22,201,111,0.3)";
        if (s.buttonShadow === "none") shadow = "none";
        else if (s.buttonShadow === "soft") shadow = "0 4px 12px rgba(0,0,0,0.15)";
        else if (s.buttonShadow === "neon") shadow = "0 4px 18px rgba(22,201,111,0.45)";
        else if (s.buttonShadow === "glow3d") shadow = "0 8px 24px rgba(214,51,132,0.4)";

        const iconMap: Record<string, string> = {
          arrow: "→",
          sparkles: "✨",
          external: "↗",
          download: "⬇",
          phone: "📞",
          mail: "✉",
          whatsapp: "💬",
          check: "✓",
        };
        const iconChar = s.buttonIcon && s.buttonIcon !== "none" ? (iconMap[s.buttonIcon] || "→") : "";
        const iconPos = s.buttonIconPos || "right";
        const iconGap = s.buttonIconGap ?? 8;

        const targetAttr = s.buttonNewTab ? `target="_blank" rel="noopener noreferrer"` : "";

        return `
          <div class="elementor-button-widget" style="text-align: ${isFull ? "center" : align}; margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%;">
            <a href="${s.buttonLink || "#"}" ${targetAttr} style="display: ${isFull ? "flex" : "inline-flex"}; justify-content: center; align-items: center; gap: ${iconGap}px; padding: ${padY}px ${padX}px; background: ${bg}; color: ${textColor}; font-weight: ${fontWeight}; font-size: ${fontSize}px; text-transform: ${textTransform}; letter-spacing: ${letterSpacing}px; border-radius: ${radius}px; border: ${border}; text-decoration: none; box-shadow: ${shadow}; transition: all 0.2s ease; ${btnAlignStyle}">
              ${iconPos === "left" && iconChar ? `<span style="font-size: 1.1em;">${iconChar}</span>` : ""}
              <span>${s.buttonText || "Comenzar Ahora"}</span>
              ${iconPos === "right" && iconChar ? `<span style="font-size: 1.1em;">${iconChar}</span>` : ""}
            </a>
          </div>
        `;
      }

      case "youtube":
      case "video": {
        const align = s.align || "center";
        const maxWidth = s.maxWidth || "100%";
        return `
          <div style="text-align: ${align}; width: 100%; margin: 16px 0;">
            <div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; border-radius: 12px; max-width: ${maxWidth}; margin: 0 auto; border: 1px solid rgba(255,255,255,0.1);">
              <iframe src="${s.videoUrl || "https://www.youtube.com/embed/dQw4w9WgXcQ"}" style="position: absolute; top:0; left: 0; width: 100%; height: 100%; border:0;" allowfullscreen></iframe>
            </div>
          </div>
        `;
      }

      case "separator": {
        const align = s.align || "center";
        const width = s.width || "100%";
        const thickness = s.thickness || 1;
        const color = s.color || "rgba(255,255,255,0.12)";
        const margin = s.margin ?? 24;
        const alignMargin = align === "center" ? "0 auto" : (align === "right" ? "0 0 0 auto" : "0 auto 0 0");
        return `
          <div style="width: 100%; padding: ${margin}px 0;">
            <hr style="border: none; border-top: ${thickness}px solid ${color}; width: ${width}; margin: ${alignMargin};" />
          </div>
        `;
      }

      case "hero": {
        const align = s.align || "center";
        const justify = align === "center" ? "center" : (align === "right" ? "flex-end" : "flex-start");
        
        const badgeText = s.badge ?? "✨ TECNOLOGÍA & INNOVACIÓN";
        const showBadge = s.showBadge !== false && !!badgeText;
        const badgeTextColor = s.badgeTextColor || "#16c96f";
        const badgeBgColor = s.badgeBgColor || "rgba(22, 201, 111, 0.12)";
        const badgeBorderColor = s.badgeBorderColor || "rgba(22, 201, 111, 0.3)";

        const heroTitle = s.heroTitle ?? "Transforma tu Futuro Digital";
        const heroTitleColor = s.heroTitleColor || s.textColor || "#ffffff";
        const heroTitleSize = s.heroTitleSize || (s.fontSize && s.fontSize > 20 ? s.fontSize : 38);
        const heroTitleWeight = s.heroTitleWeight || s.fontWeight || "900";
        const heroTitleLineHeight = s.heroTitleLineHeight || 1.2;

        const heroSubtitle = s.heroSubtitle ?? "Soluciones a medida construidas con tecnología de última generación para máxima escalabilidad y rendimiento.";
        const heroSubtitleColor = s.heroSubtitleColor || "#94a3b8";
        const heroSubtitleSize = s.heroSubtitleSize || 16;
        const heroSubtitleWeight = s.heroSubtitleWeight || "400";
        const heroSubtitleLineHeight = s.heroSubtitleLineHeight || 1.7;
        const heroSubtitleMaxWidth = s.heroSubtitleMaxWidth || 650;

        const showPrimary = s.showPrimaryBtn !== false && (s.primaryBtnText || "Ver Servicios →");
        const primaryText = s.primaryBtnText || "Ver Servicios →";
        const primaryLink = s.primaryBtnLink || "#";
        const primaryTarget = s.primaryBtnNewTab ? `target="_blank" rel="noopener noreferrer"` : "";
        const primaryColor = s.primaryBtnColor || "#000000";
        const primaryBg = s.primaryBtnBg || "linear-gradient(110deg, #16c96f, #38bdf8)";
        const primaryBorder = s.primaryBtnBorder || "none";
        const primaryRadius = s.primaryBtnRadius ?? 8;
        const primaryFontSize = s.primaryBtnFontSize || 14;
        const primaryWeight = s.primaryBtnWeight || "800";

        const showSecondary = s.showSecondaryBtn !== false && s.secondaryBtnText;
        const secondaryText = s.secondaryBtnText || "";
        const secondaryLink = s.secondaryBtnLink || "#";
        const secondaryTarget = s.secondaryBtnNewTab ? `target="_blank" rel="noopener noreferrer"` : "";
        const secondaryColor = s.secondaryBtnColor || "#ffffff";
        const secondaryBg = s.secondaryBtnBg || "rgba(255,255,255,0.06)";
        const secondaryBorder = s.secondaryBtnBorder || "1px solid rgba(255,255,255,0.15)";
        const secondaryRadius = s.secondaryBtnRadius ?? 8;
        const secondaryFontSize = s.secondaryBtnFontSize || 14;
        const secondaryWeight = s.secondaryBtnWeight || "700";

        const heroBg = s.heroBg || "radial-gradient(circle at center, rgba(22,201,111,0.15), rgba(7,21,34,0.8) 70%)";
        const heroBorderColor = s.heroBorderColor || "rgba(56,189,248,0.15)";
        const heroBorderRadius = s.heroBorderRadius ?? 12;
        const heroPaddingY = s.heroPaddingY ?? 50;
        const heroPaddingX = s.heroPaddingX ?? 20;

        return `
          <div style="width: 100%; text-align: ${align}; padding: ${heroPaddingY}px ${heroPaddingX}px; background: ${heroBg}; border: 1px solid ${heroBorderColor}; border-radius: ${heroBorderRadius}px; box-shadow: 0 10px 40px rgba(0,0,0,0.5); margin: 12px 0; box-sizing: border-box;">
            ${showBadge ? `
              <div style="display: inline-flex; align-items: center; gap: 6px; padding: 4px 14px; background: ${badgeBgColor}; border: 1px solid ${badgeBorderColor}; border-radius: 20px; color: ${badgeTextColor}; font-size: 11px; font-weight: 700; margin-bottom: 16px; text-transform: uppercase; letter-spacing: 0.5px;">
                ${badgeText}
              </div>
            ` : ""}
            <h1 style="font-size: ${heroTitleSize}px; font-weight: ${heroTitleWeight}; color: ${heroTitleColor}; line-height: ${heroTitleLineHeight}; margin: 0 0 14px; letter-spacing: -0.5px;">
              ${heroTitle}
            </h1>
            ${heroSubtitle ? `
              <p style="font-size: ${heroSubtitleSize}px; font-weight: ${heroSubtitleWeight}; line-height: ${heroSubtitleLineHeight}; color: ${heroSubtitleColor}; max-width: ${heroSubtitleMaxWidth}px; ${align === "center" ? "margin: 0 auto 24px;" : (align === "right" ? "margin: 0 0 24px auto;" : "margin: 0 0 24px 0;")}">
                ${heroSubtitle}
              </p>
            ` : ""}
            <div style="display: flex; align-items: center; justify-content: ${justify}; gap: 12px; flex-wrap: wrap;">
              ${showPrimary ? `
                <a href="${primaryLink}" ${primaryTarget} style="display: inline-flex; align-items: center; gap: 8px; padding: 12px 24px; background: ${primaryBg}; color: ${primaryColor}; font-weight: ${primaryWeight}; font-size: ${primaryFontSize}px; border-radius: ${primaryRadius}px; border: ${primaryBorder}; text-decoration: none; box-shadow: 0 4px 14px rgba(22,201,111,0.3); transition: all 0.2s ease;">
                  ${primaryText}
                </a>
              ` : ""}
              ${showSecondary ? `
                <a href="${secondaryLink}" ${secondaryTarget} style="display: inline-flex; align-items: center; gap: 8px; padding: 12px 24px; background: ${secondaryBg}; border: ${secondaryBorder}; color: ${secondaryColor}; font-weight: ${secondaryWeight}; font-size: ${secondaryFontSize}px; border-radius: ${secondaryRadius}px; text-decoration: none; transition: all 0.2s ease;">
                  ${secondaryText}
                </a>
              ` : ""}
            </div>
          </div>
        `;
      }

      case "services": {
        const items = s.items || getDefaultWidgetSettings("services").items;
        return `
          <div style="width: 100%; padding: 16px 0; margin: 12px 0;">
            <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 20px; border-bottom: 1px solid rgba(255,255,255,0.06); padding-bottom: 12px;">
              <div>
                <h3 style="font-size: 19px; font-weight: 800; color: #ffffff; text-transform: uppercase; letter-spacing: 0.5px; margin: 0 0 6px;">
                  ${s.sectionTitle || "SERVICIOS DESTACADOS"}
                </h3>
                <div style="width: 44px; height: 3px; background: #16c96f; border-radius: 2px;"></div>
              </div>
              ${s.linkText ? `<a href="${s.linkUrl || "#"}" style="font-size: 13px; font-weight: 600; color: #94a3b8; text-decoration: none;">${s.linkText} →</a>` : ""}
            </div>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 16px;">
              ${items.map((item: any) => `
                <div style="background: #040e1a; border: 1px solid rgba(56, 189, 248, 0.15); border-radius: 10px; padding: 22px; display: flex; flex-direction: column; justify-content: space-between; gap: 14px; box-shadow: 0 8px 24px rgba(0,0,0,0.4);">
                  <div>
                    <div style="display: inline-flex; align-items: center; justify-content: center; width: 42px; height: 42px; background: rgba(22, 201, 111, 0.15); border: 1px solid rgba(22, 201, 111, 0.3); border-radius: 8px; color: #16c96f; margin-bottom: 14px; font-size: 20px;">
                      ${item.icon || "⚡"}
                    </div>
                    <h4 style="font-size: 16px; font-weight: 700; color: #ffffff; margin: 0 0 8px;">${item.title}</h4>
                    <p style="font-size: 13px; line-height: 1.6; color: #94a3b8; margin: 0;">${item.desc}</p>
                  </div>
                  <a href="${item.link || "#"}" style="font-size: 12px; font-weight: 700; color: #16c96f; text-decoration: none;">Saber más →</a>
                </div>
              `).join("")}
            </div>
          </div>
        `;
      }

      case "testimonials": {
        const items = s.items || getDefaultWidgetSettings("testimonials").items;
        return `
          <div style="width: 100%; padding: 16px 0; margin: 12px 0;">
            <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 20px; border-bottom: 1px solid rgba(255,255,255,0.06); padding-bottom: 12px;">
              <div>
                <h3 style="font-size: 19px; font-weight: 800; color: #ffffff; text-transform: uppercase; letter-spacing: 0.5px; margin: 0 0 6px;">
                  ${s.sectionTitle || "LO QUE DICEN MIS CLIENTES"}
                </h3>
                <div style="width: 44px; height: 3px; background: #16c96f; border-radius: 2px;"></div>
              </div>
              ${s.linkText ? `<a href="${s.linkUrl || "#"}" style="font-size: 13px; font-weight: 600; color: #94a3b8; text-decoration: none;">${s.linkText} →</a>` : ""}
            </div>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); gap: 16px;">
              ${items.map((item: any) => `
                <div style="background: #040e1a; border: 1px solid rgba(56, 189, 248, 0.15); border-radius: 10px; padding: 20px; display: flex; flex-direction: column; justify-content: space-between; gap: 16px; box-shadow: 0 8px 24px rgba(0,0,0,0.4);">
                  <p style="font-size: 13px; line-height: 1.6; color: #e2e8f0; margin: 0; font-weight: 400;">
                    "${item.quote}"
                  </p>
                  <div>
                    <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                      <div style="width: 36px; height: 36px; border-radius: 50%; background: #10b981; color: #022c22; font-weight: 800; font-size: 13px; display: grid; place-items: center;">
                        ${item.initials || "CL"}
                      </div>
                      <div>
                        <div style="font-size: 13px; font-weight: 700; color: #ffffff; line-height: 1.2;">${item.name}</div>
                        <div style="font-size: 11px; color: #94a3b8; margin-top: 2px;">${item.role}</div>
                      </div>
                    </div>
                    <div style="color: #10b981; font-size: 12px; letter-spacing: 2px;">★★★★★</div>
                  </div>
                </div>
              `).join("")}
            </div>
          </div>
        `;
      }

      case "articles": {
        const items = s.items || getDefaultWidgetSettings("articles").items;
        return `
          <div style="width: 100%; padding: 16px 0; margin: 12px 0;">
            <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 20px; border-bottom: 1px solid rgba(255,255,255,0.06); padding-bottom: 12px;">
              <div>
                <h3 style="font-size: 19px; font-weight: 800; color: #ffffff; text-transform: uppercase; letter-spacing: 0.5px; margin: 0 0 6px;">
                  ${s.sectionTitle || "ARTÍCULOS Y RECURSOS"}
                </h3>
                <div style="width: 44px; height: 3px; background: #16c96f; border-radius: 2px;"></div>
              </div>
              ${s.linkText ? `<a href="${s.linkUrl || "#"}" style="font-size: 13px; font-weight: 600; color: #94a3b8; text-decoration: none;">${s.linkText} →</a>` : ""}
            </div>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 16px;">
              ${items.map((item: any) => `
                <div style="background: #040e1a; border: 1px solid rgba(255,255,255,0.08); border-radius: 10px; overflow: hidden; display: flex; flex-direction: column; box-shadow: 0 8px 24px rgba(0,0,0,0.4);">
                  <div style="height: 120px; background: linear-gradient(135deg, #071524, #0f2742); position: relative; padding: 12px; display: flex; align-items: flex-start;">
                    <span style="background: rgba(22, 201, 111, 0.2); color: #16c96f; border: 1px solid rgba(22, 201, 111, 0.4); font-size: 10px; font-weight: 800; padding: 3px 8px; border-radius: 4px; text-transform: uppercase;">
                      ${item.category}
                    </span>
                  </div>
                  <div style="padding: 18px; display: flex; flex-direction: column; justify-content: space-between; flex: 1; gap: 10px;">
                    <div>
                      <span style="font-size: 11px; color: #64748b; font-weight: 600;">${item.date}</span>
                      <h4 style="font-size: 15px; font-weight: 700; color: #ffffff; margin: 6px 0 8px; line-height: 1.4;">${item.title}</h4>
                      <p style="font-size: 12px; line-height: 1.5; color: #94a3b8; margin: 0;">${item.excerpt}</p>
                    </div>
                    <a href="#" style="font-size: 12px; font-weight: 700; color: #38bdf8; text-decoration: none;">Leer artículo →</a>
                  </div>
                </div>
              `).join("")}
            </div>
          </div>
        `;
      }

      case "gallery": {
        const items = s.items || getDefaultWidgetSettings("gallery").items;
        return `
          <div style="width: 100%; padding: 16px 0; margin: 12px 0;">
            <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 20px; border-bottom: 1px solid rgba(255,255,255,0.06); padding-bottom: 12px;">
              <div>
                <h3 style="font-size: 19px; font-weight: 800; color: #ffffff; text-transform: uppercase; letter-spacing: 0.5px; margin: 0 0 6px;">
                  ${s.sectionTitle || "GALERÍA DE PROYECTOS"}
                </h3>
                <div style="width: 44px; height: 3px; background: #16c96f; border-radius: 2px;"></div>
              </div>
              ${s.linkText ? `<a href="${s.linkUrl || "#"}" style="font-size: 13px; font-weight: 600; color: #94a3b8; text-decoration: none;">${s.linkText} →</a>` : ""}
            </div>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 16px;">
              ${items.map((item: any) => `
                <div style="position: relative; border-radius: 10px; overflow: hidden; height: 180px; border: 1px solid rgba(56,189,248,0.2); box-shadow: 0 8px 24px rgba(0,0,0,0.4);">
                  <img src="${item.image}" alt="${item.title}" style="width: 100%; height: 100%; object-fit: cover;" />
                  <div style="position: absolute; inset: 0; background: linear-gradient(to top, rgba(2,11,20,0.95), transparent 60%); display: flex; flex-direction: column; justify-content: flex-end; padding: 14px;">
                    <span style="font-size: 10px; font-weight: 700; color: #16c96f; text-transform: uppercase;">${item.category}</span>
                    <h4 style="font-size: 14px; font-weight: 700; color: #ffffff; margin: 2px 0 0;">${item.title}</h4>
                  </div>
                </div>
              `).join("")}
            </div>
          </div>
        `;
      }

      case "star-rating": {
        const rating = parseFloat(s.rating) || 4.5;
        const maxRating = parseInt(s.maxRating) || 5;
        const starColor = s.starColor || "#f59e0b";
        const starSize = s.starSize || 18;
        const align = s.align || "left";
        const mTop = s.marginTop ?? 8;
        const mBottom = s.marginBottom ?? 8;
        
        let starsHtml = "";
        for (let i = 1; i <= maxRating; i++) {
          if (i <= rating) {
            starsHtml += `<span style="color: ${starColor}; font-size: ${starSize}px; margin-right: 2px;">★</span>`;
          } else if (i - 0.5 <= rating) {
            starsHtml += `<span style="color: ${starColor}; font-size: ${starSize}px; margin-right: 2px;">★</span>`;
          } else {
            starsHtml += `<span style="color: rgba(255,255,255,0.2); font-size: ${starSize}px; margin-right: 2px;">☆</span>`;
          }
        }

        return `
          <div class="elementor-star-rating-widget" style="text-align: ${align}; margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%;">
            <div style="display: inline-flex; align-items: center; gap: 8px; flex-wrap: wrap;">
              ${s.title ? `<span style="font-size: 14px; font-weight: 700; color: #ffffff;">${s.title}</span>` : ""}
              <div style="display: inline-flex; align-items: center;">${starsHtml}</div>
              ${s.showScore !== false ? `<span style="font-size: 13px; font-weight: 700; color: ${starColor};">(${rating.toFixed(1)} / ${maxRating})</span>` : ""}
            </div>
          </div>
        `;
      }

      case "icon": {
        const align = s.align || "left";
        const iconColor = s.iconColor || "#16c96f";
        const iconBg = s.iconBg || "rgba(22, 201, 111, 0.15)";
        const size = s.iconSize || 28;
        const shape = s.shape || "circle";
        const radius = shape === "circle" ? "50%" : (shape === "rounded" ? "8px" : "0px");
        const mTop = s.marginTop ?? 8;
        const mBottom = s.marginBottom ?? 8;
        
        const iconMap: Record<string, string> = {
          sparkles: "✨",
          star: "⭐",
          zap: "⚡",
          check: "✓",
          shield: "🛡️",
          rocket: "🚀",
          heart: "❤️",
          globe: "🌐",
          code: "💻",
          lock: "🔒",
        };
        const iconChar = iconMap[s.icon] || s.icon || "✨";

        const iconBox = `
          <div style="display: inline-flex; align-items: center; justify-content: center; width: ${size * 2}px; height: ${size * 2}px; background: ${iconBg}; border-radius: ${radius}; color: ${iconColor}; font-size: ${size}px; transition: transform 0.2s;">
            ${iconChar}
          </div>
        `;

        return `
          <div class="elementor-icon-widget" style="text-align: ${align}; margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%;">
            ${s.linkUrl ? `<a href="${s.linkUrl}" style="text-decoration: none; display: inline-block;">${iconBox}</a>` : iconBox}
          </div>
        `;
      }

      case "image-box": {
        const align = s.align || "center";
        const radius = s.borderRadius ?? 8;
        const mTop = s.marginTop ?? 12;
        const mBottom = s.marginBottom ?? 12;
        return `
          <div class="elementor-image-box-widget" style="text-align: ${align}; margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%; background: #040e1a; border: 1px solid rgba(255,255,255,0.08); border-radius: 12px; overflow: hidden; padding: 20px; box-shadow: 0 8px 24px rgba(0,0,0,0.35);">
            <img src="${s.imageUrl || "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80"}" alt="${s.title || ""}" style="width: 100%; height: 180px; object-fit: cover; border-radius: ${radius}px; margin-bottom: 16px;" />
            <h3 style="font-size: 18px; font-weight: 800; color: #ffffff; margin: 0 0 8px;">${s.title || "Infraestructura Cloud"}</h3>
            <p style="font-size: 14px; color: #94a3b8; line-height: 1.6; margin: 0 0 14px;">${s.description || "Despliegues automatizados y alta disponibilidad con arquitectura serverless y Kubernetes."}</p>
            ${s.linkText ? `<a href="${s.linkUrl || "#"}" style="font-size: 13px; font-weight: 700; color: #16c96f; text-decoration: none;">${s.linkText}</a>` : ""}
          </div>
        `;
      }

      case "icon-box": {
        const align = s.align || "left";
        const iconColor = s.iconColor || "#16c96f";
        const mTop = s.marginTop ?? 12;
        const mBottom = s.marginBottom ?? 12;
        return `
          <div class="elementor-icon-box-widget" style="text-align: ${align}; margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%; background: #040e1a; border: 1px solid rgba(56,189,248,0.15); border-radius: 12px; padding: 24px; box-shadow: 0 8px 24px rgba(0,0,0,0.35);">
            <div style="display: inline-flex; align-items: center; justify-content: center; width: 48px; height: 48px; border-radius: 10px; background: rgba(22, 201, 111, 0.12); color: ${iconColor}; font-size: 24px; margin-bottom: 14px;">
              ${s.icon || "⚡"}
            </div>
            <h3 style="font-size: 18px; font-weight: 800; color: #ffffff; margin: 0 0 8px;">${s.title || "Velocidad Extrema"}</h3>
            <p style="font-size: 14px; color: #94a3b8; line-height: 1.6; margin: 0 0 14px;">${s.description || "Optimización de Core Web Vitals para tiempos de carga inferiores a 0.5 segundos."}</p>
            ${s.linkText ? `<a href="${s.linkUrl || "#"}" style="font-size: 13px; font-weight: 700; color: #38bdf8; text-decoration: none;">${s.linkText}</a>` : ""}
          </div>
        `;
      }

      case "carousel": {
        const rawImages = s.images;
        const images = (Array.isArray(rawImages) && rawImages.length > 0)
          ? rawImages
          : ((rawImages === undefined) ? getDefaultWidgetSettings("carousel").images : []);
        const height = s.height || 280;
        const radius = s.borderRadius ?? 10;
        const mTop = s.marginTop ?? 12;
        const mBottom = s.marginBottom ?? 12;
        const autoplay = s.autoplay !== false;
        const autoplaySpeed = s.autoplaySpeed || 3000;
        const slidesToShow = s.slidesToShow || 3;
        const showArrows = s.showArrows !== false;
        const showDots = s.showDots !== false;
        const pauseOnHover = s.pauseOnHover !== false;
        const trackId = "track-" + wid.id;

        if (images.length === 0) {
          return `
            <div class="elementor-carousel-widget" style="margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%;">
              <div style="padding: 36px 20px; border: 2px dashed #2d3238; border-radius: 10px; background: rgba(24,27,30,0.5); text-align: center;">
                <span style="font-size: 28px; display: block; margin-bottom: 8px;">🎠</span>
                <p style="color: #94a3b8; font-size: 13px; margin: 0; font-weight: 600;">Carrusel vacío. Añade imágenes o súbelas desde el panel lateral izquierdo.</p>
              </div>
            </div>
          `;
        }

        const flexBasis = slidesToShow === 1 ? "100%" : (slidesToShow === 2 ? "calc(50% - 7px)" : (slidesToShow === 4 ? "calc(25% - 11px)" : "calc(33.333% - 10px)"));
        const minWidth = slidesToShow === 1 ? "280px" : (slidesToShow === 2 ? "260px" : "220px");

        return `
          <div class="elementor-carousel-widget" style="position: relative; margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%;">
            <!-- Carrusel Track -->
            <div
              id="${trackId}"
              class="elementor-carousel-track"
              data-autoplay="${autoplay}"
              data-speed="${autoplaySpeed}"
              data-pause="${pauseOnHover}"
              style="display: flex; gap: 14px; overflow-x: auto; scroll-snap-type: x mandatory; scroll-behavior: smooth; padding-bottom: 10px; scrollbar-width: none; -ms-overflow-style: none;"
            >
              ${images.map((img: any) => `
                <div style="flex: 0 0 ${flexBasis}; min-width: ${minWidth}; scroll-snap-align: start; position: relative; height: ${height}px; border-radius: ${radius}px; overflow: hidden; border: 1px solid rgba(255,255,255,0.12); box-shadow: 0 8px 24px rgba(0,0,0,0.4);">
                  <img src="${img.url}" alt="${img.caption || ""}" style="width: 100%; height: 100%; object-fit: cover;" />
                  ${img.caption ? `
                    <div style="position: absolute; inset: 0; background: linear-gradient(to top, rgba(0,0,0,0.85), transparent 60%); display: flex; align-items: flex-end; padding: 14px;">
                      <span style="font-size: 13px; font-weight: 700; color: #ffffff; text-shadow: 0 2px 4px rgba(0,0,0,0.8);">${img.caption}</span>
                    </div>
                  ` : ""}
                </div>
              `).join("")}
            </div>

            <!-- Flechas de navegación Anterior / Siguiente -->
            ${showArrows && images.length > 1 ? `
              <button
                type="button"
                onclick="(function(e){ e.stopPropagation(); var t = document.getElementById('${trackId}'); if(t){ var w = (t.firstElementChild && t.firstElementChild.offsetWidth) || 280; t.scrollBy({ left: -(w + 14), behavior: 'smooth' }); } })(event)"
                style="position: absolute; left: 8px; top: calc(50% - 24px); width: 36px; height: 36px; border-radius: 50%; background: rgba(10,12,16,0.85); backdrop-filter: blur(8px); border: 1px solid rgba(255,255,255,0.25); color: #ffffff; display: flex; align-items: center; justify-content: center; cursor: pointer; z-index: 10; font-size: 18px; font-weight: 800; box-shadow: 0 4px 14px rgba(0,0,0,0.6);"
                title="Diapositiva anterior"
              >
                ‹
              </button>
              <button
                type="button"
                onclick="(function(e){ e.stopPropagation(); var t = document.getElementById('${trackId}'); if(t){ var w = (t.firstElementChild && t.firstElementChild.offsetWidth) || 280; t.scrollBy({ left: w + 14, behavior: 'smooth' }); } })(event)"
                style="position: absolute; right: 8px; top: calc(50% - 24px); width: 36px; height: 36px; border-radius: 50%; background: rgba(10,12,16,0.85); backdrop-filter: blur(8px); border: 1px solid rgba(255,255,255,0.25); color: #ffffff; display: flex; align-items: center; justify-content: center; cursor: pointer; z-index: 10; font-size: 18px; font-weight: 800; box-shadow: 0 4px 14px rgba(0,0,0,0.6);"
                title="Siguiente diapositiva"
              >
                ›
              </button>
            ` : ""}

            <!-- Puntos de navegación (Dots) -->
            ${showDots && images.length > 1 ? `
              <div style="display: flex; justify-content: center; align-items: center; gap: 8px; margin-top: 10px;">
                ${images.map((_: any, idx: number) => `
                  <button
                    type="button"
                    onclick="(function(e){ e.stopPropagation(); var t = document.getElementById('${trackId}'); if(t){ var w = (t.firstElementChild && t.firstElementChild.offsetWidth) || 280; t.scrollTo({ left: ${idx} * (w + 14), behavior: 'smooth' }); } })(event)"
                    style="width: ${idx === 0 ? "24px" : "8px"}; height: 8px; border-radius: 4px; background: ${idx === 0 ? "#16c96f" : "rgba(255,255,255,0.25)"}; border: none; padding: 0; cursor: pointer; transition: all 0.3s ease;"
                    title="Ir a diapositiva ${idx + 1}"
                  ></button>
                `).join("")}
              </div>
            ` : ""}
          </div>
        `;
      }

      case "icon-list": {
        const items = s.items || getDefaultWidgetSettings("icon-list").items;
        const iconColor = s.iconColor || "#16c96f";
        const textColor = s.textColor || "#e2e8f0";
        const align = s.align || "left";
        const mTop = s.marginTop ?? 8;
        const mBottom = s.marginBottom ?? 8;
        return `
          <div class="elementor-icon-list-widget" style="text-align: ${align}; margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%;">
            <ul style="list-style: none; padding: 0; margin: 0; display: inline-flex; flex-direction: column; gap: 10px; text-align: left;">
              ${items.map((item: any) => `
                <li style="display: flex; align-items: center; gap: 10px; font-size: 14px; color: ${textColor}; line-height: 1.5;">
                  <span style="display: inline-flex; align-items: center; justify-content: center; width: 20px; height: 20px; border-radius: 50%; background: rgba(22,201,111,0.15); color: ${iconColor}; font-size: 12px; font-weight: 800; flex-shrink: 0;">${item.icon || "✓"}</span>
                  <span>${item.text}</span>
                </li>
              `).join("")}
            </ul>
          </div>
        `;
      }

      case "counter": {
        const num = s.endingNumber ?? 150;
        const prefix = s.prefix || "+";
        const suffix = s.suffix || "K";
        const numColor = s.numberColor || "#16c96f";
        const numSize = s.numberSize || 42;
        const titleColor = s.titleColor || "#94a3b8";
        const align = s.align || "center";
        const mTop = s.marginTop ?? 12;
        const mBottom = s.marginBottom ?? 12;
        return `
          <div class="elementor-counter-widget" style="text-align: ${align}; margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%; background: #040e1a; border: 1px solid rgba(255,255,255,0.08); border-radius: 12px; padding: 24px; box-shadow: 0 8px 24px rgba(0,0,0,0.35);">
            <div style="font-size: ${numSize}px; font-weight: 900; color: ${numColor}; line-height: 1; letter-spacing: -1px; margin-bottom: 6px;">
              ${prefix}${num}${suffix}
            </div>
            <div style="font-size: 13px; font-weight: 700; color: ${titleColor}; text-transform: uppercase; letter-spacing: 0.5px;">
              ${s.title || "Usuarios Activos al Mes"}
            </div>
          </div>
        `;
      }

      case "spacer": {
        const height = s.spaceHeight ?? 50;
        return `<div class="elementor-spacer-widget" style="height: ${height}px; width: 100%;"></div>`;
      }

      case "testimonial-card": {
        const rating = s.rating || 5;
        const cardBg = s.cardBg || "#040e1a";
        const borderColor = s.borderColor || "rgba(56, 189, 248, 0.15)";
        const mTop = s.marginTop ?? 12;
        const mBottom = s.marginBottom ?? 12;
        return `
          <div class="elementor-testimonial-card-widget" style="margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%; background: ${cardBg}; border: 1px solid ${borderColor}; border-radius: 12px; padding: 24px; box-shadow: 0 8px 24px rgba(0,0,0,0.35);">
            <div style="color: #f59e0b; font-size: 14px; letter-spacing: 2px; margin-bottom: 12px;">${"★".repeat(rating)}</div>
            <p style="font-size: 14px; line-height: 1.7; color: #cbd5e1; font-style: italic; margin: 0 0 16px;">"${s.quote || "Excelente servicio y gran calidad profesional."}"</p>
            <div style="display: flex; align-items: center; gap: 12px;">
              <div style="width: 40px; height: 40px; border-radius: 50%; background: linear-gradient(135deg, #16c96f, #38bdf8); color: #000; font-weight: 800; font-size: 14px; display: grid; place-items: center;">
                ${s.initials || "MG"}
              </div>
              <div>
                <div style="font-size: 14px; font-weight: 700; color: #ffffff;">${s.author || "María González"}</div>
                <div style="font-size: 12px; color: #94a3b8;">${s.role || "CEO en FinTech Global"}</div>
              </div>
            </div>
          </div>
        `;
      }

      case "tabs": {
        const tabs = s.tabs || getDefaultWidgetSettings("tabs").tabs;
        const tabColor = s.tabColor || "#16c96f";
        const mTop = s.marginTop ?? 12;
        const mBottom = s.marginBottom ?? 12;
        return `
          <div class="elementor-tabs-widget" style="margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%; background: #040e1a; border: 1px solid rgba(255,255,255,0.08); border-radius: 12px; overflow: hidden;">
            <div style="display: flex; border-bottom: 1px solid rgba(255,255,255,0.08); background: rgba(255,255,255,0.02); overflow-x: auto;">
              ${tabs.map((tab: any, idx: number) => `
                <div style="padding: 12px 20px; font-size: 13px; font-weight: 700; color: ${idx === 0 ? tabColor : "#94a3b8"}; border-bottom: 2px solid ${idx === 0 ? tabColor : "transparent"}; cursor: pointer; white-space: nowrap;">
                  ${tab.title}
                </div>
              `).join("")}
            </div>
            <div style="padding: 20px; font-size: 14px; color: #cbd5e1; line-height: 1.7;">
              ${tabs[0]?.content || "Contenido de la pestaña"}
            </div>
          </div>
        `;
      }

      case "accordion": {
        const items = s.items || getDefaultWidgetSettings("accordion").items;
        const mTop = s.marginTop ?? 12;
        const mBottom = s.marginBottom ?? 12;
        return `
          <div class="elementor-accordion-widget" style="margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%; display: flex; flex-direction: column; gap: 8px;">
            ${items.map((item: any, idx: number) => `
              <div style="background: #040e1a; border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; overflow: hidden;">
                <div style="padding: 14px 18px; font-size: 14px; font-weight: 700; color: #ffffff; display: flex; justify-content: space-between; align-items: center; cursor: pointer; background: rgba(255,255,255,0.02);">
                  <span>${item.title}</span>
                  <span style="color: #16c96f; font-size: 16px;">${idx === 0 ? "−" : "+"}</span>
                </div>
                ${idx === 0 ? `
                  <div style="padding: 14px 18px; font-size: 13px; color: #94a3b8; line-height: 1.6; border-top: 1px solid rgba(255,255,255,0.05);">
                    ${item.content}
                  </div>
                ` : ""}
              </div>
            `).join("")}
          </div>
        `;
      }

      case "toggle": {
        const isOpen = s.isOpen !== false;
        const mTop = s.marginTop ?? 8;
        const mBottom = s.marginBottom ?? 8;
        return `
          <div class="elementor-toggle-widget" style="margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%; background: #040e1a; border: 1px solid rgba(56,189,248,0.2); border-radius: 8px; overflow: hidden;">
            <div style="padding: 14px 18px; font-size: 14px; font-weight: 700; color: #ffffff; display: flex; justify-content: space-between; align-items: center;">
              <span>${s.title || "¿Se puede migrar desde WordPress fácilmente?"}</span>
              <span style="color: #38bdf8; font-size: 14px;">${isOpen ? "▲" : "▼"}</span>
            </div>
            ${isOpen ? `
              <div style="padding: 14px 18px; font-size: 13px; color: #94a3b8; line-height: 1.6; border-top: 1px solid rgba(255,255,255,0.05);">
                ${s.content || "Sí, nuestro sistema permite importar todo tu contenido, URLs, slugs y optimizaciones SEO sin perder posicionamiento en Google."}
              </div>
            ` : ""}
          </div>
        `;
      }

      case "social-icons": {
        const networks = s.networks || getDefaultWidgetSettings("social-icons").networks;
        const align = s.align || "center";
        const size = s.size || 38;
        const shape = s.shape || "circle";
        const radius = shape === "circle" ? "50%" : (shape === "rounded" ? "8px" : "0px");
        const mTop = s.marginTop ?? 8;
        const mBottom = s.marginBottom ?? 8;
        return `
          <div class="elementor-social-icons-widget" style="text-align: ${align}; margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%;">
            <div style="display: inline-flex; gap: 10px; flex-wrap: wrap;">
              ${networks.map((net: any) => `
                <a href="${net.url || "#"}" target="_blank" rel="noopener noreferrer" style="display: inline-flex; align-items: center; justify-content: center; width: ${size}px; height: ${size}px; border-radius: ${radius}; background: ${net.color || "#1e293b"}; color: #ffffff; font-size: 16px; text-decoration: none; box-shadow: 0 4px 12px rgba(0,0,0,0.3); transition: transform 0.2s;" title="${net.name}">
                  ${net.icon || "🌐"}
                </a>
              `).join("")}
            </div>
          </div>
        `;
      }

      case "progress-bar": {
        const pct = Math.min(100, Math.max(0, parseInt(s.percentage) || 95));
        const color = s.barColor || "#16c96f";
        const height = s.height || 12;
        const mTop = s.marginTop ?? 8;
        const mBottom = s.marginBottom ?? 8;
        return `
          <div class="elementor-progress-bar-widget" style="margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
              <span style="font-size: 13px; font-weight: 700; color: #ffffff;">${s.title || "Optimización de Rendimiento Web"}</span>
              ${s.showPercentage !== false ? `<span style="font-size: 12px; font-weight: 800; color: ${color};">${pct}%</span>` : ""}
            </div>
            <div style="width: 100%; height: ${height}px; background: rgba(255,255,255,0.08); border-radius: ${height / 2}px; overflow: hidden; position: relative;">
              <div style="width: ${pct}%; height: 100%; background: linear-gradient(90deg, ${color}, #38bdf8); border-radius: ${height / 2}px;"></div>
            </div>
          </div>
        `;
      }

      case "soundcloud": {
        const height = s.height || 140;
        const mTop = s.marginTop ?? 10;
        const mBottom = s.marginBottom ?? 10;
        return `
          <div class="elementor-soundcloud-widget" style="margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%; border-radius: 10px; overflow: hidden; border: 1px solid rgba(255,255,255,0.12);">
            <iframe width="100%" height="${height}" scrolling="no" frameborder="no" allow="autoplay" src="${s.audioUrl || "https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/293&color=%2316c96f"}"></iframe>
          </div>
        `;
      }

      case "shortcode": {
        const code = s.shortcode || "[form_contacto id='principal']";
        const fallback = s.fallbackText || "Formulario de Contacto Dinámico TechLab";
        const mTop = s.marginTop ?? 8;
        const mBottom = s.marginBottom ?? 8;
        return `
          <div class="elementor-shortcode-widget" style="margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%; padding: 16px; background: rgba(56,189,248,0.05); border: 1px dashed rgba(56,189,248,0.3); border-radius: 8px; text-align: center;">
            <span style="font-family: monospace; font-size: 13px; font-weight: 700; color: #38bdf8;">${code}</span>
            <div style="font-size: 11px; color: #94a3b8; margin-top: 4px;">${fallback}</div>
          </div>
        `;
      }

      case "html": {
        const raw = s.customHtml || `<div style="padding: 16px; color: #94a3b8; font-size: 13px;">HTML personalizado</div>`;
        const mTop = s.marginTop ?? 0;
        const mBottom = s.marginBottom ?? 0;
        return `<div class="elementor-html-widget" style="margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%;">${raw}</div>`;
      }

      case "menu-anchor": {
        const id = s.anchorId || "contacto";
        return `
          <div id="${id}" class="elementor-menu-anchor-widget" style="width: 100%; padding: 8px 12px; background: rgba(22,201,111,0.1); border: 1px dashed rgba(22,201,111,0.4); border-radius: 6px; font-size: 12px; font-weight: 700; color: #16c96f; display: flex; align-items: center; gap: 8px;">
            <span>⚓</span> Ancla de Menú (#${id})
          </div>
        `;
      }

      case "alert": {
        const type = s.alertType || "info";
        const typeColors: Record<string, { bg: string; border: string; text: string; icon: string }> = {
          info: { bg: "rgba(56,189,248,0.12)", border: "rgba(56,189,248,0.3)", text: "#38bdf8", icon: "ℹ️" },
          success: { bg: "rgba(22,201,111,0.12)", border: "rgba(22,201,111,0.3)", text: "#16c96f", icon: "✓" },
          warning: { bg: "rgba(245,158,11,0.12)", border: "rgba(245,158,11,0.3)", text: "#f59e0b", icon: "⚠️" },
          danger: { bg: "rgba(239,68,68,0.12)", border: "rgba(239,68,68,0.3)", text: "#ef4444", icon: "⛔" },
        };
        const c = typeColors[type] || typeColors.info;
        const mTop = s.marginTop ?? 8;
        const mBottom = s.marginBottom ?? 8;
        return `
          <div class="elementor-alert-widget" style="margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%; background: ${c.bg}; border: 1px solid ${c.border}; border-radius: 8px; padding: 14px 18px; display: flex; align-items: flex-start; gap: 12px;">
            <span style="font-size: 16px; line-height: 1;">${c.icon}</span>
            <div style="flex: 1;">
              ${s.title ? `<div style="font-size: 14px; font-weight: 700; color: ${c.text}; margin-bottom: 4px;">${s.title}</div>` : ""}
              <div style="font-size: 13px; color: #cbd5e1; line-height: 1.5;">${s.message || "Esta sección cuenta con certificado SSL de alta seguridad y respaldo en la nube."}</div>
            </div>
          </div>
        `;
      }

      case "sidebar-widget": {
        const links = s.links || getDefaultWidgetSettings("sidebar-widget").links;
        const mTop = s.marginTop ?? 8;
        const mBottom = s.marginBottom ?? 8;
        return `
          <div class="elementor-sidebar-widget" style="margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%; background: #040e1a; border: 1px solid rgba(255,255,255,0.08); border-radius: 10px; padding: 18px;">
            <h4 style="font-size: 14px; font-weight: 800; color: #ffffff; text-transform: uppercase; letter-spacing: 0.5px; margin: 0 0 12px; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 8px;">
              ${s.title || "Navegación Rápida"}
            </h4>
            <ul style="list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: 8px;">
              ${links.map((link: any) => `
                <li>
                  <a href="${link.url || "#"}" style="font-size: 13px; color: #94a3b8; text-decoration: none; display: flex; justify-content: space-between; align-items: center; padding: 4px 0; transition: color 0.15s;">
                    <span>${link.text}</span>
                    <span style="color: #16c96f;">→</span>
                  </a>
                </li>
              `).join("")}
            </ul>
          </div>
        `;
      }

      case "text-path": {
        const text = s.text || "✨ INGENIERÍA • TECNOLOGÍA • INNOVACIÓN • ESCALABILIDAD • RENDIMIENTO • ";
        const color = s.textColor || "#38bdf8";
        const size = s.fontSize || 16;
        const weight = s.fontWeight || "800";
        const mTop = s.marginTop ?? 10;
        const mBottom = s.marginBottom ?? 10;
        return `
          <div class="elementor-text-path-widget" style="margin-top: ${mTop}px; margin-bottom: ${mBottom}px; width: 100%; overflow: hidden; background: rgba(56,189,248,0.05); border: 1px solid rgba(56,189,248,0.15); border-radius: 8px; padding: 12px 0;">
            <div style="white-space: nowrap; font-size: ${size}px; font-weight: ${weight}; color: ${color}; letter-spacing: 2px; text-transform: uppercase; display: flex; gap: 20px;">
              <span>${text}</span>
              <span>${text}</span>
            </div>
          </div>
        `;
      }

      default:
        return `<div style="padding: 12px; border: 1px dashed #475569; color: #94a3b8; border-radius: 6px;">Widget ${wid.type}</div>`;
    }
  };

  const handleSaveElementor = async (newStatus: "Borrador" | "Publicado") => {
    setIsSaving(true);
    const finalHtml = generateCanvasHtml();
    const contentWithJson = `${finalHtml}\n<!-- ELEMENTOR_DATA_START -->${JSON.stringify(containers)}<!-- ELEMENTOR_DATA_END -->`;

    const payload = {
      id: pageId || undefined,
      title: pageTitle.trim() || "Página Elementor",
      slug: pageSlug || `elementor-${Date.now().toString().slice(-4)}`,
      content: contentWithJson,
      status: newStatus,
      template: "elementor_canvas",
    };
    try {
      const res = await fetch("/api/pages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (data.success) {
        setPageStatus(newStatus);
        if (data.page?.id && !pageId) {
          router.replace(`/dashboard/elementor/editor?id=${data.page.id}`);
        }
        showToast(newStatus === "Publicado" ? "¡Página de Elementor publicada exitosamente!" : "Borrador de Elementor guardado.", "success");
      } else {
        showToast(data.error || "Error al guardar.", "error");
      }
    } catch {
      showToast("Error de conexión al servidor.", "error");
    } finally {
      setIsSaving(false);
    }
  };

  const openStructureModal = (index: number | null = null) => {
    setInsertTargetIndex(index);
    setStructureDesignType("choice");
    setShowStructureModal(true);
  };

  const handleSelectStructurePreset = (preset: typeof STRUCTURE_PRESETS[0]) => {
    const newContainer: ContainerItem = {
      id: `cont-${Date.now()}`,
      layoutType: "flexbox",
      direction: preset.direction,
      structurePreset: preset.id,
      columns: preset.columns.map((c, i) => ({
        id: `col-${Date.now()}-${i}`,
        width: c.width,
        widgets: [],
      })),
      styles: {
        paddingTop: 40,
        paddingBottom: 40,
        paddingLeft: 24,
        paddingRight: 24,
        marginTop: 0,
        marginBottom: 0,
        backgroundColor: "transparent",
        borderRadius: 8,
      },
    };

    if (insertTargetIndex !== null) {
      const copy = [...containers];
      copy.splice(insertTargetIndex, 0, newContainer);
      setContainers(copy);
    } else {
      setContainers([...containers, newContainer]);
    }

    setShowStructureModal(false);
    setSelectedContainerId(newContainer.id);
    setSelectedColumnId(newContainer.columns[0]?.id || null);
    setSelectedWidgetId(null);
    setSidebarMode("flexbox");
    showToast(`Contenedor ${preset.label} añadido.`, "info");
  };

  const handleDeleteContainer = (contId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setContainers(containers.filter((c) => c.id !== contId));
    if (selectedContainerId === contId) {
      setSelectedContainerId(null);
      setSelectedColumnId(null);
      setSelectedWidgetId(null);
      setSidebarMode("widgets");
    }
  };

  const handleAddWidget = (
    widgetType: WidgetType,
    insertPosition?: "before" | "after",
    referenceWidgetId?: string
  ) => {
    let targetContId = selectedContainerId;
    let targetColId = selectedColumnId;

    if (!targetContId || containers.length === 0) {
      const autoCont: ContainerItem = {
        id: `cont-${Date.now()}`,
        layoutType: "flexbox",
        direction: "column",
        structurePreset: 1,
        columns: [{ id: `col-${Date.now()}-0`, width: "100%", widgets: [] }],
        styles: { paddingTop: 30, paddingBottom: 30, paddingLeft: 20, paddingRight: 20, gap: 16 },
      };
      setContainers([...containers, autoCont]);
      targetContId = autoCont.id;
      targetColId = autoCont.columns[0].id;
    }

    const newWidget: WidgetItem = {
      id: `wid-${Date.now()}-${Math.round(Math.random() * 1e3)}`,
      type: widgetType,
      title: widgetType.toUpperCase(),
      settings: getDefaultWidgetSettings(widgetType),
    };

    setContainers((prev) =>
      prev.map((c) => {
        if (c.id === targetContId) {
          return {
            ...c,
            columns: c.columns.map((col) => {
              if (!targetColId || col.id === targetColId) {
                const widgetsCopy = [...col.widgets];
                if (referenceWidgetId && insertPosition) {
                  const refIndex = widgetsCopy.findIndex((w) => w.id === referenceWidgetId);
                  if (refIndex !== -1) {
                    const insertIdx = insertPosition === "before" ? refIndex : refIndex + 1;
                    widgetsCopy.splice(insertIdx, 0, newWidget);
                    return { ...col, widgets: widgetsCopy };
                  }
                }
                widgetsCopy.push(newWidget);
                return { ...col, widgets: widgetsCopy };
              }
              return col;
            }),
          };
        }
        return c;
      })
    );

    setSelectedWidgetId(newWidget.id);
    setSidebarMode("widget");
    showToast(`Widget ${widgetType} añadido.`, "success");
  };

  const currentSelectedContainer = containers.find((c) => c.id === selectedContainerId);
  const currentSelectedWidget = containers
    .flatMap((c) => c.columns)
    .flatMap((col) => col.widgets)
    .find((w) => w.id === selectedWidgetId);

  const updateContainerStyles = (key: keyof ContainerItem["styles"], value: any) => {
    if (!selectedContainerId) return;
    setContainers((prev) =>
      prev.map((c) => (c.id === selectedContainerId ? { ...c, styles: { ...c.styles, [key]: value } } : c))
    );
  };

  const updateWidgetSetting = (key: string, value: any) => {
    if (!selectedWidgetId) return;
    setContainers((prev) =>
      prev.map((c) => ({
        ...c,
        columns: c.columns.map((col) => ({
          ...col,
          widgets: col.widgets.map((w) => (w.id === selectedWidgetId ? { ...w, settings: { ...w.settings, [key]: value } } : w)),
        })),
      }))
    );
  };

  const [isUploadingMedia, setIsUploadingMedia] = useState(false);

  const handleUploadMedia = async (file: File): Promise<string | null> => {
    try {
      setIsUploadingMedia(true);
      const formData = new FormData();
      formData.append("file", file);
      formData.append("attachedToType", "elementor_page");
      if (pageId) formData.append("attachedToId", pageId);

      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      if (data.url) {
        showToast("Imagen subida al servidor correctamente.", "success");
        return data.url;
      } else {
        showToast(data.error || "Error al subir imagen al servidor.", "error");
        return null;
      }
    } catch (err: any) {
      console.error("Error al subir archivo:", err);
      showToast("Error de conexión al subir imagen al servidor.", "error");
      return null;
    } finally {
      setIsUploadingMedia(false);
    }
  };

  // Temporizador para animación automática (autoplay) de todos los carruseles activos en el editor
  useEffect(() => {
    const interval = setInterval(() => {
      const tracks = document.querySelectorAll<HTMLElement>(".elementor-carousel-track");
      tracks.forEach((track) => {
        if (track.getAttribute("data-autoplay") === "false") return;
        if (track.matches(":hover")) return; // Pausar al pasar el ratón
        const maxScroll = track.scrollWidth - track.clientWidth;
        if (maxScroll <= 2) return;
        const firstCard = track.firstElementChild as HTMLElement;
        const step = firstCard ? firstCard.offsetWidth + 14 : 320;
        if (track.scrollLeft >= maxScroll - 10) {
          track.scrollTo({ left: 0, behavior: "smooth" });
        } else {
          track.scrollBy({ left: step, behavior: "smooth" });
        }
      });
    }, 3000);
    return () => clearInterval(interval);
  }, [containers]);

  const handleDeleteWidget = (widId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setContainers((prev) =>
      prev.map((c) => ({
        ...c,
        columns: c.columns.map((col) => ({
          ...col,
          widgets: col.widgets.filter((w) => w.id !== widId),
        })),
      }))
    );
    if (selectedWidgetId === widId) {
      setSelectedWidgetId(null);
      setSidebarMode("widgets");
    }
  };

  if (isLoading) {
    return (
      <div className="elementor-loading-screen">
        <div className="elementor-logo-pulse">E</div>
        <p>Cargando Lienzo de Elementor Pro...</p>
        <Loader2 className="animate-spin" />
        <style jsx>{`
          .elementor-loading-screen { min-height: 100vh; background: #121212; color: #ffffff; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 16px; font-family: sans-serif; }
          .elementor-logo-pulse { width: 54px; height: 54px; background: #d63384; border-radius: 50%; display: grid; place-items: center; font-size: 26px; font-weight: 900; color: #fff; animation: pulse 1.5s infinite alternate; }
          @keyframes pulse { from { transform: scale(0.95); } to { transform: scale(1.05); } }
        `}</style>
      </div>
    );
  }

  return (
    <div className="elementor-workspace-root">
      {toastMessage && (
        <div className={`elementor-toast ${toastType}`}>
          {toastType === "success" ? <CheckCircle2 /> : <AlertTriangle />}
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 1. BARRA SUPERIOR (HEADER ELEMENTOR 3.x) */}
      <header className="elementor-top-header">
        <div className="top-header-left">
          <div className="elementor-brand-dropdown-wrap">
            <button type="button" className="elementor-brand-btn" onClick={() => setShowElementorMenu(!showElementorMenu)}>
              <span>E</span>
            </button>
            {showElementorMenu && (
              <div className="elementor-popup-menu">
                <Link href="/dashboard" className="popup-menu-item"><Home style={{ width: 14, height: 14 }} /><span>Ir al Dashboard</span></Link>
                <Link href="/dashboard/paginas" className="popup-menu-item"><Files style={{ width: 14, height: 14 }} /><span>Todas las Páginas</span></Link>
                {pageId && (
                  <Link href={`/dashboard/paginas/nuevo?edit=${pageId}`} className="popup-menu-item">
                    <FileCode style={{ width: 14, height: 14 }} /><span>Editor Estándar</span>
                  </Link>
                )}
                {pageSlug && (
                  <a href={pageSlug === "home" ? "/" : `/paginas/${pageSlug}`} target="_blank" rel="noopener noreferrer" className="popup-menu-item">
                    <ExternalLink style={{ width: 14, height: 14 }} /><span>Ver Página en Vivo</span>
                  </a>
                )}
              </div>
            )}
          </div>

          <button
            type="button"
            className={`top-icon-btn ${sidebarMode === "widgets" ? "active" : ""}`}
            onClick={() => { setSidebarMode("widgets"); setSelectedWidgetId(null); }}
            title="Añadir Elementos"
          >
            <Plus />
          </button>

          <div className="history-group">
            <button type="button" className="top-icon-btn" title="Deshacer"><Undo2 /></button>
            <button type="button" className="top-icon-btn" title="Rehacer"><Redo2 /></button>
          </div>

          <button type="button" className="top-icon-btn" title="Estilos Globales"><Palette /></button>
        </div>

        <div className="top-header-center">
          <div className="page-title-dropdown">
            <span className="doc-title-text">{pageTitle}</span>
            <span className="doc-status-text">({pageStatus})</span>
            <ChevronDown className="title-chevron" />
          </div>

          <div className="responsive-mode-switcher">
            <button
              type="button"
              className={`resp-btn ${responsiveMode === "desktop" ? "active" : ""}`}
              onClick={() => setResponsiveMode("desktop")}
              title="Escritorio"
            >
              <Monitor />
            </button>
            <button
              type="button"
              className={`resp-btn ${responsiveMode === "tablet" ? "active" : ""}`}
              onClick={() => setResponsiveMode("tablet")}
              title="Tablet (768px)"
            >
              <Tablet />
            </button>
            <button
              type="button"
              className={`resp-btn ${responsiveMode === "mobile" ? "active" : ""}`}
              onClick={() => setResponsiveMode("mobile")}
              title="Móvil (375px)"
            >
              <Smartphone />
            </button>
          </div>
        </div>

        <div className="top-header-right">
          <button type="button" className="top-icon-btn" title="Capas"><Layers /></button>
          <button type="button" className="top-icon-btn" title="Buscar"><Search /></button>
          {pageSlug && (
            <a href={`/paginas/${pageSlug}`} target="_blank" rel="noopener noreferrer" className="top-icon-btn" title="Ver en vivo">
              <Eye />
            </a>
          )}
          <button
            type="button"
            className="elementor-publish-btn"
            onClick={() => handleSaveElementor("Publicado")}
            disabled={isSaving}
          >
            {isSaving ? <Loader2 className="animate-spin" /> : <span>{pageStatus === "Publicado" ? "Actualizar" : "Publicar"}</span>}
          </button>
        </div>
      </header>

      {/* 2. CUERPO PRINCIPAL */}
      <div className="elementor-main-body">
        {/* BARRA LATERAL IZQUIERDA */}
        <aside className="elementor-sidebar">
          {sidebarMode === "widgets" && (
            <div className="sidebar-widgets-view">
              <div className="sidebar-top-tabs">
                <button type="button" className="tab-pill active">Widgets</button>
                <button type="button" className="tab-pill">Componentes</button>
                <button type="button" className="tab-pill">Globales</button>
              </div>

              <div className="widget-search-wrap">
                <Search className="search-ico" />
                <input
                  type="text"
                  placeholder="Buscar widget..."
                  value={widgetSearchQuery}
                  onChange={(e) => setWidgetSearchQuery(e.target.value)}
                  className="widget-search-input"
                />
              </div>

              {/* ======================================================== */}
              {/* CATEGORÍA 1: BÁSICO (ELEMENTOR BASIC WIDGETS) */}
              {/* ======================================================== */}
              {("básico basic".includes(widgetSearchQuery.toLowerCase()) ||
                ["sección", "inner section", "encabezado", "heading", "imagen", "image", "editor de texto", "párrafo", "text", "video", "botón", "boton", "button", "star rating", "estrellas", "valoración", "divisor", "divider", "separador", "google maps", "mapa", "icono", "icon", "image box", "caja de imagen", "icon box", "caja de icono"].some(w => w.includes(widgetSearchQuery.toLowerCase()))) && (
                <div className="widget-category-group">
                  <div className="category-header">
                    <div className="category-title">
                      <ChevronDown className="cat-chev" />
                      <span>Básico</span>
                    </div>
                  </div>

                  <div className="widgets-grid">
                    {(!widgetSearchQuery || "inner section sección interior flexbox".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "div")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => openStructureModal(null)}
                        title="Inner Section / Contenedor Flexbox"
                      >
                        <Columns className="w-ico" />
                        <span>Inner Section</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "encabezado heading título".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "heading")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("heading")}
                        title="Encabezado / Heading"
                      >
                        <Type className="w-ico" />
                        <span>Heading</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "imagen image foto".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "image")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("image")}
                        title="Imagen / Image"
                      >
                        <ImageIcon className="w-ico" />
                        <span>Image</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "editor de texto párrafo text editor".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "text")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("text")}
                        title="Editor de Texto / Text Editor"
                      >
                        <AlignLeft className="w-ico" />
                        <span>Text Editor</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "video youtube vimeo".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "video")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("video")}
                        title="Video / YouTube"
                      >
                        <Film className="w-ico" />
                        <span>Video</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "botón boton button enlace".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "button")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("button")}
                        title="Botón / Button"
                      >
                        <Play className="w-ico" />
                        <span>Button</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "star rating estrellas valoración calificacion".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "star-rating")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("star-rating")}
                        title="Valoración de Estrellas"
                      >
                        <Star className="w-ico" style={{ color: "#f59e0b" }} />
                        <span>Star Rating</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "divisor divider separador línea".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "separator")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("separator")}
                        title="Separador / Divider"
                      >
                        <Minus className="w-ico" />
                        <span>Divider</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "icono icon símbolo".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "icon")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("icon")}
                        title="Icono Individual"
                      >
                        <Sparkles className="w-ico" style={{ color: "#16c96f" }} />
                        <span>Icon</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "image box caja de imagen tarjeta foto".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "image-box")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("image-box")}
                        title="Caja de Imagen / Image Box"
                      >
                        <LayoutTemplate className="w-ico" style={{ color: "#38bdf8" }} />
                        <span>Image Box</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "icon box caja de icono característica feature".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "icon-box")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("icon-box")}
                        title="Caja de Icono / Icon Box"
                      >
                        <Award className="w-ico" style={{ color: "#a855f7" }} />
                        <span>Icon Box</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* ======================================================== */}
              {/* CATEGORÍA 2: GENERAL (ELEMENTOR GENERAL WIDGETS) */}
              {/* ======================================================== */}
              {("general".includes(widgetSearchQuery.toLowerCase()) ||
                ["galería", "gallery", "carrusel", "carousel", "slider", "icon list", "lista de iconos", "counter", "contador", "spacer", "espaciador", "testimonial", "testimonio", "tabs", "pestañas", "accordion", "acordeon", "toggle", "conmutador", "social icons", "redes sociales", "progress bar", "barra de progreso", "soundcloud", "audio", "shortcode", "html", "menu anchor", "ancla", "alert", "alerta", "sidebar", "barra lateral", "text path", "ruta de texto"].some(w => w.includes(widgetSearchQuery.toLowerCase()))) && (
                <div className="widget-category-group">
                  <div className="category-header">
                    <div className="category-title">
                      <ChevronDown className="cat-chev" />
                      <span>General</span>
                    </div>
                  </div>

                  <div className="widgets-grid">
                    {(!widgetSearchQuery || "basic gallery galería fotos imagenes".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "gallery")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("gallery")}
                        title="Galería Básica de Imágenes"
                      >
                        <LayoutGrid className="w-ico" />
                        <span>Basic Gallery</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "image carousel carrusel slider fotos".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "carousel")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("carousel")}
                        title="Carrusel de Imágenes"
                      >
                        <Sliders className="w-ico" />
                        <span>Image Carousel</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "icon list lista de iconos viñetas checks".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "icon-list")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("icon-list")}
                        title="Lista de Iconos"
                      >
                        <ListChecks className="w-ico" style={{ color: "#16c96f" }} />
                        <span>Icon List</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "counter contador número estadísticas metricas".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "counter")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("counter")}
                        title="Contador Numérico Animado"
                      >
                        <Hash className="w-ico" style={{ color: "#38bdf8" }} />
                        <span>Counter</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "spacer espaciador espacio vertical".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "spacer")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("spacer")}
                        title="Espaciador Vertical"
                      >
                        <MoveVertical className="w-ico" />
                        <span>Spacer</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "testimonial testimonio reseña cliente".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "testimonial-card")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("testimonial-card")}
                        title="Testimonio de Cliente"
                      >
                        <MessageSquareQuote className="w-ico" style={{ color: "#f59e0b" }} />
                        <span>Testimonial</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "tabs pestañas secciones".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "tabs")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("tabs")}
                        title="Pestañas / Tabs"
                      >
                        <FolderKanban className="w-ico" style={{ color: "#10b981" }} />
                        <span>Tabs</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "accordion acordeón acordeon faq preguntas".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "accordion")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("accordion")}
                        title="Acordeón Desplegable (FAQ)"
                      >
                        <ChevronDown className="w-ico" />
                        <span>Accordion</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "toggle conmutador colapsable".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "toggle")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("toggle")}
                        title="Conmutador / Toggle"
                      >
                        <ToggleLeft className="w-ico" />
                        <span>Toggle</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "social icons iconos sociales redes facebook linkedin twitter".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "social-icons")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("social-icons")}
                        title="Iconos de Redes Sociales"
                      >
                        <Share2 className="w-ico" style={{ color: "#38bdf8" }} />
                        <span>Social Icons</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "progress bar barra de progreso porcentaje".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "progress-bar")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("progress-bar")}
                        title="Barra de Progreso"
                      >
                        <BarChart2 className="w-ico" style={{ color: "#16c96f" }} />
                        <span>Progress Bar</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "soundcloud audio podcast música reproductor".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "soundcloud")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("soundcloud")}
                        title="Reproductor de Audio / SoundCloud"
                      >
                        <Headphones className="w-ico" style={{ color: "#ec4899" }} />
                        <span>SoundCloud</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "shortcode codigo corto dinamico".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "shortcode")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("shortcode")}
                        title="Ejecutor de Shortcode"
                      >
                        <FileCode className="w-ico" />
                        <span>Shortcode</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "html código embebido iframe script".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "html")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("html")}
                        title="Código HTML Personalizado"
                      >
                        <Code2 className="w-ico" style={{ color: "#f59e0b" }} />
                        <span>HTML</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "menu anchor ancla enlace interno smooth scroll".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "menu-anchor")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("menu-anchor")}
                        title="Ancla de Menú (#id)"
                      >
                        <Anchor className="w-ico" style={{ color: "#16c96f" }} />
                        <span>Menu Anchor</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "alert alerta aviso notificación".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "alert")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("alert")}
                        title="Cuadro de Alerta / Aviso"
                      >
                        <AlertCircle className="w-ico" style={{ color: "#38bdf8" }} />
                        <span>Alert</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "sidebar barra lateral menú lateral enlaces".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "sidebar-widget")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("sidebar-widget")}
                        title="Barra Lateral de Enlaces"
                      >
                        <SidebarIcon className="w-ico" />
                        <span>Sidebar</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "text path ruta de texto tipografía decorativa".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "text-path")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("text-path")}
                        title="Ruta de Texto / Text Path"
                      >
                        <PenTool className="w-ico" style={{ color: "#d63384" }} />
                        <span>Text Path</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* ======================================================== */}
              {/* CATEGORÍA 3: WIDGETS DINÁMICOS PRO (TECHLAB PRO) */}
              {/* ======================================================== */}
              {("pro dinámicos".includes(widgetSearchQuery.toLowerCase()) ||
                ["hero", "banner", "servicios", "testimonios", "artículos", "blog"].some(w => w.includes(widgetSearchQuery.toLowerCase()))) && (
                <div className="widget-category-group">
                  <div className="category-header">
                    <div className="category-title">
                      <ChevronDown className="cat-chev" />
                      <span>Widgets Dinámicos Pro</span>
                    </div>
                    <span className="badge-pro">Pro</span>
                  </div>

                  <div className="widgets-grid">
                    {(!widgetSearchQuery || "hero banner cabecera principal".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "hero")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("hero")}
                        title="Hero Banner Principal"
                      >
                        <PanelTop className="w-ico" style={{ color: "#38bdf8" }} />
                        <span>Hero Banner</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "servicios services portafolio".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "services")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("services")}
                        title="Servicios Dinámicos de la BD"
                      >
                        <Briefcase className="w-ico" style={{ color: "#16c96f" }} />
                        <span>Servicios</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "testimonios testimoniales reviews".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "testimonials")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("testimonials")}
                        title="Testimonios Dinámicos de la BD"
                      >
                        <MessageSquareQuote className="w-ico" style={{ color: "#f59e0b" }} />
                        <span>Testimonios Grid</span>
                      </div>
                    )}
                    {(!widgetSearchQuery || "artículos articulos blog posts noticias".includes(widgetSearchQuery.toLowerCase())) && (
                      <div
                        className="widget-card"
                        draggable
                        onDragStart={(e) => handleSidebarDragStart(e, "articles")}
                        onDragEnd={handleSidebarDragEnd}
                        onClick={() => handleAddWidget("articles")}
                        title="Artículos Dinámicos de la BD"
                      >
                        <Newspaper className="w-ico" style={{ color: "#ec4899" }} />
                        <span>Artículos</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              <div className="sidebar-bottom-pro-banner">
                <p style={{ margin: 0 }}>Arrastra widgets o haz clic para añadir.</p>
                <span className="pro-link">Versión Activa TechLab 1.6</span>
              </div>
            </div>
          )}

          {sidebarMode === "flexbox" && currentSelectedContainer && (
            <div className="sidebar-editor-view">
              <div className="editor-view-header">
                <div className="editor-title-row">
                  <button type="button" className="back-btn" onClick={() => setSidebarMode("widgets")}><ArrowLeft /></button>
                  <h3 className="editor-title">Editar Flexbox ⚙️</h3>
                </div>
              </div>

              <div className="editor-sub-tabs">
                <button type="button" className={`sub-tab ${sidebarTab === "general" ? "active" : ""}`} onClick={() => setSidebarTab("general")}>General</button>
                <button type="button" className={`sub-tab ${sidebarTab === "estilo" ? "active" : ""}`} onClick={() => setSidebarTab("estilo")}>Estilo</button>
                <button type="button" className={`sub-tab ${sidebarTab === "interacciones" ? "active" : ""}`} onClick={() => setSidebarTab("interacciones")}>Interacciones</button>
              </div>

              {/* Botones para reordenar contenedor */}
              <div style={{ padding: "10px 12px 0 12px" }}>
                <div style={{ display: "flex", gap: "6px", background: "#181b1e", padding: "6px", borderRadius: "6px", border: "1px solid #2d3238" }}>
                  <button
                    type="button"
                    style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: "4px", padding: "6px", background: "rgba(56, 189, 248, 0.12)", border: "1px solid rgba(56, 189, 248, 0.3)", borderRadius: "4px", color: "#38bdf8", fontSize: "11px", fontWeight: 700, cursor: "pointer" }}
                    onClick={(e) => handleMoveContainerOrder(currentSelectedContainer.id, "up", e)}
                    title="Mover este contenedor hacia arriba"
                  >
                    <ArrowUp style={{ width: 12, height: 12 }} /> Subir Sección
                  </button>
                  <button
                    type="button"
                    style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: "4px", padding: "6px", background: "rgba(22, 201, 111, 0.12)", border: "1px solid rgba(22, 201, 111, 0.3)", borderRadius: "4px", color: "#16c96f", fontSize: "11px", fontWeight: 700, cursor: "pointer" }}
                    onClick={(e) => handleMoveContainerOrder(currentSelectedContainer.id, "down", e)}
                    title="Mover este contenedor hacia abajo"
                  >
                    <ArrowDown style={{ width: 12, height: 12 }} /> Bajar Sección
                  </button>
                </div>
              </div>

              <div className="editor-controls-stack">
                <div className="control-accordion-item">
                  <div className="accordion-label"><span>Disposición</span><ChevronDown className="acc-chev" /></div>
                  <div className="accordion-body">
                    <div className="ctrl-row">
                      <label>Dirección:</label>
                      <div className="btn-group-2">
                        <button type="button" className={currentSelectedContainer.direction === "column" ? "active" : ""} onClick={() => setContainers(prev => prev.map(c => c.id === selectedContainerId ? { ...c, direction: "column" } : c))}>Vertical ↓</button>
                        <button type="button" className={currentSelectedContainer.direction === "row" ? "active" : ""} onClick={() => setContainers(prev => prev.map(c => c.id === selectedContainerId ? { ...c, direction: "row" } : c))}>Horizontal →</button>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="control-accordion-item">
                  <div className="accordion-label"><span>Espaciado (Padding & Gap)</span><ChevronDown className="acc-chev" /></div>
                  <div className="accordion-body">
                    <div className="ctrl-row">
                      <label>Padding Superior (px):</label>
                      <input type="number" value={currentSelectedContainer.styles.paddingTop ?? 40} onChange={(e) => updateContainerStyles("paddingTop", parseInt(e.target.value) || 0)} />
                    </div>
                    <div className="ctrl-row">
                      <label>Padding Inferior (px):</label>
                      <input type="number" value={currentSelectedContainer.styles.paddingBottom ?? 40} onChange={(e) => updateContainerStyles("paddingBottom", parseInt(e.target.value) || 0)} />
                    </div>
                    <div className="ctrl-row">
                      <label>Espacio entre elementos (Gap px):</label>
                      <input type="number" value={currentSelectedContainer.styles.gap ?? 20} onChange={(e) => updateContainerStyles("gap", parseInt(e.target.value) || 0)} />
                    </div>
                  </div>
                </div>

                <div className="control-accordion-item">
                  <div className="accordion-label"><span>Fondo</span><ChevronDown className="acc-chev" /></div>
                  <div className="accordion-body">
                    <div className="ctrl-row">
                      <label>Color de fondo:</label>
                      <input type="color" value={currentSelectedContainer.styles.backgroundColor || "#000000"} onChange={(e) => updateContainerStyles("backgroundColor", e.target.value)} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {sidebarMode === "widget" && currentSelectedWidget && (
            <div className="sidebar-editor-view">
              <div className="editor-view-header">
                <div className="editor-title-row">
                  <button type="button" className="back-btn" onClick={() => setSidebarMode("widgets")}><ArrowLeft /></button>
                  <h3 className="editor-title">Editar {currentSelectedWidget.type.toUpperCase()} ✏️</h3>
                </div>
              </div>

              {/* Pestañas de Edición de Elementor: General / Estilo / Disposición */}
              <div className="editor-sub-tabs">
                <button
                  type="button"
                  className={`sub-tab ${sidebarTab === "general" ? "active" : ""}`}
                  onClick={() => setSidebarTab("general")}
                >
                  General
                </button>
                <button
                  type="button"
                  className={`sub-tab ${sidebarTab === "estilo" ? "active" : ""}`}
                  onClick={() => setSidebarTab("estilo")}
                >
                  Estilo
                </button>
                <button
                  type="button"
                  className={`sub-tab ${sidebarTab === "interacciones" ? "active" : ""}`}
                  onClick={() => setSidebarTab("interacciones")}
                >
                  Disposición
                </button>
              </div>

              {/* Botones de acción rápida: Insertar Arriba / Abajo */}
              <div style={{ padding: "10px 12px 0 12px" }}>
                <div style={{ display: "flex", gap: "6px", background: "#181b1e", padding: "6px", borderRadius: "6px", border: "1px solid #2d3238" }}>
                  <button
                    type="button"
                    style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: "4px", padding: "6px", background: "rgba(56, 189, 248, 0.12)", border: "1px solid rgba(56, 189, 248, 0.3)", borderRadius: "4px", color: "#38bdf8", fontSize: "11px", fontWeight: 700, cursor: "pointer" }}
                    onClick={() => {
                      setSidebarMode("widgets");
                    }}
                    title="Selecciona un widget de la barra para insertar arriba"
                  >
                    <ArrowUp style={{ width: 12, height: 12 }} /> + Arriba
                  </button>
                  <button
                    type="button"
                    style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: "4px", padding: "6px", background: "rgba(22, 201, 111, 0.12)", border: "1px solid rgba(22, 201, 111, 0.3)", borderRadius: "4px", color: "#16c96f", fontSize: "11px", fontWeight: 700, cursor: "pointer" }}
                    onClick={() => {
                      setSidebarMode("widgets");
                    }}
                    title="Selecciona un widget de la barra para insertar abajo"
                  >
                    <ArrowDown style={{ width: 12, height: 12 }} /> + Abajo
                  </button>
                </div>
              </div>

              <div className="editor-controls-stack">
                {/* ======================================================== */}
                {/* 1. PESTAÑA GENERAL: CONTENIDO Y AJUSTES PRINCIPALES */}
                {/* ======================================================== */}
                {sidebarTab === "general" && (
                  <>
                    {/* ENCABEZADO (HEADING) */}
                    {currentSelectedWidget.type === "heading" && (
                      <>
                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Contenido</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row-col">
                              <label>Título:</label>
                              <textarea
                                rows={3}
                                value={currentSelectedWidget.settings.title || ""}
                                onChange={(e) => updateWidgetSetting("title", e.target.value)}
                                placeholder="Escribe tu título aquí..."
                                className="wp-textarea"
                              />
                            </div>
                            <div className="ctrl-row-col">
                              <label>Enlace (URL opcional):</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.linkUrl || ""}
                                onChange={(e) => updateWidgetSetting("linkUrl", e.target.value)}
                                placeholder="https://ejemplo.com o #seccion"
                              />
                            </div>
                          </div>
                        </div>

                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Ajustes</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row">
                              <label>Etiqueta HTML:</label>
                              <select
                                value={currentSelectedWidget.settings.tag || "h2"}
                                onChange={(e) => updateWidgetSetting("tag", e.target.value)}
                                style={{ background: "#141414", color: "#fff", border: "1px solid #33383c", padding: "4px 8px", borderRadius: "4px" }}
                              >
                                <option value="h1">H1</option>
                                <option value="h2">H2</option>
                                <option value="h3">H3</option>
                                <option value="h4">H4</option>
                                <option value="h5">H5</option>
                                <option value="h6">H6</option>
                                <option value="p">p</option>
                                <option value="span">span</option>
                                <option value="div">div</option>
                              </select>
                            </div>

                            <div className="ctrl-row-col">
                              <label>Alineación:</label>
                              <div className="btn-group-4">
                                <button
                                  type="button"
                                  className={(currentSelectedWidget.settings.align || "left") === "left" ? "active" : ""}
                                  onClick={() => updateWidgetSetting("align", "left")}
                                  title="Alinear a la Izquierda"
                                >
                                  <AlignLeft style={{ width: 14, height: 14 }} />
                                </button>
                                <button
                                  type="button"
                                  className={currentSelectedWidget.settings.align === "center" ? "active" : ""}
                                  onClick={() => updateWidgetSetting("align", "center")}
                                  title="Centrar"
                                >
                                  <AlignCenter style={{ width: 14, height: 14 }} />
                                </button>
                                <button
                                  type="button"
                                  className={currentSelectedWidget.settings.align === "right" ? "active" : ""}
                                  onClick={() => updateWidgetSetting("align", "right")}
                                  title="Alinear a la Derecha"
                                >
                                  <AlignRight style={{ width: 14, height: 14 }} />
                                </button>
                                <button
                                  type="button"
                                  className={currentSelectedWidget.settings.align === "justify" ? "active" : ""}
                                  onClick={() => updateWidgetSetting("align", "justify")}
                                  title="Justificado"
                                >
                                  <AlignJustify style={{ width: 14, height: 14 }} />
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </>
                    )}

                    {/* TEXTO / PÁRRAFO */}
                    {currentSelectedWidget.type === "text" && (
                      <div className="control-accordion-item">
                        <div className="accordion-label"><span>Editor de Texto</span><ChevronDown className="acc-chev" /></div>
                        <div className="accordion-body">
                          <textarea
                            rows={6}
                            value={currentSelectedWidget.settings.content || ""}
                            onChange={(e) => updateWidgetSetting("content", e.target.value)}
                            className="wp-textarea"
                            placeholder="Escribe tu párrafo o contenido HTML..."
                          />
                          <div className="ctrl-row-col">
                            <label>Alineación:</label>
                            <div className="btn-group-4">
                              <button
                                type="button"
                                className={(currentSelectedWidget.settings.align || "left") === "left" ? "active" : ""}
                                onClick={() => updateWidgetSetting("align", "left")}
                                title="Izquierda"
                              >
                                <AlignLeft style={{ width: 14, height: 14 }} />
                              </button>
                              <button
                                type="button"
                                className={currentSelectedWidget.settings.align === "center" ? "active" : ""}
                                onClick={() => updateWidgetSetting("align", "center")}
                                title="Centro"
                              >
                                <AlignCenter style={{ width: 14, height: 14 }} />
                              </button>
                              <button
                                type="button"
                                className={currentSelectedWidget.settings.align === "right" ? "active" : ""}
                                onClick={() => updateWidgetSetting("align", "right")}
                                title="Derecha"
                              >
                                <AlignRight style={{ width: 14, height: 14 }} />
                              </button>
                              <button
                                type="button"
                                className={currentSelectedWidget.settings.align === "justify" ? "active" : ""}
                                onClick={() => updateWidgetSetting("align", "justify")}
                                title="Justificado"
                              >
                                <AlignJustify style={{ width: 14, height: 14 }} />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* IMAGEN */}
                    {currentSelectedWidget.type === "image" && (
                      <div className="control-accordion-item">
                        <div className="accordion-label"><span>Contenido de Imagen</span><ChevronDown className="acc-chev" /></div>
                        <div className="accordion-body">
                          <div className="ctrl-row-col">
                            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
                              <label style={{ margin: 0 }}>Imagen:</label>
                              <label
                                style={{
                                  display: "inline-flex",
                                  alignItems: "center",
                                  gap: "4px",
                                  background: "#16c96f",
                                  color: "#020b14",
                                  fontSize: "11px",
                                  fontWeight: 800,
                                  padding: "4px 8px",
                                  borderRadius: "4px",
                                  cursor: isUploadingMedia ? "not-allowed" : "pointer"
                                }}
                              >
                                {isUploadingMedia ? <Loader2 className="animate-spin" style={{ width: 12, height: 12 }} /> : <Upload style={{ width: 12, height: 12 }} />}
                                {isUploadingMedia ? "Subiendo..." : "Subir del Servidor"}
                                <input
                                  type="file"
                                  accept="image/*"
                                  disabled={isUploadingMedia}
                                  style={{ display: "none" }}
                                  onChange={async (e) => {
                                    const file = e.target.files?.[0];
                                    if (!file) return;
                                    const uploadedUrl = await handleUploadMedia(file);
                                    if (uploadedUrl) {
                                      updateWidgetSetting("imageUrl", uploadedUrl);
                                    }
                                  }}
                                />
                              </label>
                            </div>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.imageUrl || ""}
                              onChange={(e) => updateWidgetSetting("imageUrl", e.target.value)}
                              placeholder="https://... o sube un archivo local"
                            />
                            {currentSelectedWidget.settings.imageUrl && (
                              <div style={{ marginTop: 6, borderRadius: 6, overflow: "hidden", border: "1px solid #33383c", maxHeight: 120, background: "#0a0a0a" }}>
                                <img src={currentSelectedWidget.settings.imageUrl} alt="" style={{ width: "100%", maxHeight: 120, objectFit: "contain" }} />
                              </div>
                            )}
                          </div>
                          <div className="ctrl-row-col">
                            <label>Texto Alternativo (Alt):</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.imageAlt || ""}
                              onChange={(e) => updateWidgetSetting("imageAlt", e.target.value)}
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>Enlace al hacer clic:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.linkUrl || ""}
                              onChange={(e) => updateWidgetSetting("linkUrl", e.target.value)}
                              placeholder="https://..."
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>Alineación:</label>
                            <div className="btn-group-3">
                              <button
                                type="button"
                                className={(currentSelectedWidget.settings.align || "center") === "left" ? "active" : ""}
                                onClick={() => updateWidgetSetting("align", "left")}
                                title="Izquierda"
                              >
                                <AlignLeft style={{ width: 14, height: 14 }} />
                              </button>
                              <button
                                type="button"
                                className={(currentSelectedWidget.settings.align || "center") === "center" ? "active" : ""}
                                onClick={() => updateWidgetSetting("align", "center")}
                                title="Centro"
                              >
                                <AlignCenter style={{ width: 14, height: 14 }} />
                              </button>
                              <button
                                type="button"
                                className={currentSelectedWidget.settings.align === "right" ? "active" : ""}
                                onClick={() => updateWidgetSetting("align", "right")}
                                title="Derecha"
                              >
                                <AlignRight style={{ width: 14, height: 14 }} />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* BOTÓN */}
                    {currentSelectedWidget.type === "button" && (
                      <>
                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Contenido del Botón</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row-col">
                              <label>Texto del Botón:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.buttonText || ""}
                                onChange={(e) => updateWidgetSetting("buttonText", e.target.value)}
                                placeholder="Ej: Comenzar Ahora"
                              />
                            </div>
                            <div className="ctrl-row-col">
                              <label>Enlace de Destino (URL):</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.buttonLink || ""}
                                onChange={(e) => updateWidgetSetting("buttonLink", e.target.value)}
                                placeholder="https://... o /servicios o #contacto"
                              />
                            </div>
                            <div className="ctrl-row">
                              <label>Abrir en nueva pestaña:</label>
                              <input
                                type="checkbox"
                                checked={!!currentSelectedWidget.settings.buttonNewTab}
                                onChange={(e) => updateWidgetSetting("buttonNewTab", e.target.checked)}
                              />
                            </div>
                          </div>
                        </div>

                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Icono del Botón</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row">
                              <label>Icono:</label>
                              <select
                                value={currentSelectedWidget.settings.buttonIcon || "arrow"}
                                onChange={(e) => updateWidgetSetting("buttonIcon", e.target.value)}
                                style={{ background: "#141414", color: "#fff", border: "1px solid #33383c", padding: "4px 8px", borderRadius: "4px" }}
                              >
                                <option value="none">Sin Icono</option>
                                <option value="arrow">Flecha →</option>
                                <option value="sparkles">Destellos ✨</option>
                                <option value="external">Enlace Externo ↗</option>
                                <option value="download">Descargar ⬇</option>
                                <option value="phone">Teléfono 📞</option>
                                <option value="whatsapp">WhatsApp 💬</option>
                                <option value="mail">Correo ✉</option>
                                <option value="check">Check / Listo ✓</option>
                              </select>
                            </div>
                            <div className="ctrl-row">
                              <label>Posición del Icono:</label>
                              <select
                                value={currentSelectedWidget.settings.buttonIconPos || "right"}
                                onChange={(e) => updateWidgetSetting("buttonIconPos", e.target.value)}
                                style={{ background: "#141414", color: "#fff", border: "1px solid #33383c", padding: "4px 8px", borderRadius: "4px" }}
                              >
                                <option value="left">Izquierda (Antes del texto)</option>
                                <option value="right">Derecha (Después del texto)</option>
                              </select>
                            </div>
                            <div className="ctrl-row">
                              <label>Espacio del Icono (px):</label>
                              <input
                                type="number"
                                value={currentSelectedWidget.settings.buttonIconGap ?? 8}
                                onChange={(e) => updateWidgetSetting("buttonIconGap", parseInt(e.target.value) || 0)}
                              />
                            </div>
                          </div>
                        </div>

                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Alineación y Disposición</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row-col">
                              <label>Alineación:</label>
                              <div className="btn-group-4">
                                <button
                                  type="button"
                                  className={(currentSelectedWidget.settings.buttonAlign || "left") === "left" ? "active" : ""}
                                  onClick={() => updateWidgetSetting("buttonAlign", "left")}
                                  title="Izquierda"
                                >
                                  <AlignLeft style={{ width: 14, height: 14 }} />
                                </button>
                                <button
                                  type="button"
                                  className={currentSelectedWidget.settings.buttonAlign === "center" ? "active" : ""}
                                  onClick={() => updateWidgetSetting("buttonAlign", "center")}
                                  title="Centro"
                                >
                                  <AlignCenter style={{ width: 14, height: 14 }} />
                                </button>
                                <button
                                  type="button"
                                  className={currentSelectedWidget.settings.buttonAlign === "right" ? "active" : ""}
                                  onClick={() => updateWidgetSetting("buttonAlign", "right")}
                                  title="Derecha"
                                >
                                  <AlignRight style={{ width: 14, height: 14 }} />
                                </button>
                                <button
                                  type="button"
                                  className={currentSelectedWidget.settings.buttonAlign === "justify" ? "active" : ""}
                                  onClick={() => updateWidgetSetting("buttonAlign", "justify")}
                                  title="Ancho Completo (100%)"
                                >
                                  <AlignJustify style={{ width: 14, height: 14 }} />
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </>
                    )}

                    {/* HERO */}
                    {currentSelectedWidget.type === "hero" && (
                      <>
                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Badge / Etiqueta Superior</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row">
                              <label>Mostrar Badge:</label>
                              <input
                                type="checkbox"
                                checked={currentSelectedWidget.settings.showBadge !== false}
                                onChange={(e) => updateWidgetSetting("showBadge", e.target.checked)}
                              />
                            </div>
                            <div className="ctrl-row-col">
                              <label>Texto del Badge:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.badge || ""}
                                onChange={(e) => updateWidgetSetting("badge", e.target.value)}
                                placeholder="✨ TECNOLOGÍA & INNOVACIÓN"
                              />
                            </div>
                          </div>
                        </div>

                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Título y Descripción</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row-col">
                              <label>Título Principal:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.heroTitle || ""}
                                onChange={(e) => updateWidgetSetting("heroTitle", e.target.value)}
                                placeholder="Transforma tu Futuro Digital"
                              />
                            </div>
                            <div className="ctrl-row-col">
                              <label>Subtítulo / Descripción:</label>
                              <textarea
                                rows={3}
                                value={currentSelectedWidget.settings.heroSubtitle || ""}
                                onChange={(e) => updateWidgetSetting("heroSubtitle", e.target.value)}
                                className="wp-textarea"
                                placeholder="Describe tu propuesta de valor..."
                              />
                            </div>
                            <div className="ctrl-row-col">
                              <label>Alineación del Hero:</label>
                              <div className="btn-group-3">
                                <button
                                  type="button"
                                  className={(currentSelectedWidget.settings.align || "center") === "left" ? "active" : ""}
                                  onClick={() => updateWidgetSetting("align", "left")}
                                  title="Izquierda"
                                >
                                  <AlignLeft style={{ width: 14, height: 14 }} />
                                </button>
                                <button
                                  type="button"
                                  className={(currentSelectedWidget.settings.align || "center") === "center" ? "active" : ""}
                                  onClick={() => updateWidgetSetting("align", "center")}
                                  title="Centro"
                                >
                                  <AlignCenter style={{ width: 14, height: 14 }} />
                                </button>
                                <button
                                  type="button"
                                  className={currentSelectedWidget.settings.align === "right" ? "active" : ""}
                                  onClick={() => updateWidgetSetting("align", "right")}
                                  title="Derecha"
                                >
                                  <AlignRight style={{ width: 14, height: 14 }} />
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Botón Principal (Primario)</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row">
                              <label>Mostrar Botón 1:</label>
                              <input
                                type="checkbox"
                                checked={currentSelectedWidget.settings.showPrimaryBtn !== false}
                                onChange={(e) => updateWidgetSetting("showPrimaryBtn", e.target.checked)}
                              />
                            </div>
                            <div className="ctrl-row-col">
                              <label>Texto del Botón:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.primaryBtnText || ""}
                                onChange={(e) => updateWidgetSetting("primaryBtnText", e.target.value)}
                                placeholder="Ver Servicios →"
                              />
                            </div>
                            <div className="ctrl-row-col">
                              <label>Enlace / URL de Destino:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.primaryBtnLink || ""}
                                onChange={(e) => updateWidgetSetting("primaryBtnLink", e.target.value)}
                                placeholder="/servicios o https://..."
                              />
                            </div>
                            <div className="ctrl-row">
                              <label>Abrir en nueva pestaña:</label>
                              <input
                                type="checkbox"
                                checked={!!currentSelectedWidget.settings.primaryBtnNewTab}
                                onChange={(e) => updateWidgetSetting("primaryBtnNewTab", e.target.checked)}
                              />
                            </div>
                          </div>
                        </div>

                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Botón Secundario</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row">
                              <label>Mostrar Botón 2:</label>
                              <input
                                type="checkbox"
                                checked={currentSelectedWidget.settings.showSecondaryBtn !== false}
                                onChange={(e) => updateWidgetSetting("showSecondaryBtn", e.target.checked)}
                              />
                            </div>
                            <div className="ctrl-row-col">
                              <label>Texto del Botón:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.secondaryBtnText || ""}
                                onChange={(e) => updateWidgetSetting("secondaryBtnText", e.target.value)}
                                placeholder="Contáctanos"
                              />
                            </div>
                            <div className="ctrl-row-col">
                              <label>Enlace / URL de Destino:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.secondaryBtnLink || ""}
                                onChange={(e) => updateWidgetSetting("secondaryBtnLink", e.target.value)}
                                placeholder="#contacto o https://..."
                              />
                            </div>
                            <div className="ctrl-row">
                              <label>Abrir en nueva pestaña:</label>
                              <input
                                type="checkbox"
                                checked={!!currentSelectedWidget.settings.secondaryBtnNewTab}
                                onChange={(e) => updateWidgetSetting("secondaryBtnNewTab", e.target.checked)}
                              />
                            </div>
                          </div>
                        </div>
                      </>
                    )}

                    {/* SEPARADOR */}
                    {currentSelectedWidget.type === "separator" && (
                      <div className="control-accordion-item">
                        <div className="accordion-label"><span>Ajustes de Separador</span><ChevronDown className="acc-chev" /></div>
                        <div className="accordion-body">
                          <div className="ctrl-row">
                            <label>Ancho:</label>
                            <select
                              value={currentSelectedWidget.settings.width || "100%"}
                              onChange={(e) => updateWidgetSetting("width", e.target.value)}
                              style={{ background: "#141414", color: "#fff", border: "1px solid #33383c", padding: "4px 8px", borderRadius: "4px" }}
                            >
                              <option value="25%">25%</option>
                              <option value="50%">50%</option>
                              <option value="75%">75%</option>
                              <option value="100%">100% (Completo)</option>
                            </select>
                          </div>
                          <div className="ctrl-row-col">
                            <label>Alineación:</label>
                            <div className="btn-group-3">
                              <button
                                type="button"
                                className={currentSelectedWidget.settings.align === "left" ? "active" : ""}
                                onClick={() => updateWidgetSetting("align", "left")}
                                title="Izquierda"
                              >
                                <AlignLeft style={{ width: 14, height: 14 }} />
                              </button>
                              <button
                                type="button"
                                className={(currentSelectedWidget.settings.align || "center") === "center" ? "active" : ""}
                                onClick={() => updateWidgetSetting("align", "center")}
                                title="Centro"
                              >
                                <AlignCenter style={{ width: 14, height: 14 }} />
                              </button>
                              <button
                                type="button"
                                className={currentSelectedWidget.settings.align === "right" ? "active" : ""}
                                onClick={() => updateWidgetSetting("align", "right")}
                                title="Derecha"
                              >
                                <AlignRight style={{ width: 14, height: 14 }} />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* VIDEO */}
                    {(currentSelectedWidget.type === "video" || currentSelectedWidget.type === "youtube") && (
                      <div className="control-accordion-item">
                        <div className="accordion-label"><span>URL del Video</span><ChevronDown className="acc-chev" /></div>
                        <div className="accordion-body">
                          <div className="ctrl-row-col">
                            <label>Enlace Embed (YouTube / Vimeo / MP4):</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.videoUrl || ""}
                              onChange={(e) => updateWidgetSetting("videoUrl", e.target.value)}
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>Alineación:</label>
                            <div className="btn-group-3">
                              <button
                                type="button"
                                className={currentSelectedWidget.settings.align === "left" ? "active" : ""}
                                onClick={() => updateWidgetSetting("align", "left")}
                                title="Izquierda"
                              >
                                <AlignLeft style={{ width: 14, height: 14 }} />
                              </button>
                              <button
                                type="button"
                                className={(currentSelectedWidget.settings.align || "center") === "center" ? "active" : ""}
                                onClick={() => updateWidgetSetting("align", "center")}
                                title="Centro"
                              >
                                <AlignCenter style={{ width: 14, height: 14 }} />
                              </button>
                              <button
                                type="button"
                                className={currentSelectedWidget.settings.align === "right" ? "active" : ""}
                                onClick={() => updateWidgetSetting("align", "right")}
                                title="Derecha"
                              >
                                <AlignRight style={{ width: 14, height: 14 }} />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* WIDGETS DINÁMICOS (SERVICIOS, TESTIMONIOS, ARTÍCULOS, GALERÍA) */}
                    {["services", "testimonials", "articles", "gallery"].includes(currentSelectedWidget.type) && (
                      <div className="control-accordion-item">
                        <div className="accordion-label"><span>Cabecera de la Sección</span><ChevronDown className="acc-chev" /></div>
                        <div className="accordion-body">
                          <div className="ctrl-row-col">
                            <label>Título de la Sección (Mayúsculas):</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.sectionTitle || ""}
                              onChange={(e) => updateWidgetSetting("sectionTitle", e.target.value)}
                              placeholder="Ej: LO QUE DICEN MIS CLIENTES"
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>Alineación de la Cabecera:</label>
                            <div className="btn-group-3">
                              <button
                                type="button"
                                className={(currentSelectedWidget.settings.headerAlign || "left") === "left" ? "active" : ""}
                                onClick={() => updateWidgetSetting("headerAlign", "left")}
                                title="Izquierda"
                              >
                                <AlignLeft style={{ width: 14, height: 14 }} />
                              </button>
                              <button
                                type="button"
                                className={currentSelectedWidget.settings.headerAlign === "center" ? "active" : ""}
                                onClick={() => updateWidgetSetting("headerAlign", "center")}
                                title="Centro"
                              >
                                <AlignCenter style={{ width: 14, height: 14 }} />
                              </button>
                              <button
                                type="button"
                                className={currentSelectedWidget.settings.headerAlign === "right" ? "active" : ""}
                                onClick={() => updateWidgetSetting("headerAlign", "right")}
                                title="Derecha"
                              >
                                <AlignRight style={{ width: 14, height: 14 }} />
                              </button>
                            </div>
                          </div>
                          <div className="ctrl-row-col">
                            <label>Texto del Enlace Superior Derecho:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.linkText || ""}
                              onChange={(e) => updateWidgetSetting("linkText", e.target.value)}
                              placeholder="Ej: Ver más testimonios"
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>URL / Destino del Enlace:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.linkUrl || ""}
                              onChange={(e) => updateWidgetSetting("linkUrl", e.target.value)}
                              placeholder="Ej: /testimonios"
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {/* STAR RATING */}
                    {currentSelectedWidget.type === "star-rating" && (
                      <div className="control-accordion-item">
                        <div className="accordion-label"><span>Valoración de Estrellas</span><ChevronDown className="acc-chev" /></div>
                        <div className="accordion-body">
                          <div className="ctrl-row-col">
                            <label>Título (opcional):</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.title || ""}
                              onChange={(e) => updateWidgetSetting("title", e.target.value)}
                              placeholder="Ej: Valoración Excelente"
                            />
                          </div>
                          <div className="ctrl-row">
                            <label>Puntuación (Rating):</label>
                            <input
                              type="number"
                              step="0.1"
                              min="0"
                              max="5"
                              value={currentSelectedWidget.settings.rating ?? 4.5}
                              onChange={(e) => updateWidgetSetting("rating", parseFloat(e.target.value) || 0)}
                            />
                          </div>
                          <div className="ctrl-row">
                            <label>Color de Estrellas:</label>
                            <input
                              type="color"
                              value={currentSelectedWidget.settings.starColor || "#f59e0b"}
                              onChange={(e) => updateWidgetSetting("starColor", e.target.value)}
                            />
                          </div>
                          <div className="ctrl-row">
                            <label>Tamaño Estrellas (px):</label>
                            <input
                              type="number"
                              value={currentSelectedWidget.settings.starSize || 18}
                              onChange={(e) => updateWidgetSetting("starSize", parseInt(e.target.value) || 18)}
                            />
                          </div>
                          <div className="ctrl-row">
                            <label>Mostrar puntuación numérica:</label>
                            <input
                              type="checkbox"
                              checked={currentSelectedWidget.settings.showScore !== false}
                              onChange={(e) => updateWidgetSetting("showScore", e.target.checked)}
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>Alineación:</label>
                            <div className="btn-group-3">
                              <button type="button" className={(currentSelectedWidget.settings.align || "left") === "left" ? "active" : ""} onClick={() => updateWidgetSetting("align", "left")}><AlignLeft style={{ width: 14, height: 14 }} /></button>
                              <button type="button" className={currentSelectedWidget.settings.align === "center" ? "active" : ""} onClick={() => updateWidgetSetting("align", "center")}><AlignCenter style={{ width: 14, height: 14 }} /></button>
                              <button type="button" className={currentSelectedWidget.settings.align === "right" ? "active" : ""} onClick={() => updateWidgetSetting("align", "right")}><AlignRight style={{ width: 14, height: 14 }} /></button>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* CAROUSEL / CARRUSEL DE IMÁGENES */}
                    {currentSelectedWidget.type === "carousel" && (
                      <>
                        <div className="control-accordion-item">
                          <div className="accordion-label">
                            <span>Diapositivas e Imágenes ({((currentSelectedWidget.settings.images as any[]) || []).length})</span>
                            <ChevronDown className="acc-chev" />
                          </div>
                          <div className="accordion-body">
                            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12, flexWrap: "wrap", gap: "6px" }}>
                              <label style={{ margin: 0, fontWeight: 700, color: "#e2e8f0" }}>Imágenes:</label>
                              <div style={{ display: "flex", gap: "6px" }}>
                                <label
                                  style={{
                                    display: "inline-flex",
                                    alignItems: "center",
                                    gap: "4px",
                                    background: "#38bdf8",
                                    color: "#020b14",
                                    fontWeight: 800,
                                    fontSize: "11px",
                                    padding: "5px 10px",
                                    borderRadius: "5px",
                                    cursor: isUploadingMedia ? "not-allowed" : "pointer"
                                  }}
                                  title="Subir una o varias fotos desde tu equipo al servidor"
                                >
                                  {isUploadingMedia ? <Loader2 className="animate-spin" style={{ width: 13, height: 13 }} /> : <Upload style={{ width: 13, height: 13 }} />}
                                  {isUploadingMedia ? "Subiendo..." : "Subir del Servidor"}
                                  <input
                                    type="file"
                                    accept="image/*"
                                    multiple
                                    disabled={isUploadingMedia}
                                    style={{ display: "none" }}
                                    onChange={async (e) => {
                                      const files = Array.from(e.target.files || []);
                                      if (files.length === 0) return;
                                      const newUploads: any[] = [];
                                      for (const file of files) {
                                        const uploadedUrl = await handleUploadMedia(file);
                                        if (uploadedUrl) {
                                          newUploads.push({
                                            url: uploadedUrl,
                                            caption: file.name.replace(/\.[^/.]+$/, "")
                                          });
                                        }
                                      }
                                      if (newUploads.length > 0) {
                                        const cur = Array.isArray(currentSelectedWidget.settings.images) ? currentSelectedWidget.settings.images : [];
                                        updateWidgetSetting("images", [...cur, ...newUploads]);
                                      }
                                    }}
                                  />
                                </label>

                                <button
                                  type="button"
                                  onClick={() => {
                                    const cur = Array.isArray(currentSelectedWidget.settings.images) ? currentSelectedWidget.settings.images : [];
                                    const sampleUrls = [
                                      "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80",
                                      "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80",
                                      "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80",
                                      "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80",
                                      "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80"
                                    ];
                                    const nextUrl = sampleUrls[cur.length % sampleUrls.length];
                                    updateWidgetSetting("images", [
                                      ...cur,
                                      {
                                        url: nextUrl,
                                        caption: `Diapositiva ${cur.length + 1}`
                                      }
                                    ]);
                                  }}
                                  style={{
                                    display: "flex",
                                    alignItems: "center",
                                    gap: "4px",
                                    background: "#16c96f",
                                    color: "#020b14",
                                    fontWeight: 800,
                                    fontSize: "11px",
                                    padding: "5px 10px",
                                    borderRadius: "5px",
                                    border: "none",
                                    cursor: "pointer"
                                  }}
                                  title="Añadir una diapositiva ingresando su URL"
                                >
                                  <Plus style={{ width: 13, height: 13 }} /> URL
                                </button>
                              </div>
                            </div>

                            {/* Lista de diapositivas */}
                            <div style={{ display: "flex", flexDirection: "column", gap: "10px", marginBottom: 14 }}>
                              {((currentSelectedWidget.settings.images as any[]) || []).map((img: any, idx: number) => (
                                <div
                                  key={idx}
                                  style={{
                                    background: "#181b1e",
                                    border: "1px solid #2d3238",
                                    borderRadius: "8px",
                                    padding: "10px",
                                    display: "flex",
                                    flexDirection: "column",
                                    gap: "8px"
                                  }}
                                >
                                  <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                                    <div style={{ width: "48px", height: "48px", borderRadius: "6px", overflow: "hidden", background: "#0a0a0a", flexShrink: 0, border: "1px solid #33383c" }}>
                                      <img src={img.url} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                                    </div>
                                    <div style={{ flex: 1, minWidth: 0 }}>
                                      <span style={{ fontSize: "10px", color: "#16c96f", fontWeight: 700 }}>Diapositiva #{idx + 1}</span>
                                      <div style={{ fontSize: "12px", color: "#ffffff", fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                                        {img.caption || "Sin subtítulo"}
                                      </div>
                                      <label
                                        style={{
                                          display: "inline-flex",
                                          alignItems: "center",
                                          gap: "3px",
                                          fontSize: "10px",
                                          color: "#38bdf8",
                                          marginTop: "3px",
                                          cursor: "pointer",
                                          textDecoration: "underline"
                                        }}
                                      >
                                        <Upload style={{ width: 10, height: 10 }} /> Cambiar foto
                                        <input
                                          type="file"
                                          accept="image/*"
                                          style={{ display: "none" }}
                                          onChange={async (e) => {
                                            const file = e.target.files?.[0];
                                            if (!file) return;
                                            const uploadedUrl = await handleUploadMedia(file);
                                            if (uploadedUrl) {
                                              const cur = [...((currentSelectedWidget.settings.images as any[]) || [])];
                                              cur[idx] = { ...cur[idx], url: uploadedUrl };
                                              updateWidgetSetting("images", cur);
                                            }
                                          }}
                                        />
                                      </label>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const cur = Array.isArray(currentSelectedWidget.settings.images) ? currentSelectedWidget.settings.images : [];
                                        updateWidgetSetting("images", cur.filter((_, i) => i !== idx));
                                      }}
                                      style={{ background: "rgba(239, 68, 68, 0.15)", border: "1px solid rgba(239, 68, 68, 0.3)", color: "#ef4444", borderRadius: "5px", padding: "6px", cursor: "pointer" }}
                                      title="Eliminar esta diapositiva"
                                    >
                                      <Trash2 style={{ width: 13, height: 13 }} />
                                    </button>
                                  </div>

                                  <div className="ctrl-row-col">
                                    <label style={{ fontSize: "10px" }}>URL de la Imagen:</label>
                                    <input
                                      type="text"
                                      value={img.url || ""}
                                      onChange={(e) => {
                                        const cur = [...((currentSelectedWidget.settings.images as any[]) || [])];
                                        cur[idx] = { ...cur[idx], url: e.target.value };
                                        updateWidgetSetting("images", cur);
                                      }}
                                      placeholder="https://ejemplo.com/foto.jpg"
                                      style={{ fontSize: "12px" }}
                                    />
                                  </div>

                                  <div className="ctrl-row-col">
                                    <label style={{ fontSize: "10px" }}>Subtítulo / Pie de foto (opcional):</label>
                                    <input
                                      type="text"
                                      value={img.caption || ""}
                                      onChange={(e) => {
                                        const cur = [...((currentSelectedWidget.settings.images as any[]) || [])];
                                        cur[idx] = { ...cur[idx], caption: e.target.value };
                                        updateWidgetSetting("images", cur);
                                      }}
                                      placeholder="Ej: Desarrollo Cloud y Escalabilidad"
                                      style={{ fontSize: "12px" }}
                                    />
                                  </div>
                                </div>
                              ))}

                              {(!currentSelectedWidget.settings.images || currentSelectedWidget.settings.images.length === 0) && (
                                <div style={{ padding: "16px", background: "rgba(255,255,255,0.02)", border: "1px dashed #33383c", borderRadius: "8px", textAlign: "center" }}>
                                  <p style={{ color: "#94a3b8", fontSize: "12px", margin: "0 0 8px" }}>No hay imágenes en el carrusel.</p>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      updateWidgetSetting("images", [
                                        { url: "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80", caption: "Tecnología de Punta" },
                                        { url: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80", caption: "Diseño & Estrategia" },
                                        { url: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80", caption: "Métricas & Resultados" },
                                      ]);
                                    }}
                                    style={{ background: "#16c96f", color: "#020b14", fontWeight: 700, fontSize: "11px", padding: "6px 12px", borderRadius: "4px", border: "none", cursor: "pointer" }}
                                  >
                                    Cargar imágenes de muestra
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* AJUSTES DE ANIMACIÓN Y AUTOPLAY */}
                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Animación y Cambio Automático</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row">
                              <label>Reproducción Automática (Autoplay):</label>
                              <input
                                type="checkbox"
                                checked={currentSelectedWidget.settings.autoplay !== false}
                                onChange={(e) => updateWidgetSetting("autoplay", e.target.checked)}
                              />
                            </div>

                            <div className="ctrl-row">
                              <label>Intervalo de Cambio:</label>
                              <select
                                value={currentSelectedWidget.settings.autoplaySpeed || 3000}
                                onChange={(e) => updateWidgetSetting("autoplaySpeed", parseInt(e.target.value) || 3000)}
                                style={{ background: "#141414", color: "#fff", border: "1px solid #33383c", padding: "4px 8px", borderRadius: "4px" }}
                              >
                                <option value="2000">2 segundos (Rápido)</option>
                                <option value="3000">3 segundos (Estándar)</option>
                                <option value="4000">4 segundos</option>
                                <option value="5000">5 segundos (Tranquilo)</option>
                                <option value="7000">7 segundos (Lento)</option>
                              </select>
                            </div>

                            <div className="ctrl-row">
                              <label>Pausar al pasar el ratón:</label>
                              <input
                                type="checkbox"
                                checked={currentSelectedWidget.settings.pauseOnHover !== false}
                                onChange={(e) => updateWidgetSetting("pauseOnHover", e.target.checked)}
                              />
                            </div>

                            <div className="ctrl-row">
                              <label>Diapositivas a la vez:</label>
                              <select
                                value={currentSelectedWidget.settings.slidesToShow || 3}
                                onChange={(e) => updateWidgetSetting("slidesToShow", parseInt(e.target.value) || 3)}
                                style={{ background: "#141414", color: "#fff", border: "1px solid #33383c", padding: "4px 8px", borderRadius: "4px" }}
                              >
                                <option value="1">1 sola imagen completa</option>
                                <option value="2">2 columnas</option>
                                <option value="3">3 columnas (Predeterminado)</option>
                                <option value="4">4 columnas</option>
                              </select>
                            </div>

                            <div className="ctrl-row">
                              <label>Mostrar Flechas (‹ / ›):</label>
                              <input
                                type="checkbox"
                                checked={currentSelectedWidget.settings.showArrows !== false}
                                onChange={(e) => updateWidgetSetting("showArrows", e.target.checked)}
                              />
                            </div>

                            <div className="ctrl-row">
                              <label>Mostrar Puntos (Dots):</label>
                              <input
                                type="checkbox"
                                checked={currentSelectedWidget.settings.showDots !== false}
                                onChange={(e) => updateWidgetSetting("showDots", e.target.checked)}
                              />
                            </div>

                            <div className="ctrl-row">
                              <label>Altura de Diapositiva (px):</label>
                              <input
                                type="number"
                                min="100"
                                max="800"
                                value={currentSelectedWidget.settings.height || 280}
                                onChange={(e) => updateWidgetSetting("height", parseInt(e.target.value) || 280)}
                              />
                            </div>

                            <div className="ctrl-row">
                              <label>Radio de esquinas (px):</label>
                              <input
                                type="number"
                                min="0"
                                max="40"
                                value={currentSelectedWidget.settings.borderRadius ?? 10}
                                onChange={(e) => updateWidgetSetting("borderRadius", parseInt(e.target.value) || 0)}
                              />
                            </div>
                          </div>
                        </div>
                      </>
                    )}

                    {/* GALLERY / GALERÍA */}
                    {currentSelectedWidget.type === "gallery" && (
                      <>
                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Cabecera de Galería</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row-col">
                              <label>Título de la Sección:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.sectionTitle || ""}
                                onChange={(e) => updateWidgetSetting("sectionTitle", e.target.value)}
                              />
                            </div>
                            <div className="ctrl-row-col">
                              <label>Texto del Enlace:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.linkText || ""}
                                onChange={(e) => updateWidgetSetting("linkText", e.target.value)}
                              />
                            </div>
                            <div className="ctrl-row-col">
                              <label>URL del Enlace:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.linkUrl || ""}
                                onChange={(e) => updateWidgetSetting("linkUrl", e.target.value)}
                              />
                            </div>
                          </div>
                        </div>

                        <div className="control-accordion-item">
                          <div className="accordion-label">
                            <span>Elementos de Galería ({((currentSelectedWidget.settings.items as any[]) || []).length})</span>
                            <ChevronDown className="acc-chev" />
                          </div>
                          <div className="accordion-body">
                            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12, flexWrap: "wrap", gap: "6px" }}>
                              <label style={{ margin: 0, fontWeight: 700, color: "#e2e8f0" }}>Proyectos / Fotos:</label>
                              <div style={{ display: "flex", gap: "6px" }}>
                                <label
                                  style={{
                                    display: "inline-flex",
                                    alignItems: "center",
                                    gap: "4px",
                                    background: "#38bdf8",
                                    color: "#020b14",
                                    fontWeight: 800,
                                    fontSize: "11px",
                                    padding: "5px 10px",
                                    borderRadius: "5px",
                                    cursor: isUploadingMedia ? "not-allowed" : "pointer"
                                  }}
                                  title="Subir fotos desde tu equipo a la galería"
                                >
                                  {isUploadingMedia ? <Loader2 className="animate-spin" style={{ width: 13, height: 13 }} /> : <Upload style={{ width: 13, height: 13 }} />}
                                  {isUploadingMedia ? "Subiendo..." : "Subir del Servidor"}
                                  <input
                                    type="file"
                                    accept="image/*"
                                    multiple
                                    disabled={isUploadingMedia}
                                    style={{ display: "none" }}
                                    onChange={async (e) => {
                                      const files = Array.from(e.target.files || []);
                                      if (files.length === 0) return;
                                      const newUploads: any[] = [];
                                      for (const file of files) {
                                        const uploadedUrl = await handleUploadMedia(file);
                                        if (uploadedUrl) {
                                          newUploads.push({
                                            title: file.name.replace(/\.[^/.]+$/, ""),
                                            category: "PORTAFOLIO",
                                            image: uploadedUrl
                                          });
                                        }
                                      }
                                      if (newUploads.length > 0) {
                                        const cur = Array.isArray(currentSelectedWidget.settings.items) ? currentSelectedWidget.settings.items : [];
                                        updateWidgetSetting("items", [...cur, ...newUploads]);
                                      }
                                    }}
                                  />
                                </label>

                                <button
                                  type="button"
                                  onClick={() => {
                                    const cur = Array.isArray(currentSelectedWidget.settings.items) ? currentSelectedWidget.settings.items : [];
                                    updateWidgetSetting("items", [
                                      ...cur,
                                      {
                                        title: `Nuevo Proyecto ${cur.length + 1}`,
                                        category: "PORTAFOLIO",
                                        image: `https://images.unsplash.com/photo-${1460925895917 + (cur.length + 1) * 3000}?auto=format&fit=crop&w=600&q=80`
                                      }
                                    ]);
                                  }}
                                  style={{ display: "flex", alignItems: "center", gap: "4px", background: "#16c96f", color: "#020b14", fontWeight: 800, fontSize: "11px", padding: "5px 10px", borderRadius: "5px", border: "none", cursor: "pointer" }}
                                >
                                  <Plus style={{ width: 13, height: 13 }} /> Añadir Proyecto
                                </button>
                              </div>
                            </div>

                            <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                              {((currentSelectedWidget.settings.items as any[]) || []).map((item: any, idx: number) => (
                                <div key={idx} style={{ background: "#181b1e", border: "1px solid #2d3238", borderRadius: "8px", padding: "10px", display: "flex", flexDirection: "column", gap: "8px" }}>
                                  <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                                    <div style={{ width: "48px", height: "48px", borderRadius: "6px", overflow: "hidden", background: "#0a0a0a", flexShrink: 0, border: "1px solid #33383c" }}>
                                      <img src={item.image} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                                    </div>
                                    <div style={{ flex: 1, minWidth: 0 }}>
                                      <div style={{ fontSize: "12px", color: "#ffffff", fontWeight: 700, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                                        {item.title || "Sin título"}
                                      </div>
                                      <span style={{ fontSize: "10px", color: "#16c96f", fontWeight: 700 }}>{item.category}</span>
                                      <div>
                                        <label
                                          style={{
                                            display: "inline-flex",
                                            alignItems: "center",
                                            gap: "3px",
                                            fontSize: "10px",
                                            color: "#38bdf8",
                                            cursor: "pointer",
                                            textDecoration: "underline"
                                          }}
                                        >
                                          <Upload style={{ width: 10, height: 10 }} /> Cambiar foto
                                          <input
                                            type="file"
                                            accept="image/*"
                                            style={{ display: "none" }}
                                            onChange={async (e) => {
                                              const file = e.target.files?.[0];
                                              if (!file) return;
                                              const uploadedUrl = await handleUploadMedia(file);
                                              if (uploadedUrl) {
                                                const cur = [...((currentSelectedWidget.settings.items as any[]) || [])];
                                                cur[idx] = { ...cur[idx], image: uploadedUrl };
                                                updateWidgetSetting("items", cur);
                                              }
                                            }}
                                          />
                                        </label>
                                      </div>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const cur = Array.isArray(currentSelectedWidget.settings.items) ? currentSelectedWidget.settings.items : [];
                                        updateWidgetSetting("items", cur.filter((_, i) => i !== idx));
                                      }}
                                      style={{ background: "rgba(239, 68, 68, 0.15)", border: "1px solid rgba(239, 68, 68, 0.3)", color: "#ef4444", borderRadius: "5px", padding: "6px", cursor: "pointer" }}
                                      title="Eliminar este elemento"
                                    >
                                      <Trash2 style={{ width: 13, height: 13 }} />
                                    </button>
                                  </div>

                                  <div className="ctrl-row-col">
                                    <label style={{ fontSize: "10px" }}>Título:</label>
                                    <input
                                      type="text"
                                      value={item.title || ""}
                                      onChange={(e) => {
                                        const cur = [...((currentSelectedWidget.settings.items as any[]) || [])];
                                        cur[idx] = { ...cur[idx], title: e.target.value };
                                        updateWidgetSetting("items", cur);
                                      }}
                                      style={{ fontSize: "12px" }}
                                    />
                                  </div>

                                  <div className="ctrl-row-col">
                                    <label style={{ fontSize: "10px" }}>Categoría:</label>
                                    <input
                                      type="text"
                                      value={item.category || ""}
                                      onChange={(e) => {
                                        const cur = [...((currentSelectedWidget.settings.items as any[]) || [])];
                                        cur[idx] = { ...cur[idx], category: e.target.value };
                                        updateWidgetSetting("items", cur);
                                      }}
                                      style={{ fontSize: "12px" }}
                                    />
                                  </div>

                                  <div className="ctrl-row-col">
                                    <label style={{ fontSize: "10px" }}>URL Imagen:</label>
                                    <input
                                      type="text"
                                      value={item.image || ""}
                                      onChange={(e) => {
                                        const cur = [...((currentSelectedWidget.settings.items as any[]) || [])];
                                        cur[idx] = { ...cur[idx], image: e.target.value };
                                        updateWidgetSetting("items", cur);
                                      }}
                                      style={{ fontSize: "12px" }}
                                    />
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </>
                    )}

                    {/* ICON */}
                    {currentSelectedWidget.type === "icon" && (
                      <div className="control-accordion-item">
                        <div className="accordion-label"><span>Ajustes del Icono</span><ChevronDown className="acc-chev" /></div>
                        <div className="accordion-body">
                          <div className="ctrl-row">
                            <label>Icono:</label>
                            <select
                              value={currentSelectedWidget.settings.icon || "sparkles"}
                              onChange={(e) => updateWidgetSetting("icon", e.target.value)}
                              style={{ background: "#141414", color: "#fff", border: "1px solid #33383c", padding: "4px 8px", borderRadius: "4px" }}
                            >
                              <option value="sparkles">✨ Destellos / Sparkles</option>
                              <option value="star">⭐ Estrella</option>
                              <option value="zap">⚡ Rayo / Velocidad</option>
                              <option value="check">✓ Verificado</option>
                              <option value="shield">🛡️ Escudo / Seguridad</option>
                              <option value="rocket">🚀 Cohete / Lanzamiento</option>
                              <option value="heart">❤️ Corazón</option>
                              <option value="globe">🌐 Mundo / Global</option>
                              <option value="code">💻 Código</option>
                              <option value="lock">🔒 Candado</option>
                            </select>
                          </div>
                          <div className="ctrl-row">
                            <label>Color del Icono:</label>
                            <input
                              type="color"
                              value={currentSelectedWidget.settings.iconColor || "#16c96f"}
                              onChange={(e) => updateWidgetSetting("iconColor", e.target.value)}
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>Color de Fondo del Badge:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.iconBg || "rgba(22, 201, 111, 0.15)"}
                              onChange={(e) => updateWidgetSetting("iconBg", e.target.value)}
                              placeholder="rgba(...) o #hex"
                            />
                          </div>
                          <div className="ctrl-row">
                            <label>Forma del Contenedor:</label>
                            <select
                              value={currentSelectedWidget.settings.shape || "circle"}
                              onChange={(e) => updateWidgetSetting("shape", e.target.value)}
                              style={{ background: "#141414", color: "#fff", border: "1px solid #33383c", padding: "4px 8px", borderRadius: "4px" }}
                            >
                              <option value="circle">Circular</option>
                              <option value="rounded">Redondeado</option>
                              <option value="square">Cuadrado</option>
                            </select>
                          </div>
                          <div className="ctrl-row">
                            <label>Tamaño (px):</label>
                            <input
                              type="number"
                              value={currentSelectedWidget.settings.iconSize || 28}
                              onChange={(e) => updateWidgetSetting("iconSize", parseInt(e.target.value) || 28)}
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>Enlace URL (opcional):</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.linkUrl || ""}
                              onChange={(e) => updateWidgetSetting("linkUrl", e.target.value)}
                              placeholder="https://... o #seccion"
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>Alineación:</label>
                            <div className="btn-group-3">
                              <button type="button" className={(currentSelectedWidget.settings.align || "left") === "left" ? "active" : ""} onClick={() => updateWidgetSetting("align", "left")}><AlignLeft style={{ width: 14, height: 14 }} /></button>
                              <button type="button" className={currentSelectedWidget.settings.align === "center" ? "active" : ""} onClick={() => updateWidgetSetting("align", "center")}><AlignCenter style={{ width: 14, height: 14 }} /></button>
                              <button type="button" className={currentSelectedWidget.settings.align === "right" ? "active" : ""} onClick={() => updateWidgetSetting("align", "right")}><AlignRight style={{ width: 14, height: 14 }} /></button>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* IMAGE BOX */}
                    {currentSelectedWidget.type === "image-box" && (
                      <div className="control-accordion-item">
                        <div className="accordion-label"><span>Caja de Imagen (Image Box)</span><ChevronDown className="acc-chev" /></div>
                        <div className="accordion-body">
                          <div className="ctrl-row-col">
                            <label>URL de Imagen:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.imageUrl || ""}
                              onChange={(e) => updateWidgetSetting("imageUrl", e.target.value)}
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>Título:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.title || ""}
                              onChange={(e) => updateWidgetSetting("title", e.target.value)}
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>Descripción:</label>
                            <textarea
                              rows={3}
                              value={currentSelectedWidget.settings.description || ""}
                              onChange={(e) => updateWidgetSetting("description", e.target.value)}
                              className="wp-textarea"
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>Texto del Enlace:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.linkText || ""}
                              onChange={(e) => updateWidgetSetting("linkText", e.target.value)}
                              placeholder="Ej: Conocer más →"
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>URL del Enlace:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.linkUrl || ""}
                              onChange={(e) => updateWidgetSetting("linkUrl", e.target.value)}
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>Alineación:</label>
                            <div className="btn-group-3">
                              <button type="button" className={(currentSelectedWidget.settings.align || "center") === "left" ? "active" : ""} onClick={() => updateWidgetSetting("align", "left")}><AlignLeft style={{ width: 14, height: 14 }} /></button>
                              <button type="button" className={(currentSelectedWidget.settings.align || "center") === "center" ? "active" : ""} onClick={() => updateWidgetSetting("align", "center")}><AlignCenter style={{ width: 14, height: 14 }} /></button>
                              <button type="button" className={currentSelectedWidget.settings.align === "right" ? "active" : ""} onClick={() => updateWidgetSetting("align", "right")}><AlignRight style={{ width: 14, height: 14 }} /></button>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* ICON BOX */}
                    {currentSelectedWidget.type === "icon-box" && (
                      <div className="control-accordion-item">
                        <div className="accordion-label"><span>Caja de Icono (Icon Box)</span><ChevronDown className="acc-chev" /></div>
                        <div className="accordion-body">
                          <div className="ctrl-row-col">
                            <label>Icono / Emoji:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.icon || "⚡"}
                              onChange={(e) => updateWidgetSetting("icon", e.target.value)}
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>Título:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.title || ""}
                              onChange={(e) => updateWidgetSetting("title", e.target.value)}
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>Descripción:</label>
                            <textarea
                              rows={3}
                              value={currentSelectedWidget.settings.description || ""}
                              onChange={(e) => updateWidgetSetting("description", e.target.value)}
                              className="wp-textarea"
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>Texto del Enlace:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.linkText || ""}
                              onChange={(e) => updateWidgetSetting("linkText", e.target.value)}
                              placeholder="Ej: Ver detalles →"
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>URL del Enlace:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.linkUrl || ""}
                              onChange={(e) => updateWidgetSetting("linkUrl", e.target.value)}
                            />
                          </div>
                          <div className="ctrl-row">
                            <label>Color del Icono:</label>
                            <input
                              type="color"
                              value={currentSelectedWidget.settings.iconColor || "#16c96f"}
                              onChange={(e) => updateWidgetSetting("iconColor", e.target.value)}
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {/* COUNTER */}
                    {currentSelectedWidget.type === "counter" && (
                      <div className="control-accordion-item">
                        <div className="accordion-label"><span>Ajustes del Contador</span><ChevronDown className="acc-chev" /></div>
                        <div className="accordion-body">
                          <div className="ctrl-row">
                            <label>Número Final:</label>
                            <input
                              type="number"
                              value={currentSelectedWidget.settings.endingNumber ?? 150}
                              onChange={(e) => updateWidgetSetting("endingNumber", parseInt(e.target.value) || 0)}
                            />
                          </div>
                          <div className="ctrl-row">
                            <label>Prefijo:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.prefix || ""}
                              onChange={(e) => updateWidgetSetting("prefix", e.target.value)}
                              placeholder="Ej: +"
                            />
                          </div>
                          <div className="ctrl-row">
                            <label>Sufijo:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.suffix || ""}
                              onChange={(e) => updateWidgetSetting("suffix", e.target.value)}
                              placeholder="Ej: K o %"
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>Título / Etiqueta:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.title || ""}
                              onChange={(e) => updateWidgetSetting("title", e.target.value)}
                              placeholder="Ej: Usuarios Activos"
                            />
                          </div>
                          <div className="ctrl-row">
                            <label>Color del Número:</label>
                            <input
                              type="color"
                              value={currentSelectedWidget.settings.numberColor || "#16c96f"}
                              onChange={(e) => updateWidgetSetting("numberColor", e.target.value)}
                            />
                          </div>
                          <div className="ctrl-row">
                            <label>Tamaño del Número (px):</label>
                            <input
                              type="number"
                              value={currentSelectedWidget.settings.numberSize || 42}
                              onChange={(e) => updateWidgetSetting("numberSize", parseInt(e.target.value) || 42)}
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {/* SPACER */}
                    {currentSelectedWidget.type === "spacer" && (
                      <div className="control-accordion-item">
                        <div className="accordion-label"><span>Espacio Vertical</span><ChevronDown className="acc-chev" /></div>
                        <div className="accordion-body">
                          <div className="ctrl-row">
                            <label>Altura del Espacio (px):</label>
                            <input
                              type="number"
                              min="10"
                              max="300"
                              value={currentSelectedWidget.settings.spaceHeight ?? 50}
                              onChange={(e) => updateWidgetSetting("spaceHeight", parseInt(e.target.value) || 50)}
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {/* TESTIMONIAL CARD */}
                    {currentSelectedWidget.type === "testimonial-card" && (
                      <div className="control-accordion-item">
                        <div className="accordion-label"><span>Testimonio Individual</span><ChevronDown className="acc-chev" /></div>
                        <div className="accordion-body">
                          <div className="ctrl-row-col">
                            <label>Cita / Testimonio:</label>
                            <textarea
                              rows={3}
                              value={currentSelectedWidget.settings.quote || ""}
                              onChange={(e) => updateWidgetSetting("quote", e.target.value)}
                              className="wp-textarea"
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>Autor:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.author || ""}
                              onChange={(e) => updateWidgetSetting("author", e.target.value)}
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>Cargo / Empresa:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.role || ""}
                              onChange={(e) => updateWidgetSetting("role", e.target.value)}
                            />
                          </div>
                          <div className="ctrl-row">
                            <label>Estrellas (1-5):</label>
                            <input
                              type="number"
                              min="1"
                              max="5"
                              value={currentSelectedWidget.settings.rating ?? 5}
                              onChange={(e) => updateWidgetSetting("rating", parseInt(e.target.value) || 5)}
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {/* PROGRESS BAR */}
                    {currentSelectedWidget.type === "progress-bar" && (
                      <div className="control-accordion-item">
                        <div className="accordion-label"><span>Barra de Progreso</span><ChevronDown className="acc-chev" /></div>
                        <div className="accordion-body">
                          <div className="ctrl-row-col">
                            <label>Título:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.title || ""}
                              onChange={(e) => updateWidgetSetting("title", e.target.value)}
                            />
                          </div>
                          <div className="ctrl-row">
                            <label>Porcentaje (0-100%):</label>
                            <input
                              type="number"
                              min="0"
                              max="100"
                              value={currentSelectedWidget.settings.percentage ?? 95}
                              onChange={(e) => updateWidgetSetting("percentage", parseInt(e.target.value) || 0)}
                            />
                          </div>
                          <div className="ctrl-row">
                            <label>Color de Barra:</label>
                            <input
                              type="color"
                              value={currentSelectedWidget.settings.barColor || "#16c96f"}
                              onChange={(e) => updateWidgetSetting("barColor", e.target.value)}
                            />
                          </div>
                          <div className="ctrl-row">
                            <label>Mostrar número porcentual:</label>
                            <input
                              type="checkbox"
                              checked={currentSelectedWidget.settings.showPercentage !== false}
                              onChange={(e) => updateWidgetSetting("showPercentage", e.target.checked)}
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {/* SOCIAL ICONS */}
                    {currentSelectedWidget.type === "social-icons" && (
                      <>
                        <div className="control-accordion-item">
                          <div className="accordion-label">
                            <span>Redes Sociales ({((currentSelectedWidget.settings.networks as any[]) || []).length})</span>
                            <ChevronDown className="acc-chev" />
                          </div>
                          <div className="accordion-body">
                            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                              <label style={{ margin: 0, fontWeight: 700, color: "#e2e8f0" }}>Redes Disponibles:</label>
                              <button
                                type="button"
                                onClick={() => {
                                  const cur = Array.isArray(currentSelectedWidget.settings.networks) ? currentSelectedWidget.settings.networks : [];
                                  const presets = [
                                    { name: "Instagram", url: "https://instagram.com", color: "#e1306c", icon: "📸" },
                                    { name: "YouTube", url: "https://youtube.com", color: "#ff0000", icon: "▶️" },
                                    { name: "TikTok", url: "https://tiktok.com", color: "#000000", icon: "🎵" },
                                    { name: "Facebook", url: "https://facebook.com", color: "#1877f2", icon: "👥" },
                                    { name: "LinkedIn", url: "https://linkedin.com", color: "#0077b5", icon: "💼" },
                                    { name: "WhatsApp", url: "https://wa.me/51999999999", color: "#25d366", icon: "💬" },
                                  ];
                                  const nextPreset = presets[cur.length % presets.length];
                                  updateWidgetSetting("networks", [...cur, nextPreset]);
                                }}
                                style={{ display: "flex", alignItems: "center", gap: "4px", background: "#16c96f", color: "#020b14", fontWeight: 800, fontSize: "11px", padding: "5px 10px", borderRadius: "5px", border: "none", cursor: "pointer" }}
                              >
                                <Plus style={{ width: 13, height: 13 }} /> Añadir Red
                              </button>
                            </div>

                            <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                              {((currentSelectedWidget.settings.networks as any[]) || []).map((net: any, idx: number) => (
                                <div key={idx} style={{ background: "#181b1e", border: "1px solid #2d3238", borderRadius: "6px", padding: "8px", display: "flex", flexDirection: "column", gap: "6px" }}>
                                  <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                                    <input
                                      type="text"
                                      value={net.icon || "🔗"}
                                      onChange={(e) => {
                                        const cur = [...((currentSelectedWidget.settings.networks as any[]) || [])];
                                        cur[idx] = { ...cur[idx], icon: e.target.value };
                                        updateWidgetSetting("networks", cur);
                                      }}
                                      style={{ width: "32px", textAlign: "center", padding: "3px" }}
                                      title="Emoji / Icono"
                                    />
                                    <input
                                      type="text"
                                      value={net.name || ""}
                                      onChange={(e) => {
                                        const cur = [...((currentSelectedWidget.settings.networks as any[]) || [])];
                                        cur[idx] = { ...cur[idx], name: e.target.value };
                                        updateWidgetSetting("networks", cur);
                                      }}
                                      placeholder="Nombre de red..."
                                      style={{ flex: 1, padding: "3px 6px", fontSize: "11px" }}
                                    />
                                    <input
                                      type="color"
                                      value={net.color || "#16c96f"}
                                      onChange={(e) => {
                                        const cur = [...((currentSelectedWidget.settings.networks as any[]) || [])];
                                        cur[idx] = { ...cur[idx], color: e.target.value };
                                        updateWidgetSetting("networks", cur);
                                      }}
                                      style={{ width: "26px", height: "26px", padding: 0, border: "none", cursor: "pointer" }}
                                    />
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const cur = Array.isArray(currentSelectedWidget.settings.networks) ? currentSelectedWidget.settings.networks : [];
                                        updateWidgetSetting("networks", cur.filter((_, i) => i !== idx));
                                      }}
                                      style={{ background: "rgba(239, 68, 68, 0.15)", border: "1px solid rgba(239, 68, 68, 0.3)", color: "#ef4444", borderRadius: "4px", padding: "4px 6px", cursor: "pointer" }}
                                      title="Eliminar red social"
                                    >
                                      <Trash2 style={{ width: 12, height: 12 }} />
                                    </button>
                                  </div>
                                  <input
                                    type="text"
                                    value={net.url || ""}
                                    onChange={(e) => {
                                      const cur = [...((currentSelectedWidget.settings.networks as any[]) || [])];
                                      cur[idx] = { ...cur[idx], url: e.target.value };
                                      updateWidgetSetting("networks", cur);
                                    }}
                                    placeholder="https://..."
                                    style={{ fontSize: "11px", padding: "3px 6px" }}
                                  />
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>

                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Formato de Iconos</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row">
                              <label>Forma:</label>
                              <select
                                value={currentSelectedWidget.settings.shape || "circle"}
                                onChange={(e) => updateWidgetSetting("shape", e.target.value)}
                                style={{ background: "#141414", color: "#fff", border: "1px solid #33383c", padding: "4px 8px", borderRadius: "4px" }}
                              >
                                <option value="circle">Circular</option>
                                <option value="rounded">Redondeado</option>
                                <option value="square">Cuadrado</option>
                              </select>
                            </div>
                            <div className="ctrl-row">
                              <label>Tamaño (px):</label>
                              <input
                                type="number"
                                value={currentSelectedWidget.settings.size || 38}
                                onChange={(e) => updateWidgetSetting("size", parseInt(e.target.value) || 38)}
                              />
                            </div>
                            <div className="ctrl-row-col">
                              <label>Alineación:</label>
                              <div className="btn-group-3">
                                <button type="button" className={(currentSelectedWidget.settings.align || "center") === "left" ? "active" : ""} onClick={() => updateWidgetSetting("align", "left")}><AlignLeft style={{ width: 14, height: 14 }} /></button>
                                <button type="button" className={(currentSelectedWidget.settings.align || "center") === "center" ? "active" : ""} onClick={() => updateWidgetSetting("align", "center")}><AlignCenter style={{ width: 14, height: 14 }} /></button>
                                <button type="button" className={(currentSelectedWidget.settings.align || "center") === "right" ? "active" : ""} onClick={() => updateWidgetSetting("align", "right")}><AlignRight style={{ width: 14, height: 14 }} /></button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </>
                    )}

                    {/* ALERT */}
                    {currentSelectedWidget.type === "alert" && (
                      <div className="control-accordion-item">
                        <div className="accordion-label"><span>Cuadro de Alerta</span><ChevronDown className="acc-chev" /></div>
                        <div className="accordion-body">
                          <div className="ctrl-row">
                            <label>Tipo de Alerta:</label>
                            <select
                              value={currentSelectedWidget.settings.alertType || "info"}
                              onChange={(e) => updateWidgetSetting("alertType", e.target.value)}
                              style={{ background: "#141414", color: "#fff", border: "1px solid #33383c", padding: "4px 8px", borderRadius: "4px" }}
                            >
                              <option value="info">Información (Azul)</option>
                              <option value="success">Éxito (Verde)</option>
                              <option value="warning">Advertencia (Ámbar)</option>
                              <option value="danger">Peligro (Rojo)</option>
                            </select>
                          </div>
                          <div className="ctrl-row-col">
                            <label>Título:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.title || ""}
                              onChange={(e) => updateWidgetSetting("title", e.target.value)}
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>Mensaje:</label>
                            <textarea
                              rows={3}
                              value={currentSelectedWidget.settings.message || ""}
                              onChange={(e) => updateWidgetSetting("message", e.target.value)}
                              className="wp-textarea"
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {/* HTML */}
                    {currentSelectedWidget.type === "html" && (
                      <div className="control-accordion-item">
                        <div className="accordion-label"><span>Código HTML Personalizado</span><ChevronDown className="acc-chev" /></div>
                        <div className="accordion-body">
                          <div className="ctrl-row-col">
                            <label>Código HTML / CSS:</label>
                            <textarea
                              rows={8}
                              value={currentSelectedWidget.settings.customHtml || ""}
                              onChange={(e) => updateWidgetSetting("customHtml", e.target.value)}
                              className="wp-textarea"
                              style={{ fontFamily: "monospace", fontSize: "12px" }}
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {/* SHORTCODE */}
                    {currentSelectedWidget.type === "shortcode" && (
                      <div className="control-accordion-item">
                        <div className="accordion-label"><span>Ejecutor de Shortcode</span><ChevronDown className="acc-chev" /></div>
                        <div className="accordion-body">
                          <div className="ctrl-row-col">
                            <label>Shortcode:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.shortcode || ""}
                              onChange={(e) => updateWidgetSetting("shortcode", e.target.value)}
                              placeholder="[nombre_shortcode id='1']"
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {/* MENU ANCHOR */}
                    {currentSelectedWidget.type === "menu-anchor" && (
                      <div className="control-accordion-item">
                        <div className="accordion-label"><span>Ancla de Menú (#ID)</span><ChevronDown className="acc-chev" /></div>
                        <div className="accordion-body">
                          <div className="ctrl-row-col">
                            <label>ID del Ancla (sin #):</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.anchorId || ""}
                              onChange={(e) => updateWidgetSetting("anchorId", e.target.value)}
                              placeholder="contacto"
                            />
                            <span style={{ fontSize: "11px", color: "#64748b", marginTop: "4px" }}>
                              Luego enlaza botones o menús a #{currentSelectedWidget.settings.anchorId || "contacto"}
                            </span>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* SOUNDCLOUD */}
                    {currentSelectedWidget.type === "soundcloud" && (
                      <div className="control-accordion-item">
                        <div className="accordion-label"><span>Audio / SoundCloud</span><ChevronDown className="acc-chev" /></div>
                        <div className="accordion-body">
                          <div className="ctrl-row-col">
                            <label>URL de Reproducción:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.audioUrl || ""}
                              onChange={(e) => updateWidgetSetting("audioUrl", e.target.value)}
                            />
                          </div>
                          <div className="ctrl-row">
                            <label>Altura (px):</label>
                            <input
                              type="number"
                              value={currentSelectedWidget.settings.height || 140}
                              onChange={(e) => updateWidgetSetting("height", parseInt(e.target.value) || 140)}
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {/* TEXT PATH */}
                    {currentSelectedWidget.type === "text-path" && (
                      <div className="control-accordion-item">
                        <div className="accordion-label"><span>Ruta de Texto / Text Path</span><ChevronDown className="acc-chev" /></div>
                        <div className="accordion-body">
                          <div className="ctrl-row-col">
                            <label>Texto Decorativo:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.text || ""}
                              onChange={(e) => updateWidgetSetting("text", e.target.value)}
                            />
                          </div>
                          <div className="ctrl-row">
                            <label>Color de Texto:</label>
                            <input
                              type="color"
                              value={currentSelectedWidget.settings.textColor || "#38bdf8"}
                              onChange={(e) => updateWidgetSetting("textColor", e.target.value)}
                            />
                          </div>
                          <div className="ctrl-row">
                            <label>Tamaño Fuente (px):</label>
                            <input
                              type="number"
                              value={currentSelectedWidget.settings.fontSize || 16}
                              onChange={(e) => updateWidgetSetting("fontSize", parseInt(e.target.value) || 16)}
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {/* TABS / PESTAÑAS */}
                    {currentSelectedWidget.type === "tabs" && (
                      <>
                        <div className="control-accordion-item">
                          <div className="accordion-label">
                            <span>Pestañas ({((currentSelectedWidget.settings.tabs as any[]) || []).length})</span>
                            <ChevronDown className="acc-chev" />
                          </div>
                          <div className="accordion-body">
                            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                              <label style={{ margin: 0, fontWeight: 700, color: "#e2e8f0" }}>Lista de Pestañas:</label>
                              <button
                                type="button"
                                onClick={() => {
                                  const cur = Array.isArray(currentSelectedWidget.settings.tabs) ? currentSelectedWidget.settings.tabs : [];
                                  updateWidgetSetting("tabs", [
                                    ...cur,
                                    { title: `Pestaña ${cur.length + 1}`, content: "Escribe aquí la descripción o contenido de esta pestaña." }
                                  ]);
                                }}
                                style={{ display: "flex", alignItems: "center", gap: "4px", background: "#16c96f", color: "#020b14", fontWeight: 800, fontSize: "11px", padding: "5px 10px", borderRadius: "5px", border: "none", cursor: "pointer" }}
                              >
                                <Plus style={{ width: 13, height: 13 }} /> Añadir Pestaña
                              </button>
                            </div>

                            <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                              {((currentSelectedWidget.settings.tabs as any[]) || []).map((t: any, idx: number) => (
                                <div key={idx} style={{ background: "#181b1e", border: "1px solid #2d3238", borderRadius: "8px", padding: "10px", display: "flex", flexDirection: "column", gap: "8px" }}>
                                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                                    <span style={{ fontSize: "11px", color: "#16c96f", fontWeight: 700 }}>Pestaña #{idx + 1}</span>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const cur = Array.isArray(currentSelectedWidget.settings.tabs) ? currentSelectedWidget.settings.tabs : [];
                                        updateWidgetSetting("tabs", cur.filter((_, i) => i !== idx));
                                      }}
                                      style={{ background: "rgba(239, 68, 68, 0.15)", border: "1px solid rgba(239, 68, 68, 0.3)", color: "#ef4444", borderRadius: "5px", padding: "4px 8px", cursor: "pointer" }}
                                      title="Eliminar pestaña"
                                    >
                                      <Trash2 style={{ width: 12, height: 12 }} />
                                    </button>
                                  </div>

                                  <div className="ctrl-row-col">
                                    <label style={{ fontSize: "10px" }}>Título de la Pestaña:</label>
                                    <input
                                      type="text"
                                      value={t.title || ""}
                                      onChange={(e) => {
                                        const cur = [...((currentSelectedWidget.settings.tabs as any[]) || [])];
                                        cur[idx] = { ...cur[idx], title: e.target.value };
                                        updateWidgetSetting("tabs", cur);
                                      }}
                                      style={{ fontSize: "12px" }}
                                    />
                                  </div>

                                  <div className="ctrl-row-col">
                                    <label style={{ fontSize: "10px" }}>Contenido:</label>
                                    <textarea
                                      rows={3}
                                      value={t.content || ""}
                                      onChange={(e) => {
                                        const cur = [...((currentSelectedWidget.settings.tabs as any[]) || [])];
                                        cur[idx] = { ...cur[idx], content: e.target.value };
                                        updateWidgetSetting("tabs", cur);
                                      }}
                                      className="wp-textarea"
                                      style={{ fontSize: "12px" }}
                                    />
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>

                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Ajustes de Pestañas</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row">
                              <label>Color Pestaña Activa:</label>
                              <input
                                type="color"
                                value={currentSelectedWidget.settings.tabColor || "#16c96f"}
                                onChange={(e) => updateWidgetSetting("tabColor", e.target.value)}
                              />
                            </div>
                          </div>
                        </div>
                      </>
                    )}

                    {/* ACCORDION / ACORDEÓN */}
                    {currentSelectedWidget.type === "accordion" && (
                      <div className="control-accordion-item">
                        <div className="accordion-label">
                          <span>Elementos de Acordeón ({((currentSelectedWidget.settings.items as any[]) || []).length})</span>
                          <ChevronDown className="acc-chev" />
                        </div>
                        <div className="accordion-body">
                          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                            <label style={{ margin: 0, fontWeight: 700, color: "#e2e8f0" }}>Preguntas / Secciones:</label>
                            <button
                              type="button"
                              onClick={() => {
                                const cur = Array.isArray(currentSelectedWidget.settings.items) ? currentSelectedWidget.settings.items : [];
                                updateWidgetSetting("items", [
                                  ...cur,
                                  { title: `¿Nueva Pregunta ${cur.length + 1}?`, content: "Respuesta detallada para esta sección del acordeón." }
                                ]);
                              }}
                              style={{ display: "flex", alignItems: "center", gap: "4px", background: "#16c96f", color: "#020b14", fontWeight: 800, fontSize: "11px", padding: "5px 10px", borderRadius: "5px", border: "none", cursor: "pointer" }}
                            >
                              <Plus style={{ width: 13, height: 13 }} /> Añadir Elemento
                            </button>
                          </div>

                          <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                            {((currentSelectedWidget.settings.items as any[]) || []).map((item: any, idx: number) => (
                              <div key={idx} style={{ background: "#181b1e", border: "1px solid #2d3238", borderRadius: "8px", padding: "10px", display: "flex", flexDirection: "column", gap: "8px" }}>
                                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                                  <span style={{ fontSize: "11px", color: "#16c96f", fontWeight: 700 }}>Elemento #{idx + 1}</span>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const cur = Array.isArray(currentSelectedWidget.settings.items) ? currentSelectedWidget.settings.items : [];
                                      updateWidgetSetting("items", cur.filter((_, i) => i !== idx));
                                    }}
                                    style={{ background: "rgba(239, 68, 68, 0.15)", border: "1px solid rgba(239, 68, 68, 0.3)", color: "#ef4444", borderRadius: "5px", padding: "4px 8px", cursor: "pointer" }}
                                    title="Eliminar elemento"
                                  >
                                    <Trash2 style={{ width: 12, height: 12 }} />
                                  </button>
                                </div>

                                <div className="ctrl-row-col">
                                  <label style={{ fontSize: "10px" }}>Título / Pregunta:</label>
                                  <input
                                    type="text"
                                    value={item.title || ""}
                                    onChange={(e) => {
                                      const cur = [...((currentSelectedWidget.settings.items as any[]) || [])];
                                      cur[idx] = { ...cur[idx], title: e.target.value };
                                      updateWidgetSetting("items", cur);
                                    }}
                                    style={{ fontSize: "12px" }}
                                  />
                                </div>

                                <div className="ctrl-row-col">
                                  <label style={{ fontSize: "10px" }}>Contenido / Respuesta:</label>
                                  <textarea
                                    rows={3}
                                    value={item.content || ""}
                                    onChange={(e) => {
                                      const cur = [...((currentSelectedWidget.settings.items as any[]) || [])];
                                      cur[idx] = { ...cur[idx], content: e.target.value };
                                      updateWidgetSetting("items", cur);
                                    }}
                                    className="wp-textarea"
                                    style={{ fontSize: "12px" }}
                                  />
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* TOGGLE / CONMUTADOR */}
                    {currentSelectedWidget.type === "toggle" && (
                      <div className="control-accordion-item">
                        <div className="accordion-label"><span>Conmutador (Toggle)</span><ChevronDown className="acc-chev" /></div>
                        <div className="accordion-body">
                          <div className="ctrl-row-col">
                            <label>Título / Pregunta:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.title || ""}
                              onChange={(e) => updateWidgetSetting("title", e.target.value)}
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>Contenido / Respuesta:</label>
                            <textarea
                              rows={4}
                              value={currentSelectedWidget.settings.content || ""}
                              onChange={(e) => updateWidgetSetting("content", e.target.value)}
                              className="wp-textarea"
                            />
                          </div>
                          <div className="ctrl-row">
                            <label>Mostrar desplegado por defecto:</label>
                            <input
                              type="checkbox"
                              checked={currentSelectedWidget.settings.isOpen !== false}
                              onChange={(e) => updateWidgetSetting("isOpen", e.target.checked)}
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {/* ICON LIST / LISTA DE ICONOS */}
                    {currentSelectedWidget.type === "icon-list" && (
                      <>
                        <div className="control-accordion-item">
                          <div className="accordion-label">
                            <span>Ítems de la Lista ({((currentSelectedWidget.settings.items as any[]) || []).length})</span>
                            <ChevronDown className="acc-chev" />
                          </div>
                          <div className="accordion-body">
                            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                              <label style={{ margin: 0, fontWeight: 700, color: "#e2e8f0" }}>Elementos:</label>
                              <button
                                type="button"
                                onClick={() => {
                                  const cur = Array.isArray(currentSelectedWidget.settings.items) ? currentSelectedWidget.settings.items : [];
                                  updateWidgetSetting("items", [
                                    ...cur,
                                    { icon: "✓", text: `Nuevo ítem de lista ${cur.length + 1}` }
                                  ]);
                                }}
                                style={{ display: "flex", alignItems: "center", gap: "4px", background: "#16c96f", color: "#020b14", fontWeight: 800, fontSize: "11px", padding: "5px 10px", borderRadius: "5px", border: "none", cursor: "pointer" }}
                              >
                                <Plus style={{ width: 13, height: 13 }} /> Añadir Ítem
                              </button>
                            </div>

                            <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                              {((currentSelectedWidget.settings.items as any[]) || []).map((it: any, idx: number) => (
                                <div key={idx} style={{ background: "#181b1e", border: "1px solid #2d3238", borderRadius: "6px", padding: "8px", display: "flex", alignItems: "center", gap: "8px" }}>
                                  <input
                                    type="text"
                                    value={it.icon || "✓"}
                                    onChange={(e) => {
                                      const cur = [...((currentSelectedWidget.settings.items as any[]) || [])];
                                      cur[idx] = { ...cur[idx], icon: e.target.value };
                                      updateWidgetSetting("items", cur);
                                    }}
                                    style={{ width: "38px", textAlign: "center", fontSize: "13px", padding: "4px" }}
                                    title="Icono o Símbolo"
                                  />
                                  <input
                                    type="text"
                                    value={it.text || ""}
                                    onChange={(e) => {
                                      const cur = [...((currentSelectedWidget.settings.items as any[]) || [])];
                                      cur[idx] = { ...cur[idx], text: e.target.value };
                                      updateWidgetSetting("items", cur);
                                    }}
                                    placeholder="Texto descriptivo..."
                                    style={{ flex: 1, fontSize: "12px", padding: "4px 8px" }}
                                  />
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const cur = Array.isArray(currentSelectedWidget.settings.items) ? currentSelectedWidget.settings.items : [];
                                      updateWidgetSetting("items", cur.filter((_, i) => i !== idx));
                                    }}
                                    style={{ background: "rgba(239, 68, 68, 0.15)", border: "1px solid rgba(239, 68, 68, 0.3)", color: "#ef4444", borderRadius: "4px", padding: "4px 6px", cursor: "pointer" }}
                                  >
                                    <Trash2 style={{ width: 12, height: 12 }} />
                                  </button>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>

                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Estilos de Lista</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row">
                              <label>Color del Icono:</label>
                              <input
                                type="color"
                                value={currentSelectedWidget.settings.iconColor || "#16c96f"}
                                onChange={(e) => updateWidgetSetting("iconColor", e.target.value)}
                              />
                            </div>
                            <div className="ctrl-row">
                              <label>Color del Texto:</label>
                              <input
                                type="color"
                                value={currentSelectedWidget.settings.textColor || "#e2e8f0"}
                                onChange={(e) => updateWidgetSetting("textColor", e.target.value)}
                              />
                            </div>
                          </div>
                        </div>
                      </>
                    )}

                    {/* SERVICES / SERVICIOS */}
                    {currentSelectedWidget.type === "services" && (
                      <>
                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Cabecera de Servicios</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row-col">
                              <label>Título de la Sección:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.sectionTitle || ""}
                                onChange={(e) => updateWidgetSetting("sectionTitle", e.target.value)}
                              />
                            </div>
                            <div className="ctrl-row-col">
                              <label>Texto del Enlace:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.linkText || ""}
                                onChange={(e) => updateWidgetSetting("linkText", e.target.value)}
                              />
                            </div>
                            <div className="ctrl-row-col">
                              <label>URL del Enlace:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.linkUrl || ""}
                                onChange={(e) => updateWidgetSetting("linkUrl", e.target.value)}
                              />
                            </div>
                          </div>
                        </div>

                        <div className="control-accordion-item">
                          <div className="accordion-label">
                            <span>Tarjetas de Servicio ({((currentSelectedWidget.settings.items as any[]) || []).length})</span>
                            <ChevronDown className="acc-chev" />
                          </div>
                          <div className="accordion-body">
                            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                              <label style={{ margin: 0, fontWeight: 700, color: "#e2e8f0" }}>Servicios:</label>
                              <button
                                type="button"
                                onClick={() => {
                                  const cur = Array.isArray(currentSelectedWidget.settings.items) ? currentSelectedWidget.settings.items : [];
                                  updateWidgetSetting("items", [
                                    ...cur,
                                    { icon: "🚀", title: `Nuevo Servicio ${cur.length + 1}`, description: "Descripción detallada del servicio ofrecido a los clientes." }
                                  ]);
                                }}
                                style={{ display: "flex", alignItems: "center", gap: "4px", background: "#16c96f", color: "#020b14", fontWeight: 800, fontSize: "11px", padding: "5px 10px", borderRadius: "5px", border: "none", cursor: "pointer" }}
                              >
                                <Plus style={{ width: 13, height: 13 }} /> Añadir Servicio
                              </button>
                            </div>

                            <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                              {((currentSelectedWidget.settings.items as any[]) || []).map((sItem: any, idx: number) => (
                                <div key={idx} style={{ background: "#181b1e", border: "1px solid #2d3238", borderRadius: "8px", padding: "10px", display: "flex", flexDirection: "column", gap: "8px" }}>
                                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                                    <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                                      <input
                                        type="text"
                                        value={sItem.icon || "⚙️"}
                                        onChange={(e) => {
                                          const cur = [...((currentSelectedWidget.settings.items as any[]) || [])];
                                          cur[idx] = { ...cur[idx], icon: e.target.value };
                                          updateWidgetSetting("items", cur);
                                        }}
                                        style={{ width: "32px", textAlign: "center", padding: "3px" }}
                                        title="Icono / Emoji"
                                      />
                                      <span style={{ fontSize: "11px", color: "#16c96f", fontWeight: 700 }}>Servicio #{idx + 1}</span>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const cur = Array.isArray(currentSelectedWidget.settings.items) ? currentSelectedWidget.settings.items : [];
                                        updateWidgetSetting("items", cur.filter((_, i) => i !== idx));
                                      }}
                                      style={{ background: "rgba(239, 68, 68, 0.15)", border: "1px solid rgba(239, 68, 68, 0.3)", color: "#ef4444", borderRadius: "4px", padding: "4px 8px", cursor: "pointer" }}
                                    >
                                      <Trash2 style={{ width: 12, height: 12 }} />
                                    </button>
                                  </div>

                                  <div className="ctrl-row-col">
                                    <label style={{ fontSize: "10px" }}>Título:</label>
                                    <input
                                      type="text"
                                      value={sItem.title || ""}
                                      onChange={(e) => {
                                        const cur = [...((currentSelectedWidget.settings.items as any[]) || [])];
                                        cur[idx] = { ...cur[idx], title: e.target.value };
                                        updateWidgetSetting("items", cur);
                                      }}
                                      style={{ fontSize: "12px" }}
                                    />
                                  </div>

                                  <div className="ctrl-row-col">
                                    <label style={{ fontSize: "10px" }}>Descripción:</label>
                                    <textarea
                                      rows={2}
                                      value={sItem.description || ""}
                                      onChange={(e) => {
                                        const cur = [...((currentSelectedWidget.settings.items as any[]) || [])];
                                        cur[idx] = { ...cur[idx], description: e.target.value };
                                        updateWidgetSetting("items", cur);
                                      }}
                                      className="wp-textarea"
                                      style={{ fontSize: "12px" }}
                                    />
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </>
                    )}

                    {/* TESTIMONIALS / TESTIMONIOS */}
                    {currentSelectedWidget.type === "testimonials" && (
                      <>
                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Cabecera de Testimonios</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row-col">
                              <label>Título de la Sección:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.sectionTitle || ""}
                                onChange={(e) => updateWidgetSetting("sectionTitle", e.target.value)}
                              />
                            </div>
                            <div className="ctrl-row-col">
                              <label>Texto del Enlace:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.linkText || ""}
                                onChange={(e) => updateWidgetSetting("linkText", e.target.value)}
                              />
                            </div>
                          </div>
                        </div>

                        <div className="control-accordion-item">
                          <div className="accordion-label">
                            <span>Testimonios ({((currentSelectedWidget.settings.items as any[]) || []).length})</span>
                            <ChevronDown className="acc-chev" />
                          </div>
                          <div className="accordion-body">
                            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                              <label style={{ margin: 0, fontWeight: 700, color: "#e2e8f0" }}>Opiniones:</label>
                              <button
                                type="button"
                                onClick={() => {
                                  const cur = Array.isArray(currentSelectedWidget.settings.items) ? currentSelectedWidget.settings.items : [];
                                  updateWidgetSetting("items", [
                                    ...cur,
                                    { quote: "Excelente servicio, superó todas nuestras expectativas con profesionalismo y velocidad.", name: `Cliente ${cur.length + 1}`, role: "Gerente de Operaciones", initials: "CO" }
                                  ]);
                                }}
                                style={{ display: "flex", alignItems: "center", gap: "4px", background: "#16c96f", color: "#020b14", fontWeight: 800, fontSize: "11px", padding: "5px 10px", borderRadius: "5px", border: "none", cursor: "pointer" }}
                              >
                                <Plus style={{ width: 13, height: 13 }} /> Añadir Testimonio
                              </button>
                            </div>

                            <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                              {((currentSelectedWidget.settings.items as any[]) || []).map((tItem: any, idx: number) => (
                                <div key={idx} style={{ background: "#181b1e", border: "1px solid #2d3238", borderRadius: "8px", padding: "10px", display: "flex", flexDirection: "column", gap: "8px" }}>
                                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                                    <span style={{ fontSize: "11px", color: "#16c96f", fontWeight: 700 }}>Testimonio #{idx + 1}</span>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const cur = Array.isArray(currentSelectedWidget.settings.items) ? currentSelectedWidget.settings.items : [];
                                        updateWidgetSetting("items", cur.filter((_, i) => i !== idx));
                                      }}
                                      style={{ background: "rgba(239, 68, 68, 0.15)", border: "1px solid rgba(239, 68, 68, 0.3)", color: "#ef4444", borderRadius: "4px", padding: "4px 8px", cursor: "pointer" }}
                                    >
                                      <Trash2 style={{ width: 12, height: 12 }} />
                                    </button>
                                  </div>

                                  <div className="ctrl-row-col">
                                    <label style={{ fontSize: "10px" }}>Cita / Opinión:</label>
                                    <textarea
                                      rows={2}
                                      value={tItem.quote || ""}
                                      onChange={(e) => {
                                        const cur = [...((currentSelectedWidget.settings.items as any[]) || [])];
                                        cur[idx] = { ...cur[idx], quote: e.target.value };
                                        updateWidgetSetting("items", cur);
                                      }}
                                      className="wp-textarea"
                                      style={{ fontSize: "12px" }}
                                    />
                                  </div>

                                  <div className="ctrl-row-col">
                                    <label style={{ fontSize: "10px" }}>Nombre del Autor:</label>
                                    <input
                                      type="text"
                                      value={tItem.name || ""}
                                      onChange={(e) => {
                                        const cur = [...((currentSelectedWidget.settings.items as any[]) || [])];
                                        cur[idx] = { ...cur[idx], name: e.target.value };
                                        updateWidgetSetting("items", cur);
                                      }}
                                      style={{ fontSize: "12px" }}
                                    />
                                  </div>

                                  <div className="ctrl-row-col">
                                    <label style={{ fontSize: "10px" }}>Cargo / Empresa:</label>
                                    <input
                                      type="text"
                                      value={tItem.role || ""}
                                      onChange={(e) => {
                                        const cur = [...((currentSelectedWidget.settings.items as any[]) || [])];
                                        cur[idx] = { ...cur[idx], role: e.target.value };
                                        updateWidgetSetting("items", cur);
                                      }}
                                      style={{ fontSize: "12px" }}
                                    />
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </>
                    )}

                    {/* ARTICLES / ARTÍCULOS */}
                    {currentSelectedWidget.type === "articles" && (
                      <>
                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Cabecera de Artículos</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row-col">
                              <label>Título de la Sección:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.sectionTitle || ""}
                                onChange={(e) => updateWidgetSetting("sectionTitle", e.target.value)}
                              />
                            </div>
                            <div className="ctrl-row-col">
                              <label>Texto del Enlace:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.linkText || ""}
                                onChange={(e) => updateWidgetSetting("linkText", e.target.value)}
                              />
                            </div>
                          </div>
                        </div>

                        <div className="control-accordion-item">
                          <div className="accordion-label">
                            <span>Artículos / Entradas ({((currentSelectedWidget.settings.items as any[]) || []).length})</span>
                            <ChevronDown className="acc-chev" />
                          </div>
                          <div className="accordion-body">
                            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                              <label style={{ margin: 0, fontWeight: 700, color: "#e2e8f0" }}>Publicaciones:</label>
                              <button
                                type="button"
                                onClick={() => {
                                  const cur = Array.isArray(currentSelectedWidget.settings.items) ? currentSelectedWidget.settings.items : [];
                                  updateWidgetSetting("items", [
                                    ...cur,
                                    { title: `Nuevo Artículo ${cur.length + 1}`, excerpt: "Breve resumen o extracto de la publicación del blog.", category: "TECNOLOGÍA", date: "HOY" }
                                  ]);
                                }}
                                style={{ display: "flex", alignItems: "center", gap: "4px", background: "#16c96f", color: "#020b14", fontWeight: 800, fontSize: "11px", padding: "5px 10px", borderRadius: "5px", border: "none", cursor: "pointer" }}
                              >
                                <Plus style={{ width: 13, height: 13 }} /> Añadir Artículo
                              </button>
                            </div>

                            <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                              {((currentSelectedWidget.settings.items as any[]) || []).map((art: any, idx: number) => (
                                <div key={idx} style={{ background: "#181b1e", border: "1px solid #2d3238", borderRadius: "8px", padding: "10px", display: "flex", flexDirection: "column", gap: "8px" }}>
                                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                                    <span style={{ fontSize: "11px", color: "#16c96f", fontWeight: 700 }}>Artículo #{idx + 1}</span>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const cur = Array.isArray(currentSelectedWidget.settings.items) ? currentSelectedWidget.settings.items : [];
                                        updateWidgetSetting("items", cur.filter((_, i) => i !== idx));
                                      }}
                                      style={{ background: "rgba(239, 68, 68, 0.15)", border: "1px solid rgba(239, 68, 68, 0.3)", color: "#ef4444", borderRadius: "4px", padding: "4px 8px", cursor: "pointer" }}
                                    >
                                      <Trash2 style={{ width: 12, height: 12 }} />
                                    </button>
                                  </div>

                                  <div className="ctrl-row-col">
                                    <label style={{ fontSize: "10px" }}>Título:</label>
                                    <input
                                      type="text"
                                      value={art.title || ""}
                                      onChange={(e) => {
                                        const cur = [...((currentSelectedWidget.settings.items as any[]) || [])];
                                        cur[idx] = { ...cur[idx], title: e.target.value };
                                        updateWidgetSetting("items", cur);
                                      }}
                                      style={{ fontSize: "12px" }}
                                    />
                                  </div>

                                  <div className="ctrl-row-col">
                                    <label style={{ fontSize: "10px" }}>Extracto:</label>
                                    <textarea
                                      rows={2}
                                      value={art.excerpt || ""}
                                      onChange={(e) => {
                                        const cur = [...((currentSelectedWidget.settings.items as any[]) || [])];
                                        cur[idx] = { ...cur[idx], excerpt: e.target.value };
                                        updateWidgetSetting("items", cur);
                                      }}
                                      className="wp-textarea"
                                      style={{ fontSize: "12px" }}
                                    />
                                  </div>

                                  <div style={{ display: "flex", gap: "8px" }}>
                                    <div className="ctrl-row-col" style={{ flex: 1 }}>
                                      <label style={{ fontSize: "10px" }}>Categoría:</label>
                                      <input
                                        type="text"
                                        value={art.category || ""}
                                        onChange={(e) => {
                                          const cur = [...((currentSelectedWidget.settings.items as any[]) || [])];
                                          cur[idx] = { ...cur[idx], category: e.target.value };
                                          updateWidgetSetting("items", cur);
                                        }}
                                        style={{ fontSize: "11px" }}
                                      />
                                    </div>
                                    <div className="ctrl-row-col" style={{ flex: 1 }}>
                                      <label style={{ fontSize: "10px" }}>Fecha:</label>
                                      <input
                                        type="text"
                                        value={art.date || ""}
                                        onChange={(e) => {
                                          const cur = [...((currentSelectedWidget.settings.items as any[]) || [])];
                                          cur[idx] = { ...cur[idx], date: e.target.value };
                                          updateWidgetSetting("items", cur);
                                        }}
                                        style={{ fontSize: "11px" }}
                                      />
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </>
                    )}

                    {/* SIDEBAR WIDGET */}
                    {currentSelectedWidget.type === "sidebar-widget" && (
                      <div className="control-accordion-item">
                        <div className="accordion-label"><span>Barra Lateral (Sidebar)</span><ChevronDown className="acc-chev" /></div>
                        <div className="accordion-body">
                          <div className="ctrl-row-col">
                            <label>Título del Widget:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.sidebarTitle || ""}
                              onChange={(e) => updateWidgetSetting("sidebarTitle", e.target.value)}
                            />
                          </div>
                          <div className="ctrl-row-col">
                            <label>Placeholder de Búsqueda:</label>
                            <input
                              type="text"
                              value={currentSelectedWidget.settings.searchPlaceholder || ""}
                              onChange={(e) => updateWidgetSetting("searchPlaceholder", e.target.value)}
                            />
                          </div>
                        </div>
                      </div>
                    )}
                  </>
                )}

                {/* ======================================================== */}
                {/* 2. PESTAÑA ESTILO: TIPOGRAFÍA, COLORES Y DECORACIONES */}
                {/* ======================================================== */}
                {/* ======================================================== */}
                {/* 2. PESTAÑA ESTILO: TIPOGRAFÍA, COLORES Y DECORACIONES */}
                {/* ======================================================== */}
                {sidebarTab === "estilo" && (
                  <>
                    {/* ESTILO EXCLUSIVO PARA HERO */}
                    {currentSelectedWidget.type === "hero" && (
                      <>
                        {/* TÍTULO HERO */}
                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Tipografía y Color del Título</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row">
                              <label>Color del Título:</label>
                              <input
                                type="color"
                                value={currentSelectedWidget.settings.heroTitleColor || "#ffffff"}
                                onChange={(e) => updateWidgetSetting("heroTitleColor", e.target.value)}
                              />
                            </div>
                            <div className="ctrl-row">
                              <label>Tamaño de Fuente (px):</label>
                              <input
                                type="number"
                                value={currentSelectedWidget.settings.heroTitleSize || 38}
                                onChange={(e) => updateWidgetSetting("heroTitleSize", parseInt(e.target.value) || 38)}
                              />
                            </div>
                            <div className="ctrl-row">
                              <label>Peso de Fuente:</label>
                              <select
                                value={currentSelectedWidget.settings.heroTitleWeight || "900"}
                                onChange={(e) => updateWidgetSetting("heroTitleWeight", e.target.value)}
                                style={{ background: "#141414", color: "#fff", border: "1px solid #33383c", padding: "4px 8px", borderRadius: "4px" }}
                              >
                                <option value="400">400 Normal</option>
                                <option value="600">600 Semi-Bold</option>
                                <option value="700">700 Bold</option>
                                <option value="800">800 Extra-Bold</option>
                                <option value="900">900 Black</option>
                              </select>
                            </div>
                            <div className="ctrl-row">
                              <label>Altura de Línea:</label>
                              <input
                                type="number"
                                step="0.1"
                                value={currentSelectedWidget.settings.heroTitleLineHeight || 1.2}
                                onChange={(e) => updateWidgetSetting("heroTitleLineHeight", parseFloat(e.target.value) || 1.2)}
                              />
                            </div>
                          </div>
                        </div>

                        {/* DESCRIPCIÓN / SUBTÍTULO HERO */}
                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Tipografía y Color de Descripción</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row">
                              <label>Color de Texto:</label>
                              <input
                                type="color"
                                value={currentSelectedWidget.settings.heroSubtitleColor || "#94a3b8"}
                                onChange={(e) => updateWidgetSetting("heroSubtitleColor", e.target.value)}
                              />
                            </div>
                            <div className="ctrl-row">
                              <label>Tamaño Fuente (px):</label>
                              <input
                                type="number"
                                value={currentSelectedWidget.settings.heroSubtitleSize || 16}
                                onChange={(e) => updateWidgetSetting("heroSubtitleSize", parseInt(e.target.value) || 16)}
                              />
                            </div>
                            <div className="ctrl-row">
                              <label>Peso de Fuente:</label>
                              <select
                                value={currentSelectedWidget.settings.heroSubtitleWeight || "400"}
                                onChange={(e) => updateWidgetSetting("heroSubtitleWeight", e.target.value)}
                                style={{ background: "#141414", color: "#fff", border: "1px solid #33383c", padding: "4px 8px", borderRadius: "4px" }}
                              >
                                <option value="300">300 Ligera</option>
                                <option value="400">400 Normal</option>
                                <option value="500">500 Media</option>
                                <option value="600">600 Semi-Bold</option>
                              </select>
                            </div>
                            <div className="ctrl-row">
                              <label>Ancho Máximo (px):</label>
                              <input
                                type="number"
                                value={currentSelectedWidget.settings.heroSubtitleMaxWidth || 650}
                                onChange={(e) => updateWidgetSetting("heroSubtitleMaxWidth", parseInt(e.target.value) || 650)}
                              />
                            </div>
                          </div>
                        </div>

                        {/* BADGE / ETIQUETA */}
                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Estilo del Badge</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row">
                              <label>Color de Texto:</label>
                              <input
                                type="color"
                                value={currentSelectedWidget.settings.badgeTextColor || "#16c96f"}
                                onChange={(e) => updateWidgetSetting("badgeTextColor", e.target.value)}
                              />
                            </div>
                            <div className="ctrl-row-col">
                              <label>Color / Fondo del Badge:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.badgeBgColor || "rgba(22, 201, 111, 0.12)"}
                                onChange={(e) => updateWidgetSetting("badgeBgColor", e.target.value)}
                                placeholder="rgba(...) o #hex"
                              />
                            </div>
                            <div className="ctrl-row-col">
                              <label>Color de Borde del Badge:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.badgeBorderColor || "rgba(22, 201, 111, 0.3)"}
                                onChange={(e) => updateWidgetSetting("badgeBorderColor", e.target.value)}
                                placeholder="rgba(...) o #hex"
                              />
                            </div>
                          </div>
                        </div>

                        {/* ESTILO BOTÓN 1 */}
                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Estilo Botón Principal</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row">
                              <label>Color de Texto:</label>
                              <input
                                type="color"
                                value={currentSelectedWidget.settings.primaryBtnColor || "#000000"}
                                onChange={(e) => updateWidgetSetting("primaryBtnColor", e.target.value)}
                              />
                            </div>
                            <div className="ctrl-row-col">
                              <label>Fondo / Gradiente:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.primaryBtnBg || "linear-gradient(110deg, #16c96f, #38bdf8)"}
                                onChange={(e) => updateWidgetSetting("primaryBtnBg", e.target.value)}
                                placeholder="#16c96f o linear-gradient(...)"
                              />
                            </div>
                            <div className="ctrl-row">
                              <label>Radio de Esquinas (px):</label>
                              <input
                                type="number"
                                value={currentSelectedWidget.settings.primaryBtnRadius ?? 8}
                                onChange={(e) => updateWidgetSetting("primaryBtnRadius", parseInt(e.target.value) || 0)}
                              />
                            </div>
                            <div className="ctrl-row">
                              <label>Tamaño de Fuente (px):</label>
                              <input
                                type="number"
                                value={currentSelectedWidget.settings.primaryBtnFontSize || 14}
                                onChange={(e) => updateWidgetSetting("primaryBtnFontSize", parseInt(e.target.value) || 14)}
                              />
                            </div>
                          </div>
                        </div>

                        {/* ESTILO BOTÓN 2 */}
                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Estilo Botón Secundario</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row">
                              <label>Color de Texto:</label>
                              <input
                                type="color"
                                value={currentSelectedWidget.settings.secondaryBtnColor || "#ffffff"}
                                onChange={(e) => updateWidgetSetting("secondaryBtnColor", e.target.value)}
                              />
                            </div>
                            <div className="ctrl-row-col">
                              <label>Color de Fondo:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.secondaryBtnBg || "rgba(255, 255, 255, 0.06)"}
                                onChange={(e) => updateWidgetSetting("secondaryBtnBg", e.target.value)}
                                placeholder="rgba(...) o #hex"
                              />
                            </div>
                            <div className="ctrl-row-col">
                              <label>Color de Borde:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.secondaryBtnBorder || "1px solid rgba(255, 255, 255, 0.15)"}
                                onChange={(e) => updateWidgetSetting("secondaryBtnBorder", e.target.value)}
                                placeholder="1px solid rgba(...)"
                              />
                            </div>
                            <div className="ctrl-row">
                              <label>Radio de Esquinas (px):</label>
                              <input
                                type="number"
                                value={currentSelectedWidget.settings.secondaryBtnRadius ?? 8}
                                onChange={(e) => updateWidgetSetting("secondaryBtnRadius", parseInt(e.target.value) || 0)}
                              />
                            </div>
                          </div>
                        </div>

                        {/* FONDO HERO */}
                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Fondo y Marco del Hero</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row-col">
                              <label>Fondo / Gradiente:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.heroBg || "radial-gradient(circle at center, rgba(22,201,111,0.15), rgba(7,21,34,0.8) 70%)"}
                                onChange={(e) => updateWidgetSetting("heroBg", e.target.value)}
                              />
                            </div>
                            <div className="ctrl-row">
                              <label>Color de Borde:</label>
                              <input
                                type="text"
                                value={currentSelectedWidget.settings.heroBorderColor || "rgba(56,189,248,0.15)"}
                                onChange={(e) => updateWidgetSetting("heroBorderColor", e.target.value)}
                              />
                            </div>
                            <div className="ctrl-row">
                              <label>Radio de Esquinas (px):</label>
                              <input
                                type="number"
                                value={currentSelectedWidget.settings.heroBorderRadius ?? 12}
                                onChange={(e) => updateWidgetSetting("heroBorderRadius", parseInt(e.target.value) || 0)}
                              />
                            </div>
                            <div className="ctrl-row">
                              <label>Padding Vertical (px):</label>
                              <input
                                type="number"
                                value={currentSelectedWidget.settings.heroPaddingY ?? 50}
                                onChange={(e) => updateWidgetSetting("heroPaddingY", parseInt(e.target.value) || 0)}
                              />
                            </div>
                          </div>
                        </div>
                      </>
                    )}

                    {/* ESTILO EXCLUSIVO PARA BOTÓN INDIVIDUAL */}
                    {currentSelectedWidget.type === "button" && (
                      <>
                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Tipografía del Botón</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row">
                              <label>Tamaño de Fuente (px):</label>
                              <input
                                type="number"
                                value={currentSelectedWidget.settings.buttonFontSize || 14}
                                onChange={(e) => updateWidgetSetting("buttonFontSize", parseInt(e.target.value) || 14)}
                              />
                            </div>
                            <div className="ctrl-row">
                              <label>Peso de Fuente:</label>
                              <select
                                value={currentSelectedWidget.settings.buttonFontWeight || "800"}
                                onChange={(e) => updateWidgetSetting("buttonFontWeight", e.target.value)}
                                style={{ background: "#141414", color: "#fff", border: "1px solid #33383c", padding: "4px 8px", borderRadius: "4px" }}
                              >
                                <option value="400">400 Normal</option>
                                <option value="600">600 Semi-Bold</option>
                                <option value="700">700 Bold</option>
                                <option value="800">800 Extra-Bold</option>
                                <option value="900">900 Black</option>
                              </select>
                            </div>
                            <div className="ctrl-row">
                              <label>Transformación:</label>
                              <select
                                value={currentSelectedWidget.settings.buttonTextTransform || "none"}
                                onChange={(e) => updateWidgetSetting("buttonTextTransform", e.target.value)}
                                style={{ background: "#141414", color: "#fff", border: "1px solid #33383c", padding: "4px 8px", borderRadius: "4px" }}
                              >
                                <option value="none">Por defecto</option>
                                <option value="uppercase">MAYÚSCULAS</option>
                                <option value="lowercase">minúsculas</option>
                                <option value="capitalize">Capitalizar</option>
                              </select>
                            </div>
                            <div className="ctrl-row">
                              <label>Espaciado letras (px):</label>
                              <input
                                type="number"
                                value={currentSelectedWidget.settings.buttonLetterSpacing || 0}
                                onChange={(e) => updateWidgetSetting("buttonLetterSpacing", parseFloat(e.target.value) || 0)}
                              />
                            </div>
                          </div>
                        </div>

                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Colores y Fondo</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row">
                              <label>Color del Texto:</label>
                              <input
                                type="color"
                                value={currentSelectedWidget.settings.buttonTextColor || "#000000"}
                                onChange={(e) => updateWidgetSetting("buttonTextColor", e.target.value)}
                              />
                            </div>
                            <div className="ctrl-row">
                              <label>Tipo de Fondo:</label>
                              <select
                                value={currentSelectedWidget.settings.buttonBgType || "gradient"}
                                onChange={(e) => updateWidgetSetting("buttonBgType", e.target.value)}
                                style={{ background: "#141414", color: "#fff", border: "1px solid #33383c", padding: "4px 8px", borderRadius: "4px" }}
                              >
                                <option value="solid">Color Sólido</option>
                                <option value="gradient">Degradado / Gradiente</option>
                                <option value="transparent">Transparente (Outline)</option>
                              </select>
                            </div>
                            <div className="ctrl-row">
                              <label>Color de Fondo {currentSelectedWidget.settings.buttonBgType === "gradient" ? "(Inicio)" : ""}:</label>
                              <input
                                type="color"
                                value={currentSelectedWidget.settings.buttonBgColor || "#16c96f"}
                                onChange={(e) => updateWidgetSetting("buttonBgColor", e.target.value)}
                              />
                            </div>
                            {currentSelectedWidget.settings.buttonBgType === "gradient" && (
                              <div className="ctrl-row">
                                <label>Color Gradiente (Fin):</label>
                                <input
                                  type="color"
                                  value={currentSelectedWidget.settings.buttonGradientEnd || "#38bdf8"}
                                  onChange={(e) => updateWidgetSetting("buttonGradientEnd", e.target.value)}
                                />
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Bordes y Esquinas</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row">
                              <label>Radio de Esquinas (px):</label>
                              <input
                                type="number"
                                value={currentSelectedWidget.settings.buttonRadius ?? 8}
                                onChange={(e) => updateWidgetSetting("buttonRadius", parseInt(e.target.value) || 0)}
                              />
                            </div>
                            <div className="ctrl-row-col">
                              <label>Presets de Forma:</label>
                              <div className="btn-group-4">
                                <button
                                  type="button"
                                  className={currentSelectedWidget.settings.buttonRadius === 0 ? "active" : ""}
                                  onClick={() => updateWidgetSetting("buttonRadius", 0)}
                                  title="Recto"
                                >
                                  0px
                                </button>
                                <button
                                  type="button"
                                  className={(currentSelectedWidget.settings.buttonRadius ?? 8) === 8 ? "active" : ""}
                                  onClick={() => updateWidgetSetting("buttonRadius", 8)}
                                  title="Suave"
                                >
                                  8px
                                </button>
                                <button
                                  type="button"
                                  className={currentSelectedWidget.settings.buttonRadius === 16 ? "active" : ""}
                                  onClick={() => updateWidgetSetting("buttonRadius", 16)}
                                  title="Redondo"
                                >
                                  16px
                                </button>
                                <button
                                  type="button"
                                  className={currentSelectedWidget.settings.buttonRadius === 99 ? "active" : ""}
                                  onClick={() => updateWidgetSetting("buttonRadius", 99)}
                                  title="Píldora / Cápsula"
                                >
                                  99px
                                </button>
                              </div>
                            </div>
                            <div className="ctrl-row">
                              <label>Grosor de Borde (px):</label>
                              <input
                                type="number"
                                value={currentSelectedWidget.settings.buttonBorderWidth || 0}
                                onChange={(e) => updateWidgetSetting("buttonBorderWidth", parseInt(e.target.value) || 0)}
                              />
                            </div>
                            <div className="ctrl-row">
                              <label>Color de Borde:</label>
                              <input
                                type="color"
                                value={currentSelectedWidget.settings.buttonBorderColor || "#16c96f"}
                                onChange={(e) => updateWidgetSetting("buttonBorderColor", e.target.value)}
                              />
                            </div>
                          </div>
                        </div>

                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Relleno / Padding</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row">
                              <label>Padding Horizontal (px):</label>
                              <input
                                type="number"
                                value={currentSelectedWidget.settings.buttonPaddingX ?? 24}
                                onChange={(e) => updateWidgetSetting("buttonPaddingX", parseInt(e.target.value) || 0)}
                              />
                            </div>
                            <div className="ctrl-row">
                              <label>Padding Vertical (px):</label>
                              <input
                                type="number"
                                value={currentSelectedWidget.settings.buttonPaddingY ?? 12}
                                onChange={(e) => updateWidgetSetting("buttonPaddingY", parseInt(e.target.value) || 0)}
                              />
                            </div>
                          </div>
                        </div>

                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Sombra y Efectos</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row">
                              <label>Efecto de Sombra:</label>
                              <select
                                value={currentSelectedWidget.settings.buttonShadow || "neon"}
                                onChange={(e) => updateWidgetSetting("buttonShadow", e.target.value)}
                                style={{ background: "#141414", color: "#fff", border: "1px solid #33383c", padding: "4px 8px", borderRadius: "4px" }}
                              >
                                <option value="none">Sin Sombra</option>
                                <option value="soft">Sombra Suave</option>
                                <option value="neon">Resplandor Neón Verde</option>
                                <option value="glow3d">Resplandor Pro Rosa / Fucsia</option>
                              </select>
                            </div>
                          </div>
                        </div>
                      </>
                    )}

                    {/* ESTILOS PARA OTROS WIDGETS (HEADING, TEXT, IMAGE, ETC.) */}
                    {!["hero", "button"].includes(currentSelectedWidget.type) && (
                      <>
                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Tipografía y Colores</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row">
                              <label>Color de Texto:</label>
                              <input
                                type="color"
                                value={currentSelectedWidget.settings.textColor || (currentSelectedWidget.type === "heading" ? "#ffffff" : "#94a3b8")}
                                onChange={(e) => updateWidgetSetting("textColor", e.target.value)}
                              />
                            </div>

                            <div className="ctrl-row">
                              <label>Tamaño Fuente (px):</label>
                              <input
                                type="number"
                                value={currentSelectedWidget.settings.fontSize || (currentSelectedWidget.type === "heading" ? 32 : 16)}
                                onChange={(e) => updateWidgetSetting("fontSize", parseInt(e.target.value) || 16)}
                              />
                            </div>

                            <div className="ctrl-row">
                              <label>Peso de Fuente:</label>
                              <select
                                value={currentSelectedWidget.settings.fontWeight || (currentSelectedWidget.type === "heading" ? "800" : "400")}
                                onChange={(e) => updateWidgetSetting("fontWeight", e.target.value)}
                                style={{ background: "#141414", color: "#fff", border: "1px solid #33383c", padding: "4px 8px", borderRadius: "4px" }}
                              >
                                <option value="300">300 Ligera</option>
                                <option value="400">400 Normal</option>
                                <option value="500">500 Media</option>
                                <option value="600">600 Semi-Bold</option>
                                <option value="700">700 Bold</option>
                                <option value="800">800 Extra-Bold</option>
                                <option value="900">900 Black</option>
                              </select>
                            </div>

                            <div className="ctrl-row">
                              <label>Transformación:</label>
                              <select
                                value={currentSelectedWidget.settings.textTransform || "none"}
                                onChange={(e) => updateWidgetSetting("textTransform", e.target.value)}
                                style={{ background: "#141414", color: "#fff", border: "1px solid #33383c", padding: "4px 8px", borderRadius: "4px" }}
                              >
                                <option value="none">Por defecto</option>
                                <option value="uppercase">MAYÚSCULAS</option>
                                <option value="lowercase">minúsculas</option>
                                <option value="capitalize">Capitalizar</option>
                              </select>
                            </div>

                            <div className="ctrl-row">
                              <label>Espaciado letras (px):</label>
                              <input
                                type="number"
                                value={currentSelectedWidget.settings.letterSpacing || 0}
                                onChange={(e) => updateWidgetSetting("letterSpacing", parseFloat(e.target.value) || 0)}
                              />
                            </div>

                            {currentSelectedWidget.type === "heading" && (
                              <div className="ctrl-row">
                                <label>Barra acento verde:</label>
                                <input
                                  type="checkbox"
                                  checked={!!currentSelectedWidget.settings.hasAccentBar}
                                  onChange={(e) => updateWidgetSetting("hasAccentBar", e.target.checked)}
                                />
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="control-accordion-item">
                          <div className="accordion-label"><span>Alineación de Texto</span><ChevronDown className="acc-chev" /></div>
                          <div className="accordion-body">
                            <div className="ctrl-row-col">
                              <div className="btn-group-4">
                                <button
                                  type="button"
                                  className={(currentSelectedWidget.settings.align || "left") === "left" ? "active" : ""}
                                  onClick={() => updateWidgetSetting("align", "left")}
                                  title="Izquierda"
                                >
                                  <AlignLeft style={{ width: 14, height: 14 }} />
                                </button>
                                <button
                                  type="button"
                                  className={currentSelectedWidget.settings.align === "center" ? "active" : ""}
                                  onClick={() => updateWidgetSetting("align", "center")}
                                  title="Centro"
                                >
                                  <AlignCenter style={{ width: 14, height: 14 }} />
                                </button>
                                <button
                                  type="button"
                                  className={currentSelectedWidget.settings.align === "right" ? "active" : ""}
                                  onClick={() => updateWidgetSetting("align", "right")}
                                  title="Derecha"
                                >
                                  <AlignRight style={{ width: 14, height: 14 }} />
                                </button>
                                <button
                                  type="button"
                                  className={currentSelectedWidget.settings.align === "justify" ? "active" : ""}
                                  onClick={() => updateWidgetSetting("align", "justify")}
                                  title="Justificado"
                                >
                                  <AlignJustify style={{ width: 14, height: 14 }} />
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>

                        {currentSelectedWidget.type === "image" && (
                          <div className="control-accordion-item">
                            <div className="accordion-label"><span>Estilo de Imagen</span><ChevronDown className="acc-chev" /></div>
                            <div className="accordion-body">
                              <div className="ctrl-row">
                                <label>Radio de esquinas (px):</label>
                                <input
                                  type="number"
                                  value={currentSelectedWidget.settings.borderRadius ?? 8}
                                  onChange={(e) => updateWidgetSetting("borderRadius", parseInt(e.target.value) || 0)}
                                />
                              </div>
                              <div className="ctrl-row">
                                <label>Ancho Máximo:</label>
                                <select
                                  value={currentSelectedWidget.settings.width || "100%"}
                                  onChange={(e) => updateWidgetSetting("width", e.target.value)}
                                  style={{ background: "#141414", color: "#fff", border: "1px solid #33383c", padding: "4px 8px", borderRadius: "4px" }}
                                >
                                  <option value="100%">100% (Completo)</option>
                                  <option value="75%">75%</option>
                                  <option value="50%">50%</option>
                                  <option value="350px">350px</option>
                                  <option value="200px">200px (Icono)</option>
                                </select>
                              </div>
                            </div>
                          </div>
                        )}

                        {currentSelectedWidget.type === "carousel" && (
                          <div className="control-accordion-item">
                            <div className="accordion-label"><span>Estilo del Carrusel</span><ChevronDown className="acc-chev" /></div>
                            <div className="accordion-body">
                              <div className="ctrl-row">
                                <label>Altura de Diapositiva (px):</label>
                                <input
                                  type="number"
                                  min="100"
                                  max="800"
                                  value={currentSelectedWidget.settings.height || 280}
                                  onChange={(e) => updateWidgetSetting("height", parseInt(e.target.value) || 280)}
                                />
                              </div>
                              <div className="ctrl-row">
                                <label>Radio de Esquinas (px):</label>
                                <input
                                  type="number"
                                  min="0"
                                  max="40"
                                  value={currentSelectedWidget.settings.borderRadius ?? 10}
                                  onChange={(e) => updateWidgetSetting("borderRadius", parseInt(e.target.value) || 0)}
                                />
                              </div>
                              <div className="ctrl-row">
                                <label>Margen Superior (px):</label>
                                <input
                                  type="number"
                                  value={currentSelectedWidget.settings.marginTop ?? 12}
                                  onChange={(e) => updateWidgetSetting("marginTop", parseInt(e.target.value) || 0)}
                                />
                              </div>
                              <div className="ctrl-row">
                                <label>Margen Inferior (px):</label>
                                <input
                                  type="number"
                                  value={currentSelectedWidget.settings.marginBottom ?? 12}
                                  onChange={(e) => updateWidgetSetting("marginBottom", parseInt(e.target.value) || 0)}
                                />
                              </div>
                            </div>
                          </div>
                        )}
                      </>
                    )}
                  </>
                )}

                {/* ======================================================== */}
                {/* 3. PESTAÑA DISPOSICIÓN / AVANZADO (FOTO 2 ELEMENTOR) */}
                {/* ======================================================== */}
                {sidebarTab === "interacciones" && (
                  <>
                    <div className="control-accordion-item">
                      <div className="accordion-label"><span>Disposición</span><ChevronDown className="acc-chev" /></div>
                      <div className="accordion-body">
                        <div className="ctrl-row">
                          <label>Visualización:</label>
                          <select
                            value={currentSelectedWidget.settings.display || "block"}
                            onChange={(e) => updateWidgetSetting("display", e.target.value)}
                            style={{ background: "#141414", color: "#fff", border: "1px solid #33383c", padding: "4px 8px", borderRadius: "4px" }}
                          >
                            <option value="block">Bloque</option>
                            <option value="flex">Flex</option>
                            <option value="grid">Grid</option>
                            <option value="inline-block">En línea</option>
                          </select>
                        </div>

                        <div className="ctrl-row">
                          <label>Justify content:</label>
                          <select
                            value={currentSelectedWidget.settings.justifyContent || "flex-start"}
                            onChange={(e) => updateWidgetSetting("justifyContent", e.target.value)}
                            style={{ background: "#141414", color: "#fff", border: "1px solid #33383c", padding: "4px 8px", borderRadius: "4px" }}
                          >
                            <option value="flex-start">Inicio (Izquierda)</option>
                            <option value="center">Centro</option>
                            <option value="flex-end">Final (Derecha)</option>
                            <option value="space-between">Espacio entre</option>
                            <option value="space-around">Espacio alrededor</option>
                          </select>
                        </div>

                        <div className="ctrl-row">
                          <label>Alinear elementos:</label>
                          <select
                            value={currentSelectedWidget.settings.alignItems || "stretch"}
                            onChange={(e) => updateWidgetSetting("alignItems", e.target.value)}
                            style={{ background: "#141414", color: "#fff", border: "1px solid #33383c", padding: "4px 8px", borderRadius: "4px" }}
                          >
                            <option value="flex-start">Inicio</option>
                            <option value="center">Centro</option>
                            <option value="flex-end">Final</option>
                            <option value="stretch">Estirar</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    <div className="control-accordion-item">
                      <div className="accordion-label"><span>Márgenes y Relleno</span><ChevronDown className="acc-chev" /></div>
                      <div className="accordion-body">
                        <div className="ctrl-row">
                          <label>Margen Superior (px):</label>
                          <input
                            type="number"
                            value={currentSelectedWidget.settings.marginTop ?? 0}
                            onChange={(e) => updateWidgetSetting("marginTop", parseInt(e.target.value) || 0)}
                          />
                        </div>

                        <div className="ctrl-row">
                          <label>Margen Inferior (px):</label>
                          <input
                            type="number"
                            value={currentSelectedWidget.settings.marginBottom ?? 12}
                            onChange={(e) => updateWidgetSetting("marginBottom", parseInt(e.target.value) || 0)}
                          />
                        </div>

                        <div className="ctrl-row">
                          <label>Padding Superior (px):</label>
                          <input
                            type="number"
                            value={currentSelectedWidget.settings.paddingTop ?? 0}
                            onChange={(e) => updateWidgetSetting("paddingTop", parseInt(e.target.value) || 0)}
                          />
                        </div>

                        <div className="ctrl-row">
                          <label>Padding Inferior (px):</label>
                          <input
                            type="number"
                            value={currentSelectedWidget.settings.paddingBottom ?? 0}
                            onChange={(e) => updateWidgetSetting("paddingBottom", parseInt(e.target.value) || 0)}
                          />
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
          )}
        </aside>

        {/* LIENZO CENTRAL */}
        <main className="elementor-canvas-scroll-area">
          <div className={`elementor-canvas-viewport ${responsiveMode} ${Boolean(draggedWidgetType || draggedExistingWidget) ? "is-dragging-mode" : ""}`}>
            {containers.map((cont, cIndex) => {
              const isSelected = selectedContainerId === cont.id;
              const isRow = cont.direction === "row";
              const isContDropTarget = containerDropIndicator?.targetContId === cont.id;
              const isBeingDragged = draggedContainerId === cont.id;

              return (
                <div key={cont.id} style={{ position: "relative", width: "100%" }}>
                  {/* Línea indicadora si se arrastra un contenedor ARRIBA de este */}
                  {isContDropTarget && containerDropIndicator.position === "before" && (
                    <div className="container-drop-indicator-line before">
                      <span className="container-drop-badge">Mover Contenedor Arriba ↑</span>
                    </div>
                  )}

                  <div
                    className={`canvas-container-wrapper ${isSelected ? "is-selected" : ""} ${isBeingDragged ? "is-dragging" : ""}`}
                    onDragOver={(e) => handleContainerDragOver(e, cont.id, cIndex)}
                    onDrop={(e) => handleContainerDrop(e, cont.id, cIndex)}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedContainerId(cont.id);
                      setSelectedWidgetId(null);
                      setSidebarMode("flexbox");
                    }}
                  >
                    <div className="container-control-handle-bar">
                      <button
                        type="button"
                        className="handle-btn plus"
                        onClick={(e) => { e.stopPropagation(); openStructureModal(cIndex); }}
                        title="Añadir contenedor arriba"
                      >
                        <Plus />
                      </button>
                      <div
                        className="handle-btn drag"
                        draggable
                        onDragStart={(e) => handleContainerDragStart(e, cont.id)}
                        onDragEnd={handleContainerDragEnd}
                        title="Arrastra estos puntitos para mover el contenedor arriba o abajo"
                      >
                        <GripVertical />
                      </div>
                      <button
                        type="button"
                        className="handle-btn delete"
                        onClick={(e) => handleDeleteContainer(cont.id, e)}
                        title="Eliminar este contenedor"
                      >
                        <X />
                      </button>
                    </div>

                    <div
                      className="canvas-container-body"
                      style={{
                        display: "flex",
                        flexDirection: cont.direction,
                        gap: `${cont.styles.gap || 20}px`,
                        padding: `${cont.styles.paddingTop || 30}px ${cont.styles.paddingRight || 20}px ${cont.styles.paddingBottom || 30}px ${cont.styles.paddingLeft || 20}px`,
                        backgroundColor: cont.styles.backgroundColor || "transparent",
                        borderRadius: `${cont.styles.borderRadius || 0}px`,
                        justifyContent: cont.styles.justifyContent || "flex-start",
                      }}
                    >
                      {cont.columns.map((col) => {
                        const colWidth = col.width || (isRow ? `${100 / cont.columns.length}%` : "100%");
                        const isColDragOver = dragOverColumnId === col.id;

                        return (
                          <div
                            key={col.id}
                            className={`canvas-column-box ${isColDragOver ? "is-drag-over" : ""}`}
                            style={{ flex: `1 1 ${colWidth}`, maxWidth: colWidth }}
                            onDragOver={(e) => handleColumnDragOver(e, col.id, cont.id, col.widgets.length)}
                            onDragLeave={(e) => handleColumnDragLeave(e, col.id)}
                            onDrop={(e) => handleColumnDrop(e, cont.id, col.id)}
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedContainerId(cont.id);
                              setSelectedColumnId(col.id);
                            }}
                          >
                            {col.widgets.length === 0 ? (
                              <div
                                className={`empty-column-placeholder ${isColDragOver ? "is-drag-over" : ""}`}
                                onClick={() => {
                                  setSelectedContainerId(cont.id);
                                  setSelectedColumnId(col.id);
                                  setSidebarMode("widgets");
                                }}
                              >
                                <div className="placeholder-plus-circle">
                                  <Plus style={{ width: 22, height: 22 }} />
                                </div>
                                <span className="placeholder-title">
                                  {isColDragOver ? "¡Suelta el widget aquí!" : "Arrastra un widget aquí o haz clic"}
                                </span>
                                <span className="placeholder-subtitle">
                                  {isColDragOver ? "Se agregará a esta columna" : "Haz clic para seleccionar de los 30 widgets"}
                                </span>
                              </div>
                            ) : (
                              <>
                                {col.widgets.map((wid, wIndex) => {
                                  const isWidSelected = selectedWidgetId === wid.id;
                                  const isDropTarget = dropIndicator?.targetWidgetId === wid.id;

                                  return (
                                    <div key={wid.id} style={{ position: "relative", width: "100%" }}>
                                      {/* Barra indicadora generosa si se suelta ARRIBA */}
                                      {isDropTarget && dropIndicator.position === "before" && (
                                        <div className="drop-indicator-bar before">
                                          <Plus style={{ width: 14, height: 14 }} />
                                          <span>Soltar aquí para insertar arriba ↑</span>
                                        </div>
                                      )}

                                      <div
                                        draggable
                                        onDragStart={(e) => handleExistingWidgetDragStart(e, wid.id, cont.id, col.id)}
                                        onDragOver={(e) => handleWidgetDragOver(e, cont.id, col.id, wid.id, wIndex)}
                                        onDrop={(e) => {
                                          e.stopPropagation();
                                          const insertIdx = dropIndicator?.position === "before" ? wIndex : wIndex + 1;
                                          handleColumnDrop(e, cont.id, col.id, insertIdx);
                                        }}
                                        className={`canvas-widget-wrapper ${isWidSelected ? "is-selected" : ""}`}
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          setSelectedWidgetId(wid.id);
                                          setSelectedContainerId(cont.id);
                                          setSelectedColumnId(col.id);
                                          setSidebarMode("widget");
                                        }}
                                      >
                                        <div className="wid-drag-handle" title="Arrastra para reordenar arriba o abajo">
                                          <GripVertical />
                                        </div>

                                        {/* Botones de acción rápida al pasar el mouse */}
                                        <div className="wid-quick-actions">
                                          <button
                                            type="button"
                                            className="wid-quick-btn"
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              setSelectedContainerId(cont.id);
                                              setSelectedColumnId(col.id);
                                              setSelectedWidgetId(wid.id);
                                              setSidebarMode("widgets");
                                            }}
                                            title="Añadir otro widget a esta columna"
                                          >
                                            <Plus style={{ width: 12, height: 12 }} />
                                          </button>
                                          <button
                                            type="button"
                                            className="wid-delete-btn"
                                            onClick={(e) => handleDeleteWidget(wid.id, e)}
                                            title="Eliminar widget"
                                          >
                                            <Trash2 style={{ width: 12, height: 12 }} />
                                          </button>
                                        </div>

                                        <div dangerouslySetInnerHTML={{ __html: renderWidgetToHtml(wid) }} />
                                      </div>

                                      {/* Barra indicadora generosa si se suelta ABAJO */}
                                      {isDropTarget && dropIndicator.position === "after" && (
                                        <div className="drop-indicator-bar after">
                                          <Plus style={{ width: 14, height: 14 }} />
                                          <span>Soltar aquí para insertar abajo ↓</span>
                                        </div>
                                      )}
                                    </div>
                                  );
                                })}

                                {/* DROPZONE INFERIOR DEDICADA PARA EL 2do, 3er WIDGET EN EL MISMO CONTENEDOR */}
                                <div
                                  className={`column-bottom-dropzone ${isColDragOver && (!dropIndicator || dropIndicator.targetIndex === col.widgets.length) ? "is-drag-over" : ""}`}
                                  onDragOver={(e) => {
                                    if (draggedContainerId) return;
                                    e.preventDefault();
                                    e.stopPropagation();
                                    e.dataTransfer.dropEffect = draggedExistingWidget ? "move" : "copy";
                                    setDropIndicator({
                                      contId: cont.id,
                                      colId: col.id,
                                      targetWidgetId: null,
                                      position: "after",
                                      targetIndex: col.widgets.length,
                                    });
                                    setDragOverColumnId(col.id);
                                  }}
                                  onDrop={(e) => {
                                    e.stopPropagation();
                                    handleColumnDrop(e, cont.id, col.id, col.widgets.length);
                                  }}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedContainerId(cont.id);
                                    setSelectedColumnId(col.id);
                                    setSidebarMode("widgets");
                                  }}
                                  title="Añadir otro widget a este contenedor"
                                >
                                  <Plus style={{ width: 14, height: 14 }} />
                                  <span>
                                    {isColDragOver && (!dropIndicator || dropIndicator.targetIndex === col.widgets.length)
                                      ? "¡Suelta aquí para añadir a este contenedor!"
                                      : "+ Añadir otro widget a este contenedor"}
                                  </span>
                                </div>
                              </>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Línea indicadora si se arrastra un contenedor ABAJO de este */}
                  {isContDropTarget && containerDropIndicator.position === "after" && (
                    <div className="container-drop-indicator-line after">
                      <span className="container-drop-badge">Mover Contenedor Abajo ↓</span>
                    </div>
                  )}
                </div>
              );
            })}

            {/* CONTENEDOR VACÍO CON BOTÓN ÚNICO (+) Y SOPORTE DE DRAG & DROP */}
            <div
              className={`canvas-empty-dropzone-box ${isDropzoneHovered ? "is-drag-over" : ""}`}
              onDragOver={(e) => {
                e.preventDefault();
                setIsDropzoneHovered(true);
                e.dataTransfer.dropEffect = "copy";
              }}
              onDragLeave={() => setIsDropzoneHovered(false)}
              onDrop={handleDropOnEmptyArea}
            >
              {showStructureModal ? (
                <div className="structure-picker-container">
                  {structureDesignType === "choice" ? (
                    <div className="structure-choice-step">
                      <div className="choice-header">
                        <h4>¿Qué diseño te gustaría utilizar?</h4>
                        <button type="button" className="close-choice-btn" onClick={() => setShowStructureModal(false)}><X /></button>
                      </div>
                      <div className="choice-cards-row">
                        <div className="choice-card active" onClick={() => setStructureDesignType("flexbox")}>
                          <div className="choice-preview-icon"><Columns /></div>
                          <span>Flexbox</span>
                        </div>
                        <div className="choice-card" onClick={() => setStructureDesignType("flexbox")}>
                          <div className="choice-preview-icon dashed"><LayoutGrid /></div>
                          <span>Grid</span>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="structure-presets-step">
                      <div className="presets-header">
                        <button type="button" className="back-step-btn" onClick={() => setStructureDesignType("choice")} title="Volver"><ChevronLeft /></button>
                        <h4>Selecciona la estructura</h4>
                        <button type="button" className="close-choice-btn" onClick={() => setShowStructureModal(false)}><X /></button>
                      </div>

                      <div className="presets-12-grid">
                        {STRUCTURE_PRESETS.map((preset) => (
                          <div key={preset.id} className="preset-structure-tile" onClick={() => handleSelectStructurePreset(preset)} title={preset.label}>
                            <div className={`tile-columns-preview ${preset.direction}`}>
                              {preset.columns.map((c, ci) => (
                                <div key={ci} className="tile-col" style={{ width: preset.direction === "row" ? c.width : "100%", height: preset.direction === "column" ? "50%" : "100%" }} />
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="empty-dropzone-inner" onClick={() => openStructureModal(null)}>
                  <div className="dropzone-add-btn" title="Añadir nueva estructura">
                    <Plus />
                  </div>
                  <span className="dropzone-text">Arrastra aquí el widget o haz clic para añadir sección</span>
                </div>
              )}
            </div>

            <div className="canvas-footer-watermark">
              <span>Todos los derechos reservados</span>
            </div>
          </div>
        </main>
      </div>

      <style jsx>{`
        .elementor-workspace-root { height: 100vh; display: flex; flex-direction: column; background: #121212; color: #ffffff; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; overflow: hidden; user-select: none; }
        .elementor-toast { position: fixed; top: 50px; right: 20px; z-index: 10000; display: flex; align-items: center; gap: 8px; padding: 10px 16px; border-radius: 6px; font-size: 13px; font-weight: 600; box-shadow: 0 10px 30px rgba(0,0,0,0.8); }
        .elementor-toast.success { background: #064e3b; border: 1px solid #10b981; color: #a7f3d0; }
        .elementor-toast.error { background: #450a0a; border: 1px solid #ef4444; color: #fca5a5; }
        .elementor-toast.info { background: #1e1b4b; border: 1px solid #6366f1; color: #c7d2fe; }

        .elementor-top-header { height: 48px; background: #1e1e1e; border-bottom: 1px solid #2d2d2d; display: flex; align-items: center; justify-content: space-between; padding: 0 12px; flex-shrink: 0; z-index: 100; }
        .top-header-left, .top-header-center, .top-header-right { display: flex; align-items: center; gap: 8px; }
        .elementor-brand-btn { width: 32px; height: 32px; background: #d63384; border: none; border-radius: 4px; color: #fff; font-size: 16px; font-weight: 900; display: grid; place-items: center; cursor: pointer; }
        .elementor-brand-dropdown-wrap { position: relative; }
        .elementor-popup-menu { position: absolute; top: 38px; left: 0; background: #26292c; border: 1px solid #3d4145; border-radius: 6px; box-shadow: 0 10px 30px rgba(0,0,0,0.7); width: 200px; z-index: 2000; overflow: hidden; }
        .popup-menu-item { display: flex; align-items: center; gap: 10px; padding: 10px 14px; font-size: 12px; color: #cbd5e1; text-decoration: none; }
        .popup-menu-item:hover { background: #33383c; color: #ffffff; }

        .top-icon-btn { width: 30px; height: 30px; background: transparent; border: none; border-radius: 4px; color: #94a3b8; display: grid; place-items: center; cursor: pointer; }
        .top-icon-btn:hover, .top-icon-btn.active { background: #2a2a2a; color: #ffffff; }
        .history-group { display: flex; background: #26292c; border-radius: 4px; }

        .page-title-dropdown { display: flex; align-items: center; gap: 6px; padding: 4px 10px; background: #26292c; border: 1px solid #33383c; border-radius: 4px; font-size: 12px; color: #e2e8f0; }
        .doc-title-text { font-weight: 700; }
        .doc-status-text { color: #94a3b8; font-style: italic; }
        .title-chevron { width: 12px; height: 12px; color: #64748b; }

        .responsive-mode-switcher { display: flex; background: #26292c; border-radius: 4px; padding: 2px; }
        .resp-btn { width: 28px; height: 24px; background: transparent; border: none; border-radius: 3px; color: #94a3b8; display: grid; place-items: center; cursor: pointer; }
        .resp-btn.active { background: #3b4248; color: #38bdf8; }

        .elementor-publish-btn { display: flex; align-items: center; gap: 6px; background: #e91e63; border: none; border-radius: 4px; color: #ffffff; font-size: 12px; font-weight: 700; padding: 6px 14px; cursor: pointer; }
        .elementor-publish-btn:hover { background: #d81b60; }

        .elementor-main-body { flex: 1; display: flex; overflow: hidden; position: relative; }
        .elementor-sidebar { width: 320px; background: #26292c; border-right: 1px solid #33383c; display: flex; flex-direction: column; flex-shrink: 0; overflow-y: auto; z-index: 50; }

        .sidebar-top-tabs { display: flex; padding: 8px 10px; gap: 6px; background: #1e1e1e; border-bottom: 1px solid #33383c; }
        .tab-pill { flex: 1; padding: 6px 0; background: transparent; border: none; border-radius: 4px; font-size: 11px; font-weight: 600; color: #94a3b8; cursor: pointer; text-align: center; }
        .tab-pill.active { background: #33383c; color: #ffffff; }

        .widget-search-wrap { padding: 10px 12px; position: relative; }
        .search-ico { position: absolute; left: 20px; top: 19px; width: 14px; height: 14px; color: #64748b; }
        .widget-search-input { width: 100%; height: 32px; background: #1e1e1e; border: 1px solid #33383c; border-radius: 4px; color: #ffffff; padding: 0 10px 0 30px; font-size: 12px; }
        .widget-search-input:focus { outline: none; border-color: #38bdf8; }

        .widget-category-group { padding: 8px 12px; }
        .category-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
        .category-title { display: flex; align-items: center; gap: 6px; font-size: 11px; font-weight: 700; color: #cbd5e1; text-transform: uppercase; }
        .cat-chev { width: 12px; height: 12px; color: #64748b; }
        .badge-new { font-size: 9px; background: rgba(56, 189, 248, 0.15); color: #38bdf8; padding: 2px 6px; border-radius: 3px; font-weight: 700; }
        .badge-pro { font-size: 9px; background: rgba(22, 201, 111, 0.2); color: #16c96f; padding: 2px 6px; border-radius: 3px; font-weight: 700; }

        .widgets-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; }
        .widget-card { background: #1e1e1e; border: 1px solid #33383c; border-radius: 6px; padding: 12px 8px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 8px; cursor: grab; user-select: none; transition: all 0.15s; }
        .widget-card:hover { background: #2b3035; border-color: #d63384; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.4); }
        .widget-card:active { cursor: grabbing; transform: scale(0.95); opacity: 0.85; }
        .widget-card span { font-size: 11px; color: #cbd5e1; }

        .sidebar-bottom-pro-banner { margin-top: auto; padding: 12px; background: #1e1e1e; border-top: 1px solid #33383c; text-align: center; font-size: 11px; color: #94a3b8; }
        .pro-link { color: #16c96f; font-weight: 700; }

        .editor-view-header { padding: 12px 14px; background: #1e1e1e; border-bottom: 1px solid #33383c; }
        .editor-title-row { display: flex; align-items: center; gap: 10px; }
        .back-btn { width: 24px; height: 24px; background: transparent; border: none; color: #94a3b8; display: grid; place-items: center; cursor: pointer; }
        .editor-title { font-size: 13px; font-weight: 700; color: #ffffff; margin: 0; }

        .editor-sub-tabs { display: flex; background: #202326; border-bottom: 1px solid #33383c; }
        .sub-tab { flex: 1; padding: 8px 0; background: transparent; border: none; border-bottom: 2px solid transparent; font-size: 11px; font-weight: 600; color: #94a3b8; cursor: pointer; }
        .sub-tab.active { color: #d63384; border-bottom-color: #d63384; }

        .editor-controls-stack { padding: 10px 12px; display: flex; flex-direction: column; gap: 8px; }
        .control-accordion-item { background: #1e1e1e; border: 1px solid #33383c; border-radius: 6px; overflow: hidden; }
        .accordion-label { padding: 10px 12px; display: flex; justify-content: space-between; align-items: center; font-size: 12px; font-weight: 600; color: #e2e8f0; cursor: pointer; }
        .acc-chev { width: 12px; height: 12px; color: #64748b; }
        .accordion-body { padding: 10px 12px; border-top: 1px solid #2a2a2a; display: flex; flex-direction: column; gap: 10px; }
        .ctrl-row { display: flex; justify-content: space-between; align-items: center; font-size: 11px; color: #94a3b8; }
        .ctrl-row-col { display: flex; flex-direction: column; gap: 5px; font-size: 11px; color: #94a3b8; }
        .ctrl-row input, .ctrl-row-col input { height: 28px; background: #141414; border: 1px solid #33383c; border-radius: 4px; color: #fff; padding: 0 8px; font-size: 11px; }
        .wp-textarea { width: 100%; background: #141414; border: 1px solid #33383c; border-radius: 4px; color: #fff; padding: 8px; font-size: 11px; line-height: 1.5; }

        .btn-group-4, .btn-group-3, .btn-group-2 { display: flex; background: #141414; border: 1px solid #33383c; border-radius: 4px; padding: 2px; gap: 2px; }
        .btn-group-4 button, .btn-group-3 button, .btn-group-2 button { flex: 1; height: 28px; display: grid; place-items: center; background: transparent; border: none; border-radius: 3px; color: #94a3b8; font-size: 11px; cursor: pointer; transition: all 0.15s; }
        .btn-group-4 button:hover, .btn-group-3 button:hover, .btn-group-2 button:hover { background: #262a2e; color: #ffffff; }
        .btn-group-4 button.active, .btn-group-3 button.active, .btn-group-2 button.active { background: #d63384; color: #ffffff; font-weight: 700; box-shadow: 0 1px 4px rgba(214,51,132,0.4); }

        .elementor-canvas-scroll-area { flex: 1; background: #030d17; overflow-y: auto; display: flex; justify-content: center; padding: 24px; }
        .elementor-canvas-viewport { width: 100%; min-height: 100%; background: #040e1a; border: 1px solid rgba(56,189,248,0.15); border-radius: 6px; box-shadow: 0 10px 40px rgba(0,0,0,0.8); position: relative; display: flex; flex-direction: column; transition: width 0.2s ease; }
        .elementor-canvas-viewport.desktop { max-width: 100%; }
        .elementor-canvas-viewport.tablet { max-width: 768px; }
        .elementor-canvas-viewport.mobile { max-width: 375px; }

        .canvas-container-wrapper { position: relative; border: 1px dashed rgba(255,255,255,0.06); transition: all 0.15s; }
        .canvas-container-wrapper:hover, .canvas-container-wrapper.is-selected { border-color: #d63384; }
        .canvas-container-wrapper.is-dragging { opacity: 0.4; border: 2px dashed #d63384; }

        .container-control-handle-bar { position: absolute; top: -24px; left: 50%; transform: translateX(-50%); display: none; align-items: center; background: #d63384; border-radius: 4px 4px 0 0; padding: 2px 4px; z-index: 30; }
        .canvas-container-wrapper:hover .container-control-handle-bar, .canvas-container-wrapper.is-selected .container-control-handle-bar { display: flex; }
        .handle-btn { width: 22px; height: 20px; background: transparent; border: none; color: #ffffff; display: grid; place-items: center; cursor: pointer; }
        .handle-btn:hover { background: rgba(0,0,0,0.2); border-radius: 2px; }
        .handle-btn.drag { cursor: grab; }
        .handle-btn.drag:active { cursor: grabbing; }

        .container-drop-indicator-line { position: absolute; left: 0; right: 0; height: 5px; background: #d63384; z-index: 45; border-radius: 3px; box-shadow: 0 0 12px #d63384; display: flex; align-items: center; justify-content: center; }
        .container-drop-indicator-line.before { top: -8px; }
        .container-drop-indicator-line.after { bottom: -8px; }
        .container-drop-badge { background: #d63384; color: #ffffff; font-size: 11px; font-weight: 800; padding: 3px 10px; border-radius: 12px; transform: translateY(-50%); box-shadow: 0 2px 8px rgba(0,0,0,0.5); }

        .canvas-column-box { position: relative; min-height: 100px; border: 1px dashed rgba(255,255,255,0.1); border-radius: 8px; padding: 12px; display: flex; flex-direction: column; gap: 10px; transition: border-color 0.2s, background-color 0.2s; }
        .canvas-column-box.is-drag-over { border: 2px dashed #16c96f !important; background: rgba(22, 201, 111, 0.05) !important; }

        .drop-indicator-bar { display: flex; align-items: center; justify-content: center; gap: 8px; height: 38px; width: 100%; background: rgba(22, 201, 111, 0.25); border: 2px dashed #16c96f; border-radius: 6px; color: #16c96f; font-size: 12px; font-weight: 800; pointer-events: none; margin: 6px 0; animation: pulseGlow 1.2s infinite alternate ease-in-out; box-shadow: 0 0 16px rgba(22, 201, 111, 0.35); z-index: 40; }
        .drop-indicator-bar span { text-transform: uppercase; letter-spacing: 0.5px; }
        @keyframes pulseGlow {
          0% { opacity: 0.85; transform: scale(0.995); }
          100% { opacity: 1; transform: scale(1.005); }
        }

        .empty-column-placeholder { width: 100%; min-height: 110px; border: 2px dashed rgba(255,255,255,0.12); border-radius: 8px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 8px; padding: 16px; cursor: pointer; transition: all 0.2s ease; background: rgba(255,255,255,0.01); }
        .empty-column-placeholder:hover { border-color: #38bdf8; background: rgba(56, 189, 248, 0.04); }
        .empty-column-placeholder.is-drag-over { border: 2px dashed #16c96f !important; background: rgba(22, 201, 111, 0.15) !important; transform: scale(1.01); box-shadow: 0 0 20px rgba(22,201,111,0.25); }
        .placeholder-plus-circle { width: 34px; height: 34px; border-radius: 50%; background: rgba(56, 189, 248, 0.1); border: 1px solid rgba(56, 189, 248, 0.25); color: #38bdf8; display: grid; place-items: center; transition: all 0.2s; }
        .empty-column-placeholder:hover .placeholder-plus-circle { background: #38bdf8; color: #000; }
        .empty-column-placeholder.is-drag-over .placeholder-plus-circle { background: #16c96f; color: #000; border-color: #16c96f; transform: scale(1.15); }
        .placeholder-title { font-size: 13px; font-weight: 700; color: #ffffff; }
        .placeholder-subtitle { font-size: 11px; color: #64748b; }

        .column-bottom-dropzone { display: flex; align-items: center; justify-content: center; gap: 8px; min-height: 42px; margin-top: 6px; padding: 8px 14px; border: 1px dashed rgba(255, 255, 255, 0.15); border-radius: 6px; background: rgba(255, 255, 255, 0.02); color: #94a3b8; font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.2s ease; }
        .column-bottom-dropzone:hover { border-color: #38bdf8; color: #38bdf8; background: rgba(56, 189, 248, 0.06); }
        .column-bottom-dropzone.is-drag-over { border: 2px dashed #16c96f !important; background: rgba(22, 201, 111, 0.18) !important; color: #16c96f !important; font-weight: 800 !important; transform: scale(1.01); box-shadow: 0 0 16px rgba(22, 201, 111, 0.3); }

        .is-dragging-mode iframe,
        .is-dragging-mode button,
        .is-dragging-mode a {
          pointer-events: none !important;
        }

        .canvas-widget-wrapper { position: relative; padding: 8px; border: 1px dashed transparent; border-radius: 6px; cursor: grab; transition: all 0.15s; }
        .canvas-widget-wrapper:active { cursor: grabbing; }
        .canvas-widget-wrapper:hover, .canvas-widget-wrapper.is-selected { border-color: #38bdf8; background: rgba(56, 189, 248, 0.04); }
        .wid-drag-handle { position: absolute; top: 6px; left: 6px; width: 22px; height: 22px; background: #38bdf8; border-radius: 4px; color: #000; display: none; place-items: center; cursor: grab; z-index: 20; box-shadow: 0 2px 6px rgba(0,0,0,0.5); }
        .canvas-widget-wrapper:hover .wid-drag-handle { display: grid; }
        
        .wid-quick-actions { position: absolute; top: 6px; right: 6px; display: none; align-items: center; gap: 4px; z-index: 20; }
        .canvas-widget-wrapper:hover .wid-quick-actions { display: flex; }
        .wid-quick-btn { width: 22px; height: 22px; background: #16c96f; border: none; border-radius: 4px; color: #000; display: grid; place-items: center; cursor: pointer; }
        .wid-delete-btn { width: 22px; height: 22px; background: #ef4444; border: none; border-radius: 4px; color: #fff; display: grid; place-items: center; cursor: pointer; }

        .canvas-empty-dropzone-box { margin: 30px; border: 2px dashed rgba(255,255,255,0.15); border-radius: 8px; min-height: 120px; display: flex; align-items: center; justify-content: center; background: rgba(255,255,255,0.02); transition: all 0.2s; }
        .canvas-empty-dropzone-box.is-drag-over { border: 2px dashed #16c96f !important; background: rgba(22, 201, 111, 0.08) !important; transform: scale(1.01); }
        .empty-dropzone-inner { display: flex; flex-direction: column; align-items: center; gap: 8px; cursor: pointer; padding: 20px; }
        .dropzone-add-btn { width: 42px; height: 42px; border-radius: 50%; background: #0a192f; border: 1px solid rgba(22, 201, 111, 0.4); color: #16c96f; display: grid; place-items: center; transition: all 0.2s; }
        .empty-dropzone-inner:hover .dropzone-add-btn { background: #16c96f; color: #000; transform: scale(1.1); box-shadow: 0 0 16px rgba(22,201,111,0.5); }
        .dropzone-text { font-size: 12px; color: #64748b; font-style: italic; }

        .structure-picker-container { width: 100%; padding: 16px; }
        .choice-header, .presets-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
        .choice-header h4, .presets-header h4 { font-size: 13px; color: #cbd5e1; margin: 0; font-weight: 600; }
        .close-choice-btn, .back-step-btn { width: 24px; height: 24px; background: transparent; border: none; color: #94a3b8; display: grid; place-items: center; cursor: pointer; }

        .choice-cards-row { display: flex; justify-content: center; gap: 20px; }
        .choice-card { display: flex; flex-direction: column; align-items: center; gap: 6px; cursor: pointer; }
        .choice-preview-icon { width: 70px; height: 60px; background: #0b1e33; border: 1px solid rgba(56,189,248,0.3); border-radius: 6px; display: grid; place-items: center; color: #38bdf8; }
        .choice-preview-icon.dashed { background: transparent; border: 1px dashed #64748b; color: #94a3b8; }
        .choice-card:hover .choice-preview-icon { background: #d63384; color: #fff; border-color: #d63384; }
        .choice-card span { font-size: 11px; font-weight: 600; color: #cbd5e1; }

        .presets-12-grid { display: grid; grid-template-columns: repeat(6, 1fr); gap: 8px; max-width: 680px; margin: 0 auto; }
        .preset-structure-tile { height: 46px; background: #0b1e33; border: 1px solid rgba(255,255,255,0.08); border-radius: 4px; padding: 4px; cursor: pointer; }
        .preset-structure-tile:hover { border-color: #38bdf8; background: #122842; transform: translateY(-1px); }
        .tile-columns-preview { width: 100%; height: 100%; display: flex; gap: 2px; }
        .tile-columns-preview.column { flex-direction: column; }
        .tile-col { background: rgba(56,189,248,0.2); border-radius: 2px; }
        .preset-structure-tile:hover .tile-col { background: #38bdf8; }

        .canvas-footer-watermark { margin-top: auto; text-align: right; padding: 16px 24px; font-size: 11px; color: #334155; }
      `}</style>
    </div>
  );
}

export default function ElementorBuilderPage() {
  return (
    <Suspense fallback={<div style={{ minHeight: "100vh", background: "#121212", display: "grid", placeItems: "center", color: "#fff" }}><Loader2 className="animate-spin" /></div>}>
      <ElementorBuilderContent />
    </Suspense>
  );
}
