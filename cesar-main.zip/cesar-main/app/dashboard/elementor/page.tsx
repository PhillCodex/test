"use client";

import { useState, useEffect, useCallback, useMemo } from "react";
import Link from "next/link";
import {
  Sparkles,
  Search,
  Plus,
  SlidersHorizontal,
  ExternalLink,
  Trash2,
  Check,
  RefreshCw,
  AlertTriangle,
  Loader2,
  ChevronLeft,
  ChevronRight,
  Layers,
  Globe,
  FileCode,
  Layout,
  Pencil,
  ChevronDown,
  Settings,
  BookOpen,
} from "lucide-react";

interface ElementorPageItem {
  id: string;
  slug: string;
  title: string;
  template: string;
  status: "Publicado" | "Borrador" | "Privado";
  seoScore: number | null;
  views: number;
  date: string;
  timeAgo: string;
  author: string;
  isElementor: boolean;
  content: string;
}

export default function ElementorHubPage() {
  const [pages, setPages] = useState<ElementorPageItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [page, setPage] = useState(1);
  const [showFilters, setShowFilters] = useState(false);
  const [showSiteMenu, setShowSiteMenu] = useState(false);
  const itemsPerPage = 10;

  // Estado del Modal de Eliminación
  const [deleteModal, setDeleteModal] = useState<{
    isOpen: boolean;
    id: string;
    title: string;
    isDeleting: boolean;
  }>({
    isOpen: false,
    id: "",
    title: "",
    isDeleting: false,
  });

  // Estado de Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<"success" | "error">("success");

  const showToast = (msg: string, type: "success" | "error" = "success") => {
    setToastMessage(msg);
    setToastType(type);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const getTimeAgo = (date: Date): string => {
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
    if (seconds < 60) return "hace unos segundos";
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `hace ${minutes}m`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `hace ${hours}h`;
    const days = Math.floor(hours / 24);
    if (days < 30) return `hace ${days}d`;
    const months = Math.floor(days / 30);
    return `hace ${months}m`;
  };

  // Cargar páginas desde MySQL AWS RDS
  const fetchPages = useCallback(async () => {
    setIsLoading(true);
    try {
      const res = await fetch("/api/pages");
      const data = await res.json();

      if (data.pages && Array.isArray(data.pages)) {
        const mapped: ElementorPageItem[] = data.pages.map((p: any) => {
          const rawContent = p.content || "";
          const isElem =
            p.template === "elementor_canvas" ||
            rawContent.includes("ELEMENTOR_DATA") ||
            rawContent.trim().startsWith("[");
          const createdDate = new Date(p.createdAt);

          return {
            id: p.id,
            slug: p.slug,
            title: p.title,
            template: p.template || "default",
            status: (p.status as "Publicado" | "Borrador" | "Privado") || "Publicado",
            seoScore: typeof p.seoScore === "number" ? p.seoScore : null,
            views: p.views || 0,
            date: createdDate.toLocaleDateString("es-ES", {
              day: "2-digit",
              month: "short",
              year: "numeric",
            }),
            timeAgo: getTimeAgo(createdDate),
            author: p.author?.name || "Cesar Fuentes",
            isElementor: isElem,
            content: rawContent,
          };
        });

        setPages(mapped);
      } else {
        setPages([]);
      }
    } catch (e) {
      console.error("Error al cargar páginas de Elementor:", e);
      showToast("Error al conectar con la base de datos.", "error");
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPages();
  }, [fetchPages]);

  useEffect(() => {
    const handleClickOutside = () => setShowSiteMenu(false);
    if (showSiteMenu) {
      window.addEventListener("click", handleClickOutside);
    }
    return () => window.removeEventListener("click", handleClickOutside);
  }, [showSiteMenu]);

  const filteredPages = useMemo(() => {
    return pages.filter((p) => {
      const matchesSearch =
        p.title.toLowerCase().includes(search.toLowerCase()) ||
        p.slug.toLowerCase().includes(search.toLowerCase()) ||
        p.author.toLowerCase().includes(search.toLowerCase());

      if (!matchesSearch) return false;

      if (statusFilter === "ALL") return true;
      if (statusFilter === "ELEMENTOR_ONLY") return p.isElementor;
      if (statusFilter === "CANVAS") return p.template === "elementor_canvas";
      return p.status === statusFilter;
    });
  }, [pages, search, statusFilter]);

  // Paginación a 10 por página exacta
  const totalPagesCount = Math.ceil(filteredPages.length / itemsPerPage) || 1;
  const paginatedPages = useMemo(() => {
    const start = (page - 1) * itemsPerPage;
    return filteredPages.slice(start, start + itemsPerPage);
  }, [filteredPages, page]);

  // Métricas
  const totalElementorCount = pages.filter((p) => p.isElementor).length;
  const publishedElementorCount = pages.filter((p) => p.isElementor && p.status === "Publicado").length;
  const draftElementorCount = pages.filter((p) => p.isElementor && p.status === "Borrador").length;

  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      setSelectedIds(paginatedPages.map((p) => p.id));
    } else {
      setSelectedIds([]);
    }
  };

  const handleSelectOne = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const openDeleteModal = (id: string, title: string) => {
    setDeleteModal({ isOpen: true, id, title, isDeleting: false });
  };

  const confirmDelete = async () => {
    if (!deleteModal.id) return;
    setDeleteModal((prev) => ({ ...prev, isDeleting: true }));

    try {
      const res = await fetch(`/api/pages?id=${deleteModal.id}`, { method: "DELETE" });
      const data = await res.json();

      if (data.success) {
        showToast("Página eliminada correctamente de MySQL.", "success");
        setPages((prev) => prev.filter((p) => p.id !== deleteModal.id));
        setSelectedIds((prev) => prev.filter((id) => id !== deleteModal.id));
        setDeleteModal({ isOpen: false, id: "", title: "", isDeleting: false });
      } else {
        showToast(data.error || "No se pudo eliminar la página.", "error");
        setDeleteModal((prev) => ({ ...prev, isDeleting: false }));
      }
    } catch {
      showToast("Error de conexión al servidor.", "error");
      setDeleteModal((prev) => ({ ...prev, isDeleting: false }));
    }
  };

  return (
    <div className="elementor-hub-module-root">
      {/* Toast Notification */}
      {toastMessage && (
        <div className={`elementor-toast-badge ${toastType}`}>
          {toastType === "success" ? <Check /> : <AlertTriangle />}
          <span>{toastMessage}</span>
        </div>
      )}

      {/* =================================================================
          CABECERA DEL MÓDULO ELEMENTOR HUB
          ================================================================= */}
      <header className="elementor-hub-header">
        <div className="header-brand-meta">
          <div className="elementor-hub-badge-icon">E</div>
          <div>
            <div className="header-badge-row">
              <h1 className="elementor-hub-title">Constructor Elementor</h1>
              <span className="elementor-pro-pill">PRO HUB</span>
            </div>
            <p className="elementor-hub-subtitle">
              Gestión y maquetación visual de páginas en tiempo real &nbsp;|&nbsp;{" "}
              <Link href="/dashboard/ajustes" className="header-link-inline">
                Ir a la configuración del sitio &gt;
              </Link>
            </p>
          </div>
        </div>

        <div className="header-actions-row">
          <button
            type="button"
            className="btn-refresh-hub"
            onClick={fetchPages}
            disabled={isLoading}
            title="Recargar páginas"
          >
            <RefreshCw className={isLoading ? "animate-spin" : ""} />
            <span>Actualizar</span>
          </button>

          {/* Menú Desplegable "Editar Sitio" */}
          <div className="site-edit-dropdown-wrap">
            <button
              type="button"
              className="btn-site-edit-dropdown"
              onClick={(e) => {
                e.stopPropagation();
                setShowSiteMenu(!showSiteMenu);
              }}
            >
              <span>Editar sitio</span>
              <ChevronDown />
            </button>

            {showSiteMenu && (
              <div className="site-edit-popover-menu" onClick={(e) => e.stopPropagation()}>
                <Link
                  href="/dashboard/elementor/editor?new=1"
                  className="popover-menu-item"
                  onClick={() => setShowSiteMenu(false)}
                >
                  <Sparkles style={{ color: "#d63384" }} />
                  <span>Añadir una página con Elementor</span>
                </Link>
                <Link
                  href="/dashboard/paginas/nuevo"
                  className="popover-menu-item"
                  onClick={() => setShowSiteMenu(false)}
                >
                  <Layout />
                  <span>Añadir una página estándar</span>
                </Link>
                <Link
                  href="/dashboard/posts/nuevo"
                  className="popover-menu-item"
                  onClick={() => setShowSiteMenu(false)}
                >
                  <BookOpen />
                  <span>Añadir una entrada de blog</span>
                </Link>
                <Link
                  href="/dashboard/ajustes"
                  className="popover-menu-item"
                  onClick={() => setShowSiteMenu(false)}
                >
                  <Settings />
                  <span>Ajustes del sitio</span>
                </Link>
              </div>
            )}
          </div>

          <Link
            href="/dashboard/elementor/editor?new=1"
            className="btn-create-elementor-main"
          >
            <Plus style={{ width: 16, height: 16 }} />
            <span>Crear con Elementor</span>
          </Link>
        </div>
      </header>

      {/* =================================================================
          TARJETAS DE MÉTRICAS & ESTADÍSTICAS
          ================================================================= */}
      <section className="elementor-stats-grid">
        <div className="stat-card">
          <div className="stat-icon pink">
            <Sparkles />
          </div>
          <div className="stat-data">
            <span className="stat-label">Páginas con Elementor</span>
            <strong className="stat-number">{totalElementorCount}</strong>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon green">
            <Globe />
          </div>
          <div className="stat-data">
            <span className="stat-label">Publicadas en Vivo</span>
            <strong className="stat-number">{publishedElementorCount}</strong>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon amber">
            <FileCode />
          </div>
          <div className="stat-data">
            <span className="stat-label">Borradores en Diseño</span>
            <strong className="stat-number">{draftElementorCount}</strong>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon blue">
            <Layers />
          </div>
          <div className="stat-data">
            <span className="stat-label">Widgets Disponibles</span>
            <strong className="stat-number">12 Pro</strong>
          </div>
        </div>
      </section>

      {/* =================================================================
          BARRA DE BÚSQUEDA Y FILTROS
          ================================================================= */}
      <div className="elementor-toolbar-card">
        <div className="toolbar-search-box">
          <Search />
          <input
            type="text"
            placeholder="Buscar páginas de Elementor por título o slug..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
          />
        </div>

        <button
          type="button"
          className={`btn-filters-toggle ${showFilters ? "active" : ""}`}
          onClick={() => setShowFilters(!showFilters)}
        >
          <SlidersHorizontal />
          <span>Filtros</span>
        </button>
      </div>

      {showFilters && (
        <div className="elementor-filters-drawer">
          <span>Filtrar páginas:</span>
          <button
            type="button"
            className={`filter-chip ${statusFilter === "ALL" ? "selected" : ""}`}
            onClick={() => {
              setStatusFilter("ALL");
              setPage(1);
            }}
          >
            Todas ({pages.length})
          </button>
          <button
            type="button"
            className={`filter-chip pink ${statusFilter === "ELEMENTOR_ONLY" ? "selected" : ""}`}
            onClick={() => {
              setStatusFilter("ELEMENTOR_ONLY");
              setPage(1);
            }}
          >
            Solo Elementor ({totalElementorCount})
          </button>
          <button
            type="button"
            className={`filter-chip green ${statusFilter === "Publicado" ? "selected" : ""}`}
            onClick={() => {
              setStatusFilter("Publicado");
              setPage(1);
            }}
          >
            Publicadas ({pages.filter((p) => p.status === "Publicado").length})
          </button>
          <button
            type="button"
            className={`filter-chip amber ${statusFilter === "Borrador" ? "selected" : ""}`}
            onClick={() => {
              setStatusFilter("Borrador");
              setPage(1);
            }}
          >
            Borradores ({pages.filter((p) => p.status === "Borrador").length})
          </button>
        </div>
      )}

      {/* =================================================================
          TABLA DE PÁGINAS (10 POR PÁGINA)
          ================================================================= */}
      <div className="elementor-table-card">
        {isLoading ? (
          <div className="table-loading-box">
            <Loader2 className="animate-spin" />
            <span>Cargando páginas de Elementor...</span>
          </div>
        ) : paginatedPages.length === 0 ? (
          <div className="table-empty-box">
            <div className="empty-badge-logo">E</div>
            <h3>No se encontraron páginas de Elementor</h3>
            <p>Comienza a diseñar tu primera página visual con secciones flexbox y widgets dinámicos.</p>
            <Link
              href="/dashboard/elementor/editor?new=1"
              className="btn-create-elementor-main"
            >
              <Plus style={{ width: 16, height: 16 }} />
              <span>Crear mi primera página con Elementor</span>
            </Link>
          </div>
        ) : (
          <>
            <div className="table-responsive-wrapper">
              <table className="elementor-hub-table">
                <thead>
                  <tr>
                    <th className="th-checkbox">
                      <input
                        type="checkbox"
                        checked={
                          paginatedPages.length > 0 &&
                          selectedIds.length === paginatedPages.length
                        }
                        onChange={handleSelectAll}
                      />
                    </th>
                    <th className="th-title">Título de la Página</th>
                    <th className="th-builder">Constructor</th>
                    <th className="th-template">Plantilla</th>
                    <th className="th-status">Estado</th>
                    <th className="th-views">Vistas</th>
                    <th className="th-date">Fecha de Creación</th>
                    <th className="th-author">Autor</th>
                    <th className="th-actions">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {paginatedPages.map((p) => {
                    const isSelected = selectedIds.includes(p.id);

                    return (
                      <tr key={p.id} className={isSelected ? "is-selected" : ""}>
                        <td className="td-checkbox">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => handleSelectOne(p.id)}
                          />
                        </td>

                        <td className="td-title">
                          <div className="title-cell-wrap">
                            <div className="title-name-row">
                              <Link
                                href={`/dashboard/elementor/editor?id=${p.id}`}
                                className="page-title-link"
                              >
                                {p.title || "Página sin título"}
                              </Link>
                            </div>
                            <span className="page-slug-sub">/paginas/{p.slug}</span>
                          </div>
                        </td>

                        <td className="td-builder">
                          {p.isElementor ? (
                            <span className="elementor-pill-tag">
                              <strong>E</strong> Elementor Pro
                            </span>
                          ) : (
                            <span className="standard-pill-tag">Estándar</span>
                          )}
                        </td>

                        <td className="td-template">
                          <span className="template-badge">
                            {p.template === "elementor_canvas"
                              ? "Elementor Canvas"
                              : p.template === "fullwidth"
                              ? "Ancho Completo"
                              : "Página Estándar"}
                          </span>
                        </td>

                        <td className="td-status">
                          <span
                            className={`status-pill ${
                              p.status === "Publicado"
                                ? "green"
                                : p.status === "Borrador"
                                ? "amber"
                                : "purple"
                            }`}
                          >
                            {p.status}
                          </span>
                        </td>

                        <td className="td-views">{p.views}</td>

                        <td className="td-date">
                          <div className="date-cell-wrap">
                            <strong>{p.date}</strong>
                            <small>{p.timeAgo}</small>
                          </div>
                        </td>

                        <td className="td-author">{p.author}</td>

                        <td className="td-actions">
                          <div className="table-actions-cluster">
                            <Link
                              href={`/dashboard/elementor/editor?id=${p.id}`}
                              className="action-btn-hub elementor"
                              title="Editar con Elementor Pro"
                            >
                              <Sparkles />
                            </Link>

                            <Link
                              href={`/dashboard/paginas/nuevo?edit=${p.id}`}
                              className="action-btn-hub edit"
                              title="Ajustes de la página"
                            >
                              <Pencil />
                            </Link>

                            <a
                              href={`/paginas/${p.slug}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="action-btn-hub view"
                              title="Ver página en vivo"
                            >
                              <ExternalLink />
                            </a>

                            <button
                              type="button"
                              className="action-btn-hub delete"
                              onClick={() => openDeleteModal(p.id, p.title)}
                              title="Eliminar página"
                            >
                              <Trash2 />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Paginación a 10 por página */}
            <div className="table-pagination-footer">
              <span className="pagination-info">
                Mostrando {(page - 1) * itemsPerPage + 1} a{" "}
                {Math.min(page * itemsPerPage, filteredPages.length)} de{" "}
                {filteredPages.length} páginas
              </span>

              <div className="pagination-controls">
                <button
                  type="button"
                  className="page-nav-btn"
                  onClick={() => setPage((prev) => Math.max(prev - 1, 1))}
                  disabled={page === 1}
                >
                  <ChevronLeft />
                </button>

                {Array.from({ length: totalPagesCount }).map((_, idx) => (
                  <button
                    key={idx}
                    type="button"
                    className={`page-num-btn ${page === idx + 1 ? "active" : ""}`}
                    onClick={() => setPage(idx + 1)}
                  >
                    {idx + 1}
                  </button>
                ))}

                <button
                  type="button"
                  className="page-nav-btn"
                  onClick={() => setPage((prev) => Math.min(prev + 1, totalPagesCount))}
                  disabled={page === totalPagesCount}
                >
                  <ChevronRight />
                </button>
              </div>
            </div>
          </>
        )}
      </div>

      {/* =================================================================
          SECCIÓN ELEMENTOR HUB "EMPECEMOS A CONSTRUIR"
          ================================================================= */}
      <section className="elementor-starter-hub-card">
        <div className="starter-header">
          <div className="starter-icon-ring">
            <Sparkles />
          </div>
          <div>
            <h3 className="starter-title">Empecemos a construir con Elementor</h3>
            <p className="starter-desc">
              Diseña maquetas profesionales y sitios web de alto impacto arrastrando componentes flexbox en tiempo real.
            </p>
          </div>
        </div>

        <div className="starter-cards-grid">
          <Link href="/dashboard/elementor/editor?new=1" className="starter-mini-card">
            <div className="mini-card-icon pink">
              <Layout />
            </div>
            <h4>Nueva Landing Page</h4>
            <p>Comienza una página desde cero con contenedores de 1 a 6 columnas.</p>
            <span className="mini-card-link">Crear ahora &rarr;</span>
          </Link>

          <Link href="/dashboard/paginas" className="starter-mini-card">
            <div className="mini-card-icon green">
              <Globe />
            </div>
            <h4>Todas las Páginas</h4>
            <p>Gestiona los slugs, enlaces y estado de publicación en la web.</p>
            <span className="mini-card-link">Ver catálogo &rarr;</span>
          </Link>

          <Link href="/dashboard/ajustes" className="starter-mini-card">
            <div className="mini-card-icon blue">
              <Settings />
            </div>
            <h4>Configuración del Sitio</h4>
            <p>Ajusta el footer panorámico, tipografías globales y logos institucionales.</p>
            <span className="mini-card-link">Configurar &rarr;</span>
          </Link>
        </div>
      </section>

      {/* =================================================================
          MODAL DE CONFIRMACIÓN DE ELIMINACIÓN
          ================================================================= */}
      {deleteModal.isOpen && (
        <div className="modal-backdrop-blur">
          <div className="modal-card-box">
            <div className="modal-icon-danger">
              <Trash2 />
            </div>
            <h3>¿Eliminar página de Elementor?</h3>
            <p>
              Estás a punto de eliminar <strong>"{deleteModal.title}"</strong>. Esta acción borrará permanentemente la página de MySQL RDS.
            </p>

            <div className="modal-btn-row">
              <button
                type="button"
                className="btn-modal-cancel"
                onClick={() => setDeleteModal({ isOpen: false, id: "", title: "", isDeleting: false })}
                disabled={deleteModal.isDeleting}
              >
                Cancelar
              </button>
              <button
                type="button"
                className="btn-modal-delete"
                onClick={confirmDelete}
                disabled={deleteModal.isDeleting}
              >
                {deleteModal.isDeleting ? (
                  <>
                    <Loader2 className="animate-spin" />
                    <span>Eliminando...</span>
                  </>
                ) : (
                  <span>Sí, Eliminar</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =================================================================
          ESTILOS CSS (SOPORTE COMPLETO LIGHT & DARK MODE)
          ================================================================= */}
      <style jsx>{`
        .elementor-hub-module-root {
          padding: 24px;
          display: flex;
          flex-direction: column;
          gap: 24px;
          max-width: 1400px;
          margin: 0 auto;
        }

        /* Toast */
        .elementor-toast-badge {
          position: fixed;
          top: 24px;
          right: 24px;
          z-index: 1000;
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 12px 20px;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 700;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
          animation: slideIn 0.2s ease;
        }
        .elementor-toast-badge.success {
          background: #022c15;
          border: 1px solid #16c96f;
          color: #43ff93;
        }
        .elementor-toast-badge.error {
          background: #3b0712;
          border: 1px solid #f43f5e;
          color: #fda4af;
        }
        @keyframes slideIn {
          from { transform: translateY(-10px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }

        /* Header */
        .elementor-hub-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 16px;
          flex-wrap: wrap;
        }
        .header-brand-meta {
          display: flex;
          align-items: center;
          gap: 14px;
        }
        .elementor-hub-badge-icon {
          width: 44px;
          height: 44px;
          background: #d63384;
          color: #ffffff;
          font-size: 24px;
          font-weight: 900;
          border-radius: 10px;
          display: grid;
          place-items: center;
          box-shadow: 0 4px 16px rgba(214, 51, 132, 0.4);
        }
        .header-badge-row {
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .elementor-hub-title {
          font-size: 22px;
          font-weight: 800;
          color: #ffffff;
          margin: 0;
        }
        .elementor-pro-pill {
          background: rgba(214, 51, 132, 0.15);
          color: #f472b6;
          border: 1px solid rgba(214, 51, 132, 0.4);
          font-size: 10px;
          font-weight: 800;
          padding: 2px 8px;
          border-radius: 20px;
          letter-spacing: 0.5px;
        }
        .elementor-hub-subtitle {
          font-size: 13px;
          color: #94a3b8;
          margin: 4px 0 0;
        }
        .elementor-hub-subtitle strong {
          color: #cbd5e1;
        }
        .header-link-inline {
          color: #d63384;
          text-decoration: none;
          font-weight: 600;
        }
        .header-link-inline:hover {
          text-decoration: underline;
        }

        .header-actions-row {
          display: flex;
          align-items: center;
          gap: 10px;
          position: relative;
        }

        .btn-refresh-hub {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          height: 38px;
          padding: 0 14px;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          color: #cbd5e1;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.15s ease;
        }
        .btn-refresh-hub:hover {
          background: rgba(255, 255, 255, 0.1);
          color: #ffffff;
        }

        /* Site Edit Dropdown */
        .site-edit-dropdown-wrap {
          position: relative;
        }
        .btn-site-edit-dropdown {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          height: 38px;
          padding: 0 14px;
          background: #e9d5ff;
          border: 1px solid #d8b4fe;
          border-radius: 8px;
          color: #581c87;
          font-size: 13px;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.15s ease;
        }
        .btn-site-edit-dropdown:hover {
          background: #d8b4fe;
        }
        .site-edit-popover-menu {
          position: absolute;
          top: 44px;
          right: 0;
          width: 260px;
          background: #0b1522;
          border: 1px solid rgba(255, 255, 255, 0.12);
          border-radius: 8px;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
          padding: 6px;
          display: flex;
          flex-direction: column;
          gap: 4px;
          z-index: 100;
        }
        .popover-menu-item {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 9px 12px;
          color: #cbd5e1;
          font-size: 12px;
          font-weight: 600;
          text-decoration: none;
          border-radius: 6px;
          transition: all 0.15s ease;
        }
        .popover-menu-item:hover {
          background: rgba(255, 255, 255, 0.08);
          color: #ffffff;
        }

        .btn-create-elementor-main,
        :global(.btn-create-elementor-main) {
          display: inline-flex !important;
          align-items: center !important;
          justify-content: center !important;
          gap: 8px !important;
          height: 38px !important;
          padding: 0 18px !important;
          background: #d63384 !important;
          border: 1px solid #d63384 !important;
          border-radius: 8px !important;
          color: #ffffff !important;
          font-size: 13px !important;
          font-weight: 700 !important;
          text-decoration: none !important;
          white-space: nowrap !important;
          box-shadow: 0 4px 14px rgba(214, 51, 132, 0.4) !important;
          transition: all 0.2s ease !important;
          cursor: pointer !important;
        }
        .btn-create-elementor-main:hover,
        :global(.btn-create-elementor-main:hover) {
          background: #e83e8c !important;
          border-color: #e83e8c !important;
          color: #ffffff !important;
          transform: translateY(-1px) !important;
          box-shadow: 0 6px 18px rgba(214, 51, 132, 0.6) !important;
        }

        /* Stats Cards */
        .elementor-stats-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 16px;
        }
        .stat-card {
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 12px;
          padding: 16px 20px;
          display: flex;
          align-items: center;
          gap: 16px;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
        }
        .stat-icon {
          width: 44px;
          height: 44px;
          border-radius: 10px;
          display: grid;
          place-items: center;
        }
        .stat-icon.pink { background: rgba(214, 51, 132, 0.15); color: #f472b6; border: 1px solid rgba(214, 51, 132, 0.3); }
        .stat-icon.green { background: rgba(22, 201, 111, 0.15); color: #43ff93; border: 1px solid rgba(22, 201, 111, 0.3); }
        .stat-icon.amber { background: rgba(245, 158, 11, 0.15); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.3); }
        .stat-icon.blue { background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); }
        .stat-data {
          display: flex;
          flex-direction: column;
        }
        .stat-label {
          font-size: 12px;
          color: #94a3b8;
          font-weight: 600;
        }
        .stat-number {
          font-size: 22px;
          font-weight: 800;
          color: #ffffff;
        }

        /* Toolbar */
        .elementor-toolbar-card {
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 12px;
          padding: 12px 16px;
          display: flex;
          align-items: center;
          gap: 12px;
        }
        .toolbar-search-box {
          flex: 1;
          position: relative;
          display: flex;
          align-items: center;
        }
        .toolbar-search-box :global(svg) {
          position: absolute;
          left: 12px;
          width: 15px;
          height: 15px;
          color: #64748b;
        }
        .toolbar-search-box input {
          width: 100%;
          height: 38px;
          background: rgba(255, 255, 255, 0.04);
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 8px;
          padding: 0 14px 0 36px;
          color: #ffffff;
          font-size: 12px;
          outline: none;
        }
        .toolbar-search-box input:focus {
          border-color: #d63384;
        }
        .btn-filters-toggle {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          height: 38px;
          padding: 0 16px;
          background: rgba(255, 255, 255, 0.04);
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 8px;
          color: #cbd5e1;
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
        }
        .btn-filters-toggle.active {
          background: rgba(214, 51, 132, 0.15);
          border-color: #d63384;
          color: #f472b6;
        }

        /* Filter Drawer */
        .elementor-filters-drawer {
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 12px;
          padding: 12px 16px;
          display: flex;
          align-items: center;
          gap: 10px;
          flex-wrap: wrap;
          font-size: 12px;
          color: #94a3b8;
        }
        .filter-chip {
          padding: 5px 12px;
          background: rgba(255, 255, 255, 0.04);
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 20px;
          color: #cbd5e1;
          font-size: 11px;
          font-weight: 600;
          cursor: pointer;
        }
        .filter-chip.selected {
          background: #d63384;
          color: #ffffff;
          border-color: #d63384;
        }

        /* Table Card */
        .elementor-table-card {
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 12px;
          overflow: hidden;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
        }
        .table-loading-box, .table-empty-box {
          padding: 60px 20px;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          text-align: center;
          gap: 12px;
          color: #94a3b8;
          font-size: 13px;
        }
        .empty-badge-logo {
          width: 54px;
          height: 54px;
          background: #d63384;
          color: #ffffff;
          font-size: 30px;
          font-weight: 900;
          border-radius: 14px;
          display: grid;
          place-items: center;
          box-shadow: 0 6px 20px rgba(214, 51, 132, 0.4);
          margin-bottom: 6px;
        }
        .table-empty-box h3 {
          font-size: 18px;
          font-weight: 800;
          color: #ffffff;
          margin: 0;
        }

        .table-responsive-wrapper {
          overflow-x: auto;
        }
        .elementor-hub-table {
          width: 100%;
          border-collapse: collapse;
          font-size: 12px;
        }
        .elementor-hub-table th {
          background: #07131e;
          color: #94a3b8;
          font-size: 11px;
          font-weight: 700;
          text-align: left;
          padding: 12px 14px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }
        .elementor-hub-table td {
          padding: 14px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.04);
          color: #cbd5e1;
        }
        .elementor-hub-table tr:hover td {
          background: rgba(255, 255, 255, 0.02);
        }
        .elementor-hub-table tr.is-selected td {
          background: rgba(214, 51, 132, 0.05);
        }

        .th-checkbox, .td-checkbox {
          width: 32px;
          text-align: center;
        }
        .th-checkbox input, .td-checkbox input {
          accent-color: #d63384;
          cursor: pointer;
        }

        .title-cell-wrap {
          display: flex;
          flex-direction: column;
          gap: 2px;
        }
        .page-title-link {
          color: #ffffff;
          font-weight: 700;
          font-size: 13px;
          text-decoration: none;
        }
        .page-title-link:hover {
          color: #d63384;
        }
        .page-slug-sub {
          font-size: 11px;
          color: #64748b;
        }

        .elementor-pill-tag {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          background: rgba(214, 51, 132, 0.15);
          color: #f472b6;
          border: 1px solid rgba(214, 51, 132, 0.35);
          padding: 3px 8px;
          border-radius: 4px;
          font-weight: 700;
          font-size: 11px;
        }
        .elementor-pill-tag strong {
          background: #d63384;
          color: #ffffff;
          width: 14px;
          height: 14px;
          border-radius: 2px;
          display: grid;
          place-items: center;
          font-size: 9px;
        }
        .standard-pill-tag {
          background: rgba(255, 255, 255, 0.05);
          color: #94a3b8;
          border: 1px solid rgba(255, 255, 255, 0.1);
          padding: 3px 8px;
          border-radius: 4px;
          font-size: 11px;
        }

        .template-badge {
          background: rgba(56, 189, 248, 0.1);
          border: 1px solid rgba(56, 189, 248, 0.25);
          color: #38bdf8;
          padding: 3px 8px;
          border-radius: 4px;
          font-size: 11px;
          font-weight: 600;
        }

        .status-pill {
          display: inline-block;
          padding: 3px 9px;
          border-radius: 12px;
          font-size: 11px;
          font-weight: 700;
        }
        .status-pill.green { background: rgba(22, 201, 111, 0.15); color: #43ff93; border: 1px solid rgba(22, 201, 111, 0.3); }
        .status-pill.amber { background: rgba(245, 158, 11, 0.15); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.3); }
        .status-pill.purple { background: rgba(168, 85, 247, 0.15); color: #c084fc; border: 1px solid rgba(168, 85, 247, 0.3); }

        .date-cell-wrap {
          display: flex;
          flex-direction: column;
          gap: 1px;
        }
        .date-cell-wrap strong { color: #cbd5e1; font-weight: 600; }
        .date-cell-wrap small { color: #64748b; font-size: 10px; }

        /* Actions Cluster */
        .table-actions-cluster {
          display: flex;
          align-items: center;
          gap: 6px;
        }
        .action-btn-hub {
          width: 30px;
          height: 30px;
          border-radius: 6px;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: #cbd5e1;
          display: grid;
          place-items: center;
          text-decoration: none;
          cursor: pointer;
          transition: all 0.15s ease;
        }
        .action-btn-hub :global(svg) { width: 14px; height: 14px; }
        .action-btn-hub.elementor {
          color: #f472b6;
          border-color: rgba(214, 51, 132, 0.3);
        }
        .action-btn-hub.elementor:hover {
          background: #d63384;
          color: #ffffff;
          border-color: #d63384;
        }
        .action-btn-hub.edit:hover { background: #38bdf8; color: #040c14; border-color: #38bdf8; }
        .action-btn-hub.view:hover { background: #16c96f; color: #040c14; border-color: #16c96f; }
        .action-btn-hub.delete:hover { background: #f43f5e; color: #ffffff; border-color: #f43f5e; }

        /* Pagination Footer */
        .table-pagination-footer {
          padding: 14px 20px;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
          display: flex;
          align-items: center;
          justify-content: space-between;
          font-size: 12px;
          color: #94a3b8;
        }
        .pagination-controls {
          display: flex;
          align-items: center;
          gap: 6px;
        }
        .page-nav-btn, .page-num-btn {
          height: 32px;
          min-width: 32px;
          padding: 0 8px;
          background: rgba(255, 255, 255, 0.04);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          color: #cbd5e1;
          font-size: 12px;
          font-weight: 700;
          cursor: pointer;
          display: grid;
          place-items: center;
          transition: all 0.15s ease;
        }
        .page-nav-btn:hover:not(:disabled), .page-num-btn:hover {
          background: rgba(255, 255, 255, 0.1);
          color: #ffffff;
        }
        .page-nav-btn:disabled {
          opacity: 0.4;
          cursor: not-allowed;
        }
        .page-num-btn.active {
          background: #d63384;
          border-color: #d63384;
          color: #ffffff;
        }

        /* Starter Hub Card */
        .elementor-starter-hub-card {
          background: #040c14;
          border: 1px solid rgba(214, 51, 132, 0.25);
          border-radius: 12px;
          padding: 24px;
          display: flex;
          flex-direction: column;
          gap: 20px;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
        }
        .starter-header {
          display: flex;
          align-items: center;
          gap: 14px;
        }
        .starter-icon-ring {
          width: 44px;
          height: 44px;
          border-radius: 50%;
          background: rgba(214, 51, 132, 0.15);
          border: 1px solid rgba(214, 51, 132, 0.4);
          color: #f472b6;
          display: grid;
          place-items: center;
        }
        .starter-title {
          font-size: 18px;
          font-weight: 800;
          color: #ffffff;
          margin: 0;
        }
        .starter-desc {
          font-size: 13px;
          color: #94a3b8;
          margin: 4px 0 0;
        }
        .starter-cards-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 14px;
        }
        .starter-mini-card {
          background: rgba(255, 255, 255, 0.03);
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          padding: 16px;
          text-decoration: none;
          display: flex;
          flex-direction: column;
          gap: 8px;
          transition: all 0.2s ease;
        }
        .starter-mini-card:hover {
          background: rgba(255, 255, 255, 0.06);
          border-color: rgba(214, 51, 132, 0.4);
          transform: translateY(-2px);
        }
        .mini-card-icon {
          width: 34px;
          height: 34px;
          border-radius: 8px;
          display: grid;
          place-items: center;
        }
        .mini-card-icon.pink { background: rgba(214, 51, 132, 0.15); color: #f472b6; }
        .mini-card-icon.green { background: rgba(22, 201, 111, 0.15); color: #43ff93; }
        .mini-card-icon.blue { background: rgba(56, 189, 248, 0.15); color: #38bdf8; }
        .starter-mini-card h4 {
          font-size: 14px;
          font-weight: 700;
          color: #ffffff;
          margin: 0;
        }
        .starter-mini-card p {
          font-size: 12px;
          color: #94a3b8;
          margin: 0;
          line-height: 1.4;
        }
        .mini-card-link {
          font-size: 12px;
          font-weight: 700;
          color: #f472b6;
          margin-top: auto;
        }

        /* Modal Delete */
        .modal-backdrop-blur {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.75);
          backdrop-filter: blur(4px);
          display: grid;
          place-items: center;
          z-index: 1000;
          padding: 20px;
        }
        .modal-card-box {
          background: #0b1522;
          border: 1px solid rgba(255, 255, 255, 0.12);
          border-radius: 12px;
          padding: 28px;
          max-width: 440px;
          width: 100%;
          text-align: center;
          display: flex;
          flex-direction: column;
          align-items: center;
          box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
        }
        .modal-icon-danger {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          background: rgba(244, 63, 94, 0.15);
          color: #f43f5e;
          display: grid;
          place-items: center;
          margin-bottom: 14px;
        }
        .modal-card-box h3 {
          font-size: 18px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 8px;
        }
        .modal-card-box p {
          font-size: 13px;
          color: #94a3b8;
          margin: 0 0 20px;
          line-height: 1.5;
        }
        .modal-card-box p strong { color: #ffffff; }
        .modal-btn-row {
          display: flex;
          gap: 12px;
          width: 100%;
        }
        .btn-modal-cancel {
          flex: 1;
          height: 38px;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: #cbd5e1;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
        }
        .btn-modal-delete {
          flex: 1;
          height: 38px;
          background: #f43f5e;
          border: 1px solid #f43f5e;
          color: #ffffff;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 700;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
        }

        /* =================================================================
           TEMA CLARO (LIGHT MODE)
           ================================================================= */
        :global(.theme-light) .elementor-hub-title,
        :global(.theme-light) .starter-title,
        :global(.theme-light) .stat-number,
        :global(.theme-light) .page-title-link,
        :global(.theme-light) .starter-mini-card h4,
        :global(.theme-light) .modal-card-box h3 {
          color: #0f172a !important;
        }

        :global(.theme-light) .elementor-hub-subtitle,
        :global(.theme-light) .stat-label,
        :global(.theme-light) .page-slug-sub,
        :global(.theme-light) .starter-desc,
        :global(.theme-light) .starter-mini-card p,
        :global(.theme-light) .pagination-info,
        :global(.theme-light) .modal-card-box p {
          color: #475569 !important;
        }

        :global(.theme-light) .stat-card,
        :global(.theme-light) .elementor-toolbar-card,
        :global(.theme-light) .elementor-filters-drawer,
        :global(.theme-light) .elementor-table-card,
        :global(.theme-light) .elementor-starter-hub-card {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .elementor-hub-table th {
          background: #f8fafc !important;
          color: #475569 !important;
          border-bottom-color: #e2e8f0 !important;
        }

        :global(.theme-light) .elementor-hub-table td {
          border-bottom-color: #f1f5f9 !important;
          color: #334155 !important;
        }

        :global(.theme-light) .elementor-hub-table tr:hover td {
          background: #f8fafc !important;
        }

        :global(.theme-light) .toolbar-search-box input {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .site-edit-popover-menu {
          background: #ffffff !important;
          border: 1px solid #e2e8f0 !important;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12) !important;
        }

        :global(.theme-light) .popover-menu-item {
          color: #0f172a !important;
        }

        :global(.theme-light) .popover-menu-item:hover {
          background: #f1f5f9 !important;
          color: #d63384 !important;
        }

        :global(.theme-light) .btn-site-edit-dropdown {
          background: #f3e8ff !important;
          border: 1px solid #d8b4fe !important;
          color: #6b21a8 !important;
        }

        :global(.theme-light) .btn-site-edit-dropdown:hover {
          background: #e9d5ff !important;
        }

        :global(.theme-light) .btn-filters-toggle,
        :global(.theme-light) .filter-chip,
        :global(.theme-light) .btn-refresh-hub,
        :global(.theme-light) .page-nav-btn,
        :global(.theme-light) .page-num-btn {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #334155 !important;
        }

        :global(.theme-light) .action-btn-hub {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #475569 !important;
        }

        :global(.theme-light) .starter-mini-card {
          background: #f8fafc !important;
          border-color: #e2e8f0 !important;
        }

        :global(.theme-light) .starter-mini-card:hover {
          background: #f1f5f9 !important;
          border-color: #d63384 !important;
        }

        :global(.theme-light) .modal-card-box {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
        }

        :global(.theme-light) .btn-modal-cancel {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #334155 !important;
        }

        @media (max-width: 1024px) {
          .elementor-stats-grid { grid-template-columns: repeat(2, 1fr); }
          .starter-cards-grid { grid-template-columns: 1fr; }
        }
        @media (max-width: 640px) {
          .elementor-stats-grid { grid-template-columns: 1fr; }
        }
      `}</style>
    </div>
  );
}
