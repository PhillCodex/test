"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import Link from "next/link";
import {
  Upload,
  Image as ImageIcon,
  Film,
  Music,
  FileText,
  Search,
  Grid,
  List,
  ChevronLeft,
  ChevronRight,
  X,
  Trash2,
  Copy,
  Check,
  ExternalLink,
  Download,
  AlertTriangle,
  CheckCircle2,
  Loader2,
  RefreshCw,
  Eye,
  Plus,
  SlidersHorizontal,
} from "lucide-react";

interface MediaItem {
  id: string;
  filename: string;
  originalName: string;
  url: string;
  mimeType: string;
  size: number;
  dimensions?: string | null;
  altText?: string | null;
  title?: string | null;
  caption?: string | null;
  description?: string | null;
  uploadedBy?: string | null;
  attachedToTitle?: string | null;
  attachedToUrl?: string | null;
  attachedToType?: string | null;
  attachedToId?: string | null;
  createdAt: string;
  updatedAt?: string;
}

export default function MediosPage() {
  const [mediaList, setMediaList] = useState<MediaItem[]>([]);
  const [availableDates, setAvailableDates] = useState<{ value: string; label: string }[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");

  // Filtros y Búsqueda
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [dateFilter, setDateFilter] = useState<string>("all");

  // Selección en Lote
  const [bulkMode, setBulkMode] = useState<boolean>(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [isDeletingBulk, setIsDeletingBulk] = useState<boolean>(false);

  // Subida de Archivos y Drag & Drop
  const [showDropzone, setShowDropzone] = useState<boolean>(false);
  const [isDraggingOver, setIsDraggingOver] = useState<boolean>(false);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Modal Detalles del Adjunto (Modal WordPress)
  const [selectedMediaIndex, setSelectedMediaIndex] = useState<number | null>(null);
  const [isSavingDetails, setIsSavingDetails] = useState<boolean>(false);
  const [detailsSavedMessage, setDetailsSavedMessage] = useState<string | null>(null);
  const [copiedUrl, setCopiedUrl] = useState<boolean>(false);

  // Campos de edición en el modal
  const [editAltText, setEditAltText] = useState<string>("");
  const [editTitle, setEditTitle] = useState<string>("");
  const [editCaption, setEditCaption] = useState<string>("");
  const [editDescription, setEditDescription] = useState<string>("");

  // Toast
  const [toast, setToast] = useState<{ message: string; type: "success" | "error" | "info" } | null>(null);

  const showToast = (message: string, type: "success" | "error" | "info" = "success") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  // Cargar Medios
  const fetchMedia = useCallback(async () => {
    setIsLoading(true);
    try {
      const params = new URLSearchParams();
      if (searchQuery) params.set("search", searchQuery);
      if (typeFilter !== "all") params.set("type", typeFilter);
      if (dateFilter !== "all") params.set("date", dateFilter);

      const res = await fetch(`/api/media?${params.toString()}`);
      const data = await res.json();
      if (data.success) {
        setMediaList(data.media || []);
        if (data.availableDates) {
          setAvailableDates(data.availableDates);
        }
      } else {
        showToast(data.error || "Error al cargar biblioteca de medios.", "error");
      }
    } catch (err) {
      console.error("Error al cargar medios:", err);
      showToast("Error de conexión con la base de datos.", "error");
    } finally {
      setIsLoading(false);
    }
  }, [searchQuery, typeFilter, dateFilter]);

  useEffect(() => {
    fetchMedia();
  }, [fetchMedia]);

  // Subir Archivos
  const handleUploadFiles = async (files: FileList | File[]) => {
    if (!files || files.length === 0) return;

    setIsUploading(true);
    setUploadProgress(15);

    const formData = new FormData();
    Array.from(files).forEach((file) => {
      formData.append("files", file);
    });

    try {
      setUploadProgress(45);
      const res = await fetch("/api/media", {
        method: "POST",
        body: formData,
      });
      setUploadProgress(85);
      const data = await res.json();

      if (data.success) {
        setUploadProgress(100);
        showToast(data.message || "Archivos subidos exitosamente.", "success");
        setShowDropzone(false);
        fetchMedia();
      } else {
        showToast(data.error || "Error al subir archivos.", "error");
      }
    } catch (err) {
      console.error(err);
      showToast("Error al procesar la subida.", "error");
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  // Drag and Drop Global
  useEffect(() => {
    const handleDragOver = (e: DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setIsDraggingOver(true);
    };

    const handleDragLeave = (e: DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      if (e.relatedTarget === null) {
        setIsDraggingOver(false);
      }
    };

    const handleDrop = (e: DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setIsDraggingOver(false);
      if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length > 0) {
        handleUploadFiles(e.dataTransfer.files);
      }
    };

    window.addEventListener("dragover", handleDragOver);
    window.addEventListener("dragleave", handleDragLeave);
    window.addEventListener("drop", handleDrop);

    return () => {
      window.removeEventListener("dragover", handleDragOver);
      window.removeEventListener("dragleave", handleDragLeave);
      window.removeEventListener("drop", handleDrop);
    };
  }, []);

  // Abrir Modal de Detalles
  const currentSelectedMedia =
    selectedMediaIndex !== null && mediaList[selectedMediaIndex]
      ? mediaList[selectedMediaIndex]
      : null;

  const openMediaModal = (index: number) => {
    if (bulkMode) {
      toggleSelectId(mediaList[index].id);
      return;
    }
    const item = mediaList[index];
    setSelectedMediaIndex(index);
    setEditAltText(item.altText || "");
    setEditTitle(item.title || item.originalName || "");
    setEditCaption(item.caption || "");
    setEditDescription(item.description || "");
    setDetailsSavedMessage(null);
    setCopiedUrl(false);
  };

  // Navegación en el Modal
  const goToNextMedia = () => {
    if (selectedMediaIndex === null) return;
    const nextIdx = (selectedMediaIndex + 1) % mediaList.length;
    openMediaModal(nextIdx);
  };

  const goToPrevMedia = () => {
    if (selectedMediaIndex === null) return;
    const prevIdx = (selectedMediaIndex - 1 + mediaList.length) % mediaList.length;
    openMediaModal(prevIdx);
  };

  // Atajos de Teclado para el Modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (selectedMediaIndex === null) return;
      if (e.key === "Escape") {
        setSelectedMediaIndex(null);
      } else if (e.key === "ArrowRight") {
        goToNextMedia();
      } else if (e.key === "ArrowLeft") {
        goToPrevMedia();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [selectedMediaIndex, mediaList]);

  // Guardar Cambios de Metadatos
  const handleSaveMediaDetails = async () => {
    if (!currentSelectedMedia) return;
    setIsSavingDetails(true);
    try {
      const res = await fetch(`/api/media/${currentSelectedMedia.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          altText: editAltText,
          title: editTitle,
          caption: editCaption,
          description: editDescription,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setDetailsSavedMessage("Guardado");
        setTimeout(() => setDetailsSavedMessage(null), 2500);
        // Actualizar lista local
        setMediaList((prev) =>
          prev.map((m) => (m.id === currentSelectedMedia.id ? { ...m, ...data.media } : m))
        );
      } else {
        showToast(data.error || "Error al guardar detalles.", "error");
      }
    } catch {
      showToast("Error de conexión al guardar.", "error");
    } finally {
      setIsSavingDetails(false);
    }
  };

  // Eliminar un solo archivo
  const handleDeleteSingleMedia = async (id: string) => {
    if (!confirm("¿Estás seguro de que deseas eliminar permanentemente este archivo de medios?")) {
      return;
    }
    try {
      const res = await fetch(`/api/media/${id}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) {
        showToast("Archivo eliminado permanentemente.", "success");
        setSelectedMediaIndex(null);
        fetchMedia();
      } else {
        showToast(data.error || "Error al eliminar archivo.", "error");
      }
    } catch {
      showToast("Error de conexión al eliminar archivo.", "error");
    }
  };

  // Selección en Lote
  const toggleSelectId = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSelectAll = () => {
    if (selectedIds.length === mediaList.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(mediaList.map((m) => m.id));
    }
  };

  const handleDeleteBulk = async () => {
    if (selectedIds.length === 0) return;
    if (
      !confirm(
        `¿Estás seguro de que deseas eliminar permanentemente los ${selectedIds.length} archivos seleccionados?`
      )
    ) {
      return;
    }
    setIsDeletingBulk(true);
    try {
      const res = await fetch("/api/media", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ids: selectedIds }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(`${selectedIds.length} archivos eliminados.`, "success");
        setSelectedIds([]);
        setBulkMode(false);
        fetchMedia();
      } else {
        showToast(data.error || "Error al eliminar en lote.", "error");
      }
    } catch {
      showToast("Error al conectar con el servidor.", "error");
    } finally {
      setIsDeletingBulk(false);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString("es-ES", {
      day: "numeric",
      month: "long",
      year: "numeric",
    });
  };

  return (
    <div className="wp-media-library-page">
      {/* Toast */}
      {toast && (
        <div className={`wp-media-toast ${toast.type}`}>
          {toast.type === "success" && <CheckCircle2 />}
          {toast.type === "error" && <AlertTriangle />}
          <span>{toast.message}</span>
        </div>
      )}

      {/* Overlay al arrastrar sobre toda la pantalla */}
      {isDraggingOver && (
        <div className="wp-global-drag-overlay">
          <div className="drag-overlay-box">
            <Upload className="animate-bounce" />
            <h3>Suelta los archivos aquí para subirlos a Medios</h3>
          </div>
        </div>
      )}

      {/* Encabezado Principal estilo WordPress */}
      <div className="wp-media-header-bar">
        <div className="wp-media-title-group">
          <h1>Biblioteca de medios</h1>
          <button
            type="button"
            className="wp-add-new-btn"
            onClick={() => setShowDropzone(!showDropzone)}
          >
            {showDropzone ? "Cerrar subida" : "Añadir nuevo medio"}
          </button>
        </div>
      </div>

      {/* Zona Drag & Drop Colapsable estilo WordPress (Imagen 2) */}
      {showDropzone && (
        <div className="wp-dropzone-uploader-card">
          <div
            className="wp-dropzone-interior"
            onDragOver={(e) => {
              e.preventDefault();
              e.stopPropagation();
            }}
            onDrop={(e) => {
              e.preventDefault();
              e.stopPropagation();
              if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                handleUploadFiles(e.dataTransfer.files);
              }
            }}
          >
            <Upload className="drop-icon" />
            <p className="drop-main-text">Arrastra los archivos para subirlos</p>
            <span className="drop-or-text">o</span>
            <input
              type="file"
              multiple
              ref={fileInputRef}
              style={{ display: "none" }}
              onChange={(e) => {
                if (e.target.files) handleUploadFiles(e.target.files);
              }}
            />
            <button
              type="button"
              className="wp-button-select-files"
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
            >
              {isUploading ? "Subiendo..." : "Selecciona archivos"}
            </button>
            <span className="drop-hint-text">Tamaño máximo de archivo para subir: 64 MB.</span>

            {/* Barra de Progreso Azul */}
            {isUploading && (
              <div className="wp-upload-progress-container">
                <div className="wp-upload-progress-bar" style={{ width: `${uploadProgress}%` }} />
              </div>
            )}
          </div>
        </div>
      )}

      {/* Barra de Filtros y Herramientas estilo WordPress (Imagen 1) */}
      <div className="wp-media-toolbar">
        <div className="toolbar-left-group">
          {/* Botones de Vista (Lista / Cuadrícula) */}
          <div className="view-mode-buttons">
            <button
              type="button"
              className={`view-btn ${viewMode === "list" ? "active" : ""}`}
              onClick={() => setViewMode("list")}
              title="Vista de lista"
              aria-label="Vista de lista"
            >
              <List />
            </button>
            <button
              type="button"
              className={`view-btn ${viewMode === "grid" ? "active" : ""}`}
              onClick={() => setViewMode("grid")}
              title="Vista de cuadrícula"
              aria-label="Vista de cuadrícula"
            >
              <Grid />
            </button>
          </div>

          {/* Filtro por Tipo de Medio */}
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="wp-filter-select"
            aria-label="Filtrar por tipo de medio"
          >
            <option value="all">Todos los medios</option>
            <option value="image">Imágenes</option>
            <option value="audio">Audio</option>
            <option value="video">Video</option>
            <option value="document">Documentos / PDFs</option>
          </select>

          {/* Filtro por Fechas */}
          <select
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            className="wp-filter-select"
            aria-label="Filtrar por fecha"
          >
            <option value="all">Todas las fechas</option>
            {availableDates.map((d) => (
              <option key={d.value} value={d.value}>
                {d.label}
              </option>
            ))}
          </select>

          {/* Botón de Selección en Lotes */}
          {!bulkMode ? (
            <button
              type="button"
              className="wp-bulk-select-btn"
              onClick={() => {
                setBulkMode(true);
                setSelectedIds([]);
              }}
            >
              Selección en lotes
            </button>
          ) : (
            <div className="bulk-actions-active-row">
              <button
                type="button"
                className="wp-bulk-select-btn"
                onClick={handleSelectAll}
              >
                {selectedIds.length === mediaList.length ? "Deseleccionar todo" : "Seleccionar todo"}
              </button>
              <button
                type="button"
                className="wp-delete-bulk-btn"
                onClick={handleDeleteBulk}
                disabled={selectedIds.length === 0 || isDeletingBulk}
              >
                {isDeletingBulk ? <Loader2 className="animate-spin" /> : <Trash2 />}
                <span>Borrar seleccionados ({selectedIds.length})</span>
              </button>
              <button
                type="button"
                className="wp-cancel-bulk-btn"
                onClick={() => {
                  setBulkMode(false);
                  setSelectedIds([]);
                }}
              >
                Cancelar
              </button>
            </div>
          )}
        </div>

        {/* Buscador a la Derecha */}
        <div className="toolbar-right-group">
          <label htmlFor="mediaSearch" className="search-label">
            Buscar medios
          </label>
          <div className="search-input-wrapper">
            <input
              id="mediaSearch"
              type="text"
              placeholder=""
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="wp-search-input"
            />
          </div>
        </div>
      </div>

      {/* Contenido Principal de Medios */}
      {isLoading ? (
        <div className="wp-media-loading">
          <Loader2 className="animate-spin" />
          <span>Cargando biblioteca de medios...</span>
        </div>
      ) : mediaList.length === 0 ? (
        <div className="wp-media-empty-state">
          <p>No se han encontrado archivos de medios.</p>
        </div>
      ) : viewMode === "grid" ? (
        /* VISTA EN CUADRÍCULA ESTILO WORDPRESS (Imagen 3) */
        <div className="wp-media-grid-container">
          {mediaList.map((item, index) => {
            const isSelected = selectedIds.includes(item.id);
            const isImage = item.mimeType.startsWith("image/");
            const isVideo = item.mimeType.startsWith("video/");
            const isAudio = item.mimeType.startsWith("audio/");

            return (
              <div
                key={item.id}
                className={`wp-grid-thumbnail-card ${isSelected ? "is-selected" : ""}`}
                onClick={() => openMediaModal(index)}
              >
                <div className="thumbnail-aspect-ratio">
                  {isImage ? (
                    <img src={item.url} alt={item.altText || item.title || item.originalName} />
                  ) : isVideo ? (
                    <div className="file-icon-placeholder video">
                      <Film />
                    </div>
                  ) : isAudio ? (
                    <div className="file-icon-placeholder audio">
                      <Music />
                    </div>
                  ) : (
                    <div className="file-icon-placeholder document">
                      <FileText />
                    </div>
                  )}

                  {/* Checkmark en Selección en Lote */}
                  {bulkMode && (
                    <div className={`bulk-check-badge ${isSelected ? "checked" : ""}`}>
                      {isSelected && <Check />}
                    </div>
                  )}
                </div>

                <div className="thumbnail-caption-bar" title={item.title || item.originalName}>
                  <span>{item.title || item.originalName}</span>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* VISTA EN LISTA ESTILO WORDPRESS */
        <div className="wp-media-list-card">
          <table className="wp-media-list-table">
            <thead>
              <tr>
                <th style={{ width: "40px" }}>
                  {bulkMode && (
                    <input
                      type="checkbox"
                      checked={selectedIds.length === mediaList.length && mediaList.length > 0}
                      onChange={handleSelectAll}
                      aria-label="Seleccionar todo"
                    />
                  )}
                </th>
                <th>Miniatura</th>
                <th>Archivo</th>
                <th>Autor</th>
                <th>Subido a</th>
                <th>Fecha</th>
                <th>Tamaño</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {mediaList.map((item, index) => {
                const isSelected = selectedIds.includes(item.id);
                const isImage = item.mimeType.startsWith("image/");

                return (
                  <tr key={item.id} className={isSelected ? "row-selected" : ""}>
                    <td>
                      {bulkMode && (
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleSelectId(item.id)}
                          aria-label={`Seleccionar ${item.title}`}
                        />
                      )}
                    </td>
                    <td>
                      <div
                        className="list-thumb-wrap"
                        onClick={() => openMediaModal(index)}
                      >
                        {isImage ? (
                          <img src={item.url} alt="" />
                        ) : (
                          <FileText className="doc-icon" />
                        )}
                      </div>
                    </td>
                    <td>
                      <button
                        type="button"
                        className="list-file-title-btn"
                        onClick={() => openMediaModal(index)}
                      >
                        <strong>{item.title || item.originalName}</strong>
                      </button>
                      <small className="list-filename-sub">{item.filename}</small>
                    </td>
                    <td>{item.uploadedBy || "Admin"}</td>
                    <td>
                      {item.attachedToTitle ? (
                        item.attachedToUrl ? (
                          <Link href={item.attachedToUrl} className="wp-attached-link" title={`Editar ${item.attachedToTitle}`}>
                            {item.attachedToTitle}
                          </Link>
                        ) : (
                          <span className="wp-attached-link">{item.attachedToTitle}</span>
                        )
                      ) : (
                        <span className="wp-unattached-text">(sin título)</span>
                      )}
                    </td>
                    <td>{formatDate(item.createdAt)}</td>
                    <td>{formatFileSize(item.size)}</td>
                    <td>
                      <div className="list-row-actions">
                        <button
                          type="button"
                          className="action-link edit"
                          onClick={() => openMediaModal(index)}
                        >
                          Editar
                        </button>
                        <span className="action-sep">|</span>
                        <button
                          type="button"
                          className="action-link delete"
                          onClick={() => handleDeleteSingleMedia(item.id)}
                        >
                          Borrar
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* =========================================================================
          MODAL DETALLES DEL ADJUNTO ESTILO WORDPRESS (Imagen 4)
          ========================================================================= */}
      {currentSelectedMedia && (
        <div className="wp-attachment-modal-overlay" onClick={() => setSelectedMediaIndex(null)}>
          <div
            className="wp-attachment-modal-content"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header del Modal con Navegación y Cierre */}
            <div className="attachment-modal-header">
              <h2>Detalles del adjunto</h2>
              <div className="header-nav-buttons">
                <button
                  type="button"
                  className="nav-arrow-btn"
                  onClick={goToPrevMedia}
                  title="Anterior (←)"
                  aria-label="Elemento anterior"
                >
                  <ChevronLeft />
                </button>
                <button
                  type="button"
                  className="nav-arrow-btn"
                  onClick={goToNextMedia}
                  title="Siguiente (→)"
                  aria-label="Elemento siguiente"
                >
                  <ChevronRight />
                </button>
                <button
                  type="button"
                  className="close-modal-btn"
                  onClick={() => setSelectedMediaIndex(null)}
                  title="Cerrar (Esc)"
                  aria-label="Cerrar modal"
                >
                  <X />
                </button>
              </div>
            </div>

            {/* Cuerpo del Modal (2 Columnas) */}
            <div className="attachment-modal-body">
              {/* Columna Izquierda: Vista Previa de la Imagen */}
              <div className="attachment-preview-col">
                <div className="preview-image-container">
                  {currentSelectedMedia.mimeType.startsWith("image/") ? (
                    <img
                      src={currentSelectedMedia.url}
                      alt={currentSelectedMedia.altText || currentSelectedMedia.title || ""}
                    />
                  ) : currentSelectedMedia.mimeType.startsWith("video/") ? (
                    <video src={currentSelectedMedia.url} controls />
                  ) : currentSelectedMedia.mimeType.startsWith("audio/") ? (
                    <audio src={currentSelectedMedia.url} controls />
                  ) : (
                    <div className="doc-large-icon">
                      <FileText />
                      <span>{currentSelectedMedia.originalName}</span>
                    </div>
                  )}
                </div>

                <div className="preview-action-row">
                  <a
                    href={currentSelectedMedia.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="wp-btn-edit-image"
                  >
                    Ver archivo original
                  </a>
                </div>
              </div>

              {/* Columna Derecha: Metadatos y Formulario Editable */}
              <div className="attachment-details-col">
                {/* Meta Info */}
                <div className="media-meta-info-box">
                  <p>
                    <strong>Subido el:</strong> {formatDate(currentSelectedMedia.createdAt)}
                  </p>
                  <p>
                    <strong>Subido por:</strong> <span className="blue-link">{currentSelectedMedia.uploadedBy || "Admin"}</span>
                  </p>
                  <p>
                    <strong>Subido a:</strong>{" "}
                    {currentSelectedMedia.attachedToTitle ? (
                      currentSelectedMedia.attachedToUrl ? (
                        <Link href={currentSelectedMedia.attachedToUrl} className="blue-link" title={`Ir a ${currentSelectedMedia.attachedToTitle}`}>
                          {currentSelectedMedia.attachedToTitle}
                        </Link>
                      ) : (
                        <span className="blue-link">{currentSelectedMedia.attachedToTitle}</span>
                      )
                    ) : (
                      <span className="blue-link" style={{ color: "#38bdf8" }}>(sin título)</span>
                    )}
                  </p>
                  <p>
                    <strong>Nombre del archivo:</strong> {currentSelectedMedia.filename}
                  </p>
                  <p>
                    <strong>Tipo de archivo:</strong> {currentSelectedMedia.mimeType}
                  </p>
                  <p>
                    <strong>Tamaño del archivo:</strong> {formatFileSize(currentSelectedMedia.size)}
                  </p>
                  {currentSelectedMedia.dimensions && (
                    <p>
                      <strong>Dimensiones:</strong> {currentSelectedMedia.dimensions}
                    </p>
                  )}
                </div>

                {/* Formulario de Metadatos */}
                <div className="media-edit-fields-stack">
                  {/* Texto alternativo */}
                  <div className="attachment-field-row">
                    <label htmlFor="modalAltText">Texto alternativo</label>
                    <div className="field-input-wrap">
                      <input
                        id="modalAltText"
                        type="text"
                        value={editAltText}
                        onChange={(e) => setEditAltText(e.target.value)}
                        onBlur={handleSaveMediaDetails}
                        className="wp-modal-input"
                      />
                      <small className="help-text">
                        Aprende cómo describir el propósito de la imagen. Déjalo vacío si la imagen es puramente decorativa.
                      </small>
                    </div>
                  </div>

                  {/* Título */}
                  <div className="attachment-field-row">
                    <label htmlFor="modalTitle">Título</label>
                    <div className="field-input-wrap">
                      <input
                        id="modalTitle"
                        type="text"
                        value={editTitle}
                        onChange={(e) => setEditTitle(e.target.value)}
                        onBlur={handleSaveMediaDetails}
                        className="wp-modal-input"
                      />
                    </div>
                  </div>

                  {/* Leyenda */}
                  <div className="attachment-field-row">
                    <label htmlFor="modalCaption">Leyenda de la imagen</label>
                    <div className="field-input-wrap">
                      <textarea
                        id="modalCaption"
                        rows={2}
                        value={editCaption}
                        onChange={(e) => setEditCaption(e.target.value)}
                        onBlur={handleSaveMediaDetails}
                        className="wp-modal-textarea"
                      />
                    </div>
                  </div>

                  {/* Descripción */}
                  <div className="attachment-field-row">
                    <label htmlFor="modalDescription">Descripción</label>
                    <div className="field-input-wrap">
                      <textarea
                        id="modalDescription"
                        rows={3}
                        value={editDescription}
                        onChange={(e) => setEditDescription(e.target.value)}
                        onBlur={handleSaveMediaDetails}
                        className="wp-modal-textarea"
                      />
                    </div>
                  </div>

                  {/* URL del archivo */}
                  <div className="attachment-field-row">
                    <label htmlFor="modalFileUrl">URL del archivo:</label>
                    <div className="field-input-wrap">
                      <input
                        id="modalFileUrl"
                        type="text"
                        readOnly
                        value={typeof window !== "undefined" ? `${window.location.origin}${currentSelectedMedia.url}` : currentSelectedMedia.url}
                        className="wp-modal-input readonly"
                      />
                      <button
                        type="button"
                        className="wp-btn-copy-url"
                        onClick={() => {
                          const fullUrl = typeof window !== "undefined" ? `${window.location.origin}${currentSelectedMedia.url}` : currentSelectedMedia.url;
                          navigator.clipboard.writeText(fullUrl);
                          setCopiedUrl(true);
                          setTimeout(() => setCopiedUrl(false), 2000);
                        }}
                      >
                        {copiedUrl ? <Check className="btn-ico" /> : <Copy className="btn-ico" />}
                        <span>{copiedUrl ? "¡Copiada!" : "Copiar la URL al portapapeles"}</span>
                      </button>
                    </div>
                  </div>

                  {/* Estado de guardado automático */}
                  {detailsSavedMessage && (
                    <div className="auto-save-status-msg">
                      <Check className="check-ico" />
                      <span>{detailsSavedMessage}</span>
                    </div>
                  )}
                </div>

                {/* Enlaces de Acción Inferiores */}
                <div className="attachment-footer-links-row">
                  <a
                    href={currentSelectedMedia.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="modal-action-link"
                  >
                    Ver archivo de medios
                  </a>
                  <span className="action-divider">|</span>
                  <a
                    href={currentSelectedMedia.url}
                    download={currentSelectedMedia.filename}
                    className="modal-action-link"
                  >
                    Descargar archivo
                  </a>
                  <span className="action-divider">|</span>
                  <button
                    type="button"
                    className="modal-action-link delete-red"
                    onClick={() => handleDeleteSingleMedia(currentSelectedMedia.id)}
                  >
                    Borrar permanentemente
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ESTILOS CSS ESTILO WORDPRESS (DARK & LIGHT THEMES) */}
      <style jsx>{`
        .wp-media-library-page {
          padding: 0 0 60px;
          color: #f0f0f1;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
        }

        /* Toast */
        .wp-media-toast {
          position: fixed;
          top: 70px;
          right: 24px;
          z-index: 100000;
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 12px 18px;
          border-radius: 6px;
          font-size: 13px;
          font-weight: 600;
          box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
        }

        .wp-media-toast.success {
          background: #062316;
          border: 1px solid #16c96f;
          color: #a7f3d0;
        }

        .wp-media-toast.error {
          background: #270d0d;
          border: 1px solid #ef4444;
          color: #fca5a5;
        }

        /* Drag Overlay Global */
        .wp-global-drag-overlay {
          position: fixed;
          inset: 0;
          background: rgba(3, 11, 18, 0.85);
          backdrop-filter: blur(4px);
          z-index: 999999;
          display: grid;
          place-items: center;
        }

        .drag-overlay-box {
          border: 3px dashed #16c96f;
          border-radius: 16px;
          padding: 60px 80px;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 16px;
          color: #ffffff;
        }

        .drag-overlay-box :global(svg) {
          width: 54px;
          height: 54px;
          color: #16c96f;
        }

        .drag-overlay-box h3 {
          font-size: 20px;
          font-weight: 700;
          margin: 0;
        }

        /* Encabezado */
        .wp-media-header-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 16px;
        }

        .wp-media-title-group {
          display: flex;
          align-items: center;
          gap: 16px;
        }

        .wp-media-title-group h1 {
          font-size: 23px;
          font-weight: 400;
          color: #ffffff;
          margin: 0;
        }

        .wp-add-new-btn {
          height: 30px;
          padding: 0 12px;
          background: #2271b1;
          border: 1px solid #2271b1;
          border-radius: 4px;
          color: #ffffff;
          font-size: 13px;
          font-weight: 500;
          cursor: pointer;
          transition: background 0.15s;
        }

        .wp-add-new-btn:hover {
          background: #135e96;
        }

        /* Dropzone Uploader */
        .wp-dropzone-uploader-card {
          background: #040c14;
          border: 2px dashed rgba(255, 255, 255, 0.2);
          border-radius: 8px;
          padding: 30px 20px;
          margin-bottom: 20px;
          text-align: center;
        }

        .wp-dropzone-interior {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
        }

        .drop-icon {
          width: 38px;
          height: 38px;
          color: #64748b;
        }

        .drop-main-text {
          font-size: 15px;
          font-weight: 600;
          color: #ffffff;
          margin: 0;
        }

        .drop-or-text {
          font-size: 12px;
          color: #64748b;
        }

        .wp-button-select-files {
          height: 32px;
          padding: 0 16px;
          background: rgba(255, 255, 255, 0.08);
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 4px;
          color: #ffffff;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          margin: 4px 0;
        }

        .wp-button-select-files:hover {
          background: rgba(255, 255, 255, 0.15);
        }

        .drop-hint-text {
          font-size: 11px;
          color: #64748b;
        }

        .wp-upload-progress-container {
          width: 280px;
          height: 6px;
          background: rgba(255, 255, 255, 0.1);
          border-radius: 4px;
          overflow: hidden;
          margin-top: 12px;
        }

        .wp-upload-progress-bar {
          height: 100%;
          background: #2271b1;
          transition: width 0.2s ease;
        }

        /* Toolbar de Filtros */
        .wp-media-toolbar {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 12px;
          margin-bottom: 16px;
          flex-wrap: wrap;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 6px;
          padding: 10px 14px;
        }

        .toolbar-left-group {
          display: flex;
          align-items: center;
          gap: 10px;
          flex-wrap: wrap;
        }

        .view-mode-buttons {
          display: flex;
          border: 1px solid rgba(255, 255, 255, 0.15);
          border-radius: 4px;
          overflow: hidden;
        }

        .view-btn {
          width: 32px;
          height: 30px;
          background: transparent;
          border: none;
          display: grid;
          place-items: center;
          color: #94a3b8;
          cursor: pointer;
        }

        .view-btn.active {
          background: #2271b1;
          color: #ffffff;
        }

        .view-btn :global(svg) {
          width: 15px;
          height: 15px;
        }

        .wp-filter-select {
          height: 30px;
          padding: 0 8px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.15);
          border-radius: 4px;
          color: #f0f0f1;
          font-size: 13px;
          outline: none;
          cursor: pointer;
        }

        .wp-bulk-select-btn {
          height: 30px;
          padding: 0 12px;
          background: transparent;
          border: 1px solid #2271b1;
          border-radius: 4px;
          color: #2271b1;
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
        }

        .wp-bulk-select-btn:hover {
          background: rgba(34, 113, 177, 0.15);
        }

        .bulk-actions-active-row {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .wp-delete-bulk-btn {
          height: 30px;
          padding: 0 12px;
          background: #dc2626;
          border: 1px solid #dc2626;
          border-radius: 4px;
          color: #ffffff;
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
          display: inline-flex;
          align-items: center;
          gap: 6px;
        }

        .wp-delete-bulk-btn :global(svg) {
          width: 14px;
          height: 14px;
        }

        .wp-cancel-bulk-btn {
          height: 30px;
          padding: 0 10px;
          background: transparent;
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 4px;
          color: #94a3b8;
          font-size: 12px;
          cursor: pointer;
        }

        .toolbar-right-group {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .search-label {
          font-size: 12px;
          color: #94a3b8;
        }

        .wp-search-input {
          height: 30px;
          padding: 0 10px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.15);
          border-radius: 4px;
          color: #ffffff;
          font-size: 13px;
          outline: none;
          width: 220px;
        }

        .wp-search-input:focus {
          border-color: #2271b1;
        }

        /* Loading y Empty States */
        .wp-media-loading,
        .wp-media-empty-state {
          padding: 60px 20px;
          text-align: center;
          color: #94a3b8;
          font-size: 14px;
        }

        /* VISTA EN CUADRÍCULA ESTILO WORDPRESS */
        .wp-media-grid-container {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(130px, 1fr));
          gap: 12px;
        }

        .wp-grid-thumbnail-card {
          position: relative;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          box-shadow: inset 0 0 15px rgba(0, 0, 0, 0.3);
          cursor: pointer;
          user-select: none;
          transition: border-color 0.15s, box-shadow 0.15s;
          display: flex;
          flex-direction: column;
        }

        .wp-grid-thumbnail-card:hover {
          border-color: #2271b1;
          box-shadow: 0 0 0 1px #2271b1;
        }

        .wp-grid-thumbnail-card.is-selected {
          border-color: #2271b1;
          box-shadow: 0 0 0 3px #2271b1;
        }

        .thumbnail-aspect-ratio {
          position: relative;
          width: 100%;
          padding-top: 100%; /* 1:1 Square */
          overflow: hidden;
          background: #07131e;
        }

        .thumbnail-aspect-ratio img {
          position: absolute;
          inset: 0;
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .file-icon-placeholder {
          position: absolute;
          inset: 0;
          display: grid;
          place-items: center;
          color: #64748b;
        }

        .file-icon-placeholder :global(svg) {
          width: 36px;
          height: 36px;
        }

        .bulk-check-badge {
          position: absolute;
          top: 6px;
          right: 6px;
          width: 20px;
          height: 20px;
          border-radius: 3px;
          background: rgba(0, 0, 0, 0.6);
          border: 1px solid rgba(255, 255, 255, 0.4);
          display: grid;
          place-items: center;
        }

        .bulk-check-badge.checked {
          background: #2271b1;
          border-color: #2271b1;
          color: #ffffff;
        }

        .bulk-check-badge :global(svg) {
          width: 14px;
          height: 14px;
        }

        .thumbnail-caption-bar {
          padding: 6px 8px;
          background: rgba(0, 0, 0, 0.4);
          font-size: 11px;
          color: #cbd5e1;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        /* VISTA EN LISTA */
        .wp-media-list-card {
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 6px;
          overflow-x: auto;
        }

        .wp-media-list-table {
          width: 100%;
          border-collapse: collapse;
          text-align: left;
          font-size: 13px;
        }

        .wp-media-list-table th {
          padding: 10px 14px;
          background: rgba(255, 255, 255, 0.02);
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
          color: #94a3b8;
          font-size: 12px;
        }

        .wp-media-list-table td {
          padding: 10px 14px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.04);
          color: #cbd5e1;
          vertical-align: middle;
        }

        .list-thumb-wrap {
          width: 50px;
          height: 50px;
          border-radius: 4px;
          overflow: hidden;
          background: #07131e;
          display: grid;
          place-items: center;
          cursor: pointer;
        }

        .list-thumb-wrap img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .list-file-title-btn {
          background: transparent;
          border: none;
          padding: 0;
          color: #2271b1;
          font-size: 13px;
          cursor: pointer;
          text-align: left;
          display: block;
        }

        .list-file-title-btn:hover {
          color: #72aee6;
        }

        .list-filename-sub {
          font-size: 11px;
          color: #64748b;
          display: block;
        }

        .wp-attached-link {
          color: #38bdf8;
          text-decoration: none;
          font-weight: 500;
          font-size: 13px;
        }

        .wp-attached-link:hover {
          text-decoration: underline;
          color: #7dd3fc;
        }

        .wp-unattached-text {
          color: #64748b;
          font-style: italic;
          font-size: 12.5px;
        }

        .list-row-actions {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 12px;
        }

        .action-link {
          background: transparent;
          border: none;
          padding: 0;
          cursor: pointer;
          font-size: 12px;
        }

        .action-link.edit { color: #2271b1; }
        .action-link.edit:hover { color: #72aee6; }
        .action-link.delete { color: #ef4444; }
        .action-link.delete:hover { color: #f87171; }
        .action-sep { color: #64748b; }

        /* =========================================================================
           MODAL DETALLES DEL ADJUNTO (ESTILO WORDPRESS - Imagen 4)
           ========================================================================= */
        .wp-attachment-modal-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.75);
          backdrop-filter: blur(2px);
          z-index: 1000000;
          display: grid;
          place-items: center;
          padding: 24px;
        }

        .wp-attachment-modal-content {
          width: 100%;
          max-width: 1200px;
          height: 90vh;
          max-height: 800px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.12);
          box-shadow: 0 10px 40px rgba(0, 0, 0, 0.8);
          display: flex;
          flex-direction: column;
          overflow: hidden;
        }

        /* Header Modal */
        .attachment-modal-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 12px 20px;
          background: #040c14;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .attachment-modal-header h2 {
          font-size: 18px;
          font-weight: 600;
          color: #ffffff;
          margin: 0;
        }

        .header-nav-buttons {
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .nav-arrow-btn,
        .close-modal-btn {
          width: 32px;
          height: 32px;
          background: transparent;
          border: 1px solid transparent;
          border-radius: 4px;
          color: #94a3b8;
          display: grid;
          place-items: center;
          cursor: pointer;
        }

        .nav-arrow-btn:hover,
        .close-modal-btn:hover {
          background: rgba(255, 255, 255, 0.08);
          color: #ffffff;
        }

        .nav-arrow-btn :global(svg),
        .close-modal-btn :global(svg) {
          width: 18px;
          height: 18px;
        }

        /* Cuerpo del Modal */
        .attachment-modal-body {
          display: grid;
          grid-template-columns: 1.5fr 1fr;
          height: calc(100% - 56px);
          overflow: hidden;
        }

        .attachment-preview-col {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 24px;
          background: #02080e;
          border-right: 1px solid rgba(255, 255, 255, 0.08);
          overflow: auto;
        }

        .preview-image-container {
          max-width: 100%;
          max-height: 80%;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .preview-image-container img {
          max-width: 100%;
          max-height: 520px;
          object-fit: contain;
          border-radius: 4px;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
        }

        .preview-action-row {
          margin-top: 16px;
        }

        .wp-btn-edit-image {
          display: inline-block;
          padding: 6px 14px;
          background: rgba(255, 255, 255, 0.06);
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 4px;
          color: #2271b1;
          font-size: 12px;
          font-weight: 600;
          text-decoration: none;
        }

        .wp-btn-edit-image:hover {
          background: rgba(34, 113, 177, 0.15);
        }

        /* Columna Derecha: Detalles */
        .attachment-details-col {
          padding: 20px;
          overflow-y: auto;
          display: flex;
          flex-direction: column;
          gap: 16px;
          background: #040c14;
        }

        .media-meta-info-box {
          font-size: 12px;
          color: #94a3b8;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
          padding-bottom: 14px;
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .media-meta-info-box p {
          margin: 0;
        }

        .media-meta-info-box strong {
          color: #cbd5e1;
        }

        .blue-link {
          color: #2271b1;
        }

        .media-edit-fields-stack {
          display: flex;
          flex-direction: column;
          gap: 14px;
        }

        .attachment-field-row {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .attachment-field-row label {
          font-size: 12px;
          color: #cbd5e1;
          font-weight: 600;
        }

        .field-input-wrap {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .wp-modal-input,
        .wp-modal-textarea {
          width: 100%;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.12);
          border-radius: 4px;
          padding: 6px 10px;
          color: #ffffff;
          font-size: 12px;
          outline: none;
          box-sizing: border-box;
        }

        .wp-modal-input:focus,
        .wp-modal-textarea:focus {
          border-color: #2271b1;
        }

        .wp-modal-input.readonly {
          background: rgba(255, 255, 255, 0.04);
          color: #94a3b8;
          cursor: text;
        }

        .help-text {
          font-size: 11px;
          color: #64748b;
          line-height: 1.4;
        }

        .wp-btn-copy-url {
          align-self: flex-start;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 4px 10px;
          background: transparent;
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 4px;
          color: #cbd5e1;
          font-size: 11px;
          cursor: pointer;
          margin-top: 2px;
        }

        .wp-btn-copy-url:hover {
          background: rgba(255, 255, 255, 0.08);
          color: #ffffff;
        }

        .wp-btn-copy-url :global(svg) {
          width: 12px;
          height: 12px;
        }

        .auto-save-status-msg {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 11px;
          color: #16c96f;
          margin-top: 4px;
        }

        .auto-save-status-msg :global(svg) {
          width: 12px;
          height: 12px;
        }

        /* Enlaces Inferiores */
        .attachment-footer-links-row {
          margin-top: auto;
          padding-top: 14px;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 12px;
          flex-wrap: wrap;
        }

        .modal-action-link {
          color: #2271b1;
          text-decoration: none;
          background: transparent;
          border: none;
          padding: 0;
          cursor: pointer;
        }

        .modal-action-link:hover {
          text-decoration: underline;
        }

        .modal-action-link.delete-red {
          color: #ef4444;
        }

        .action-divider {
          color: #64748b;
        }

        /* =========================================================================
           LIGHT MODE OVERRIDES ESTILO WORDPRESS CLASSIC
           ========================================================================= */
        :global(.theme-light) .wp-media-library-page {
          color: #2c3338;
        }

        :global(.theme-light) .wp-media-title-group h1 {
          color: #1d2327;
        }

        :global(.theme-light) .wp-media-toolbar,
        :global(.theme-light) .wp-dropzone-uploader-card,
        :global(.theme-light) .wp-media-list-card,
        :global(.theme-light) .wp-attachment-modal-content {
          background: #ffffff !important;
          border-color: #c3c4c7 !important;
        }

        :global(.theme-light) .wp-filter-select,
        :global(.theme-light) .wp-search-input,
        :global(.theme-light) .wp-modal-input,
        :global(.theme-light) .wp-modal-textarea {
          background: #ffffff !important;
          border-color: #8c8f94 !important;
          color: #2c3338 !important;
        }

        :global(.theme-light) .wp-grid-thumbnail-card {
          background: #f0f0f1 !important;
          border-color: #dcdcde !important;
        }

        :global(.theme-light) .thumbnail-caption-bar {
          background: #f6f7f7 !important;
          color: #2c3338 !important;
        }

        :global(.theme-light) .attachment-modal-header {
          background: #f6f7f7 !important;
          border-bottom-color: #dcdcde !important;
        }

        :global(.theme-light) .attachment-modal-header h2 {
          color: #1d2327 !important;
        }

        :global(.theme-light) .attachment-preview-col {
          background: #f0f0f1 !important;
          border-right-color: #dcdcde !important;
        }

        :global(.theme-light) .attachment-details-col {
          background: #ffffff !important;
        }

        :global(.theme-light) .media-meta-info-box {
          border-bottom-color: #dcdcde !important;
          color: #646970 !important;
        }

        :global(.theme-light) .media-meta-info-box strong,
        :global(.theme-light) .attachment-field-row label {
          color: #1d2327 !important;
        }

        :global(.theme-light) .wp-btn-copy-url {
          border-color: #8c8f94 !important;
          color: #2c3338 !important;
        }

        :global(.theme-light) .wp-button-select-files {
          background: #f6f7f7 !important;
          border-color: #2271b1 !important;
          color: #2271b1 !important;
        }

        @media (max-width: 900px) {
          .attachment-modal-body {
            grid-template-columns: 1fr;
            overflow-y: auto;
          }
          .attachment-preview-col {
            border-right: none;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
          }
        }
      `}</style>
    </div>
  );
}
