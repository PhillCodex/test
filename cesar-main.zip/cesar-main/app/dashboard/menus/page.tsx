"use client";

import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import {
  Menu as MenuIcon,
  Plus,
  Trash2,
  Save,
  CheckCircle2,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  GripVertical,
  ExternalLink,
  CornerDownRight,
  ArrowUp,
  ArrowDown,
  FileText,
  Link2,
  FolderTree,
  Home,
  Briefcase,
  Layers,
  FolderGit2,
  Cpu,
  User,
  Mail,
  Globe,
  Code,
  Sparkles,
  Shield,
  Zap,
  Terminal,
  Layout,
  BookOpen,
  Phone,
  Compass,
  HelpCircle,
  Award,
  Flame,
  Rocket,
  Star,
  Boxes,
  Wrench,
  Search,
  Check,
  X,
  Loader2,
  RefreshCw,
} from "lucide-react";

// Mapeo de Iconos Disponibles para Selección Visual
const AVAILABLE_ICONS: { [key: string]: any } = {
  Home,
  Briefcase,
  Layers,
  FolderGit2,
  Cpu,
  User,
  Mail,
  Globe,
  Code,
  Sparkles,
  Shield,
  Zap,
  Terminal,
  Layout,
  BookOpen,
  FileText,
  Phone,
  Compass,
  HelpCircle,
  Award,
  Flame,
  Rocket,
  Star,
  Boxes,
  Wrench,
};

interface MenuItemData {
  id?: string;
  tempId: string;
  label: string;
  url: string;
  icon?: string | null;
  target?: string;
  order: number;
  isSubItem: boolean;
  parentTempId?: string | null;
  pageId?: string | null;
  type?: "page" | "custom" | "category";
  isOpen?: boolean;
}

interface MenuData {
  id?: string;
  name: string;
  slug: string;
  location: string;
  isPrimary: boolean;
  items: MenuItemData[];
}

interface PageOption {
  id: string;
  title: string;
  slug: string;
  status: string;
}

interface CategoryOption {
  id: string;
  name: string;
  slug: string;
  color: string;
}

export default function MenusDashboardPage() {
  const [menusList, setMenusList] = useState<any[]>([]);
  const [activeMenuId, setActiveMenuId] = useState<string>("");
  const [menuName, setMenuName] = useState<string>("Menú Principal (Header)");
  const [menuSlug, setMenuSlug] = useState<string>("menu-principal");
  const [menuLocation, setMenuLocation] = useState<string>("HEADER");
  const [isPrimary, setIsPrimary] = useState<boolean>(true);
  const [menuItems, setMenuItems] = useState<MenuItemData[]>([]);

  // Datos disponibles de la Base de Datos
  const [dbPages, setDbPages] = useState<PageOption[]>([]);
  const [dbCategories, setDbCategories] = useState<CategoryOption[]>([]);
  const [selectedPages, setSelectedPages] = useState<string[]>([]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);

  // Enlace personalizado manual
  const [customUrl, setCustomUrl] = useState<string>("");
  const [customText, setCustomText] = useState<string>("");

  // Búsqueda de páginas y categorías
  const [searchPageText, setSearchPageText] = useState<string>("");
  const [searchCatText, setSearchCatText] = useState<string>("");

  // Selector de Iconos Modal/Popover
  const [iconPickerTargetIndex, setIconPickerTargetIndex] = useState<number | null>(null);
  const [iconSearchText, setIconSearchText] = useState<string>("");

  // Estados de UI y AJAX
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<"success" | "error">("success");
  const [showDeleteModal, setShowDeleteModal] = useState<boolean>(false);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // Estados para Drag and Drop (Arrastrar y Soltar)
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);
  const [dragOverPosition, setDragOverPosition] = useState<"above" | "below" | "nested" | null>(null);
  const [dragStartX, setDragStartX] = useState<number>(0);

  // Acordeones de la Columna Izquierda
  const [openAccordion, setOpenAccordion] = useState<"pages" | "custom" | "categories">("pages");

  const showToast = (msg: string, type: "success" | "error" = "success") => {
    setToastMessage(msg);
    setToastType(type);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Cargar Menús y Recursos desde la API de MySQL
  const loadMenusData = useCallback(async (targetId?: string) => {
    setIsLoading(true);
    try {
      const url = targetId ? `/api/menus?id=${targetId}` : `/api/menus`;
      const res = await fetch(url);
      const data = await res.json();

      if (data.success) {
        setMenusList(data.menus || []);
        setDbPages(data.pages || []);
        setDbCategories(data.categories || []);

        if (data.menu) {
          setActiveMenuId(data.menu.id);
          setMenuName(data.menu.name);
          setMenuSlug(data.menu.slug);
          setMenuLocation(data.menu.location || "HEADER");
          setIsPrimary(Boolean(data.menu.isPrimary));

          // Aplanar jerarquía para el constructor interactivo con indicador isSubItem
          const flattened: MenuItemData[] = [];
          if (data.menu.items && Array.isArray(data.menu.items)) {
            data.menu.items.forEach((item: any, idx: number) => {
              const mainTempId = item.id || `item_${Date.now()}_${idx}`;
              flattened.push({
                id: item.id,
                tempId: mainTempId,
                label: item.label,
                url: item.url,
                icon: item.icon,
                target: item.target || "_self",
                order: item.order,
                isSubItem: Boolean(item.parentId),
                parentTempId: item.parentId,
                pageId: item.pageId,
                type: item.pageId ? "page" : "custom",
                isOpen: false,
              });

              // Si tiene hijos en el array anidado de Prisma
              if (item.children && Array.isArray(item.children)) {
                item.children.forEach((child: any, cIdx: number) => {
                  flattened.push({
                    id: child.id,
                    tempId: child.id || `sub_${mainTempId}_${cIdx}`,
                    label: child.label,
                    url: child.url,
                    icon: child.icon,
                    target: child.target || "_self",
                    order: child.order,
                    isSubItem: true,
                    parentTempId: mainTempId,
                    pageId: child.pageId,
                    type: child.pageId ? "page" : "custom",
                    isOpen: false,
                  });
                });
              }
            });
          }
          setMenuItems(flattened);
        }
      } else {
        showToast(data.error || "Error al cargar menús.", "error");
      }
    } catch (e) {
      console.error(e);
      showToast("Error de conexión al cargar menús.", "error");
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadMenusData();
  }, [loadMenusData]);

  // Cambiar Menú Activo
  const handleSelectMenu = (id: string) => {
    loadMenusData(id);
  };

  // Crear un Nuevo Menú en Blanco
  const handleCreateNewMenu = () => {
    setActiveMenuId("");
    setMenuName("Nuevo Menú");
    setMenuSlug("nuevo-menu-" + Math.floor(Math.random() * 1000));
    setMenuLocation("HEADER");
    setIsPrimary(false);
    setMenuItems([]);
    showToast("Completa la estructura y haz clic en Guardar Menú.", "success");
  };

  // 1. Añadir Páginas de la BD al Menú
  const handleAddPagesToMenu = () => {
    if (selectedPages.length === 0) return;

    const newItems: MenuItemData[] = [];
    selectedPages.forEach((pageId) => {
      const p = dbPages.find((item) => item.id === pageId);
      if (p) {
        newItems.push({
          tempId: `page_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
          label: p.title,
          url: `/paginas/${p.slug}`,
          icon: "FileText",
          target: "_self",
          order: menuItems.length + newItems.length,
          isSubItem: false,
          pageId: p.id,
          type: "page",
          isOpen: false,
        });
      }
    });

    setMenuItems([...menuItems, ...newItems]);
    setSelectedPages([]);
    showToast(`Se añadieron ${newItems.length} página(s) al menú.`, "success");
  };

  // 2. Añadir Enlace Personalizado Manual al Menú
  const handleAddCustomLink = () => {
    if (!customText.trim()) {
      showToast("Escribe el texto del enlace.", "error");
      return;
    }
    const url = customUrl.trim() || "#";

    const newItem: MenuItemData = {
      tempId: `custom_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      label: customText.trim(),
      url,
      icon: "Globe",
      target: "_self",
      order: menuItems.length,
      isSubItem: false,
      type: "custom",
      isOpen: false,
    };

    setMenuItems([...menuItems, newItem]);
    setCustomText("");
    setCustomUrl("");
    showToast("Enlace personalizado añadido al menú.", "success");
  };

  // 3. Añadir Categorías al Menú
  const handleAddCategoriesToMenu = () => {
    if (selectedCategories.length === 0) return;

    const newItems: MenuItemData[] = [];
    selectedCategories.forEach((catId) => {
      const c = dbCategories.find((item) => item.id === catId);
      if (c) {
        newItems.push({
          tempId: `cat_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
          label: c.name,
          url: `/categorias/${c.slug}`,
          icon: "Layers",
          target: "_self",
          order: menuItems.length + newItems.length,
          isSubItem: false,
          type: "category",
          isOpen: false,
        });
      }
    });

    setMenuItems([...menuItems, ...newItems]);
    setSelectedCategories([]);
    showToast(`Se añadieron ${newItems.length} categoría(s) al menú.`, "success");
  };

  // Eliminar Elemento del Menú
  const handleRemoveItem = (index: number) => {
    const updated = menuItems.filter((_, i) => i !== index);
    setMenuItems(updated);
    showToast("Elemento eliminado de la lista.", "success");
  };

  // Mover Elemento Arriba / Abajo
  const handleMoveItem = (index: number, direction: "up" | "down") => {
    if (direction === "up" && index === 0) return;
    if (direction === "down" && index === menuItems.length - 1) return;

    const updated = [...menuItems];
    const targetIdx = direction === "up" ? index - 1 : index + 1;
    const temp = updated[index];
    updated[index] = updated[targetIdx];
    updated[targetIdx] = temp;

    // Si el primer elemento quedó como sub-ítem, convertirlo en principal
    if (updated[0].isSubItem) {
      updated[0].isSubItem = false;
      updated[0].parentTempId = null;
    }

    setMenuItems(updated);
  };

  // Alternar Submenú (Sangría / Anidado bajo el elemento anterior)
  const handleToggleSubItem = (index: number) => {
    if (index === 0) return; // El primer elemento nunca puede ser sub-ítem

    const updated = [...menuItems];
    const current = updated[index];
    const newSubState = !current.isSubItem;

    current.isSubItem = newSubState;
    if (newSubState) {
      // Asignar el elemento anterior como padre
      const parent = updated[index - 1];
      current.parentTempId = parent.isSubItem ? parent.parentTempId : parent.tempId;
    } else {
      current.parentTempId = null;
    }

    setMenuItems(updated);
  };

  // --- DRAG AND DROP HANDLERS (Arrastrar y Soltar con Clip / Handle) ---
  const handleDragStart = (e: React.DragEvent, index: number) => {
    setDraggedIndex(index);
    setDragStartX(e.clientX);
    e.dataTransfer.effectAllowed = "move";
    e.dataTransfer.setData("text/plain", index.toString());
  };

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";

    if (draggedIndex === null) return;

    const targetRect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const relativeY = e.clientY - targetRect.top;
    const isBottomHalf = relativeY > targetRect.height / 2;

    // Detectar arrastre horizontal hacia la derecha para anidar como submenú
    const deltaX = e.clientX - dragStartX;
    const isNested = deltaX > 30 && index > 0;

    let position: "above" | "below" | "nested" = isBottomHalf ? "below" : "above";
    if (isNested) {
      position = "nested";
    }

    if (dragOverIndex !== index || dragOverPosition !== position) {
      setDragOverIndex(index);
      setDragOverPosition(position);
    }
  };

  const handleDragLeave = (e: React.DragEvent) => {
    const related = e.relatedTarget as HTMLElement;
    if (!related || !related.closest(".menu-item-card-wrapper")) {
      setDragOverIndex(null);
      setDragOverPosition(null);
    }
  };

  const handleDrop = (e: React.DragEvent, targetIndex: number) => {
    e.preventDefault();
    if (draggedIndex === null) return;

    if (draggedIndex === targetIndex && dragOverPosition !== "nested") {
      setDraggedIndex(null);
      setDragOverIndex(null);
      setDragOverPosition(null);
      return;
    }

    const updated = [...menuItems];
    const itemToMove = { ...updated[draggedIndex] };

    // Eliminar de su posición original
    updated.splice(draggedIndex, 1);

    // Calcular posición destino
    let insertIndex = targetIndex;
    if (draggedIndex < targetIndex) {
      insertIndex = dragOverPosition === "below" ? targetIndex : targetIndex - 1;
    } else {
      insertIndex = dragOverPosition === "below" ? targetIndex + 1 : targetIndex;
    }
    insertIndex = Math.max(0, Math.min(insertIndex, updated.length));

    // Si se soltó con sangría a la derecha (como submenú)
    if (dragOverPosition === "nested" && insertIndex > 0) {
      itemToMove.isSubItem = true;
      itemToMove.parentTempId = updated[insertIndex - 1]?.tempId || null;
    } else if (insertIndex === 0) {
      itemToMove.isSubItem = false;
      itemToMove.parentTempId = null;
    }

    // Insertar en la nueva posición calculada
    updated.splice(insertIndex, 0, itemToMove);

    setMenuItems(updated);
    setDraggedIndex(null);
    setDragOverIndex(null);
    setDragOverPosition(null);
    showToast("Elemento reordenado con éxito.", "success");
  };

  const handleDragEnd = () => {
    setDraggedIndex(null);
    setDragOverIndex(null);
    setDragOverPosition(null);
  };

  // Actualizar Propiedad de un Ítem
  const handleUpdateItemField = (index: number, field: keyof MenuItemData, value: any) => {
    const updated = [...menuItems];
    updated[index] = { ...updated[index], [field]: value };
    setMenuItems(updated);
  };

  // Alternar Acordeón de Edición del Ítem
  const handleToggleItemAccordion = (index: number) => {
    const updated = [...menuItems];
    updated[index].isOpen = !updated[index].isOpen;
    setMenuItems(updated);
  };

  // Seleccionar Icono
  const handleSelectIcon = (iconName: string | null) => {
    if (iconPickerTargetIndex !== null) {
      handleUpdateItemField(iconPickerTargetIndex, "icon", iconName);
      setIconPickerTargetIndex(null);
    }
  };

  // Guardar Todo Directamente en la Base de Datos MySQL
  const handleSaveMenu = async () => {
    if (!menuName.trim()) {
      showToast("El nombre del menú es obligatorio.", "error");
      return;
    }

    setIsSaving(true);
    try {
      const payload = {
        id: activeMenuId || undefined,
        name: menuName.trim(),
        slug: menuSlug || menuName.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
        location: menuLocation,
        isPrimary,
        items: menuItems.map((item, idx) => ({
          id: item.id,
          tempId: item.tempId,
          label: item.label,
          url: item.url,
          icon: item.icon,
          target: item.target || "_self",
          order: idx,
          isSubItem: item.isSubItem,
          parentTempId: item.parentTempId,
          pageId: item.pageId,
        })),
      };

      const res = await fetch("/api/menus", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (data.success) {
        showToast(data.message || "¡Menú guardado exitosamente en MySQL!", "success");
        if (data.menu?.id) {
          setActiveMenuId(data.menu.id);
        }
        loadMenusData(data.menu?.id);
      } else {
        showToast(data.error || "Error al guardar el menú.", "error");
      }
    } catch (e) {
      console.error(e);
      showToast("Error de conexión al servidor.", "error");
    } finally {
      setIsSaving(false);
    }
  };

  // Eliminar Menú
  const handleDeleteMenu = async () => {
    if (!activeMenuId) return;
    setIsDeleting(true);
    try {
      const res = await fetch(`/api/menus?id=${activeMenuId}`, {
        method: "DELETE",
      });
      const data = await res.json();
      if (data.success) {
        showToast("Menú eliminado de la base de datos.", "success");
        setShowDeleteModal(false);
        loadMenusData();
      } else {
        showToast(data.error || "Error al eliminar menú.", "error");
      }
    } catch (e) {
      console.error(e);
      showToast("Error al conectar con la base de datos.", "error");
    } finally {
      setIsDeleting(false);
    }
  };

  // Filtrado de Páginas y Categorías
  const filteredPages = dbPages.filter((p) =>
    p.title.toLowerCase().includes(searchPageText.toLowerCase())
  );
  const filteredCategories = dbCategories.filter((c) =>
    c.name.toLowerCase().includes(searchCatText.toLowerCase())
  );

  // Filtrado de Iconos en el Picker
  const filteredIconKeys = Object.keys(AVAILABLE_ICONS).filter((name) =>
    name.toLowerCase().includes(iconSearchText.toLowerCase())
  );

  return (
    <div className="techlab-menus-dashboard">
      {/* Toast Notification */}
      {toastMessage && (
        <div className={`techlab-toast ${toastType}`}>
          {toastType === "success" ? <CheckCircle2 /> : <AlertTriangle />}
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Superior del Panel */}
      <div className="menus-header-bar">
        <div className="header-title-group">
          <div className="header-icon-box">
            <MenuIcon />
          </div>
          <div>
            <h1>Gestor de Menús de Navegación</h1>
            <p>Crea, edita y estructura la navegación principal y de pie de página de tu sitio web</p>
          </div>
        </div>

        <div className="header-actions-group">
          <button
            type="button"
            className="neon-create-menu-btn"
            onClick={handleCreateNewMenu}
          >
            <Plus />
            <span>Crear un nuevo menú</span>
          </button>
        </div>
      </div>

      {/* Barra de Selección de Menú Activo */}
      <div className="menu-selector-ribbon">
        <label>Elige el menú que deseas editar:</label>
        <div className="selector-control-group">
          <select
            value={activeMenuId}
            onChange={(e) => handleSelectMenu(e.target.value)}
            className="menu-dropdown-select"
          >
            {menusList.map((m) => (
              <option key={m.id} value={m.id}>
                {m.name} {m.isPrimary ? "(Principal)" : ""} ({m._count?.items || 0} enlaces)
              </option>
            ))}
          </select>
          <button
            type="button"
            className="btn-select-menu"
            onClick={() => handleSelectMenu(activeMenuId)}
          >
            Elegir
          </button>
        </div>
        <span className="ribbon-sep">o</span>
        <button
          type="button"
          className="link-create-menu-inline"
          onClick={handleCreateNewMenu}
        >
          crear un nuevo menú
        </button>
      </div>

      {isLoading ? (
        <div className="loading-state-container">
          <Loader2 className="animate-spin" />
          <span>Cargando...</span>
        </div>
      ) : (
        /* Cuadrícula de 2 Columnas: Agregar Elementos (Izq) vs Estructura del Menú (Der) */
        <div className="menus-builder-grid">
          {/* =================================================================
              COLUMNA IZQUIERDA: AGREGAR ELEMENTOS AL MENÚ
              ================================================================= */}
          <aside className="builder-sources-column">
            <span className="column-main-heading">AGREGAR ELEMENTOS AL MENÚ</span>

            {/* Acordeón 1: Páginas de la Base de Datos */}
            <div className={`source-accordion-card ${openAccordion === "pages" ? "open" : ""}`}>
              <button
                type="button"
                className="accordion-toggle-btn"
                onClick={() => setOpenAccordion(openAccordion === "pages" ? (null as any) : "pages")}
              >
                <div className="acc-title-left">
                  <FileText />
                  <span>Páginas</span>
                  <span className="source-count-badge">{dbPages.length}</span>
                </div>
                <ChevronDown className="acc-chevron" />
              </button>

              {openAccordion === "pages" && (
                <div className="accordion-content-panel">
                  <div className="source-search-box">
                    <Search />
                    <input
                      type="text"
                      placeholder="Buscar páginas..."
                      value={searchPageText}
                      onChange={(e) => setSearchPageText(e.target.value)}
                    />
                  </div>

                  <div className="source-items-checkbox-list">
                    {filteredPages.length === 0 ? (
                      <span className="empty-source-hint">No hay páginas creadas aún.</span>
                    ) : (
                      filteredPages.map((p) => (
                        <label key={p.id} className="checkbox-item-row">
                          <input
                            type="checkbox"
                            checked={selectedPages.includes(p.id)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedPages([...selectedPages, p.id]);
                              } else {
                                setSelectedPages(selectedPages.filter((id) => id !== p.id));
                              }
                            }}
                          />
                          <span className="item-label-text">{p.title}</span>
                          <span className="item-url-pill">/paginas/{p.slug}</span>
                        </label>
                      ))
                    )}
                  </div>

                  <div className="accordion-footer-actions">
                    <button
                      type="button"
                      className="btn-select-all"
                      onClick={() => {
                        if (selectedPages.length === dbPages.length) setSelectedPages([]);
                        else setSelectedPages(dbPages.map((p) => p.id));
                      }}
                    >
                      {selectedPages.length === dbPages.length ? "Deseleccionar todo" : "Seleccionar todo"}
                    </button>

                    <button
                      type="button"
                      className="btn-add-to-menu-action"
                      onClick={handleAddPagesToMenu}
                      disabled={selectedPages.length === 0}
                    >
                      <Plus />
                      <span>Añadir al Menú</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Acordeón 2: Enlaces Personalizados */}
            <div className={`source-accordion-card ${openAccordion === "custom" ? "open" : ""}`}>
              <button
                type="button"
                className="accordion-toggle-btn"
                onClick={() => setOpenAccordion(openAccordion === "custom" ? (null as any) : "custom")}
              >
                <div className="acc-title-left">
                  <Link2 />
                  <span>Enlaces personalizados</span>
                </div>
                <ChevronDown className="acc-chevron" />
              </button>

              {openAccordion === "custom" && (
                <div className="accordion-content-panel">
                  <div className="custom-link-form">
                    <div className="form-group-field">
                      <label>URL de destino:</label>
                      <input
                        type="text"
                        placeholder="https:// o /#seccion"
                        value={customUrl}
                        onChange={(e) => setCustomUrl(e.target.value)}
                        className="custom-field-input"
                      />
                    </div>

                    <div className="form-group-field">
                      <label>Texto del enlace:</label>
                      <input
                        type="text"
                        placeholder="ej. Inicio, Portafolio, Contacto"
                        value={customText}
                        onChange={(e) => setCustomText(e.target.value)}
                        className="custom-field-input"
                      />
                    </div>
                  </div>

                  <div className="accordion-footer-actions right-align">
                    <button
                      type="button"
                      className="btn-add-to-menu-action"
                      onClick={handleAddCustomLink}
                      disabled={!customText.trim()}
                    >
                      <Plus />
                      <span>Añadir al Menú</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Acordeón 3: Categorías de la BD */}
            <div className={`source-accordion-card ${openAccordion === "categories" ? "open" : ""}`}>
              <button
                type="button"
                className="accordion-toggle-btn"
                onClick={() => setOpenAccordion(openAccordion === "categories" ? (null as any) : "categories")}
              >
                <div className="acc-title-left">
                  <FolderTree />
                  <span>Categorías de Posts</span>
                  <span className="source-count-badge">{dbCategories.length}</span>
                </div>
                <ChevronDown className="acc-chevron" />
              </button>

              {openAccordion === "categories" && (
                <div className="accordion-content-panel">
                  <div className="source-search-box">
                    <Search />
                    <input
                      type="text"
                      placeholder="Buscar categorías..."
                      value={searchCatText}
                      onChange={(e) => setSearchCatText(e.target.value)}
                    />
                  </div>

                  <div className="source-items-checkbox-list">
                    {filteredCategories.length === 0 ? (
                      <span className="empty-source-hint">No hay categorías creadas aún.</span>
                    ) : (
                      filteredCategories.map((c) => (
                        <label key={c.id} className="checkbox-item-row">
                          <input
                            type="checkbox"
                            checked={selectedCategories.includes(c.id)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedCategories([...selectedCategories, c.id]);
                              } else {
                                setSelectedCategories(selectedCategories.filter((id) => id !== c.id));
                              }
                            }}
                          />
                          <span className="item-label-text">{c.name}</span>
                          <span className="item-url-pill">/categorias/{c.slug}</span>
                        </label>
                      ))
                    )}
                  </div>

                  <div className="accordion-footer-actions">
                    <button
                      type="button"
                      className="btn-select-all"
                      onClick={() => {
                        if (selectedCategories.length === dbCategories.length) setSelectedCategories([]);
                        else setSelectedCategories(dbCategories.map((c) => c.id));
                      }}
                    >
                      {selectedCategories.length === dbCategories.length ? "Deseleccionar todo" : "Seleccionar todo"}
                    </button>

                    <button
                      type="button"
                      className="btn-add-to-menu-action"
                      onClick={handleAddCategoriesToMenu}
                      disabled={selectedCategories.length === 0}
                    >
                      <Plus />
                      <span>Añadir al Menú</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </aside>

          {/* =================================================================
              COLUMNA DERECHA: ESTRUCTURA DEL MENÚ & REORDENAR / SUBMENÚS
              ================================================================= */}
          <main className="builder-structure-column">
            <div className="structure-master-card">
              {/* Cabecera de la Estructura */}
              <div className="structure-card-header">
                <div className="menu-name-edit-group">
                  <label>Nombre del Menú:</label>
                  <input
                    type="text"
                    value={menuName}
                    onChange={(e) => {
                      setMenuName(e.target.value);
                      if (!activeMenuId) {
                        setMenuSlug(e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, "-"));
                      }
                    }}
                    placeholder="ej. Menú Principal"
                    className="menu-name-input"
                  />
                </div>

                <button
                  type="button"
                  className="quick-save-btn"
                  onClick={handleSaveMenu}
                  disabled={isSaving}
                >
                  {isSaving ? <Loader2 className="animate-spin" /> : <Save />}
                  <span>{isSaving ? "Guardando..." : "Guardar Menú"}</span>
                </button>
              </div>

              {/* Guía Explicativa de Jerarquía y Submenús */}
              <div className="structure-guide-banner">
                <p>
                  <strong>Estructura del Menú:</strong> Ordena los enlaces con los botones de mover. Usa{" "}
                  <code>⇥ Submenú</code> para anidar enlaces debajo de un elemento principal y crear menús desplegables.
                </p>
              </div>

              {/* Lista Interactiva de Elementos */}
              <div className="menu-items-tree-list">
                {menuItems.length === 0 ? (
                  <div className="empty-menu-placeholder">
                    <MenuIcon />
                    <h4>El menú está vacío</h4>
                    <p>Agrega páginas, categorías o enlaces personalizados desde la columna izquierda.</p>
                  </div>
                ) : (
                  menuItems.map((item, index) => {
                    const IconComponent = item.icon ? AVAILABLE_ICONS[item.icon] || Globe : null;
                    const isBeingDragged = draggedIndex === index;
                    const isDragOverAbove = dragOverIndex === index && dragOverPosition === "above";
                    const isDragOverBelow = dragOverIndex === index && dragOverPosition === "below";
                    const isDragOverNested = dragOverIndex === index && dragOverPosition === "nested";

                    return (
                      <div
                        key={item.tempId}
                        draggable={true}
                        onDragStart={(e) => handleDragStart(e, index)}
                        onDragOver={(e) => handleDragOver(e, index)}
                        onDragLeave={handleDragLeave}
                        onDrop={(e) => handleDrop(e, index)}
                        onDragEnd={handleDragEnd}
                        className={`menu-item-card-wrapper ${item.isSubItem ? "is-sub-item" : ""} ${
                          isBeingDragged ? "is-being-dragged" : ""
                        } ${isDragOverAbove ? "is-drag-over-above" : ""} ${
                          isDragOverBelow ? "is-drag-over-below" : ""
                        } ${isDragOverNested ? "is-drag-over-nested" : ""}`}
                      >
                        {/* Cabecera del Elemento (Tarjeta) */}
                        <div className="item-card-header-bar">
                          <div className="item-card-left">
                            <span
                              className="drag-handle-grip"
                              title="Arrastra para reordenar o anidar como submenú"
                            >
                              <GripVertical />
                            </span>

                            {item.isSubItem && (
                              <span className="sub-item-arrow-badge">
                                <CornerDownRight />
                                <span>SUB-MENÚ</span>
                              </span>
                            )}

                            {IconComponent && (
                              <span className="item-rendered-icon">
                                <IconComponent />
                              </span>
                            )}

                            <span className="item-card-title">{item.label}</span>

                            <span className="item-type-tag">
                              {item.type === "page"
                                ? "Página"
                                : item.type === "category"
                                ? "Categoría"
                                : "Enlace"}
                            </span>
                          </div>

                          <div className="item-card-controls">
                            {/* Botón Submenú (Sangría) */}
                            {index > 0 && (
                              <button
                                type="button"
                                className={`btn-nest-subitem ${item.isSubItem ? "active" : ""}`}
                                onClick={() => handleToggleSubItem(index)}
                                title={item.isSubItem ? "Convertir en Menú Principal" : "Convertir en Submenú"}
                              >
                                {item.isSubItem ? "⇤ Desanidar" : "⇥ Submenú"}
                              </button>
                            )}

                            {/* Botones Mover Arriba / Abajo */}
                            <button
                              type="button"
                              className="btn-order-move"
                              onClick={() => handleMoveItem(index, "up")}
                              disabled={index === 0}
                              title="Mover arriba"
                            >
                              <ArrowUp />
                            </button>
                            <button
                              type="button"
                              className="btn-order-move"
                              onClick={() => handleMoveItem(index, "down")}
                              disabled={index === menuItems.length - 1}
                              title="Mover abajo"
                            >
                              <ArrowDown />
                            </button>

                            {/* Expandir / Colapsar Panel de Ajustes */}
                            <button
                              type="button"
                              className="btn-expand-item"
                              onClick={() => handleToggleItemAccordion(index)}
                              title="Ajustes del elemento"
                            >
                              {item.isOpen ? <ChevronUp /> : <ChevronDown />}
                            </button>
                          </div>
                        </div>

                        {/* Panel Expandido de Ajustes del Ítem */}
                        {item.isOpen && (
                          <div className="item-card-expanded-body">
                            <div className="expanded-fields-grid">
                              <div className="field-block">
                                <label>Texto visible de navegación:</label>
                                <input
                                  type="text"
                                  value={item.label}
                                  onChange={(e) => handleUpdateItemField(index, "label", e.target.value)}
                                  className="item-edit-input"
                                />
                              </div>

                              <div className="field-block">
                                <label>URL de destino:</label>
                                <input
                                  type="text"
                                  value={item.url}
                                  onChange={(e) => handleUpdateItemField(index, "url", e.target.value)}
                                  className="item-edit-input"
                                />
                              </div>

                              {/* Selector de Icono */}
                              <div className="field-block">
                                <label>Icono decorativo (opcional):</label>
                                <div className="icon-selector-trigger-row">
                                  <button
                                    type="button"
                                    className="btn-open-icon-picker"
                                    onClick={() => setIconPickerTargetIndex(index)}
                                  >
                                    {item.icon && AVAILABLE_ICONS[item.icon] ? (
                                      <>
                                        {(() => {
                                          const Ico = AVAILABLE_ICONS[item.icon];
                                          return <Ico />;
                                        })()}
                                        <span>Icono: {item.icon}</span>
                                      </>
                                    ) : (
                                      <>
                                        <Sparkles />
                                        <span>Seleccionar icono...</span>
                                      </>
                                    )}
                                  </button>

                                  {item.icon && (
                                    <button
                                      type="button"
                                      className="btn-clear-icon"
                                      onClick={() => handleUpdateItemField(index, "icon", null)}
                                      title="Quitar icono"
                                    >
                                      <X />
                                    </button>
                                  )}
                                </div>
                              </div>

                              {/* Abrir en nueva pestaña */}
                              <div className="field-block checkbox-block">
                                <label className="target-checkbox-label">
                                  <input
                                    type="checkbox"
                                    checked={item.target === "_blank"}
                                    onChange={(e) =>
                                      handleUpdateItemField(index, "target", e.target.checked ? "_blank" : "_self")
                                    }
                                  />
                                  <span>Abrir enlace en una pestaña nueva (_blank)</span>
                                </label>
                              </div>
                            </div>

                            <div className="expanded-bottom-actions">
                              <button
                                type="button"
                                className="btn-delete-single-item"
                                onClick={() => handleRemoveItem(index)}
                              >
                                <Trash2 />
                                <span>Eliminar este enlace</span>
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>

              {/* Ajustes de Ubicación del Menú en el Tema */}
              <div className="menu-settings-location-box">
                <span className="location-box-title">Ajustes del Menú</span>
                <div className="location-options-list">
                  <label className="location-checkbox-item">
                    <input
                      type="checkbox"
                      checked={menuLocation === "HEADER" || isPrimary}
                      onChange={(e) => {
                        setIsPrimary(e.target.checked);
                        if (e.target.checked) setMenuLocation("HEADER");
                      }}
                    />
                    <div>
                      <strong>Menú Principal (Header Navbar)</strong>
                      <small>Se muestra en la parte superior de la página de inicio y en todo el sitio web.</small>
                    </div>
                  </label>

                  <label className="location-checkbox-item">
                    <input
                      type="checkbox"
                      checked={menuLocation === "FOOTER"}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setMenuLocation("FOOTER");
                          setIsPrimary(false);
                        } else {
                          setMenuLocation("HEADER");
                        }
                      }}
                    />
                    <div>
                      <strong>Menú de Pie de Página (Footer)</strong>
                      <small>Se muestra en la sección inferior de enlaces del sitio.</small>
                    </div>
                  </label>
                </div>
              </div>

              {/* Barra de Acciones Inferior (Guardar / Eliminar) */}
              <footer className="structure-card-footer">
                {activeMenuId ? (
                  <button
                    type="button"
                    className="btn-delete-menu-danger"
                    onClick={() => setShowDeleteModal(true)}
                  >
                    <Trash2 />
                    <span>Eliminar menú</span>
                  </button>
                ) : (
                  <div />
                )}

                <button
                  type="button"
                  className="btn-save-master-neon"
                  onClick={handleSaveMenu}
                  disabled={isSaving}
                >
                  {isSaving ? <Loader2 className="animate-spin" /> : <Save />}
                  <span>{isSaving ? "Guardando en Base de Datos..." : "Guardar Menú"}</span>
                </button>
              </footer>
            </div>
          </main>
        </div>
      )}

      {/* =================================================================
          MODAL: SELECTOR VISUAL DE ICONOS
          ================================================================= */}
      {iconPickerTargetIndex !== null && (
        <div className="techlab-modal-backdrop" onClick={() => setIconPickerTargetIndex(null)}>
          <div className="icon-picker-modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="modal-top-bar">
              <div className="modal-title-row">
                <Sparkles />
                <h3>Selecciona un Icono para el Menú</h3>
              </div>
              <button type="button" onClick={() => setIconPickerTargetIndex(null)}>
                <X />
              </button>
            </div>

            <div className="icon-picker-search-bar">
              <Search />
              <input
                type="text"
                placeholder="Buscar icono por nombre (ej. Home, Mail, Code, Shield)..."
                value={iconSearchText}
                onChange={(e) => setIconSearchText(e.target.value)}
                autoFocus
              />
            </div>

            <div className="icons-grid-scroll-area">
              {filteredIconKeys.map((name) => {
                const Icon = AVAILABLE_ICONS[name];
                return (
                  <button
                    key={name}
                    type="button"
                    className="icon-choice-btn"
                    onClick={() => handleSelectIcon(name)}
                    title={name}
                  >
                    <Icon />
                    <span>{name}</span>
                  </button>
                );
              })}
            </div>

            <div className="icon-picker-bottom-bar">
              <button
                type="button"
                className="btn-clear-choice"
                onClick={() => handleSelectIcon(null)}
              >
                Sin icono
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =================================================================
          MODAL: CONFIRMACIÓN DE ELIMINACIÓN DE MENÚ
          ================================================================= */}
      {showDeleteModal && (
        <div className="techlab-modal-backdrop" onClick={() => setShowDeleteModal(false)}>
          <div className="delete-modal-card-animated" onClick={(e) => e.stopPropagation()}>
            <div className="delete-icon-animated-badge">
              <Trash2 />
            </div>
            <h3>¿Seguro que quieres eliminar este menú?</h3>
            <p>
              Esta acción es irreversible y eliminará todos los enlaces de <strong>"{menuName}"</strong> de la base de
              datos.
            </p>

            <div className="delete-modal-buttons">
              <button
                type="button"
                className="btn-cancel-delete"
                onClick={() => setShowDeleteModal(false)}
                disabled={isDeleting}
              >
                Cancelar
              </button>
              <button
                type="button"
                className="btn-confirm-delete"
                onClick={handleDeleteMenu}
                disabled={isDeleting}
              >
                {isDeleting ? "Eliminando..." : "Sí, eliminar menú"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ESTILOS TECHLAB CYBER DARK PRO */}
      <style jsx>{`
        .techlab-menus-dashboard {
          padding: 0 0 40px;
          color: inherit;
        }

        /* Toast */
        .techlab-toast {
          position: fixed;
          top: 70px;
          right: 24px;
          z-index: 1000;
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 12px 18px;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 600;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.6);
          animation: slideIn 0.25s ease;
        }

        .techlab-toast.success {
          background: #062316;
          border: 1px solid #16c96f;
          color: #a7f3d0;
        }

        .techlab-toast.error {
          background: #270d0d;
          border: 1px solid #ef4444;
          color: #fca5a5;
        }

        @keyframes slideIn {
          from { opacity: 0; transform: translateY(-16px); }
          to { opacity: 1; transform: translateY(0); }
        }

        /* Header */
        .menus-header-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 20px;
        }

        .header-title-group {
          display: flex;
          align-items: center;
          gap: 14px;
        }

        .header-icon-box {
          width: 46px;
          height: 46px;
          border-radius: 10px;
          background: rgba(56, 189, 248, 0.12);
          border: 1px solid rgba(56, 189, 248, 0.4);
          color: #38bdf8;
          display: grid;
          place-items: center;
          box-shadow: 0 0 18px rgba(56, 189, 248, 0.2);
        }

        .header-icon-box :global(svg) {
          width: 24px;
          height: 24px;
        }

        .header-title-group h1 {
          font-size: 22px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 4px;
          letter-spacing: -0.4px;
        }

        .header-title-group p {
          font-size: 13px;
          color: #94a3b8;
          margin: 0;
        }

        .neon-create-menu-btn {
          height: 40px;
          padding: 0 18px;
          border-radius: 8px;
          background: rgba(56, 189, 248, 0.12);
          border: 1px solid rgba(56, 189, 248, 0.4);
          color: #38bdf8;
          font-size: 13px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          transition: all 0.15s;
        }

        .neon-create-menu-btn:hover {
          background: #38bdf8;
          color: #03080e;
          box-shadow: 0 0 20px rgba(56, 189, 248, 0.4);
        }

        .neon-create-menu-btn :global(svg) {
          width: 16px;
          height: 16px;
        }

        /* Ribbon de Selección */
        .menu-selector-ribbon {
          display: flex;
          align-items: center;
          gap: 12px;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          padding: 12px 18px;
          margin-bottom: 24px;
          font-size: 13px;
        }

        .menu-selector-ribbon label {
          color: #94a3b8;
          font-weight: 600;
        }

        .selector-control-group {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .menu-dropdown-select {
          height: 36px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.12);
          border-radius: 6px;
          padding: 0 12px;
          color: #ffffff;
          font-size: 13px;
          font-weight: 600;
          outline: none;
          min-width: 260px;
        }

        .btn-select-menu {
          height: 36px;
          padding: 0 14px;
          background: #071522;
          border: 1px solid rgba(56, 189, 248, 0.3);
          border-radius: 6px;
          color: #38bdf8;
          font-size: 12px;
          font-weight: 700;
          cursor: pointer;
        }

        .btn-select-menu:hover {
          background: rgba(56, 189, 248, 0.15);
        }

        .ribbon-sep {
          color: #64748b;
        }

        .link-create-menu-inline {
          background: none;
          border: none;
          color: #16c96f;
          font-size: 13px;
          font-weight: 700;
          text-decoration: underline;
          cursor: pointer;
          padding: 0;
        }

        .link-create-menu-inline:hover {
          color: #a7f3d0;
        }

        /* Loading */
        .loading-state-container {
          padding: 80px 0;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 12px;
          color: #38bdf8;
          font-size: 14px;
        }

        /* Cuadrícula Principal */
        .menus-builder-grid {
          display: grid;
          grid-template-columns: 340px 1fr;
          gap: 24px;
          align-items: start;
        }

        /* Columna Izquierda (Fuentes) */
        .builder-sources-column {
          display: flex;
          flex-direction: column;
          gap: 14px;
        }

        .column-main-heading {
          font-size: 11px;
          font-weight: 800;
          color: #64748b;
          letter-spacing: 0.5px;
        }

        .source-accordion-card {
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          overflow: hidden;
          transition: border-color 0.15s;
        }

        .source-accordion-card.open {
          border-color: rgba(56, 189, 248, 0.3);
        }

        .accordion-toggle-btn {
          width: 100%;
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 14px 16px;
          background: #07131e;
          border: none;
          color: #f1f5f9;
          font-size: 13px;
          font-weight: 700;
          cursor: pointer;
        }

        .acc-title-left {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .acc-title-left :global(svg) {
          width: 16px;
          height: 16px;
          color: #38bdf8;
        }

        .source-count-badge {
          font-size: 10px;
          padding: 2px 6px;
          border-radius: 10px;
          background: rgba(255, 255, 255, 0.08);
          color: #94a3b8;
        }

        .acc-chevron {
          width: 16px;
          height: 16px;
          color: #64748b;
          transition: transform 0.2s;
        }

        .source-accordion-card.open .acc-chevron {
          transform: rotate(180deg);
        }

        .accordion-content-panel {
          padding: 16px;
          display: flex;
          flex-direction: column;
          gap: 12px;
          background: #040c14;
          border-top: 1px solid rgba(255, 255, 255, 0.06);
        }

        .source-search-box {
          position: relative;
          display: flex;
          align-items: center;
        }

        .source-search-box :global(svg) {
          position: absolute;
          left: 10px;
          width: 13px;
          height: 13px;
          color: #64748b;
        }

        .source-search-box input {
          width: 100%;
          height: 32px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 5px;
          padding: 0 10px 0 30px;
          color: #ffffff;
          font-size: 12px;
          outline: none;
        }

        .source-items-checkbox-list {
          max-height: 200px;
          overflow-y: auto;
          display: flex;
          flex-direction: column;
          gap: 6px;
          padding-right: 4px;
        }

        .checkbox-item-row {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 6px 8px;
          border-radius: 5px;
          background: rgba(255, 255, 255, 0.02);
          cursor: pointer;
          font-size: 12px;
        }

        .checkbox-item-row:hover {
          background: rgba(56, 189, 248, 0.08);
        }

        .item-label-text {
          flex: 1;
          color: #f1f5f9;
          font-weight: 500;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        .item-url-pill {
          font-size: 10px;
          color: #64748b;
          font-family: monospace;
        }

        .empty-source-hint {
          font-size: 11px;
          color: #64748b;
          padding: 10px 0;
          text-align: center;
        }

        .accordion-footer-actions {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding-top: 10px;
          border-top: 1px solid rgba(255, 255, 255, 0.06);
        }

        .accordion-footer-actions.right-align {
          justify-content: flex-end;
        }

        .btn-select-all {
          background: none;
          border: none;
          color: #94a3b8;
          font-size: 11px;
          cursor: pointer;
          padding: 0;
        }

        .btn-select-all:hover {
          color: #ffffff;
        }

        .btn-add-to-menu-action {
          height: 32px;
          padding: 0 14px;
          background: rgba(56, 189, 248, 0.12);
          border: 1px solid rgba(56, 189, 248, 0.3);
          border-radius: 6px;
          color: #38bdf8;
          font-size: 11px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
          transition: all 0.15s;
        }

        .btn-add-to-menu-action:hover:not(:disabled) {
          background: #38bdf8;
          color: #03080e;
        }

        .btn-add-to-menu-action:disabled {
          opacity: 0.4;
          cursor: not-allowed;
        }

        .custom-link-form {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .form-group-field {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .form-group-field label {
          font-size: 11px;
          color: #94a3b8;
          font-weight: 600;
        }

        .custom-field-input {
          height: 32px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 5px;
          padding: 0 10px;
          color: #ffffff;
          font-size: 12px;
          outline: none;
        }

        /* Columna Derecha (Estructura) */
        .builder-structure-column {
          display: flex;
          flex-direction: column;
        }

        .structure-master-card {
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 12px;
          overflow: hidden;
          display: flex;
          flex-direction: column;
        }

        .structure-card-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 16px 20px;
          background: #07131e;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .menu-name-edit-group {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .menu-name-edit-group label {
          font-size: 12px;
          font-weight: 700;
          color: #cbd5e1;
        }

        .menu-name-input {
          height: 36px;
          background: #03080e;
          border: 1px solid rgba(255, 255, 255, 0.12);
          border-radius: 6px;
          padding: 0 12px;
          color: #ffffff;
          font-size: 13px;
          font-weight: 700;
          outline: none;
          min-width: 240px;
        }

        .quick-save-btn {
          height: 36px;
          padding: 0 16px;
          background: linear-gradient(110deg, #12b85f, #18d878);
          border: 1px solid rgba(67, 255, 147, 0.4);
          border-radius: 6px;
          color: #030b12;
          font-size: 12px;
          font-weight: 800;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
        }

        .structure-guide-banner {
          padding: 12px 20px;
          background: rgba(56, 189, 248, 0.04);
          border-bottom: 1px solid rgba(255, 255, 255, 0.06);
          font-size: 12px;
          color: #94a3b8;
        }

        .structure-guide-banner strong {
          color: #38bdf8;
        }

        .structure-guide-banner code {
          background: rgba(56, 189, 248, 0.15);
          color: #38bdf8;
          padding: 2px 6px;
          border-radius: 4px;
          font-size: 11px;
        }

        /* Lista de Items */
        .menu-items-tree-list {
          padding: 20px;
          display: flex;
          flex-direction: column;
          gap: 10px;
          min-height: 250px;
        }

        .empty-menu-placeholder {
          padding: 60px 20px;
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          gap: 10px;
          color: #64748b;
        }

        .empty-menu-placeholder :global(svg) {
          width: 36px;
          height: 36px;
          color: #38bdf8;
          opacity: 0.5;
        }

        .empty-menu-placeholder h4 {
          font-size: 15px;
          font-weight: 700;
          color: #cbd5e1;
          margin: 0;
        }

        .empty-menu-placeholder p {
          font-size: 12px;
          max-width: 380px;
          margin: 0;
        }

        /* Tarjeta de Elemento */
        .menu-item-card-wrapper {
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          background: #07131e;
          overflow: hidden;
          transition: transform 0.15s ease, box-shadow 0.15s ease, border-color 0.15s ease, opacity 0.15s ease;
          position: relative;
        }

        .menu-item-card-wrapper.is-sub-item {
          margin-left: 36px;
          border-left: 3px solid #38bdf8;
          background: #050e17;
        }

        /* Estados de Arrastre (Drag and Drop) */
        .menu-item-card-wrapper.is-being-dragged {
          opacity: 0.35;
          border: 1px dashed #38bdf8 !important;
          transform: scale(0.98);
        }

        .menu-item-card-wrapper.is-drag-over-above {
          border-top: 3px solid #38bdf8 !important;
          box-shadow: 0 -8px 20px rgba(56, 189, 248, 0.4);
          transform: translateY(2px);
        }

        .menu-item-card-wrapper.is-drag-over-below {
          border-bottom: 3px solid #38bdf8 !important;
          box-shadow: 0 8px 20px rgba(56, 189, 248, 0.4);
          transform: translateY(-2px);
        }

        .menu-item-card-wrapper.is-drag-over-nested {
          margin-left: 48px !important;
          border-left: 4px solid #16c96f !important;
          background: rgba(22, 201, 111, 0.1) !important;
          box-shadow: 0 0 24px rgba(22, 201, 111, 0.35);
        }

        .item-card-header-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 10px 14px;
        }

        .item-card-left {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .drag-handle-grip {
          color: #64748b;
          display: grid;
          place-items: center;
          cursor: grab;
          padding: 4px;
          border-radius: 4px;
          transition: all 0.12s;
        }

        .drag-handle-grip:hover {
          color: #38bdf8;
          background: rgba(56, 189, 248, 0.12);
        }

        .drag-handle-grip:active {
          cursor: grabbing;
        }

        .drag-handle-grip :global(svg) {
          width: 16px;
          height: 16px;
        }

        .sub-item-arrow-badge {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          padding: 2px 6px;
          border-radius: 4px;
          background: rgba(56, 189, 248, 0.12);
          color: #38bdf8;
          font-size: 9px;
          font-weight: 800;
        }

        .sub-item-arrow-badge :global(svg) {
          width: 10px;
          height: 10px;
        }

        .item-rendered-icon {
          color: #38bdf8;
          display: grid;
          place-items: center;
        }

        .item-rendered-icon :global(svg) {
          width: 15px;
          height: 15px;
        }

        .item-card-title {
          font-size: 13px;
          font-weight: 700;
          color: #f1f5f9;
        }

        .item-type-tag {
          font-size: 10px;
          color: #94a3b8;
          background: rgba(255, 255, 255, 0.05);
          padding: 2px 6px;
          border-radius: 4px;
        }

        .item-card-controls {
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .btn-nest-subitem {
          height: 26px;
          padding: 0 8px;
          background: rgba(56, 189, 248, 0.08);
          border: 1px solid rgba(56, 189, 248, 0.25);
          border-radius: 4px;
          color: #38bdf8;
          font-size: 10px;
          font-weight: 700;
          cursor: pointer;
        }

        .btn-nest-subitem.active {
          background: rgba(22, 201, 111, 0.12);
          border-color: rgba(22, 201, 111, 0.3);
          color: #16c96f;
        }

        .btn-order-move {
          width: 26px;
          height: 26px;
          background: transparent;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 4px;
          color: #94a3b8;
          display: grid;
          place-items: center;
          cursor: pointer;
        }

        .btn-order-move:hover:not(:disabled) {
          background: rgba(255, 255, 255, 0.08);
          color: #ffffff;
        }

        .btn-order-move:disabled {
          opacity: 0.3;
          cursor: not-allowed;
        }

        .btn-order-move :global(svg) {
          width: 12px;
          height: 12px;
        }

        .btn-expand-item {
          width: 26px;
          height: 26px;
          background: transparent;
          border: none;
          color: #cbd5e1;
          display: grid;
          place-items: center;
          cursor: pointer;
        }

        .btn-expand-item :global(svg) {
          width: 16px;
          height: 16px;
        }

        /* Cuerpo Expandido del Ítem */
        .item-card-expanded-body {
          padding: 16px;
          background: #03080e;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
          display: flex;
          flex-direction: column;
          gap: 14px;
        }

        .expanded-fields-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 12px;
        }

        .field-block {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .field-block label {
          font-size: 11px;
          color: #94a3b8;
          font-weight: 600;
        }

        .item-edit-input {
          height: 34px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 5px;
          padding: 0 10px;
          color: #ffffff;
          font-size: 12px;
          outline: none;
        }

        .item-edit-input:focus {
          border-color: #38bdf8;
        }

        .icon-selector-trigger-row {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .btn-open-icon-picker {
          flex: 1;
          height: 34px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 5px;
          padding: 0 10px;
          color: #cbd5e1;
          font-size: 12px;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
        }

        .btn-open-icon-picker:hover {
          border-color: #38bdf8;
          color: #38bdf8;
        }

        .btn-open-icon-picker :global(svg) {
          width: 14px;
          height: 14px;
          color: #38bdf8;
        }

        .btn-clear-icon {
          width: 34px;
          height: 34px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 5px;
          color: #ef4444;
          display: grid;
          place-items: center;
          cursor: pointer;
        }

        .btn-clear-icon :global(svg) {
          width: 14px;
          height: 14px;
        }

        .checkbox-block {
          grid-column: span 2;
          justify-content: center;
        }

        .target-checkbox-label {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          font-size: 12px;
          color: #cbd5e1;
          cursor: pointer;
        }

        .expanded-bottom-actions {
          display: flex;
          justify-content: flex-end;
          padding-top: 8px;
          border-top: 1px solid rgba(255, 255, 255, 0.05);
        }

        .btn-delete-single-item {
          background: none;
          border: none;
          color: #ef4444;
          font-size: 11px;
          font-weight: 600;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
          padding: 4px 8px;
        }

        .btn-delete-single-item:hover {
          text-decoration: underline;
        }

        .btn-delete-single-item :global(svg) {
          width: 13px;
          height: 13px;
        }

        /* Ajustes de Ubicación */
        .menu-settings-location-box {
          padding: 16px 20px;
          background: #07131e;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .location-box-title {
          font-size: 12px;
          font-weight: 800;
          color: #f1f5f9;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .location-options-list {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .location-checkbox-item {
          display: flex;
          align-items: flex-start;
          gap: 10px;
          cursor: pointer;
        }

        .location-checkbox-item input {
          margin-top: 3px;
        }

        .location-checkbox-item div {
          display: flex;
          flex-direction: column;
          gap: 2px;
        }

        .location-checkbox-item strong {
          font-size: 13px;
          color: #f1f5f9;
        }

        .location-checkbox-item small {
          font-size: 11px;
          color: #94a3b8;
        }

        /* Footer */
        .structure-card-footer {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 16px 20px;
          background: #040c14;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
        }

        .btn-delete-menu-danger {
          background: transparent;
          border: 1px solid rgba(239, 68, 68, 0.3);
          border-radius: 6px;
          color: #ef4444;
          height: 38px;
          padding: 0 14px;
          font-size: 12px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
        }

        .btn-delete-menu-danger:hover {
          background: rgba(239, 68, 68, 0.12);
        }

        .btn-delete-menu-danger :global(svg) {
          width: 14px;
          height: 14px;
        }

        .btn-save-master-neon {
          height: 40px;
          padding: 0 22px;
          border-radius: 8px;
          background: linear-gradient(110deg, #12b85f, #18d878);
          border: 1px solid rgba(67, 255, 147, 0.4);
          color: #030b12;
          font-size: 13px;
          font-weight: 800;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          box-shadow: 0 0 20px rgba(22, 201, 111, 0.3);
          transition: transform 0.15s;
        }

        .btn-save-master-neon:hover:not(:disabled) {
          transform: translateY(-1px);
          box-shadow: 0 0 26px rgba(22, 201, 111, 0.5);
        }

        .btn-save-master-neon:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }

        .btn-save-master-neon :global(svg) {
          width: 16px;
          height: 16px;
        }

        /* Modal Backdrop */
        .techlab-modal-backdrop {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.8);
          backdrop-filter: blur(4px);
          display: grid;
          place-items: center;
          z-index: 1000;
          animation: fadeIn 0.15s ease;
        }

        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        /* Modal de Iconos */
        .icon-picker-modal-card {
          width: 90%;
          max-width: 520px;
          background: #040c14;
          border: 1px solid rgba(56, 189, 248, 0.3);
          border-radius: 12px;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.8);
          overflow: hidden;
          display: flex;
          flex-direction: column;
        }

        .modal-top-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 16px 20px;
          background: #07131e;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .modal-title-row {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .modal-title-row :global(svg) {
          width: 18px;
          height: 18px;
          color: #38bdf8;
        }

        .modal-title-row h3 {
          font-size: 15px;
          font-weight: 700;
          color: #ffffff;
          margin: 0;
        }

        .modal-top-bar button {
          background: none;
          border: none;
          color: #64748b;
          cursor: pointer;
        }

        .icon-picker-search-bar {
          position: relative;
          padding: 12px 16px;
          background: #03080e;
          border-bottom: 1px solid rgba(255, 255, 255, 0.06);
          display: flex;
          align-items: center;
        }

        .icon-picker-search-bar :global(svg) {
          position: absolute;
          left: 28px;
          width: 14px;
          height: 14px;
          color: #64748b;
        }

        .icon-picker-search-bar input {
          width: 100%;
          height: 36px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 0 12px 0 34px;
          color: #ffffff;
          font-size: 13px;
          outline: none;
        }

        .icons-grid-scroll-area {
          max-height: 300px;
          overflow-y: auto;
          padding: 16px;
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 10px;
        }

        .icon-choice-btn {
          height: 60px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 8px;
          color: #cbd5e1;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          gap: 6px;
          cursor: pointer;
          transition: all 0.15s;
        }

        .icon-choice-btn:hover {
          background: rgba(56, 189, 248, 0.15);
          border-color: #38bdf8;
          color: #38bdf8;
          transform: translateY(-2px);
        }

        .icon-choice-btn :global(svg) {
          width: 20px;
          height: 20px;
        }

        .icon-choice-btn span {
          font-size: 10px;
          font-weight: 600;
        }

        .icon-picker-bottom-bar {
          padding: 12px 16px;
          background: #07131e;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
          display: flex;
          justify-content: flex-end;
        }

        .btn-clear-choice {
          height: 32px;
          padding: 0 14px;
          background: transparent;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          color: #94a3b8;
          font-size: 12px;
          cursor: pointer;
        }

        /* Modal Eliminar */
        .delete-modal-card-animated {
          width: 90%;
          max-width: 440px;
          background: #040c14;
          border: 1px solid rgba(239, 68, 68, 0.4);
          border-radius: 12px;
          padding: 24px;
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.8), 0 0 30px rgba(239, 68, 68, 0.2);
          animation: popIn 0.2s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes popIn {
          from { transform: scale(0.9); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }

        .delete-icon-animated-badge {
          width: 52px;
          height: 52px;
          border-radius: 50%;
          background: rgba(239, 68, 68, 0.15);
          border: 1px solid #ef4444;
          color: #ef4444;
          display: grid;
          place-items: center;
          margin-bottom: 14px;
        }

        .delete-icon-animated-badge :global(svg) {
          width: 24px;
          height: 24px;
        }

        .delete-modal-card-animated h3 {
          font-size: 17px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 8px;
        }

        .delete-modal-card-animated p {
          font-size: 13px;
          color: #94a3b8;
          line-height: 1.5;
          margin: 0 0 20px;
        }

        .delete-modal-card-animated p strong {
          color: #f1f5f9;
        }

        .delete-modal-buttons {
          width: 100%;
          display: flex;
          gap: 10px;
        }

        .btn-cancel-delete {
          flex: 1;
          height: 38px;
          background: transparent;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          color: #cbd5e1;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
        }

        .btn-confirm-delete {
          flex: 1;
          height: 38px;
          background: #ef4444;
          border: none;
          border-radius: 6px;
          color: #ffffff;
          font-size: 13px;
          font-weight: 700;
          cursor: pointer;
        }

        .btn-confirm-delete:hover {
          background: #dc2626;
        }

        @media (max-width: 960px) {
          .techlab-menus-dashboard {
            padding: 16px;
          }
          .menus-builder-grid {
            grid-template-columns: 1fr;
          }
          .menu-selector-ribbon {
            flex-direction: column;
            align-items: flex-start;
          }
          .selector-control-group {
            width: 100%;
          }
          .menu-dropdown-select {
            flex: 1;
          }
        }

        /* LIGHT MODE SCOPED OVERRIDES */
        :global(.theme-light) .techlab-menus-dashboard {
          color: #0f172a !important;
        }

        :global(.theme-light) .menus-header-bar {
          background: transparent !important;
          border: none !important;
        }

        :global(.theme-light) .header-title-group h1 {
          color: #0f172a !important;
        }

        :global(.theme-light) .header-title-group p {
          color: #64748b !important;
        }

        :global(.theme-light) .header-icon-box {
          background: #ffffff !important;
          border-color: #cbd5e1 !important;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05) !important;
        }

        :global(.theme-light) .neon-create-menu-btn {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0284c7 !important;
        }

        :global(.theme-light) .neon-create-menu-btn:hover {
          background: #f0f9ff !important;
          border-color: #0284c7 !important;
          color: #0369a1 !important;
          box-shadow: 0 1px 4px rgba(2, 132, 199, 0.2) !important;
        }

        :global(.theme-light) .menu-selector-ribbon {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .menu-selector-ribbon label {
          color: #1e293b !important;
        }

        :global(.theme-light) .menu-dropdown-select {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .btn-select-menu {
          background: #f1f5f9 !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .column-main-heading {
          color: #475569 !important;
        }

        :global(.theme-light) .source-accordion-card {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .accordion-toggle-btn {
          background: #f8fafc !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .source-count-badge {
          background: #e2e8f0 !important;
          color: #475569 !important;
        }

        :global(.theme-light) .accordion-content-panel {
          background: #ffffff !important;
          border-top-color: #e2e8f0 !important;
        }

        :global(.theme-light) .source-search-box input {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .source-check-item {
          color: #1e293b !important;
        }

        :global(.theme-light) .source-check-item:hover {
          background: #f8fafc !important;
        }

        :global(.theme-light) .btn-add-sources-to-menu {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .custom-links-form input {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .custom-links-form label {
          color: #1e293b !important;
        }

        /* RIGHT COLUMN: STRUCTURE BUILDER CARD */
        :global(.theme-light) .structure-master-card,
        :global(.theme-light) .menu-structure-builder {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .structure-card-header {
          background: #f8fafc !important;
          border-bottom-color: #e2e8f0 !important;
        }

        :global(.theme-light) .menu-name-edit-group label {
          color: #1e293b !important;
        }

        :global(.theme-light) .menu-name-input {
          background: #ffffff !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .structure-guide-banner {
          background: #f0f9ff !important;
          border-bottom-color: #e2e8f0 !important;
          color: #0369a1 !important;
        }

        :global(.theme-light) .menu-item-card-wrapper {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.03) !important;
        }

        :global(.theme-light) .menu-item-card-wrapper.is-sub-item {
          background: #f8fafc !important;
        }

        :global(.theme-light) .item-card-title {
          color: #0f172a !important;
        }

        :global(.theme-light) .item-card-expanded-body {
          background: #f8fafc !important;
          border-top-color: #e2e8f0 !important;
        }

        :global(.theme-light) .item-edit-input {
          background: #ffffff !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .btn-open-icon-picker,
        :global(.theme-light) .btn-clear-icon {
          background: #ffffff !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .menu-settings-location-box {
          background: #f8fafc !important;
          border-top-color: #e2e8f0 !important;
        }

        :global(.theme-light) .menu-settings-location-box h4 {
          color: #0f172a !important;
        }

        :global(.theme-light) .menu-settings-location-box label {
          color: #1e293b !important;
        }

        :global(.theme-light) .structure-card-footer {
          background: #f8fafc !important;
          border-top-color: #e2e8f0 !important;
        }

        :global(.theme-light) .icon-picker-modal-card,
        :global(.theme-light) .delete-modal-card-animated {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15) !important;
        }

        :global(.theme-light) .icon-picker-modal-card h3,
        :global(.theme-light) .delete-modal-card-animated h3 {
          color: #0f172a !important;
        }

        :global(.theme-light) .delete-modal-card-animated p {
          color: #64748b !important;
        }

        :global(.theme-light) .icon-picker-search-bar {
          background: #f8fafc !important;
        }

        :global(.theme-light) .icon-picker-search-bar input {
          background: #ffffff !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .icon-choice-btn {
          background: #f8fafc !important;
          border-color: #e2e8f0 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .icon-choice-btn:hover {
          background: #f1f5f9 !important;
          border-color: #cbd5e1 !important;
        }

        :global(.theme-light) .btn-cancel-delete {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #475569 !important;
        }
      `}</style>
    </div>
  );
}
