"use client";

import { useState, useEffect, useRef } from "react";
import {
  Globe,
  FileText,
  Folder,
  Share2,
  Bot,
  ShieldCheck,
  Map as MapIcon,
  Code2,
  Wand2,
  RotateCcw,
  Save,
  CheckCircle2,
  AlertTriangle,
  Info,
  ExternalLink,
  UploadCloud,
  Eye,
  Sliders,
  Sparkles,
  KeyRound,
  Network,
  Activity,
  Layers,
  Search,
  Check,
  ChevronRight,
  HelpCircle,
  Copy,
  Loader2,
  Twitter,
  Facebook,
  Linkedin,
  FileCode,
  ArrowUpRight,
  FolderTree,
  ListTree,
  Braces,
} from "lucide-react";

type TabId =
  | "general"
  | "publicaciones"
  | "taxonomias"
  | "social"
  | "indexacion"
  | "webmaster"
  | "sitemap"
  | "avanzado";

interface TabItem {
  id: TabId;
  label: string;
  icon: any;
}

const TABS: TabItem[] = [
  { id: "general", label: "General", icon: Globe },
  { id: "publicaciones", label: "Publicaciones", icon: FileText },
  { id: "taxonomias", label: "Taxonomías", icon: Folder },
  { id: "social", label: "Social", icon: Share2 },
  { id: "indexacion", label: "Indexación", icon: Bot },
  { id: "webmaster", label: "Webmaster", icon: ShieldCheck },
  { id: "sitemap", label: "Sitemap", icon: MapIcon },
  { id: "avanzado", label: "Avanzado", icon: Code2 },
];

export default function SeoAnalyticsPage() {
  const [activeTab, setActiveTab] = useState<TabId>("sitemap");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: "success" | "error" } | null>(null);
  const [auditModalOpen, setAuditModalOpen] = useState(false);

  // Estados de Formulario de SEO
  const [siteTitle, setSiteTitle] = useState("TechLab");
  const [siteDescription, setSiteDescription] = useState("");
  const [titleSeparator, setTitleSeparator] = useState("-");
  const [homeTitleTemplate, setHomeTitleTemplate] = useState("%sitename% - Innovación y Desarrollo Web");
  const [homeDescription, setHomeDescription] = useState("");

  // Publicaciones
  const [postTitleTemplate, setPostTitleTemplate] = useState("%title% %sep% %sitename%");
  const [pageTitleTemplate, setPageTitleTemplate] = useState("%title% %sep% %sitename%");
  const [projectTitleTemplate, setProjectTitleTemplate] = useState("%title% - Proyecto %sep% %sitename%");
  const [serviceTitleTemplate, setServiceTitleTemplate] = useState("%title% - Servicio Especializado %sep% %sitename%");
  const [autoSchemaEnabled, setAutoSchemaEnabled] = useState(true);

  // Taxonomías
  const [catTitleTemplate, setCatTitleTemplate] = useState("%category_name% - Archivo %sep% %sitename%");
  const [tagTitleTemplate, setTagTitleTemplate] = useState("%tag_name% - Etiquetas %sep% %sitename%");
  const [noIndexEmptyTaxonomies, setNoIndexEmptyTaxonomies] = useState(true);

  // Social
  const [ogTitle, setOgTitle] = useState("");
  const [ogDescription, setOgDescription] = useState("");
  const [ogDefaultImage, setOgDefaultImage] = useState("");
  const [twitterCard, setTwitterCard] = useState("summary_large_image");
  const [twitterHandle, setTwitterHandle] = useState("@cesar");
  const [facebookAppId, setFacebookAppId] = useState("");
  const [socialPlatformPreview, setSocialPlatformPreview] = useState<"facebook" | "twitter" | "linkedin">("facebook");

  // Indexación
  const [robotsTxt, setRobotsTxt] = useState("User-agent: *\nAllow: /\nDisallow: /dashboard/\nDisallow: /api/\n\nSitemap: http://localhost:3000/sitemap.xml");
  const [noIndexAdmin, setNoIndexAdmin] = useState(true);

  // Webmaster
  const [googleVerify, setGoogleVerify] = useState("");
  const [bingVerify, setBingVerify] = useState("");

  // Sitemap
  const [sitemapEnabled, setSitemapEnabled] = useState(true);
  const [sitemapChangeFreq, setSitemapChangeFreq] = useState("daily");
  const [sitemapsData, setSitemapsData] = useState<any[]>([]);
  const [selectedSitemapId, setSelectedSitemapId] = useState<string>("post");
  const [sitemapSearch, setSitemapSearch] = useState("");
  const [showRawXml, setShowRawXml] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);

  // Avanzado
  const [analyticsId, setAnalyticsId] = useState("");
  const [gtmId, setGtmId] = useState("");
  const [customHead, setCustomHead] = useState("");
  const [customBody, setCustomBody] = useState("");

  const ogImageInputRef = useRef<HTMLInputElement>(null);

  // Cargar datos reales desde MySQL
  const fetchSeoSettings = async () => {
    try {
      setLoading(true);
      const [settingsRes, sitemapSummaryRes] = await Promise.all([
        fetch("/api/settings"),
        fetch("/api/sitemap/summary"),
      ]);

      const data = await settingsRes.json();
      if (data.success && data.settings) {
        const s = data.settings;
        if (s.siteTitle) setSiteTitle(s.siteTitle);
        if (s.siteDescription) setSiteDescription(s.siteDescription);
        if (s.seoTitleSeparator) setTitleSeparator(s.seoTitleSeparator);
        if (s.seoHomeTitle) setHomeTitleTemplate(s.seoHomeTitle);
        if (s.seoHomeDescription) setHomeDescription(s.seoHomeDescription);

        if (s.seoOgTitle) setOgTitle(s.seoOgTitle);
        if (s.seoOgDescription) setOgDescription(s.seoOgDescription);
        if (s.seoOgDefaultImage) setOgDefaultImage(s.seoOgDefaultImage);
        if (s.seoTwitterCard) setTwitterCard(s.seoTwitterCard);
        if (s.seoTwitterHandle) setTwitterHandle(s.seoTwitterHandle);
        if (s.seoFacebookAppId) setFacebookAppId(s.seoFacebookAppId);

        if (s.seoRobotsTxt) setRobotsTxt(s.seoRobotsTxt);
        if (s.seoGoogleVerify) setGoogleVerify(s.seoGoogleVerify);
        if (s.seoBingVerify) setBingVerify(s.seoBingVerify);
        if (s.seoSitemapEnabled !== undefined) setSitemapEnabled(s.seoSitemapEnabled);

        if (s.seoAnalyticsId) setAnalyticsId(s.seoAnalyticsId);
        if (s.seoGtmId) setGtmId(s.seoGtmId);
        if (s.seoCustomHead) setCustomHead(s.seoCustomHead);
        if (s.seoCustomBody) setCustomBody(s.seoCustomBody);
      }

      const sitemapJson = await sitemapSummaryRes.json();
      if (sitemapJson.success && sitemapJson.sitemaps) {
        setSitemapsData(sitemapJson.sitemaps);
      }
    } catch (err) {
      console.error("Error al cargar SEO:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSeoSettings();
  }, []);

  const showToast = (message: string, type: "success" | "error") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  // Guardar en MySQL
  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          seoTitleSeparator: titleSeparator,
          seoHomeTitle: homeTitleTemplate,
          seoHomeDescription: homeDescription,
          seoOgDefaultImage: ogDefaultImage,
          seoOgTitle: ogTitle,
          seoOgDescription: ogDescription,
          seoTwitterCard: twitterCard,
          seoTwitterHandle: twitterHandle,
          seoFacebookAppId: facebookAppId,
          seoGoogleVerify: googleVerify,
          seoBingVerify: bingVerify,
          seoRobotsTxt: robotsTxt,
          seoSitemapEnabled: sitemapEnabled,
          seoAnalyticsId: analyticsId,
          seoGtmId: gtmId,
          seoCustomHead: customHead,
          seoCustomBody: customBody,
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast("¡Configuración SEO y Metadatos guardados en la base de datos!", "success");
      } else {
        showToast(data.error || "Error al guardar configuración.", "error");
      }
    } catch {
      showToast("Error de conexión al servidor.", "error");
    } finally {
      setSaving(false);
    }
  };

  // Restaurar sección actual
  const handleResetSection = () => {
    if (activeTab === "social") {
      setOgTitle("");
      setOgDescription("");
      setTwitterCard("summary_large_image");
      setTwitterHandle("@techlab");
      showToast("Pestaña Social restaurada a los valores predeterminados.", "success");
    } else if (activeTab === "general") {
      setTitleSeparator("-");
      setHomeTitleTemplate("%sitename% - Soluciones Tecnológicas de Alto Impacto");
      showToast("Pestaña General restaurada.", "success");
    } else if (activeTab === "sitemap") {
      setSitemapEnabled(true);
      setSitemapChangeFreq("daily");
      showToast("Pestaña Sitemap restaurada a parámetros recomendados.", "success");
    } else if (activeTab === "indexacion") {
      setRobotsTxt("User-agent: *\nAllow: /\nDisallow: /dashboard/\nDisallow: /api/\n\nSitemap: http://localhost:3000/sitemap.xml");
      showToast("Directivas de indexación y Robots.txt restaurados.", "success");
    } else {
      showToast("Sección restaurada a parámetros recomendados.", "success");
    }
  };

  // Copiar URL al portapapeles
  const handleCopyUrl = (url: string) => {
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      navigator.clipboard.writeText(url);
      setCopiedUrl(url);
      showToast(`Enlace copiado: ${url}`, "success");
      setTimeout(() => setCopiedUrl(null), 2500);
    }
  };

  // Subir imagen OG
  const handleUploadOgImage = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);

    try {
      showToast("Subiendo banner social...", "success");
      const res = await fetch("/api/upload", { method: "POST", body: formData });
      const data = await res.json();
      if (data.url) {
        setOgDefaultImage(data.url);
        showToast("Banner OpenGraph actualizado.", "success");
      } else {
        showToast(data.error || "Error al subir archivo.", "error");
      }
    } catch {
      showToast("Error de conexión al subir imagen.", "error");
    }
  };

  const previewTitle = ogTitle || homeTitleTemplate.replace("%sitename%", siteTitle).replace("%sep%", titleSeparator) || siteTitle;
  const previewDesc = ogDescription || homeDescription || siteDescription || "Tecnología, desarrollo web e infraestructura cloud de alto impacto.";
  const previewImg = ogDefaultImage || "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=1200&auto=format&fit=crop&q=80";

  const currentSelectedSitemap = sitemapsData.find((s) => s.id === selectedSitemapId) || sitemapsData[1] || sitemapsData[0];
  const filteredItems = (currentSelectedSitemap?.items || []).filter((item: any) =>
    (item.title || "").toLowerCase().includes(sitemapSearch.toLowerCase()) ||
    (item.loc || "").toLowerCase().includes(sitemapSearch.toLowerCase())
  );

  return (
    <div className="seo-module-root">
      {/* Toast Notification */}
      {toast && (
        <div className={`seo-toast-pill ${toast.type}`}>
          {toast.type === "success" ? <CheckCircle2 /> : <AlertTriangle />}
          <span>{toast.message}</span>
        </div>
      )}

      {/* ===================================================================
          1. HEADER SECTION (Figma Clean Specs)
          =================================================================== */}
      <div className="seo-header-section">
        <div className="header-left-meta">
          <h1 className="header-title">SEO y Meta</h1>
          <p className="header-subtitle">
            Configura los metadatos, la indexación, las plantillas SEO y la apariencia del sitio en buscadores y redes sociales.
          </p>
        </div>

        <div className="header-right-actions">
          {/* Botón 1: Verificar configuración */}
          <button
            type="button"
            className="action-btn-outline"
            onClick={() => setAuditModalOpen(true)}
            title="Auditoría y verificación técnica"
          >
            <Wand2 className="action-icon" />
            <span>Verificar configuración</span>
          </button>

          {/* Botón 2: Restaurar sección */}
          <button
            type="button"
            className="action-btn-outline"
            onClick={handleResetSection}
            title="Restaurar pestaña actual a valores por defecto"
          >
            <RotateCcw className="action-icon" />
            <span>Restaurar sección</span>
          </button>

          {/* Botón 3: Guardar cambios (Solid bright neon green) */}
          <button
            type="button"
            className="action-btn-neon-save"
            onClick={handleSave}
            disabled={saving}
          >
            {saving ? <Loader2 className="animate-spin" /> : <Save className="action-icon-save" />}
            <span>{saving ? "Guardando..." : "Guardar cambios"}</span>
          </button>
        </div>
      </div>

      {/* ===================================================================
          2. NAVIGATION BAR SECTION (Tabs container with subtle dark border)
          =================================================================== */}
      <nav className="seo-tabs-navbar">
        <div className="tabs-horizontal-track">
          {TABS.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                className={`tab-nav-btn ${isActive ? "is-active" : ""}`}
                onClick={() => setActiveTab(tab.id)}
              >
                <Icon className="tab-icon" />
                <span className="tab-label">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* ===================================================================
          3. TAB CONTENT VIEWS (Data-heavy, High-Fidelity & Clean)
          =================================================================== */}
      <main className="seo-tab-body">
        {loading ? (
          <div className="seo-loading-skeleton">
            <Loader2 className="animate-spin spinner" />
            <span>Cargando configuración SEO desde MySQL...</span>
          </div>
        ) : (
          <>
            {/* ---------------- PESTAÑA 1: GENERAL ---------------- */}
            {activeTab === "general" && (
              <div className="tab-content-pane">
                <div className="pane-header-box">
                  <div className="pane-header-info">
                    <h3>Configuración General del Título y Separadores</h3>
                    <p>Define cómo se construirán los títulos de tu web en los navegadores y resultados de búsqueda.</p>
                  </div>
                  <div className="tag-pill-badge">Global</div>
                </div>

                <div className="fields-grid-card">
                  {/* Separador */}
                  <div className="form-row-duo">
                    <div className="field-info-col">
                      <label>Separador de Títulos</label>
                      <p>Símbolo visual que separa el título del artículo y el nombre del sitio web.</p>
                    </div>
                    <div className="field-control-col">
                      <div className="separator-options-group">
                        {["-", "|", "•", "—", "/", "»"].map((sep) => (
                          <button
                            key={sep}
                            type="button"
                            className={`sep-choice-btn ${titleSeparator === sep ? "active" : ""}`}
                            onClick={() => setTitleSeparator(sep)}
                          >
                            {sep}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Título de Portada */}
                  <div className="form-row-duo">
                    <div className="field-info-col">
                      <label>Estructura del Título de Portada (Home)</label>
                      <p>Usa <code>%sitename%</code> y <code>%sep%</code> como variables dinámicas.</p>
                    </div>
                    <div className="field-control-col">
                      <input
                        type="text"
                        className="cyber-input"
                        value={homeTitleTemplate}
                        onChange={(e) => setHomeTitleTemplate(e.target.value)}
                        placeholder="%sitename% %sep% Soluciones Web"
                      />
                      <small className="field-hint">
                        Vista previa: <b>{homeTitleTemplate.replace("%sitename%", siteTitle).replace("%sep%", titleSeparator)}</b>
                      </small>
                    </div>
                  </div>

                  {/* Meta Descripción Home */}
                  <div className="form-row-duo">
                    <div className="field-info-col">
                      <label>Meta Descripción de Portada</label>
                      <p>Resumen persuasivo de 140 a 160 caracteres que aparecerá en los resultados de Google.</p>
                    </div>
                    <div className="field-control-col">
                      <textarea
                        rows={3}
                        className="cyber-textarea"
                        value={homeDescription}
                        onChange={(e) => setHomeDescription(e.target.value)}
                        placeholder="Escribe la descripción estratégica para el home..."
                      />
                      <div className="char-count-meta">
                        <span>Longitud recomendada: 140-160 caracteres</span>
                        <span className={homeDescription.length > 160 ? "warn" : "ok"}>
                          {homeDescription.length} / 160
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ---------------- PESTAÑA 2: PUBLICACIONES ---------------- */}
            {activeTab === "publicaciones" && (
              <div className="tab-content-pane">
                <div className="pane-header-box">
                  <div className="pane-header-info">
                    <h3>Plantillas SEO de Tipos de Contenido</h3>
                    <p>Automatiza los metadatos para Entradas de Blog, Páginas Estáticas, Proyectos y Servicios.</p>
                  </div>
                </div>

                <div className="fields-grid-card">
                  <div className="form-row-duo">
                    <div className="field-info-col">
                      <label>Plantilla de Título para Posts</label>
                      <p>Formato automático cuando el autor no especifique un meta título personalizado.</p>
                    </div>
                    <div className="field-control-col">
                      <input
                        type="text"
                        className="cyber-input"
                        value={postTitleTemplate}
                        onChange={(e) => setPostTitleTemplate(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="form-row-duo">
                    <div className="field-info-col">
                      <label>Plantilla de Título para Páginas</label>
                      <p>Formato para páginas internas (Acerca de, Políticas, Servicios).</p>
                    </div>
                    <div className="field-control-col">
                      <input
                        type="text"
                        className="cyber-input"
                        value={pageTitleTemplate}
                        onChange={(e) => setPageTitleTemplate(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="form-row-duo">
                    <div className="field-info-col">
                      <label>Plantilla para Proyectos (Portafolio)</label>
                      <p>Metadatos indexables para cada caso de estudio y proyecto publicado.</p>
                    </div>
                    <div className="field-control-col">
                      <input
                        type="text"
                        className="cyber-input"
                        value={projectTitleTemplate}
                        onChange={(e) => setProjectTitleTemplate(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="form-row-duo">
                    <div className="field-info-col">
                      <label>Generación Automática de Datos Estructurados (Schema.org)</label>
                      <p>Inyecta JSON-LD compatible con Google Rich Snippets (Article, Service, Organization).</p>
                    </div>
                    <div className="field-control-col">
                      <label className="toggle-switch-wrap">
                        <input
                          type="checkbox"
                          checked={autoSchemaEnabled}
                          onChange={(e) => setAutoSchemaEnabled(e.target.checked)}
                        />
                        <span className="slider" />
                        <span className="toggle-label">{autoSchemaEnabled ? "Activado (Recomendado)" : "Desactivado"}</span>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ---------------- PESTAÑA 3: TAXONOMÍAS ---------------- */}
            {activeTab === "taxonomias" && (
              <div className="tab-content-pane">
                <div className="pane-header-box">
                  <div className="pane-header-info">
                    <h3>Categorías y Etiquetas</h3>
                    <p>Controla cómo los motores de búsqueda rastrean e indexan los archivos de taxonomías.</p>
                  </div>
                </div>

                <div className="fields-grid-card">
                  <div className="form-row-duo">
                    <div className="field-info-col">
                      <label>Plantilla de Título para Categorías</label>
                      <p>Variables: <code>%category_name%</code>, <code>%sep%</code>, <code>%sitename%</code></p>
                    </div>
                    <div className="field-control-col">
                      <input
                        type="text"
                        className="cyber-input"
                        value={catTitleTemplate}
                        onChange={(e) => setCatTitleTemplate(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="form-row-duo">
                    <div className="field-info-col">
                      <label>NoIndex para Categorías Vacías</label>
                      <p>Evita penalizaciones por contenido delgado (Thin Content) impidiendo indexar categorías sin posts.</p>
                    </div>
                    <div className="field-control-col">
                      <label className="toggle-switch-wrap">
                        <input
                          type="checkbox"
                          checked={noIndexEmptyTaxonomies}
                          onChange={(e) => setNoIndexEmptyTaxonomies(e.target.checked)}
                        />
                        <span className="slider" />
                        <span className="toggle-label">{noIndexEmptyTaxonomies ? "Protección Activa" : "Desactivado"}</span>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ---------------- PESTAÑA 4: SOCIAL ---------------- */}
            {activeTab === "social" && (
              <div className="tab-content-pane">
                <div className="pane-header-box">
                  <div className="pane-header-info">
                    <h3>Metadatos OpenGraph y Redes Sociales</h3>
                    <p>Personaliza las tarjetas y previsualizaciones al compartir enlaces en Facebook, Twitter, WhatsApp y LinkedIn.</p>
                  </div>
                  <div className="tag-pill-badge active-neon">OpenGraph 4.0</div>
                </div>

                <div className="social-workspace-layout">
                  {/* Left Column: Form Fields */}
                  <div className="social-fields-column">
                    <div className="fields-grid-card">
                      {/* Título Social */}
                      <div className="form-field-unit">
                        <label>Título OpenGraph por Defecto</label>
                        <input
                          type="text"
                          className="cyber-input"
                          value={ogTitle}
                          onChange={(e) => setOgTitle(e.target.value)}
                          placeholder={siteTitle}
                        />
                        <span className="field-hint">Si se deja vacío, usará el título de la página compartida.</span>
                      </div>

                      {/* Descripción Social */}
                      <div className="form-field-unit">
                        <label>Descripción OpenGraph por Defecto</label>
                        <textarea
                          rows={3}
                          className="cyber-textarea"
                          value={ogDescription}
                          onChange={(e) => setOgDescription(e.target.value)}
                          placeholder={siteDescription || "Descripción del sitio..."}
                        />
                      </div>

                      {/* Imagen Social Banner */}
                      <div className="form-field-unit">
                        <label>Banner Social por Defecto (1200x630 px)</label>
                        <div
                          className="og-image-dropzone"
                          onClick={() => ogImageInputRef.current?.click()}
                        >
                          {ogDefaultImage ? (
                            <div className="og-image-preview-wrap">
                              <img src={ogDefaultImage} alt="OG Banner" />
                              <button
                                type="button"
                                className="remove-og-btn"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setOgDefaultImage("");
                                }}
                              >
                                Cambiar imagen
                              </button>
                            </div>
                          ) : (
                            <div className="dropzone-empty-state">
                              <UploadCloud className="upload-ico" />
                              <span>Haz clic o arrastra una imagen de alta resolución (PNG o JPG)</span>
                              <small>Tamaño óptimo recomendado: 1200 x 630 píxeles</small>
                            </div>
                          )}
                          <input
                            ref={ogImageInputRef}
                            type="file"
                            accept="image/*"
                            onChange={handleUploadOgImage}
                            style={{ display: "none" }}
                          />
                        </div>
                      </div>

                      {/* Twitter Card Type */}
                      <div className="form-row-duo inline-duo">
                        <div className="field-info-col">
                          <label>Tipo de Tarjeta Twitter (X)</label>
                        </div>
                        <div className="field-control-col">
                          <select
                            className="cyber-select"
                            value={twitterCard}
                            onChange={(e) => setTwitterCard(e.target.value)}
                          >
                            <option value="summary_large_image">Imagen Grande (summary_large_image)</option>
                            <option value="summary">Resumen Compacto (summary)</option>
                          </select>
                        </div>
                      </div>

                      {/* Twitter Username */}
                      <div className="form-row-duo inline-duo">
                        <div className="field-info-col">
                          <label>Usuario de Twitter / Creador</label>
                        </div>
                        <div className="field-control-col">
                          <input
                            type="text"
                            className="cyber-input"
                            value={twitterHandle}
                            onChange={(e) => setTwitterHandle(e.target.value)}
                            placeholder="@tuusuario"
                          />
                        </div>
                      </div>

                      {/* Facebook App ID */}
                      <div className="form-row-duo inline-duo">
                        <div className="field-info-col">
                          <label>Facebook App ID (Opcional)</label>
                        </div>
                        <div className="field-control-col">
                          <input
                            type="text"
                            className="cyber-input"
                            value={facebookAppId}
                            onChange={(e) => setFacebookAppId(e.target.value)}
                            placeholder="ej. 1029384756102"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Right Column: Live Mockup Preview */}
                  <div className="social-preview-column">
                    <div className="mockup-preview-card">
                      <div className="mockup-header-bar">
                        <span>VISTA PREVIA EN TIEMPO REAL</span>
                        <div className="platform-switch-pills">
                          <button
                            type="button"
                            className={socialPlatformPreview === "facebook" ? "active" : ""}
                            onClick={() => setSocialPlatformPreview("facebook")}
                          >
                            <Facebook /> Facebook
                          </button>
                          <button
                            type="button"
                            className={socialPlatformPreview === "twitter" ? "active" : ""}
                            onClick={() => setSocialPlatformPreview("twitter")}
                          >
                            <Twitter /> Twitter
                          </button>
                          <button
                            type="button"
                            className={socialPlatformPreview === "linkedin" ? "active" : ""}
                            onClick={() => setSocialPlatformPreview("linkedin")}
                          >
                            <Linkedin /> LinkedIn
                          </button>
                        </div>
                      </div>

                      {/* Card Rendering Simulation */}
                      <div className={`social-card-render ${socialPlatformPreview}`}>
                        <div className="render-image-container">
                          <img src={previewImg} alt="Preview" />
                        </div>
                        <div className="render-text-container">
                          <span className="render-domain">cesar.com</span>
                          <h4 className="render-title">{previewTitle}</h4>
                          <p className="render-snippet">{previewDesc}</p>
                        </div>
                      </div>

                      <div className="mockup-footer-note">
                        <Info />
                        <span>Esta es la apariencia exacta con la que tus publicaciones se visualizarán en los feeds de redes sociales.</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ---------------- PESTAÑA 5: INDEXACIÓN ---------------- */}
            {activeTab === "indexacion" && (
              <div className="tab-content-pane">
                <div className="pane-header-box">
                  <div className="pane-header-info">
                    <h3>Control de Rastreo y Archivo Robots.txt</h3>
                    <p>Instrucciones de rastreo para Googlebot, Bingbot y otros motores de búsqueda.</p>
                  </div>
                </div>

                <div className="fields-grid-card">
                  <div className="form-field-unit">
                    <div className="editor-label-row">
                      <label>Contenido del archivo Robots.txt</label>
                      <span className="badge-live">http://localhost:3000/robots.txt</span>
                    </div>
                    <textarea
                      rows={7}
                      className="cyber-textarea code-font"
                      value={robotsTxt}
                      onChange={(e) => setRobotsTxt(e.target.value)}
                    />
                    <small className="field-hint">
                      Asegúrate de permitir el rastreo de recursos CSS y JS para evitar penalizaciones de renderizado móvil.
                    </small>
                  </div>

                  <div className="form-row-duo">
                    <div className="field-info-col">
                      <label>Bloqueo de Indexación para Panel de Administración</label>
                      <p>Añade etiqueta <code>noindex, nofollow</code> en todas las rutas <code>/dashboard/*</code>.</p>
                    </div>
                    <div className="field-control-col">
                      <label className="toggle-switch-wrap">
                        <input
                          type="checkbox"
                          checked={noIndexAdmin}
                          onChange={(e) => setNoIndexAdmin(e.target.checked)}
                        />
                        <span className="slider" />
                        <span className="toggle-label">{noIndexAdmin ? "Protegido (NoIndex activo)" : "Desactivado"}</span>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ---------------- PESTAÑA 6: WEBMASTER ---------------- */}
            {activeTab === "webmaster" && (
              <div className="tab-content-pane">
                <div className="pane-header-box">
                  <div className="pane-header-info">
                    <h3>Códigos de Verificación de Motores de Búsqueda</h3>
                    <p>Verifica la propiedad de tu sitio en Google Search Console y Bing Webmaster Tools sin editar archivos HTML.</p>
                  </div>
                </div>

                <div className="fields-grid-card">
                  <div className="form-row-duo">
                    <div className="field-info-col">
                      <label>Google Search Console</label>
                      <p>Pega el código de verificación de la etiqueta HTML (ej. <code>google-site-verification</code>).</p>
                    </div>
                    <div className="field-control-col">
                      <input
                        type="text"
                        className="cyber-input"
                        value={googleVerify}
                        onChange={(e) => setGoogleVerify(e.target.value)}
                        placeholder="ej. dK93jslK29sl_k29dLsk2019slks"
                      />
                    </div>
                  </div>

                  <div className="form-row-duo">
                    <div className="field-info-col">
                      <label>Bing Webmaster Tools</label>
                      <p>Código de autenticación para Bing e IndexNow.</p>
                    </div>
                    <div className="field-control-col">
                      <input
                        type="text"
                        className="cyber-input"
                        value={bingVerify}
                        onChange={(e) => setBingVerify(e.target.value)}
                        placeholder="ej. 8B9C8928490B28929A8"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ---------------- PESTAÑA 7: SITEMAP & VISUALIZADOR MULTI-XML ---------------- */}
            {activeTab === "sitemap" && (
              <div className="tab-content-pane">
                <div className="pane-header-box">
                  <div className="pane-header-info">
                    <h3>Estructura y Visualizador de XML Sitemaps</h3>
                    <p>
                      Arquitectura de mapas del sitio indexados automáticamente: el índice principal <code>sitemap.xml</code> distribuye los sub-sitemaps de posts, páginas, categorías, proyectos y servicios.
                    </p>
                  </div>
                  <div className="tag-pill-badge active-neon">XML 2.0 Dinámico</div>
                </div>

                {/* Sitemaps Grid Cards */}
                <div className="sitemaps-catalog-grid">
                  {sitemapsData.map((sitemap) => {
                    const isSelected = selectedSitemapId === sitemap.id;
                    const isIndex = sitemap.type === "sitemapindex";

                    return (
                      <div
                        key={sitemap.id}
                        className={`sitemap-unit-card ${isSelected ? "selected-sitemap" : ""} ${isIndex ? "is-main-index" : ""}`}
                        onClick={() => setSelectedSitemapId(sitemap.id)}
                      >
                        <div className="sitemap-card-top">
                          <div className="sitemap-icon-badge">
                            {isIndex ? <FolderTree /> : sitemap.id === "post" ? <FileText /> : sitemap.id === "page" ? <Layers /> : sitemap.id === "categoria" ? <Folder /> : <MapIcon />}
                          </div>
                          <div className="sitemap-status-dot">
                            <span className="live-dot" />
                            <small>200 OK</small>
                          </div>
                        </div>

                        <div className="sitemap-card-body">
                          <h4 className="sitemap-file-name">{sitemap.file}</h4>
                          <span className="sitemap-display-name">{sitemap.name}</span>
                        </div>

                        <div className="sitemap-card-meta">
                          <span className="count-pill">
                            <b>{sitemap.count}</b> {isIndex ? "Sub-sitemaps" : "URLs"}
                          </span>

                          <div className="sitemap-card-buttons" onClick={(e) => e.stopPropagation()}>
                            <button
                              type="button"
                              className="sitemap-btn-icon"
                              onClick={() => handleCopyUrl(sitemap.url)}
                              title="Copiar URL del Sitemap"
                            >
                              {copiedUrl === sitemap.url ? <Check /> : <Copy />}
                            </button>

                            <a
                              href={sitemap.url}
                              target="_blank"
                              rel="noreferrer"
                              className="sitemap-btn-view"
                              title="Abrir archivo XML en nueva pestaña"
                            >
                              <span>Ver XML</span>
                              <ArrowUpRight />
                            </a>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Interactive Visual Explorer / Inspector Table */}
                <div className="sitemap-explorer-wrapper">
                  <div className="explorer-header-bar">
                    <div className="explorer-title-area">
                      <ListTree className="explorer-icon" />
                      <div>
                        <h4>
                          Explorador de Contenido: <code>/{currentSelectedSitemap?.file || "post.xml"}</code>
                        </h4>
                        <p>Visualiza en tiempo real los enlaces, fecha de modificación y prioridad que Googlebot leerá.</p>
                      </div>
                    </div>

                    <div className="explorer-tools-area">
                      {/* Search */}
                      <div className="explorer-search-box">
                        <Search />
                        <input
                          type="text"
                          placeholder="Filtrar URLs..."
                          value={sitemapSearch}
                          onChange={(e) => setSitemapSearch(e.target.value)}
                        />
                      </div>

                      {/* Raw XML Toggle */}
                      <button
                        type="button"
                        className={`btn-toggle-raw ${showRawXml ? "active" : ""}`}
                        onClick={() => setShowRawXml(!showRawXml)}
                      >
                        <Braces />
                        <span>{showRawXml ? "Ver Tabla" : "Ver Código XML"}</span>
                      </button>

                      {/* Direct External Link */}
                      <a
                        href={currentSelectedSitemap?.url || "/sitemap.xml"}
                        target="_blank"
                        rel="noreferrer"
                        className="btn-open-direct"
                      >
                        <ExternalLink />
                        <span>Abrir {currentSelectedSitemap?.file}</span>
                      </a>
                    </div>
                  </div>

                  {/* Raw XML Mode */}
                  {showRawXml ? (
                    <div className="raw-xml-viewer-box">
                      <pre className="raw-xml-code">
                        {`<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${(currentSelectedSitemap?.items || [])
  .map(
    (item: any) => `  <url>
    <loc>${item.loc}</loc>
    <lastmod>${item.lastmod ? new Date(item.lastmod).toISOString() : new Date().toISOString()}</lastmod>
    <changefreq>${item.changefreq || "weekly"}</changefreq>
    <priority>${item.priority || "0.8"}</priority>
  </url>`
  )
  .join("\n")}
</urlset>`}
                      </pre>
                    </div>
                  ) : (
                    /* Interactive Formatted Table */
                    <div className="explorer-table-container">
                      <table className="explorer-table">
                        <thead>
                          <tr>
                            <th>ESTADO</th>
                            <th>UBICACIÓN DE LA URL (LOC)</th>
                            <th>TÍTULO / DESCRIPCIÓN</th>
                            <th>ÚLTIMA MODIFICACIÓN</th>
                            <th>FRECUENCIA</th>
                            <th>PRIORIDAD</th>
                            <th>ACCIÓN</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filteredItems.length === 0 ? (
                            <tr>
                              <td colSpan={7} className="empty-table-cell">
                                No se encontraron URLs registradas en este sub-sitemap.
                              </td>
                            </tr>
                          ) : (
                            filteredItems.map((item: any, idx: number) => (
                              <tr key={idx}>
                                <td>
                                  <span className="live-status-badge">Indexable</span>
                                </td>
                                <td>
                                  <div className="loc-url-cell">
                                    <Globe className="loc-icon" />
                                    <span className="loc-text">{item.loc}</span>
                                  </div>
                                </td>
                                <td>
                                  <span className="item-title-text">{item.title || "Sin título"}</span>
                                </td>
                                <td>
                                  <span className="date-text">
                                    {item.lastmod
                                      ? new Date(item.lastmod).toLocaleDateString("es-ES", {
                                          day: "2-digit",
                                          month: "short",
                                          year: "numeric",
                                          hour: "2-digit",
                                          minute: "2-digit",
                                        })
                                      : "Reciente"}
                                  </span>
                                </td>
                                <td>
                                  <span className="freq-pill">{item.changefreq || "weekly"}</span>
                                </td>
                                <td>
                                  <span className="priority-pill">{item.priority || "0.8"}</span>
                                </td>
                                <td>
                                  <a
                                    href={item.loc}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="btn-table-visit"
                                    title="Visitar URL pública"
                                  >
                                    <ArrowUpRight />
                                  </a>
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ---------------- PESTAÑA 8: AVANZADO ---------------- */}
            {activeTab === "avanzado" && (
              <div className="tab-content-pane">
                <div className="pane-header-box">
                  <div className="pane-header-info">
                    <h3>Analytics e Inyección de Código</h3>
                    <p>Integra Google Analytics 4, Google Tag Manager y scripts personalizados en el encabezado o pie de página.</p>
                  </div>
                </div>

                <div className="fields-grid-card">
                  <div className="form-row-duo">
                    <div className="field-info-col">
                      <label>Google Analytics 4 (Measurement ID)</label>
                      <p>ID de seguimiento de flujo web (formato <code>G-XXXXXXXXXX</code>).</p>
                    </div>
                    <div className="field-control-col">
                      <input
                        type="text"
                        className="cyber-input"
                        value={analyticsId}
                        onChange={(e) => setAnalyticsId(e.target.value)}
                        placeholder="G-1A2B3C4D5E"
                      />
                    </div>
                  </div>

                  <div className="form-row-duo">
                    <div className="field-info-col">
                      <label>Google Tag Manager (Container ID)</label>
                      <p>Contenedor de etiquetas (formato <code>GTM-XXXXXXX</code>).</p>
                    </div>
                    <div className="field-control-col">
                      <input
                        type="text"
                        className="cyber-input"
                        value={gtmId}
                        onChange={(e) => setGtmId(e.target.value)}
                        placeholder="GTM-N1A2B3C"
                      />
                    </div>
                  </div>

                  <div className="form-field-unit">
                    <label>Scripts Adicionales en &lt;head&gt;</label>
                    <textarea
                      rows={3}
                      className="cyber-textarea code-font"
                      value={customHead}
                      onChange={(e) => setCustomHead(e.target.value)}
                      placeholder="<script>/* Código de píxeles o métricas */</script>"
                    />
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </main>

      {/* ===================================================================
          MODAL DE AUDITORÍA Y VERIFICACIÓN TÉCNICA
          =================================================================== */}
      {auditModalOpen && (
        <div className="audit-modal-backdrop" onClick={() => setAuditModalOpen(false)}>
          <div className="audit-modal-box" onClick={(e) => e.stopPropagation()}>
            <div className="audit-modal-head">
              <div className="audit-title-wrap">
                <Wand2 className="magic-icon" />
                <h3>Verificación y Diagnóstico SEO del Sitio</h3>
              </div>
              <button
                type="button"
                className="btn-close-modal"
                onClick={() => setAuditModalOpen(false)}
              >
                ✕
              </button>
            </div>

            <div className="audit-modal-content">
              <div className="audit-score-summary-bar">
                <div className="score-ring">
                  <span>94%</span>
                </div>
                <div className="score-desc">
                  <b>Salud Técnica de SEO: Excelente</b>
                  <p>Tu sitio cumple con los estándares clave de indexación y visibilidad en Google.</p>
                </div>
              </div>

              <div className="audit-checklist-list">
                <div className="audit-check-item pass">
                  <CheckCircle2 />
                  <div>
                    <b>Índice Sitemap.xml y Sub-sitemaps Activos</b>
                    <small>Distribución separada en post.xml, page.xml, categoria.xml, proyecto.xml y servicio.xml.</small>
                  </div>
                </div>

                <div className="audit-check-item pass">
                  <CheckCircle2 />
                  <div>
                    <b>Separador y títulos dinámicos configurados</b>
                    <small>Estructura %sitename% %sep% activa en todas las publicaciones.</small>
                  </div>
                </div>

                <div className="audit-check-item pass">
                  <CheckCircle2 />
                  <div>
                    <b>Etiquetas OpenGraph y Twitter Cards</b>
                    <small>Banners sociales y metadatos listos para compartir.</small>
                  </div>
                </div>

                <div className="audit-check-item pass">
                  <CheckCircle2 />
                  <div>
                    <b>Archivo Robots.txt habilitado</b>
                    <small>Rutas privadas (/dashboard) bloqueadas contra rastreo indeseado.</small>
                  </div>
                </div>

                <div className="audit-check-item warn">
                  <AlertTriangle />
                  <div>
                    <b>Google Search Console</b>
                    <small>{googleVerify ? "Código de verificación vinculado." : "Pendiente de ingresar código de verificación en la pestaña Webmaster."}</small>
                  </div>
                </div>
              </div>
            </div>

            <div className="audit-modal-foot">
              <button
                type="button"
                className="action-btn-neon-save"
                onClick={() => setAuditModalOpen(false)}
              >
                Cerrar diagnóstico
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================
          ESTILOS CSS FIGMA PRO (CHARCOAL NAVY + NEON GREEN)
          =================================================================== */}
      <style jsx>{`
        .seo-module-root {
          display: flex;
          flex-direction: column;
          gap: 20px;
          color: inherit;
        }

        /* 1. Header Section */
        .seo-header-section {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 20px;
          padding-bottom: 8px;
        }

        .header-left-meta {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .header-title {
          font-size: 28px;
          font-weight: 800;
          color: #ffffff;
          margin: 0;
          letter-spacing: -0.5px;
          line-height: 1.1;
        }

        .header-subtitle {
          font-size: 13px;
          color: #94a3b8;
          margin: 0;
          max-width: 620px;
          line-height: 1.45;
        }

        .header-right-actions {
          display: flex;
          align-items: center;
          gap: 10px;
          flex-shrink: 0;
        }

        /* Botones Outline oscuros */
        .action-btn-outline {
          height: 38px;
          padding: 0 14px;
          border-radius: 8px;
          background: #081420;
          border: 1px solid rgba(255, 255, 255, 0.12);
          color: #cbd5e1;
          font-size: 12px;
          font-weight: 600;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          transition: all 0.15s ease;
          white-space: nowrap;
        }

        .action-btn-outline:hover {
          background: #0d2235;
          border-color: rgba(56, 189, 248, 0.35);
          color: #ffffff;
        }

        .action-btn-outline :global(.action-icon) {
          width: 15px;
          height: 15px;
          color: #94a3b8;
        }

        /* Botón Guardar Verde Neón Primario */
        .action-btn-neon-save {
          height: 38px;
          padding: 0 18px;
          border-radius: 8px;
          background: linear-gradient(110deg, #12b85f, #18d878);
          border: 1px solid rgba(67, 255, 147, 0.4);
          color: #030b12;
          font-size: 13px;
          font-weight: 800;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          box-shadow: 0 0 16px rgba(22, 201, 111, 0.35);
          transition: all 0.2s ease;
          white-space: nowrap;
        }

        .action-btn-neon-save:hover:not(:disabled) {
          background: #20df7b;
          transform: translateY(-1px);
          box-shadow: 0 0 22px rgba(22, 201, 111, 0.5);
        }

        .action-btn-neon-save:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }

        .action-btn-neon-save :global(.action-icon-save) {
          width: 16px;
          height: 16px;
          color: #030b12;
        }

        /* 2. Navigation Bar Section */
        .seo-tabs-navbar {
          width: 100%;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          padding: 4px;
          overflow-x: auto;
        }

        .tabs-horizontal-track {
          display: flex;
          align-items: center;
          gap: 4px;
          min-width: max-content;
        }

        .tab-nav-btn {
          height: 38px;
          padding: 0 14px;
          border-radius: 7px;
          border: 1px solid transparent;
          background: transparent;
          color: #94a3b8;
          font-size: 12px;
          font-weight: 600;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          transition: all 0.15s ease;
          white-space: nowrap;
        }

        .tab-nav-btn:hover:not(.is-active) {
          color: #f1f5f9;
          background: rgba(255, 255, 255, 0.03);
        }

        .tab-nav-btn :global(.tab-icon) {
          width: 16px;
          height: 16px;
          color: #94a3b8;
          transition: color 0.15s ease;
        }

        /* Active Tab State: subtle neon green rounded rectangle with neon green text & icon */
        .tab-nav-btn.is-active {
          background: rgba(22, 201, 111, 0.1);
          border-color: rgba(22, 201, 111, 0.35);
          color: #16c96f;
        }

        .tab-nav-btn.is-active :global(.tab-icon) {
          color: #16c96f;
        }

        /* 3. Main Content Panes */
        .seo-tab-body {
          flex: 1;
        }

        .tab-content-pane {
          display: flex;
          flex-direction: column;
          gap: 16px;
          animation: paneFadeIn 0.2s ease;
        }

        @keyframes paneFadeIn {
          from { opacity: 0; transform: translateY(6px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .pane-header-box {
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: #040e17;
          border: 1px solid rgba(255, 255, 255, 0.06);
          border-radius: 10px;
          padding: 16px 20px;
        }

        .pane-header-info h3 {
          font-size: 15px;
          font-weight: 700;
          color: #ffffff;
          margin: 0 0 3px;
        }

        .pane-header-info p {
          font-size: 12px;
          color: #94a3b8;
          margin: 0;
        }

        .tag-pill-badge {
          font-size: 11px;
          font-weight: 700;
          padding: 4px 10px;
          border-radius: 20px;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.08);
          color: #94a3b8;
        }

        .tag-pill-badge.active-neon {
          background: rgba(22, 201, 111, 0.12);
          border-color: rgba(22, 201, 111, 0.3);
          color: #16c96f;
        }

        /* Form Cards */
        .fields-grid-card {
          background: #040e17;
          border: 1px solid rgba(255, 255, 255, 0.06);
          border-radius: 12px;
          padding: 22px;
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        .form-row-duo {
          display: grid;
          grid-template-columns: 280px 1fr;
          gap: 24px;
          align-items: flex-start;
          padding-bottom: 18px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.04);
        }

        .form-row-duo:last-child {
          border-bottom: none;
          padding-bottom: 0;
        }

        .form-row-duo.inline-duo {
          align-items: center;
        }

        .field-info-col label,
        .form-field-unit label {
          font-size: 13px;
          font-weight: 700;
          color: #ffffff;
          display: block;
          margin-bottom: 4px;
        }

        .field-info-col p {
          font-size: 11px;
          color: #64748b;
          margin: 0;
          line-height: 1.45;
        }

        .field-control-col {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .form-field-unit {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        /* Inputs & Controls */
        .cyber-input,
        .cyber-select {
          width: 100%;
          height: 38px;
          background: #03080e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 0 12px;
          color: #ffffff;
          font-size: 13px;
          outline: none;
          transition: border-color 0.15s;
        }

        .cyber-textarea {
          width: 100%;
          background: #03080e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 10px 12px;
          color: #ffffff;
          font-size: 13px;
          line-height: 1.5;
          outline: none;
          transition: border-color 0.15s;
          resize: vertical;
        }

        .cyber-input:focus,
        .cyber-select:focus,
        .cyber-textarea:focus {
          border-color: #16c96f;
        }

        .code-font {
          font-family: monospace;
          font-size: 12px;
          color: #38bdf8;
        }

        .field-hint {
          font-size: 11px;
          color: #64748b;
        }

        .field-hint b {
          color: #38bdf8;
        }

        .char-count-meta {
          display: flex;
          justify-content: space-between;
          font-size: 11px;
          color: #64748b;
        }

        .char-count-meta span.ok { color: #16c96f; }
        .char-count-meta span.warn { color: #ef4444; }

        /* Separator Buttons */
        .separator-options-group {
          display: flex;
          gap: 6px;
        }

        .sep-choice-btn {
          width: 38px;
          height: 38px;
          border-radius: 6px;
          background: #03080e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: #cbd5e1;
          font-size: 16px;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.15s;
        }

        .sep-choice-btn:hover {
          border-color: rgba(56, 189, 248, 0.4);
          color: #ffffff;
        }

        .sep-choice-btn.active {
          background: rgba(22, 201, 111, 0.12);
          border-color: #16c96f;
          color: #16c96f;
        }

        /* Toggle Switches */
        .toggle-switch-wrap {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          cursor: pointer;
        }

        .toggle-switch-wrap input {
          display: none;
        }

        .slider {
          width: 42px;
          height: 22px;
          background: #0a1926;
          border: 1px solid rgba(255, 255, 255, 0.15);
          border-radius: 20px;
          position: relative;
          transition: 0.2s;
        }

        .slider:before {
          content: "";
          position: absolute;
          width: 16px;
          height: 16px;
          left: 2px;
          bottom: 2px;
          background: #94a3b8;
          border-radius: 50%;
          transition: 0.2s;
        }

        .toggle-switch-wrap input:checked + .slider {
          background: #16c96f;
          border-color: #16c96f;
        }

        .toggle-switch-wrap input:checked + .slider:before {
          transform: translateX(20px);
          background: #030b12;
        }

        .toggle-label {
          font-size: 12px;
          font-weight: 600;
          color: #cbd5e1;
        }

        /* Sitemaps Cards Grid */
        .sitemaps-catalog-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 14px;
        }

        .sitemap-unit-card {
          background: #040e17;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 12px;
          padding: 16px;
          display: flex;
          flex-direction: column;
          gap: 12px;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .sitemap-unit-card:hover {
          border-color: rgba(56, 189, 248, 0.4);
          transform: translateY(-2px);
          box-shadow: 0 10px 25px rgba(0, 0, 0, 0.5);
        }

        .sitemap-unit-card.selected-sitemap {
          border-color: #16c96f;
          background: rgba(22, 201, 111, 0.04);
          box-shadow: 0 0 20px rgba(22, 201, 111, 0.15);
        }

        .sitemap-unit-card.is-main-index {
          border-color: rgba(56, 189, 248, 0.35);
          background: linear-gradient(145deg, #051422, #040e17);
        }

        .sitemap-card-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .sitemap-icon-badge {
          width: 36px;
          height: 36px;
          border-radius: 8px;
          background: rgba(255, 255, 255, 0.04);
          border: 1px solid rgba(255, 255, 255, 0.08);
          display: grid;
          place-items: center;
          color: #38bdf8;
        }

        .sitemap-unit-card.selected-sitemap .sitemap-icon-badge {
          background: rgba(22, 201, 111, 0.15);
          border-color: #16c96f;
          color: #16c96f;
        }

        .sitemap-icon-badge :global(svg) {
          width: 18px;
          height: 18px;
        }

        .sitemap-status-dot {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 11px;
          font-weight: 700;
          color: #16c96f;
        }

        .live-dot {
          width: 7px;
          height: 7px;
          background: #16c96f;
          border-radius: 50%;
          box-shadow: 0 0 8px #16c96f;
        }

        .sitemap-card-body h4 {
          font-size: 15px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 2px;
          letter-spacing: -0.2px;
        }

        .sitemap-display-name {
          font-size: 11px;
          color: #94a3b8;
        }

        .sitemap-card-meta {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding-top: 10px;
          border-top: 1px solid rgba(255, 255, 255, 0.05);
        }

        .count-pill {
          font-size: 11px;
          color: #cbd5e1;
        }

        .count-pill b {
          color: #16c96f;
          font-size: 12px;
        }

        .sitemap-card-buttons {
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .sitemap-btn-icon {
          width: 28px;
          height: 28px;
          border-radius: 6px;
          background: #03080e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: #94a3b8;
          display: grid;
          place-items: center;
          cursor: pointer;
          transition: all 0.15s;
        }

        .sitemap-btn-icon:hover {
          color: #ffffff;
          border-color: #38bdf8;
        }

        .sitemap-btn-icon :global(svg) {
          width: 13px;
          height: 13px;
        }

        .sitemap-btn-view {
          height: 28px;
          padding: 0 10px;
          border-radius: 6px;
          background: rgba(56, 189, 248, 0.12);
          border: 1px solid rgba(56, 189, 248, 0.3);
          color: #38bdf8;
          font-size: 11px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          gap: 4px;
          text-decoration: none;
          transition: all 0.15s;
        }

        .sitemap-btn-view:hover {
          background: #38bdf8;
          color: #030b12;
        }

        .sitemap-btn-view :global(svg) {
          width: 12px;
          height: 12px;
        }

        /* Interactive Explorer Table */
        .sitemap-explorer-wrapper {
          background: #040e17;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 12px;
          overflow: hidden;
          display: flex;
          flex-direction: column;
        }

        .explorer-header-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 16px 20px;
          background: #03080e;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
          gap: 16px;
        }

        .explorer-title-area {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .explorer-title-area :global(.explorer-icon) {
          width: 22px;
          height: 22px;
          color: #16c96f;
        }

        .explorer-title-area h4 {
          font-size: 14px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 2px;
        }

        .explorer-title-area h4 code {
          color: #16c96f;
        }

        .explorer-title-area p {
          font-size: 11px;
          color: #94a3b8;
          margin: 0;
        }

        .explorer-tools-area {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .explorer-search-box {
          position: relative;
          display: flex;
          align-items: center;
        }

        .explorer-search-box :global(svg) {
          position: absolute;
          left: 10px;
          width: 13px;
          height: 13px;
          color: #64748b;
        }

        .explorer-search-box input {
          width: 200px;
          height: 32px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 0 10px 0 30px;
          color: #ffffff;
          font-size: 12px;
          outline: none;
        }

        .explorer-search-box input:focus {
          border-color: #16c96f;
        }

        .btn-toggle-raw,
        .btn-open-direct {
          height: 32px;
          padding: 0 12px;
          border-radius: 6px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: #cbd5e1;
          font-size: 11px;
          font-weight: 600;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
          text-decoration: none;
          transition: all 0.15s;
        }

        .btn-toggle-raw:hover,
        .btn-open-direct:hover {
          border-color: #38bdf8;
          color: #ffffff;
        }

        .btn-toggle-raw.active {
          background: rgba(56, 189, 248, 0.15);
          border-color: #38bdf8;
          color: #38bdf8;
        }

        .btn-toggle-raw :global(svg),
        .btn-open-direct :global(svg) {
          width: 13px;
          height: 13px;
        }

        .explorer-table-container {
          overflow-x: auto;
        }

        .explorer-table {
          width: 100%;
          border-collapse: collapse;
          text-align: left;
          font-size: 12px;
        }

        .explorer-table th {
          padding: 10px 16px;
          background: rgba(255, 255, 255, 0.02);
          border-bottom: 1px solid rgba(255, 255, 255, 0.06);
          font-size: 10px;
          font-weight: 800;
          color: #64748b;
          letter-spacing: 0.5px;
        }

        .explorer-table td {
          padding: 12px 16px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.04);
          vertical-align: middle;
        }

        .explorer-table tr:hover td {
          background: rgba(255, 255, 255, 0.02);
        }

        .live-status-badge {
          font-size: 10px;
          font-weight: 700;
          padding: 3px 8px;
          border-radius: 20px;
          background: rgba(22, 201, 111, 0.12);
          border: 1px solid rgba(22, 201, 111, 0.3);
          color: #16c96f;
        }

        .loc-url-cell {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .loc-url-cell :global(.loc-icon) {
          width: 14px;
          height: 14px;
          color: #38bdf8;
          flex-shrink: 0;
        }

        .loc-text {
          font-family: monospace;
          color: #38bdf8;
          font-size: 11px;
          word-break: break-all;
        }

        .item-title-text {
          font-weight: 600;
          color: #ffffff;
        }

        .date-text {
          color: #94a3b8;
          font-size: 11px;
        }

        .freq-pill {
          font-size: 10px;
          background: rgba(255, 255, 255, 0.05);
          padding: 2px 6px;
          border-radius: 4px;
          color: #cbd5e1;
        }

        .priority-pill {
          font-size: 10px;
          font-weight: 700;
          background: rgba(56, 189, 248, 0.12);
          color: #38bdf8;
          padding: 2px 6px;
          border-radius: 4px;
        }

        .btn-table-visit {
          width: 28px;
          height: 28px;
          border-radius: 6px;
          background: rgba(255, 255, 255, 0.04);
          border: 1px solid rgba(255, 255, 255, 0.08);
          color: #cbd5e1;
          display: grid;
          place-items: center;
          text-decoration: none;
          transition: all 0.15s;
        }

        .btn-table-visit:hover {
          background: #16c96f;
          color: #030b12;
        }

        .btn-table-visit :global(svg) {
          width: 14px;
          height: 14px;
        }

        .empty-table-cell {
          text-align: center;
          padding: 30px;
          color: #64748b;
        }

        /* Raw XML Code Box */
        .raw-xml-viewer-box {
          background: #02070c;
          padding: 16px 20px;
          max-height: 400px;
          overflow: auto;
        }

        .raw-xml-code {
          margin: 0;
          font-family: monospace;
          font-size: 12px;
          color: #a7f3d0;
          line-height: 1.5;
        }

        /* Social Layout */
        .social-workspace-layout {
          display: grid;
          grid-template-columns: 1fr 420px;
          gap: 20px;
        }

        .social-fields-column {
          display: flex;
          flex-direction: column;
        }

        .og-image-dropzone {
          border: 1px dashed rgba(56, 189, 248, 0.3);
          border-radius: 8px;
          background: #03080e;
          padding: 16px;
          cursor: pointer;
          transition: border-color 0.15s;
        }

        .og-image-dropzone:hover {
          border-color: #16c96f;
        }

        .dropzone-empty-state {
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          gap: 4px;
          padding: 14px 0;
        }

        .dropzone-empty-state :global(.upload-ico) {
          width: 28px;
          height: 28px;
          color: #38bdf8;
          margin-bottom: 4px;
        }

        .dropzone-empty-state span {
          font-size: 12px;
          font-weight: 600;
          color: #f1f5f9;
        }

        .dropzone-empty-state small {
          font-size: 10px;
          color: #64748b;
        }

        .og-image-preview-wrap {
          position: relative;
          border-radius: 6px;
          overflow: hidden;
        }

        .og-image-preview-wrap img {
          width: 100%;
          max-height: 180px;
          object-fit: cover;
          display: block;
        }

        .remove-og-btn {
          position: absolute;
          bottom: 8px;
          right: 8px;
          background: rgba(3, 11, 18, 0.85);
          border: 1px solid rgba(255, 255, 255, 0.2);
          color: #ffffff;
          font-size: 11px;
          font-weight: 600;
          padding: 4px 10px;
          border-radius: 4px;
          cursor: pointer;
        }

        /* Mockup Right Column */
        .mockup-preview-card {
          background: #040e17;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 12px;
          padding: 18px;
          display: flex;
          flex-direction: column;
          gap: 14px;
          position: sticky;
          top: 80px;
        }

        .mockup-header-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          font-size: 10px;
          font-weight: 800;
          letter-spacing: 0.6px;
          color: #64748b;
        }

        .platform-switch-pills {
          display: flex;
          gap: 4px;
        }

        .platform-switch-pills button {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          background: #03080e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 4px;
          padding: 3px 8px;
          color: #94a3b8;
          font-size: 10px;
          font-weight: 600;
          cursor: pointer;
        }

        .platform-switch-pills button.active {
          background: rgba(56, 189, 248, 0.15);
          border-color: #38bdf8;
          color: #38bdf8;
        }

        .platform-switch-pills button :global(svg) {
          width: 11px;
          height: 11px;
        }

        /* Render Card */
        .social-card-render {
          background: #07131f;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 10px;
          overflow: hidden;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        }

        .render-image-container img {
          width: 100%;
          height: 180px;
          object-fit: cover;
          display: block;
        }

        .render-text-container {
          padding: 14px;
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .render-domain {
          font-size: 10px;
          text-transform: uppercase;
          letter-spacing: 0.4px;
          color: #64748b;
        }

        .render-title {
          font-size: 14px;
          font-weight: 700;
          color: #ffffff;
          margin: 0;
          line-height: 1.3;
        }

        .render-snippet {
          font-size: 11px;
          color: #94a3b8;
          margin: 0;
          line-height: 1.45;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }

        .mockup-footer-note {
          display: flex;
          align-items: flex-start;
          gap: 8px;
          font-size: 11px;
          color: #64748b;
          line-height: 1.4;
        }

        .mockup-footer-note :global(svg) {
          width: 14px;
          height: 14px;
          flex-shrink: 0;
          color: #38bdf8;
        }

        /* Toast */
        .seo-toast-pill {
          position: fixed;
          top: 80px;
          right: 28px;
          z-index: 1000;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 12px 20px;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 700;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.8);
          animation: toastSlide 0.25s ease;
        }

        .seo-toast-pill.success {
          background: #062316;
          border: 1px solid #16c96f;
          color: #a7f3d0;
        }

        .seo-toast-pill.error {
          background: #2b0b0b;
          border: 1px solid #ef4444;
          color: #fca5a5;
        }

        @keyframes toastSlide {
          from { transform: translateY(-16px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }

        /* Loading */
        .seo-loading-skeleton {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 80px 20px;
          gap: 12px;
          color: #94a3b8;
        }

        .seo-loading-skeleton :global(.spinner) {
          width: 28px;
          height: 28px;
          color: #16c96f;
        }

        /* Modal */
        .audit-modal-backdrop {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.8);
          backdrop-filter: blur(8px);
          z-index: 1000;
          display: grid;
          place-items: center;
          padding: 20px;
        }

        .audit-modal-box {
          width: 100%;
          max-width: 600px;
          background: #050f18;
          border: 1px solid rgba(56, 189, 248, 0.35);
          border-radius: 14px;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.9);
          overflow: hidden;
          display: flex;
          flex-direction: column;
        }

        .audit-modal-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 16px 20px;
          background: #03080e;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .audit-title-wrap {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .audit-title-wrap :global(.magic-icon) {
          width: 18px;
          height: 18px;
          color: #16c96f;
        }

        .audit-title-wrap h3 {
          font-size: 15px;
          font-weight: 700;
          color: #ffffff;
          margin: 0;
        }

        .btn-close-modal {
          background: none;
          border: none;
          color: #64748b;
          font-size: 16px;
          cursor: pointer;
        }

        .audit-modal-content {
          padding: 20px;
          display: flex;
          flex-direction: column;
          gap: 18px;
        }

        .audit-score-summary-bar {
          display: flex;
          align-items: center;
          gap: 16px;
          background: #03080e;
          border: 1px solid rgba(22, 201, 111, 0.3);
          border-radius: 10px;
          padding: 14px 18px;
        }

        .score-ring {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          background: rgba(22, 201, 111, 0.15);
          border: 2px solid #16c96f;
          display: grid;
          place-items: center;
          font-size: 14px;
          font-weight: 800;
          color: #16c96f;
        }

        .score-desc b {
          display: block;
          font-size: 13px;
          color: #ffffff;
        }

        .score-desc p {
          font-size: 11px;
          color: #94a3b8;
          margin: 3px 0 0;
        }

        .audit-checklist-list {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .audit-check-item {
          display: flex;
          align-items: flex-start;
          gap: 12px;
          background: rgba(255, 255, 255, 0.02);
          border: 1px solid rgba(255, 255, 255, 0.06);
          border-radius: 8px;
          padding: 10px 14px;
        }

        .audit-check-item.pass :global(svg) {
          color: #16c96f;
          width: 16px;
          height: 16px;
          margin-top: 2px;
          flex-shrink: 0;
        }

        .audit-check-item.warn :global(svg) {
          color: #f59e0b;
          width: 16px;
          height: 16px;
          margin-top: 2px;
          flex-shrink: 0;
        }

        .audit-check-item b {
          display: block;
          font-size: 12px;
          color: #f1f5f9;
        }

        .audit-check-item small {
          display: block;
          font-size: 10px;
          color: #64748b;
          margin-top: 2px;
        }

        .audit-modal-foot {
          padding: 14px 20px;
          background: #03080e;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
          display: flex;
          justify-content: flex-end;
        }

        @media (max-width: 900px) {
          .sitemaps-catalog-grid {
            grid-template-columns: 1fr;
          }
          .social-workspace-layout {
            grid-template-columns: 1fr;
          }
          .form-row-duo {
            grid-template-columns: 1fr;
            gap: 10px;
          }
          .seo-header-section {
            flex-direction: column;
          }
        }

        /* LIGHT MODE SCOPED OVERRIDES */
        :global(.theme-light) .seo-module-root {
          color: #0f172a !important;
        }

        :global(.theme-light) .seo-header-section {
          background: transparent !important;
          border: none !important;
        }

        :global(.theme-light) .header-title {
          color: #0f172a !important;
        }

        :global(.theme-light) .header-subtitle {
          color: #64748b !important;
        }

        :global(.theme-light) .action-btn-outline {
          background: #ffffff !important;
          border-color: #cbd5e1 !important;
          color: #334155 !important;
        }

        :global(.theme-light) .action-btn-outline:hover {
          background: #f1f5f9 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .seo-tabs-navbar {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .tab-nav-btn {
          color: #64748b !important;
        }

        :global(.theme-light) .tab-nav-btn:hover {
          color: #0f172a !important;
        }

        :global(.theme-light) .tab-nav-btn.is-active {
          color: #0d9651 !important;
          background: rgba(22, 201, 111, 0.1) !important;
        }

        /* SEO TOP BANNERS & HEADERS IN LIGHT MODE */
        :global(.theme-light) .pane-header-box {
          background: #ffffff !important;
          border: 1px solid #e2e8f0 !important;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .pane-header-info h3 {
          color: #0f172a !important;
        }

        :global(.theme-light) .pane-header-info p {
          color: #64748b !important;
        }

        :global(.theme-light) .tag-pill-badge {
          background: #f1f5f9 !important;
          border-color: #cbd5e1 !important;
          color: #475569 !important;
        }

        :global(.theme-light) .tag-pill-badge.active-neon {
          background: #f0fdf4 !important;
          border-color: #bbf7d0 !important;
          color: #16a34a !important;
        }

        /* SEO FORM AND GRID CARDS */
        :global(.theme-light) .fields-grid-card {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .fields-grid-card h3 {
          color: #0f172a !important;
        }

        :global(.theme-light) .fields-grid-card p {
          color: #64748b !important;
        }

        :global(.theme-light) .field-label,
        :global(.theme-light) .form-group-item label {
          color: #1e293b !important;
        }

        :global(.theme-light) .cyber-input,
        :global(.theme-light) .cyber-select,
        :global(.theme-light) .cyber-textarea {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .tag-token-btn {
          background: #f1f5f9 !important;
          border-color: #cbd5e1 !important;
          color: #334155 !important;
        }

        :global(.theme-light) .tag-token-btn:hover {
          background: #e2e8f0 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .robots-editor-textarea {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .sep-choice-btn {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .sep-choice-btn.is-active {
          background: rgba(22, 201, 111, 0.12) !important;
          border-color: #16c96f !important;
          color: #0d9651 !important;
        }

        /* SITEMAPS */
        :global(.theme-light) .sitemap-unit-card {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .sitemap-unit-card h4 {
          color: #0f172a !important;
        }

        :global(.theme-light) .sitemap-unit-card p {
          color: #64748b !important;
        }

        :global(.theme-light) .sitemap-icon-badge {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
        }

        :global(.theme-light) .sitemap-explorer-wrapper {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .explorer-header-bar {
          background: #ffffff !important;
          border-bottom: 1px solid #e2e8f0 !important;
        }

        :global(.theme-light) .explorer-title-area h4 {
          color: #0f172a !important;
        }

        :global(.theme-light) .explorer-title-area p {
          color: #64748b !important;
        }

        :global(.theme-light) .explorer-title-area h4 code {
          background: #f1f5f9 !important;
          color: #0284c7 !important;
        }

        :global(.theme-light) .explorer-search-box input {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .explorer-table th {
          background: #f8fafc !important;
          color: #475569 !important;
          border-bottom: 1px solid #e2e8f0 !important;
        }

        :global(.theme-light) .explorer-table td {
          border-bottom: 1px solid #f1f5f9 !important;
          color: #1e293b !important;
        }

        :global(.theme-light) .explorer-table tr:hover td {
          background: #f8fafc !important;
        }

        :global(.theme-light) .btn-toggle-raw,
        :global(.theme-light) .btn-open-direct {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #475569 !important;
        }

        /* SOCIAL & MOCKUPS */
        :global(.theme-light) .mockup-preview-card {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .mockup-preview-card h4 {
          color: #0f172a !important;
        }

        :global(.theme-light) .mockup-preview-card p {
          color: #64748b !important;
        }

        :global(.theme-light) .social-card-render {
          background: #f8fafc !important;
          border-color: #e2e8f0 !important;
        }

        :global(.theme-light) .og-image-dropzone {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
        }

        /* AUDIT MODAL */
        :global(.theme-light) .audit-modal-box {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15) !important;
        }

        :global(.theme-light) .audit-modal-head h3 {
          color: #0f172a !important;
        }

        :global(.theme-light) .audit-score-summary-bar {
          background: #f8fafc !important;
          border-color: #e2e8f0 !important;
        }

        :global(.theme-light) .audit-check-item {
          border-bottom-color: #f1f5f9 !important;
        }

        :global(.theme-light) .audit-check-title {
          color: #0f172a !important;
        }

        :global(.theme-light) .audit-modal-foot {
          background: #f8fafc !important;
          border-top-color: #e2e8f0 !important;
        }
      `}</style>
    </div>
  );
}
