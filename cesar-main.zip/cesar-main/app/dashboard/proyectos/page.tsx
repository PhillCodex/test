"use client";

import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import {
  FolderKanban,
  Plus,
  Search,
  Filter,
  Layers,
  DollarSign,
  Pencil,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  X,
  ExternalLink,
  Calendar,
  EyeOff,
  RefreshCw,
  Loader2,
  Briefcase,
} from "lucide-react";

interface ProjectCategory {
  id: string;
  name: string;
  slug: string;
  color?: string | null;
}

interface ProjectItem {
  id: string;
  title: string;
  slug: string;
  excerpt?: string | null;
  content?: string | null;
  featuredImage?: string | null;
  investment?: string | null;
  liveUrl?: string | null;
  clientName?: string | null;
  technologies?: string | null;
  status: "PUBLICADO" | "BORRADOR";
  views: number;
  category?: ProjectCategory | null;
  createdAt: string;
  updatedAt: string;
}

export default function ProjectsDashboardPage() {
  const [projects, setProjects] = useState<ProjectItem[]>([]);
  const [categories, setCategories] = useState<ProjectCategory[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [categoryFilter, setCategoryFilter] = useState<string>("ALL");
  const [statusFilter, setStatusFilter] = useState<string>("ALL");

  // Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<"success" | "error">("success");

  // Modal Categorías de Proyectos
  const [showCategoryModal, setShowCategoryModal] = useState<boolean>(false);
  const [newCatName, setNewCatName] = useState<string>("");
  const [newCatColor, setNewCatColor] = useState<string>("#16c96f");
  const [isCreatingCat, setIsCreatingCat] = useState<boolean>(false);

  // Modal Eliminación
  const [showDeleteModal, setShowDeleteModal] = useState<boolean>(false);
  const [itemToDelete, setItemToDelete] = useState<ProjectItem | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  const showToast = (msg: string, type: "success" | "error" = "success") => {
    setToastMessage(msg);
    setToastType(type);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Cargar Categorías de Proyectos
  const loadCategories = useCallback(async () => {
    try {
      const res = await fetch("/api/projects/categories");
      const data = await res.json();
      if (data.success) {
        setCategories(data.categories || []);
      }
    } catch (err) {
      console.error(err);
    }
  }, []);

  // Cargar Proyectos
  const loadProjects = useCallback(async () => {
    setIsLoading(true);
    try {
      let url = "/api/projects";
      const params = new URLSearchParams();
      if (searchQuery.trim()) params.append("q", searchQuery.trim());
      if (categoryFilter !== "ALL") params.append("category", categoryFilter);
      if (statusFilter !== "ALL") params.append("status", statusFilter);
      if (params.toString()) url += `?${params.toString()}`;

      const res = await fetch(url);
      const data = await res.json();
      if (data.success) {
        setProjects(data.projects || []);
      } else {
        showToast(data.error || "Error al cargar proyectos.", "error");
      }
    } catch (e) {
      console.error(e);
      showToast("Error de conexión al cargar proyectos.", "error");
    } finally {
      setIsLoading(false);
    }
  }, [searchQuery, categoryFilter, statusFilter]);

  useEffect(() => {
    loadCategories();
    loadProjects();
  }, [loadCategories, loadProjects]);

  // Crear Categoría de Proyecto
  const handleCreateCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;

    setIsCreatingCat(true);
    try {
      const res = await fetch("/api/projects/categories", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newCatName.trim(),
          color: newCatColor,
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast("Categoría de proyecto creada.", "success");
        setNewCatName("");
        loadCategories();
        setShowCategoryModal(false);
      } else {
        showToast(data.error || "Error al crear categoría.", "error");
      }
    } catch (err) {
      console.error(err);
      showToast("Error de conexión con el servidor.", "error");
    } finally {
      setIsCreatingCat(false);
    }
  };

  // Toggle Publicar / Borrador
  const handleToggleStatus = async (proj: ProjectItem) => {
    const nextStatus = proj.status === "PUBLICADO" ? "BORRADOR" : "PUBLICADO";
    try {
      const res = await fetch("/api/projects", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: proj.id, status: nextStatus }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(nextStatus === "PUBLICADO" ? "Proyecto publicado." : "Proyecto guardado como borrador.", "success");
        loadProjects();
      }
    } catch (err) {
      console.error(err);
      showToast("Error al actualizar estado.", "error");
    }
  };

  // Confirmar Eliminación
  const handleConfirmDelete = async () => {
    if (!itemToDelete) return;
    setIsDeleting(true);
    try {
      const res = await fetch(`/api/projects?id=${itemToDelete.id}`, {
        method: "DELETE",
      });
      const data = await res.json();
      if (data.success) {
        showToast("Proyecto eliminado correctamente.", "success");
        setShowDeleteModal(false);
        setItemToDelete(null);
        loadProjects();
      } else {
        showToast(data.error || "Error al eliminar proyecto.", "error");
      }
    } catch (err) {
      console.error(err);
      showToast("Error de conexión al servidor.", "error");
    } finally {
      setIsDeleting(false);
    }
  };

  // Métricas
  const totalCount = projects.length;
  const publishedCount = projects.filter((p) => p.status === "PUBLICADO").length;
  const draftCount = projects.filter((p) => p.status === "BORRADOR").length;

  return (
    <div className="techlab-projects-dashboard">
      {/* Toast Notification */}
      {toastMessage && (
        <div className={`techlab-toast ${toastType}`}>
          {toastType === "success" ? <CheckCircle2 /> : <AlertTriangle />}
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Cabecera Superior */}
      <div className="projects-header-bar">
        <div className="header-title-group">
          <div className="header-icon-badge">
            <FolderKanban />
          </div>
          <div>
            <h1>Gestión de Proyectos & Portafolio</h1>
            <p>Administra los casos de éxito, clientes, presupuestos e inversiones de tus proyectos</p>
          </div>
        </div>

        <div className="header-actions-group">
          <button
            type="button"
            className="btn-categories-manage"
            onClick={() => setShowCategoryModal(true)}
          >
            <Layers />
            <span>Categorías de Proyectos</span>
          </button>

          <Link href="/dashboard/proyectos/nuevo" className="neon-add-btn">
            <Plus />
            <span>Nuevo Proyecto</span>
          </Link>
        </div>
      </div>

      {/* KPI Cards */}
      <section className="projects-kpi-grid">
        <div className="kpi-card total">
          <div className="kpi-icon-box">
            <FolderKanban />
          </div>
          <div className="kpi-info">
            <span className="kpi-num">{totalCount}</span>
            <span className="kpi-label">Total Proyectos</span>
          </div>
        </div>

        <div className="kpi-card published">
          <div className="kpi-icon-box">
            <CheckCircle2 />
          </div>
          <div className="kpi-info">
            <span className="kpi-num">{publishedCount}</span>
            <span className="kpi-label">Publicados en Web</span>
          </div>
        </div>

        <div className="kpi-card draft">
          <div className="kpi-icon-box">
            <EyeOff />
          </div>
          <div className="kpi-info">
            <span className="kpi-num">{draftCount}</span>
            <span className="kpi-label">Borradores</span>
          </div>
        </div>

        <div className="kpi-card categories">
          <div className="kpi-icon-box">
            <Layers />
          </div>
          <div className="kpi-info">
            <span className="kpi-num">{categories.length}</span>
            <span className="kpi-label">Categorías Creadas</span>
          </div>
        </div>
      </section>

      {/* Barra de Filtros */}
      <div className="projects-filter-bar">
        <div className="search-input-wrapper">
          <Search />
          <input
            type="text"
            placeholder="Buscar por título, cliente, inversión o tecnologías..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <button
              type="button"
              className="clear-search-btn"
              onClick={() => setSearchQuery("")}
            >
              <X />
            </button>
          )}
        </div>

        <div className="filter-controls-group">
          <div className="filter-select-wrapper">
            <Layers />
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="filter-dropdown-select"
            >
              <option value="ALL">Todas las categorías</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div className="filter-select-wrapper">
            <Filter />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="filter-dropdown-select"
            >
              <option value="ALL">Todos los estados</option>
              <option value="PUBLICADO">Publicados</option>
              <option value="BORRADOR">Borradores</option>
            </select>
          </div>

          <button
            type="button"
            className="btn-refresh-data"
            onClick={loadProjects}
            title="Refrescar lista"
          >
            <RefreshCw className={isLoading ? "animate-spin" : ""} />
          </button>
        </div>
      </div>

      {/* Tabla de Proyectos */}
      <div className="projects-table-master-card">
        {isLoading ? (
          <div className="loading-state-container">
            <Loader2 className="animate-spin" />
            <span>Cargando...</span>
          </div>
        ) : projects.length === 0 ? (
          <div className="empty-state-container">
            <FolderKanban />
            <h3>No se encontraron proyectos</h3>
            <p>Comienza agregando tu primer proyecto con título, presupuesto, tecnologías y editor visual.</p>
            <Link href="/dashboard/proyectos/nuevo" className="neon-add-btn">
              <Plus />
              <span>Crear Primer Proyecto</span>
            </Link>
          </div>
        ) : (
          <div className="table-responsive-wrapper">
            <table className="techlab-projects-table">
              <thead>
                <tr>
                  <th>Proyecto</th>
                  <th>Cliente</th>
                  <th>Categoría</th>
                  <th>Inversión / Presupuesto</th>
                  <th>Tecnologías</th>
                  <th>Estado</th>
                  <th>Fecha</th>
                  <th className="text-right">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {projects.map((p) => {
                  const formattedDate = new Date(p.createdAt).toLocaleDateString("es-ES", {
                    day: "2-digit",
                    month: "short",
                    year: "numeric",
                  });

                  return (
                    <tr key={p.id}>
                      {/* Miniatura y Título */}
                      <td>
                        <div className="project-title-cell">
                          {p.featuredImage ? (
                            <img src={p.featuredImage} alt={p.title} className="project-thumb-img" />
                          ) : (
                            <div className="project-thumb-placeholder">
                              <FolderKanban />
                            </div>
                          )}
                          <div className="project-title-col">
                            <Link href={`/dashboard/proyectos/editar/${p.id}`} className="project-name-link">
                              {p.title}
                            </Link>
                            <small className="project-slug-sub">/{p.slug}</small>
                          </div>
                        </div>
                      </td>

                      {/* Cliente */}
                      <td>
                        <div className="client-cell">
                          <Briefcase className="client-icon" />
                          <span>{p.clientName || "—"}</span>
                        </div>
                      </td>

                      {/* Categoría */}
                      <td>
                        {p.category ? (
                          <span
                            className="cat-badge"
                            style={{
                              borderColor: `${p.category.color || "#16c96f"}50`,
                              color: p.category.color || "#16c96f",
                              backgroundColor: `${p.category.color || "#16c96f"}15`,
                            }}
                          >
                            {p.category.name}
                          </span>
                        ) : (
                          <span className="cat-badge-unassigned">Sin categoría</span>
                        )}
                      </td>

                      {/* Inversión */}
                      <td>
                        <div className="investment-cell">
                          <DollarSign className="inv-icon" />
                          <strong>{p.investment || "—"}</strong>
                        </div>
                      </td>

                      {/* Tecnologías */}
                      <td>
                        <span className="tech-text">{p.technologies || "—"}</span>
                      </td>

                      {/* Estado */}
                      <td>
                        <button
                          type="button"
                          className={`status-pill ${p.status.toLowerCase()}`}
                          onClick={() => handleToggleStatus(p)}
                          title="Clic para cambiar estado"
                        >
                          {p.status === "PUBLICADO" ? <CheckCircle2 /> : <EyeOff />}
                          <span>{p.status}</span>
                        </button>
                      </td>

                      {/* Fecha */}
                      <td>
                        <span className="date-text">
                          <Calendar className="date-icon" />
                          {formattedDate}
                        </span>
                      </td>

                      {/* Acciones */}
                      <td className="text-right">
                        <div className="table-actions-group">
                          {p.liveUrl && (
                            <a
                              href={p.liveUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="action-btn view"
                              title="Ver proyecto en vivo"
                            >
                              <ExternalLink />
                            </a>
                          )}

                          <Link
                            href={`/dashboard/proyectos/editar/${p.id}`}
                            className="action-btn edit"
                            title="Editar proyecto"
                          >
                            <Pencil />
                          </Link>

                          <button
                            type="button"
                            className="action-btn delete"
                            onClick={() => {
                              setItemToDelete(p);
                              setShowDeleteModal(true);
                            }}
                            title="Eliminar proyecto"
                          >
                            <Trash2 />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* =================================================================
          MODAL: CATEGORÍAS DE PROYECTOS
          ================================================================= */}
      {showCategoryModal && (
        <div className="techlab-modal-backdrop" onClick={() => setShowCategoryModal(false)}>
          <div className="category-modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="modal-top-header">
              <div className="modal-title-row">
                <div className="modal-header-icon">
                  <Layers />
                </div>
                <div>
                  <h3>Categorías de Proyectos</h3>
                  <p>Crea y clasifica tus proyectos de forma independiente a los artículos del blog</p>
                </div>
              </div>
              <button
                type="button"
                className="btn-close-modal"
                onClick={() => setShowCategoryModal(false)}
              >
                <X />
              </button>
            </div>

            <div className="modal-body-content">
              {/* Formulario Agregar Nueva Categoría */}
              <form onSubmit={handleCreateCategory} className="category-add-form">
                <div className="cat-inputs-row">
                  <input
                    type="text"
                    placeholder="Nombre de la nueva categoría (ej. E-Commerce)..."
                    value={newCatName}
                    onChange={(e) => setNewCatName(e.target.value)}
                    required
                    className="cat-name-input"
                  />
                  <input
                    type="color"
                    value={newCatColor}
                    onChange={(e) => setNewCatColor(e.target.value)}
                    className="cat-color-input"
                    title="Color de la categoría"
                  />
                  <button
                    type="submit"
                    className="btn-cat-add-submit"
                    disabled={isCreatingCat}
                  >
                    <Plus />
                    <span>{isCreatingCat ? "Guardando..." : "Agregar"}</span>
                  </button>
                </div>
              </form>

              {/* Lista de Categorías Existentes */}
              <div className="categories-list-box">
                <h4>Categorías Activas ({categories.length})</h4>
                <div className="categories-pills-wrap">
                  {categories.map((c) => (
                    <div
                      key={c.id}
                      className="category-pill-item"
                      style={{ borderColor: `${c.color || "#16c96f"}50` }}
                    >
                      <span className="dot" style={{ backgroundColor: c.color || "#16c96f" }} />
                      <span className="name">{c.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =================================================================
          MODAL: CONFIRMACIÓN DE ELIMINACIÓN
          ================================================================= */}
      {showDeleteModal && itemToDelete && (
        <div className="techlab-modal-backdrop" onClick={() => setShowDeleteModal(false)}>
          <div className="delete-modal-card-animated" onClick={(e) => e.stopPropagation()}>
            <div className="delete-icon-animated-badge">
              <Trash2 />
            </div>
            <h3>¿Eliminar este proyecto?</h3>
            <p>
              Esta acción es irreversible y eliminará <strong>"{itemToDelete.title}"</strong> de la base de datos MySQL.
            </p>

            <div className="delete-modal-buttons">
              <button
                type="button"
                className="btn-cancel-delete"
                onClick={() => setShowDeleteModal(false)}
                disabled={isDeleting}
              >
                Cancelar
              </button>
              <button
                type="button"
                className="btn-confirm-delete"
                onClick={handleConfirmDelete}
                disabled={isDeleting}
              >
                {isDeleting ? "Eliminando..." : "Sí, eliminar proyecto"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ESTILOS TECHLAB CYBER DARK */}
      <style jsx>{`
        .techlab-projects-dashboard {
          padding: 0 0 40px;
          color: inherit;
        }

        /* Toast */
        .techlab-toast {
          position: fixed;
          top: 70px;
          right: 24px;
          z-index: 1000;
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 12px 18px;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 600;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.6);
          animation: slideIn 0.25s ease;
        }

        .techlab-toast.success {
          background: #062316;
          border: 1px solid #16c96f;
          color: #a7f3d0;
        }

        .techlab-toast.error {
          background: #270d0d;
          border: 1px solid #ef4444;
          color: #fca5a5;
        }

        @keyframes slideIn {
          from { opacity: 0; transform: translateY(-16px); }
          to { opacity: 1; transform: translateY(0); }
        }

        /* Header */
        .projects-header-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 24px;
          gap: 16px;
        }

        .header-title-group {
          display: flex;
          align-items: center;
          gap: 14px;
        }

        .header-icon-badge {
          width: 48px;
          height: 48px;
          border-radius: 12px;
          background: rgba(22, 201, 111, 0.12);
          border: 1px solid rgba(22, 201, 111, 0.4);
          color: #16c96f;
          display: grid;
          place-items: center;
          box-shadow: 0 0 20px rgba(22, 201, 111, 0.2);
        }

        .header-icon-badge :global(svg) {
          width: 24px;
          height: 24px;
        }

        .header-title-group h1 {
          font-size: 22px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 4px;
          letter-spacing: -0.4px;
        }

        .header-title-group p {
          font-size: 13px;
          color: #94a3b8;
          margin: 0;
        }

        .header-actions-group {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .btn-categories-manage {
          height: 42px;
          padding: 0 16px;
          border-radius: 8px;
          background: #07131e;
          border: 1px solid rgba(56, 189, 248, 0.3);
          color: #38bdf8;
          font-size: 13px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
        }

        .btn-categories-manage:hover {
          background: rgba(56, 189, 248, 0.12);
        }

        .btn-categories-manage :global(svg) {
          width: 16px;
          height: 16px;
        }

        :global(.neon-add-btn) {
          height: 42px !important;
          padding: 0 20px !important;
          border-radius: 8px !important;
          background: linear-gradient(110deg, #12b85f, #18d878) !important;
          border: 1px solid rgba(67, 255, 147, 0.4) !important;
          color: #030b12 !important;
          font-size: 13px !important;
          font-weight: 800 !important;
          display: inline-flex !important;
          flex-direction: row !important;
          align-items: center !important;
          justify-content: center !important;
          gap: 8px !important;
          cursor: pointer !important;
          box-shadow: 0 0 20px rgba(22, 201, 111, 0.3) !important;
          text-decoration: none !important;
          white-space: nowrap !important;
          transition: all 0.15s ease !important;
        }

        :global(.neon-add-btn:hover) {
          transform: translateY(-2px) !important;
          box-shadow: 0 0 26px rgba(22, 201, 111, 0.5) !important;
        }

        :global(.neon-add-btn svg) {
          width: 16px !important;
          height: 16px !important;
          stroke-width: 2.5px !important;
        }

        /* KPI Grid */
        .projects-kpi-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 16px;
          margin-bottom: 24px;
        }

        .kpi-card {
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          padding: 16px;
          display: flex;
          align-items: center;
          gap: 14px;
        }

        .kpi-icon-box {
          width: 42px;
          height: 42px;
          border-radius: 8px;
          display: grid;
          place-items: center;
        }

        .kpi-icon-box :global(svg) {
          width: 20px;
          height: 20px;
        }

        .kpi-card.total .kpi-icon-box { background: rgba(56, 189, 248, 0.12); color: #38bdf8; }
        .kpi-card.published .kpi-icon-box { background: rgba(22, 201, 111, 0.12); color: #16c96f; }
        .kpi-card.draft .kpi-icon-box { background: rgba(245, 158, 11, 0.12); color: #f59e0b; }
        .kpi-card.categories .kpi-icon-box { background: rgba(168, 85, 247, 0.12); color: #c084fc; }

        .kpi-info {
          display: flex;
          flex-direction: column;
        }

        .kpi-num {
          font-size: 22px;
          font-weight: 800;
          color: #ffffff;
        }

        .kpi-label {
          font-size: 11px;
          color: #94a3b8;
          font-weight: 600;
          text-transform: uppercase;
        }

        /* Filter Bar */
        .projects-filter-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          padding: 12px 18px;
          margin-bottom: 20px;
        }

        .search-input-wrapper {
          flex: 1;
          position: relative;
          display: flex;
          align-items: center;
        }

        .search-input-wrapper :global(svg) {
          position: absolute;
          left: 12px;
          width: 15px;
          height: 15px;
          color: #64748b;
        }

        .search-input-wrapper input {
          width: 100%;
          height: 38px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 0 36px;
          color: #ffffff;
          font-size: 13px;
          outline: none;
        }

        .clear-search-btn {
          position: absolute;
          right: 10px;
          background: none;
          border: none;
          color: #64748b;
          cursor: pointer;
        }

        .filter-controls-group {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .filter-select-wrapper {
          position: relative;
          display: flex;
          align-items: center;
        }

        .filter-select-wrapper :global(svg) {
          position: absolute;
          left: 10px;
          width: 13px;
          height: 13px;
          color: #64748b;
        }

        .filter-dropdown-select {
          height: 38px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 0 14px 0 30px;
          color: #cbd5e1;
          font-size: 12px;
          font-weight: 600;
          outline: none;
        }

        .btn-refresh-data {
          width: 38px;
          height: 38px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          color: #94a3b8;
          display: grid;
          place-items: center;
          cursor: pointer;
        }

        /* Table Card */
        .projects-table-master-card {
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 12px;
          overflow: hidden;
        }

        .table-responsive-wrapper {
          overflow-x: auto;
        }

        .techlab-projects-table {
          width: 100%;
          border-collapse: collapse;
          text-align: left;
        }

        .techlab-projects-table th {
          background: #07131e;
          padding: 14px 18px;
          font-size: 11px;
          font-weight: 700;
          color: #94a3b8;
          text-transform: uppercase;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .techlab-projects-table td {
          padding: 14px 18px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.05);
          font-size: 13px;
          vertical-align: middle;
        }

        .text-right {
          text-align: right;
        }

        /* Project Title Cell */
        .project-title-cell {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .project-thumb-img {
          width: 44px;
          height: 44px;
          border-radius: 8px;
          object-fit: cover;
          border: 1px solid rgba(255, 255, 255, 0.15);
        }

        .project-thumb-placeholder {
          width: 44px;
          height: 44px;
          border-radius: 8px;
          background: #07131e;
          border: 1px solid rgba(56, 189, 248, 0.3);
          color: #38bdf8;
          display: grid;
          place-items: center;
        }

        .project-thumb-placeholder :global(svg) {
          width: 20px;
          height: 20px;
        }

        .project-title-col {
          display: flex;
          flex-direction: column;
        }

        .project-name-link {
          font-size: 13px;
          font-weight: 700;
          color: #ffffff;
          text-decoration: none;
        }

        .project-name-link:hover {
          color: #16c96f;
        }

        .project-slug-sub {
          font-size: 11px;
          color: #64748b;
          font-family: monospace;
        }

        /* Client & Investment */
        .client-cell {
          display: flex;
          align-items: center;
          gap: 6px;
          color: #cbd5e1;
        }

        .client-icon {
          width: 13px;
          height: 13px;
          color: #64748b;
        }

        .investment-cell {
          display: flex;
          align-items: center;
          gap: 4px;
          color: #16c96f;
          font-weight: 700;
        }

        .inv-icon {
          width: 14px;
          height: 14px;
        }

        .tech-text {
          font-size: 12px;
          color: #94a3b8;
          max-width: 200px;
          display: block;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        /* Badges */
        .cat-badge {
          display: inline-flex;
          padding: 3px 10px;
          border-radius: 20px;
          font-size: 11px;
          font-weight: 700;
          border: 1px solid;
        }

        .cat-badge-unassigned {
          color: #64748b;
          font-size: 11px;
          font-style: italic;
        }

        .status-pill {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          padding: 3px 10px;
          border-radius: 20px;
          font-size: 11px;
          font-weight: 700;
          cursor: pointer;
          border: none;
        }

        .status-pill.publicado {
          background: rgba(22, 201, 111, 0.15);
          color: #16c96f;
          border: 1px solid rgba(22, 201, 111, 0.3);
        }

        .status-pill.borrador {
          background: rgba(245, 158, 11, 0.15);
          color: #f59e0b;
          border: 1px solid rgba(245, 158, 11, 0.3);
        }

        .status-pill :global(svg) {
          width: 12px;
          height: 12px;
        }

        .date-text {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          color: #94a3b8;
          font-size: 12px;
        }

        .date-icon {
          width: 12px;
          height: 12px;
          color: #64748b;
        }

        /* Table Action Buttons */
        .table-actions-group {
          display: flex;
          align-items: center;
          justify-content: flex-end;
          gap: 6px;
        }

        :global(.action-btn) {
          width: 28px !important;
          height: 28px !important;
          border-radius: 4px !important;
          background: #040c14 !important;
          border: 1px solid rgba(255, 255, 255, 0.08) !important;
          color: #94a3b8 !important;
          display: grid !important;
          place-items: center !important;
          cursor: pointer !important;
          text-decoration: none !important;
          transition: all 0.15s !important;
        }

        :global(.action-btn svg) {
          width: 13px !important;
          height: 13px !important;
        }

        :global(.action-btn.edit:hover) {
          color: #38bdf8 !important;
          border-color: rgba(56, 189, 248, 0.4) !important;
          background: rgba(56, 189, 248, 0.08) !important;
        }

        :global(.action-btn.view:hover) {
          color: #16c96f !important;
          border-color: rgba(22, 201, 111, 0.4) !important;
          background: rgba(22, 201, 111, 0.08) !important;
        }

        :global(.action-btn.delete:hover) {
          color: #ef4444 !important;
          border-color: rgba(239, 68, 68, 0.4) !important;
          background: rgba(239, 68, 68, 0.08) !important;
        }

        /* Loading & Empty */
        .loading-state-container,
        .empty-state-container {
          padding: 80px 20px;
          text-align: center;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 12px;
          color: #64748b;
        }

        .empty-state-container :global(svg) {
          width: 44px;
          height: 44px;
          color: #16c96f;
          opacity: 0.5;
        }

        .empty-state-container h3 {
          font-size: 17px;
          font-weight: 700;
          color: #cbd5e1;
          margin: 0;
        }

        .empty-state-container p {
          font-size: 13px;
          max-width: 400px;
          margin: 0;
        }

        /* Modal */
        .techlab-modal-backdrop {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.82);
          backdrop-filter: blur(5px);
          display: grid;
          place-items: center;
          z-index: 1000;
          padding: 20px;
          animation: fadeIn 0.15s ease;
        }

        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        .category-modal-card {
          width: 100%;
          max-width: 520px;
          background: #040c14;
          border: 1px solid rgba(56, 189, 248, 0.3);
          border-radius: 14px;
          box-shadow: 0 24px 70px rgba(0, 0, 0, 0.8);
          overflow: hidden;
        }

        .modal-top-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 18px 24px;
          background: #07131e;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .modal-title-row {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .modal-header-icon {
          width: 40px;
          height: 40px;
          border-radius: 8px;
          background: rgba(56, 189, 248, 0.12);
          color: #38bdf8;
          display: grid;
          place-items: center;
        }

        .modal-header-icon :global(svg) {
          width: 20px;
          height: 20px;
        }

        .modal-title-row h3 {
          font-size: 16px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 2px;
        }

        .modal-title-row p {
          font-size: 12px;
          color: #94a3b8;
          margin: 0;
        }

        .btn-close-modal {
          background: none;
          border: none;
          color: #64748b;
          cursor: pointer;
        }

        .modal-body-content {
          padding: 20px 24px;
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        .cat-inputs-row {
          display: flex;
          gap: 8px;
        }

        .cat-name-input {
          flex: 1;
          height: 38px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 0 12px;
          color: #ffffff;
          font-size: 13px;
          outline: none;
        }

        .cat-color-input {
          width: 40px;
          height: 38px;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          background: transparent;
          cursor: pointer;
          padding: 2px;
        }

        .btn-cat-add-submit {
          height: 38px;
          padding: 0 16px;
          background: #16c96f;
          border: none;
          border-radius: 6px;
          color: #030b12;
          font-size: 12px;
          font-weight: 800;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
        }

        .categories-list-box h4 {
          font-size: 12px;
          font-weight: 700;
          color: #94a3b8;
          margin: 0 0 10px;
          text-transform: uppercase;
        }

        .categories-pills-wrap {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
        }

        .category-pill-item {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 4px 10px;
          border-radius: 6px;
          background: #07131e;
          border: 1px solid;
          font-size: 12px;
          font-weight: 600;
          color: #cbd5e1;
        }

        .category-pill-item .dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
        }

        /* Delete Modal */
        .delete-modal-card-animated {
          width: 90%;
          max-width: 420px;
          background: #040c14;
          border: 1px solid rgba(239, 68, 68, 0.4);
          border-radius: 12px;
          padding: 24px;
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.8);
        }

        .delete-icon-animated-badge {
          width: 52px;
          height: 52px;
          border-radius: 50%;
          background: rgba(239, 68, 68, 0.15);
          border: 1px solid #ef4444;
          color: #ef4444;
          display: grid;
          place-items: center;
          margin-bottom: 14px;
        }

        .delete-icon-animated-badge :global(svg) {
          width: 24px;
          height: 24px;
        }

        .delete-modal-card-animated h3 {
          font-size: 17px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 8px;
        }

        .delete-modal-card-animated p {
          font-size: 13px;
          color: #94a3b8;
          line-height: 1.5;
          margin: 0 0 20px;
        }

        .delete-modal-buttons {
          width: 100%;
          display: flex;
          gap: 10px;
        }

        .btn-cancel-delete {
          flex: 1;
          height: 38px;
          background: transparent;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          color: #cbd5e1;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
        }

        .btn-confirm-delete {
          flex: 1;
          height: 38px;
          background: #ef4444;
          border: none;
          border-radius: 6px;
          color: #ffffff;
          font-size: 13px;
          font-weight: 700;
          cursor: pointer;
        }

        /* LIGHT MODE SCOPED OVERRIDES */
        :global(.theme-light) .techlab-projects-dashboard {
          color: #0f172a !important;
        }

        :global(.theme-light) .projects-header-bar {
          background: transparent !important;
          border: none !important;
        }

        :global(.theme-light) .header-title-group h1 {
          color: #0f172a !important;
        }

        :global(.theme-light) .header-title-group p {
          color: #64748b !important;
        }

        :global(.theme-light) .header-icon-badge {
          background: #ffffff !important;
          border-color: #cbd5e1 !important;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05) !important;
        }

        :global(.theme-light) .btn-categories-manage {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0284c7 !important;
        }

        :global(.theme-light) .btn-categories-manage:hover {
          background: #f0f9ff !important;
          border-color: #0284c7 !important;
          color: #0369a1 !important;
        }

        :global(.theme-light) .kpi-card {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .kpi-icon-box {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
        }

        :global(.theme-light) .kpi-info-text strong {
          color: #0f172a !important;
        }

        :global(.theme-light) .kpi-info-text span {
          color: #64748b !important;
        }

        :global(.theme-light) .projects-filter-bar {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .search-input-wrapper input {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .filter-dropdown-select {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .btn-refresh-data {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #475569 !important;
        }

        :global(.theme-light) .btn-refresh-data:hover {
          background: #f1f5f9 !important;
          color: #0f172a !important;
        }

        /* TABLE MASTER CARD & ROWS */
        :global(.theme-light) .projects-table-master-card {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .techlab-projects-table th {
          background: #f8fafc !important;
          color: #475569 !important;
          border-bottom: 1px solid #e2e8f0 !important;
        }

        :global(.theme-light) .techlab-projects-table td {
          border-bottom: 1px solid #f1f5f9 !important;
          color: #1e293b !important;
        }

        :global(.theme-light) .techlab-projects-table tr:hover td {
          background: #f8fafc !important;
        }

        :global(.theme-light) .project-title-box strong {
          color: #0f172a !important;
        }

        :global(.theme-light) .project-title-box small {
          color: #64748b !important;
        }

        :global(.theme-light) .client-info-box {
          color: #334155 !important;
        }

        :global(.theme-light) .client-info-box :global(svg) {
          color: #64748b !important;
        }

        :global(.theme-light) .budget-badge {
          color: #0d9651 !important;
        }

        :global(.theme-light) .tech-stack-preview {
          color: #64748b !important;
        }

        :global(.theme-light) .date-badge-box {
          color: #64748b !important;
        }

        :global(.theme-light) .table-action-btn {
          background: #f8fafc !important;
          border-color: #e2e8f0 !important;
          color: #475569 !important;
        }

        :global(.theme-light) .table-action-btn:hover {
          background: #f1f5f9 !important;
          color: #0f172a !important;
          border-color: #cbd5e1 !important;
        }

        :global(.theme-light) .table-loading-box,
        :global(.theme-light) .table-empty-state {
          color: #64748b !important;
          background: transparent !important;
        }

        :global(.theme-light) .modal-category-card,
        :global(.theme-light) .delete-modal-card-animated {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15) !important;
        }

        :global(.theme-light) .modal-header h3,
        :global(.theme-light) .delete-modal-card-animated h3 {
          color: #0f172a !important;
        }

        :global(.theme-light) .delete-modal-card-animated p {
          color: #64748b !important;
        }

        :global(.theme-light) .btn-cancel-delete {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #475569 !important;
        }

        :global(.theme-light) .cat-input {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .existing-categories-box {
          background: #f8fafc !important;
          border-color: #e2e8f0 !important;
        }

        :global(.theme-light) .cat-badge-item {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          color: #0f172a !important;
        }
      `}</style>
    </div>
  );
}
