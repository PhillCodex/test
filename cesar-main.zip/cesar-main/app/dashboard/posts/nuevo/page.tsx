"use client";

import { useState, useRef, useEffect, useCallback, Suspense } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import {
  ChevronLeft,
  Plus,
  Undo2,
  Redo2,
  Menu,
  Monitor,
  Sidebar as SidebarIcon,
  MoreVertical,
  X,
  ChevronDown,
  ChevronUp,
  Image as ImageIcon,
  Video,
  Link2,
  Bold,
  Italic,
  Underline,
  Strikethrough,
  Code,
  Heading2,
  Heading3,
  Heading4,
  Pilcrow,
  Quote,
  List,
  ListOrdered,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  GripVertical,
  RotateCcw,
  Check,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Copy,
  ExternalLink,
  Search,
  Smartphone,
  Trash2,
  Loader2,
  CornerDownRight,
  Edit2,
  Sparkles,
  UploadCloud,
  Layers,
  Palette,
  Table,
  FileCode,
  Bookmark,
  Globe,
  Gauge,
  Share2,
  SlidersHorizontal,
  CheckCheck,
  FileText,
  KeyRound,
  ShieldCheck,
  Sun,
  Moon,
} from "lucide-react";

interface CategoryItem {
  id: string;
  name: string;
  slug: string;
  color?: string;
  parentId?: string | null;
  parent?: { id: string; name: string } | null;
}

function CesarGutenbergEditorContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const editParam = searchParams.get("edit") || searchParams.get("id");

  // Estado de Tema Light / Dark
  const [theme, setTheme] = useState<"dark" | "light">("dark");

  useEffect(() => {
    const savedTheme = localStorage.getItem("techlab_admin_theme") as "dark" | "light" | null;
    if (savedTheme === "light" || savedTheme === "dark") {
      setTheme(savedTheme);
    }
  }, []);

  const toggleTheme = () => {
    const nextTheme = theme === "dark" ? "light" : "dark";
    setTheme(nextTheme);
    localStorage.setItem("techlab_admin_theme", nextTheme);
  };

  // Estados del Documento
  const [editId, setEditId] = useState<string | null>(null);
  const [isLoadingPost, setIsLoadingPost] = useState<boolean>(false);
  const [title, setTitle] = useState("");
  const [slug, setSlug] = useState("");
  const [isSlugEdited, setIsSlugEdited] = useState(false);
  const [showSlugModal, setShowSlugModal] = useState(false);
  const [contentHtml, setContentHtml] = useState("");
  const [excerpt, setExcerpt] = useState("");
  const [showExcerptField, setShowExcerptField] = useState(false);
  const [featuredImage, setFeaturedImage] = useState("");
  const [isDragging, setIsDragging] = useState(false);

  // Estados de Metadatos (Entrada)
  const [status, setStatus] = useState<"Borrador" | "Publicado" | "Privado">("Borrador");
  const [visibility, setVisibility] = useState<"Pública" | "Privada" | "Protegida con contraseña">("Pública");
  const [publishDate, setPublishDate] = useState("Inmediatamente");
  const [authorName, setAuthorName] = useState("cesar");
  const [commentsOpen, setCommentsOpen] = useState(true);

  // Estados de Categorías (Jerarquía Padre / Hijo en MySQL)
  const [categories, setCategories] = useState<CategoryItem[]>([]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [showAddCatForm, setShowAddCatForm] = useState(false);
  const [newCatName, setNewCatName] = useState("");
  const [newCatParentId, setNewCatParentId] = useState("");
  const [isCreatingCat, setIsCreatingCat] = useState(false);

  // Estados de Etiquetas
  const [tags, setTags] = useState<string[]>(["WordPress", "Seguridad"]);
  const [tagInput, setTagInput] = useState("");

  // Estados de SEO
  const [focusKeyword, setFocusKeyword] = useState("");
  const [seoTitle, setSeoTitle] = useState("");
  const [seoDescription, setSeoDescription] = useState("");
  const [serpView, setSerpView] = useState<"desktop" | "mobile">("desktop");
  const [seoActiveTab, setSeoActiveTab] = useState<"general" | "analysis" | "social">("general");

  // Pestañas y Acordeones
  const [sidebarTab, setSidebarTab] = useState<"post" | "block">("post");
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [categoriesOpen, setCategoriesOpen] = useState(true);
  const [tagsOpen, setTagsOpen] = useState(true);
  const [seoOpen, setSeoOpen] = useState(true);

  // Inserter de Bloques [+] estilo WordPress
  const [showInlineInserter, setShowInlineInserter] = useState(false);
  const [showFullInserterDrawer, setShowFullInserterDrawer] = useState(false);
  const [inserterSearch, setInserterSearch] = useState("");

  // Barra Flotante de Bloque / Selección Gutenberg
  const [blockToolbar, setBlockToolbar] = useState<{
    visible: boolean;
    top: number;
    left: number;
    blockType: string;
    hasSelection: boolean;
  }>({
    visible: false,
    top: 0,
    left: 0,
    blockType: "p",
    hasSelection: false,
  });

  const [activeBlockEl, setActiveBlockEl] = useState<HTMLElement | null>(null);
  const [showBlockTypeMenu, setShowBlockTypeMenu] = useState(false);
  const [showAlignMenu, setShowAlignMenu] = useState(false);
  const [showLinkInput, setShowLinkInput] = useState(false);
  const [linkInputUrl, setLinkInputUrl] = useState("");
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [colorTab, setColorTab] = useState<"text" | "background">("text");
  const [activeColorPreview, setActiveColorPreview] = useState<string>("#38bdf8");
  const [showMoreMenu, setShowMoreMenu] = useState(false);

  // Estados de UI y AJAX
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [publishedUrl, setPublishedUrl] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<"success" | "error">("success");
  const [isCopied, setIsCopied] = useState(false);
  const [lastSavedTime, setLastSavedTime] = useState<string>("hace un momento");
  const [origin, setOrigin] = useState("");

  useEffect(() => {
    if (typeof window !== "undefined") {
      setOrigin(window.location.origin);
    }
  }, []);

  // Modales
  const [showLinkModal, setShowLinkModal] = useState(false);
  const [linkUrl, setLinkUrl] = useState("");
  const [linkText, setLinkText] = useState("");

  const [showVideoModal, setShowVideoModal] = useState(false);
  const [videoUrl, setVideoUrl] = useState("");

  // Estado de Auto-Guardado en Borrador
  const [autoSaveState, setAutoSaveState] = useState<"idle" | "saving" | "saved">("idle");
  const autoSaveTimerRef = useRef<NodeJS.Timeout | null>(null);
  const lastSavedPayloadRef = useRef<string>("");
  const isAutoSavingRef = useRef<boolean>(false);
  const isInitialLoadRef = useRef(true);
  const [isCanvasDragOver, setIsCanvasDragOver] = useState(false);

  const editorRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const editorImageInputRef = useRef<HTMLInputElement>(null);

  // Cargar categorías desde MySQL vía AJAX
  const loadCategories = useCallback(async () => {
    try {
      const res = await fetch("/api/categories");
      const data = await res.json();
      if (data.categories) {
        setCategories(data.categories);
        if (selectedCategories.length === 0 && data.categories.length > 0 && !editParam) {
          const defaultCat = data.categories.find((c: CategoryItem) => c.slug === "seguridad") || data.categories[0];
          setSelectedCategories([defaultCat.id]);
        }
      }
    } catch (e) {
      console.error("Error al cargar categorías:", e);
    }
  }, [selectedCategories.length, editParam]);

  useEffect(() => {
    loadCategories();
  }, [loadCategories]);

  // Cargar datos reales del Post cuando se está editando (?edit=ID)
  useEffect(() => {
    if (!editParam) return;

    const loadPostToEdit = async () => {
      setIsLoadingPost(true);
      try {
        const res = await fetch(`/api/posts?id=${encodeURIComponent(editParam)}`);
        const data = await res.json();

        if (data.success && data.post) {
          const p = data.post;
          setEditId(p.id);
          setTitle(p.title || "");
          setSlug(p.slug || "");
          setIsSlugEdited(true);
          setExcerpt(p.excerpt || "");
          setShowExcerptField(Boolean(p.excerpt));
          setContentHtml(p.content || "");
          if (editorRef.current) {
            editorRef.current.innerHTML = p.content || "";
          }
          setFeaturedImage(p.featuredImage || "");
          setStatus(p.status || "Publicado");
          setSeoTitle(p.seoTitle || p.title || "");
          setSeoDescription(p.seoDescription || p.excerpt || "");
          setFocusKeyword(p.focusKeyword || "");

          if (p.categoryId) {
            setSelectedCategories([p.categoryId]);
          }

          if (p.tags) {
            const parsedTags = p.tags
              .split(",")
              .map((t: string) => t.trim().replace(/^#/, ""))
              .filter(Boolean);
            setTags(parsedTags);
          }

          if (p.author?.name) {
            setAuthorName(p.author.name);
          }

          if (p.createdAt) {
            setPublishDate(new Date(p.createdAt).toLocaleDateString("es-ES", {
              day: "numeric",
              month: "short",
              year: "numeric",
            }));
          }

          showToast(`Cargado post: "${p.title}"`, "success");
        } else {
          showToast(data.error || "No se encontró el post para editar.", "error");
        }
      } catch (err) {
        console.error("Error al cargar post a editar:", err);
        showToast("Error al cargar datos del post.", "error");
      } finally {
        setIsLoadingPost(false);
      }
    };

    loadPostToEdit();
  }, [editParam]);

  // Sincronizar contenido del editor cuando se monte el DOM
  useEffect(() => {
    if (editorRef.current && contentHtml && !editorRef.current.innerHTML) {
      editorRef.current.innerHTML = contentHtml;
    }
  }, [contentHtml]);

  // Generador de Slug SEO
  const generateSlug = (text: string) => {
    return text
      .toLowerCase()
      .trim()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "");
  };

  const handleTitleChange = (val: string) => {
    setTitle(val);
    if (!isSlugEdited) {
      setSlug(generateSlug(val));
    }
    if (!seoTitle) {
      setSeoTitle(val);
    }
  };

  // Formato de texto nativo
  const formatDoc = (cmd: string, value: string | undefined = undefined) => {
    if (!editorRef.current) return;
    editorRef.current.focus();
    document.execCommand(cmd, false, value);
    handleEditorInput();
    setTimeout(updateBlockToolbar, 30);
  };

  const handleEditorInput = () => {
    if (editorRef.current) {
      setContentHtml(editorRef.current.innerHTML);
      setLastSavedTime("hace un instante");
    }
  };

  // Detección de bloque activo y posición de la barra flotante Gutenberg
  const updateBlockToolbar = useCallback(() => {
    if (typeof window === "undefined" || !editorRef.current) return;
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) {
      setBlockToolbar((prev) => (prev.visible ? { ...prev, visible: false } : prev));
      return;
    }

    const anchorNode = sel.anchorNode;
    if (!anchorNode || !editorRef.current.contains(anchorNode)) {
      setBlockToolbar((prev) => (prev.visible ? { ...prev, visible: false } : prev));
      return;
    }

    // Buscar elemento contenedor de bloque
    let curr: Node | null = anchorNode;
    let blockElement: HTMLElement | null = null;
    while (curr && curr !== editorRef.current) {
      if (curr.nodeType === Node.ELEMENT_NODE) {
        const tag = (curr as HTMLElement).tagName.toLowerCase();
        if (["p", "h1", "h2", "h3", "h4", "blockquote", "pre", "ul", "ol", "figure", "div"].includes(tag)) {
          blockElement = curr as HTMLElement;
          break;
        }
      }
      curr = curr.parentNode;
    }

    if (!blockElement && anchorNode.nodeType === Node.ELEMENT_NODE && anchorNode !== editorRef.current) {
      blockElement = anchorNode as HTMLElement;
    }

    setActiveBlockEl(blockElement);

    const hasSelection = !sel.isCollapsed && sel.toString().trim().length > 0;

    let rect: DOMRect | null = null;
    if (hasSelection) {
      const range = sel.getRangeAt(0);
      rect = range.getBoundingClientRect();
    } else if (blockElement) {
      rect = blockElement.getBoundingClientRect();
    } else {
      const range = sel.getRangeAt(0);
      rect = range.getBoundingClientRect();
    }

    if (rect && (rect.width > 0 || rect.height > 0 || rect.top > 0)) {
      const editorRect = editorRef.current.getBoundingClientRect();
      const tag = blockElement ? blockElement.tagName.toLowerCase() : "p";

      const targetTop = Math.max(72, rect.top - 46);
      const targetLeft = Math.max(
        editorRect.left + 8,
        Math.min(rect.left, editorRect.right - 360)
      );

      setBlockToolbar({
        visible: true,
        top: targetTop,
        left: targetLeft,
        blockType: tag,
        hasSelection,
      });
    }
  }, []);

  // Listeners de selección y clic fuera
  useEffect(() => {
    const handleDocSelection = () => {
      updateBlockToolbar();
    };

    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (
        !editorRef.current?.contains(target) &&
        !target.closest(".gutenberg-floating-block-toolbar") &&
        !target.closest(".gutenberg-tb-popover")
      ) {
        setBlockToolbar((prev) => (prev.visible ? { ...prev, visible: false } : prev));
        setShowBlockTypeMenu(false);
        setShowAlignMenu(false);
        setShowLinkInput(false);
        setShowColorPicker(false);
        setShowMoreMenu(false);
      }
    };

    document.addEventListener("selectionchange", handleDocSelection);
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("selectionchange", handleDocSelection);
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [updateBlockToolbar]);

  // Transformar tipo de bloque
  const transformBlockType = (tag: string) => {
    if (!editorRef.current) return;
    editorRef.current.focus();
    if (["p", "h2", "h3", "h4", "blockquote", "pre"].includes(tag)) {
      document.execCommand("formatBlock", false, `<${tag}>`);
    } else if (tag === "ul") {
      document.execCommand("insertUnorderedList");
    } else if (tag === "ol") {
      document.execCommand("insertOrderedList");
    }
    setShowBlockTypeMenu(false);
    handleEditorInput();
    setTimeout(updateBlockToolbar, 50);
  };

  // Mover bloque activo arriba o abajo
  const moveActiveBlock = (dir: "up" | "down") => {
    if (!activeBlockEl || !editorRef.current) return;
    if (dir === "up" && activeBlockEl.previousElementSibling) {
      editorRef.current.insertBefore(activeBlockEl, activeBlockEl.previousElementSibling);
    } else if (dir === "down" && activeBlockEl.nextElementSibling) {
      editorRef.current.insertBefore(activeBlockEl.nextElementSibling, activeBlockEl);
    }
    handleEditorInput();
    setTimeout(updateBlockToolbar, 50);
  };

  // Aplicar alineación
  const applyAlignment = (alignCmd: string) => {
    formatDoc(alignCmd);
    setShowAlignMenu(false);
  };

  // Aplicar enlace rápido
  const handleApplyLink = () => {
    if (!linkInputUrl.trim()) {
      setShowLinkInput(false);
      return;
    }
    let url = linkInputUrl.trim();
    if (!/^https?:\/\//i.test(url)) {
      url = "https://" + url;
    }
    formatDoc("createLink", url);
    setShowLinkInput(false);
    setLinkInputUrl("");
  };

  // Aplicar Color de Texto o Fondo/Resaltado
  const applyColor = (type: "text" | "background", colorHex: string) => {
    if (!editorRef.current) return;
    editorRef.current.focus();

    if (blockToolbar.hasSelection) {
      document.execCommand("styleWithCSS", false, "true");
      if (type === "text") {
        document.execCommand("foreColor", false, colorHex);
        setActiveColorPreview(colorHex);
      } else {
        document.execCommand("hiliteColor", false, colorHex);
      }
    } else {
      if (activeBlockEl) {
        if (type === "text") {
          activeBlockEl.style.color = colorHex === "inherit" ? "" : colorHex;
          setActiveColorPreview(colorHex);
        } else {
          if (colorHex === "transparent") {
            activeBlockEl.style.backgroundColor = "";
            activeBlockEl.style.padding = "";
            activeBlockEl.style.borderRadius = "";
          } else {
            activeBlockEl.style.backgroundColor = colorHex;
            activeBlockEl.style.padding = "6px 12px";
            activeBlockEl.style.borderRadius = "6px";
          }
        }
      } else {
        document.execCommand("styleWithCSS", false, "true");
        if (type === "text") {
          document.execCommand("foreColor", false, colorHex);
        } else {
          document.execCommand("hiliteColor", false, colorHex);
        }
      }
    }

    handleEditorInput();
  };

  // Duplicar bloque
  const duplicateBlock = () => {
    if (!activeBlockEl || !editorRef.current) return;
    const clone = activeBlockEl.cloneNode(true) as HTMLElement;
    if (activeBlockEl.nextSibling) {
      editorRef.current.insertBefore(clone, activeBlockEl.nextSibling);
    } else {
      editorRef.current.appendChild(clone);
    }
    handleEditorInput();
    setShowMoreMenu(false);
    setTimeout(updateBlockToolbar, 50);
  };

  // Insertar bloque antes / después
  const insertBlockRelative = (pos: "before" | "after") => {
    if (!activeBlockEl || !editorRef.current) return;
    const p = document.createElement("p");
    p.innerHTML = "<br>";
    if (pos === "before") {
      editorRef.current.insertBefore(p, activeBlockEl);
    } else {
      if (activeBlockEl.nextSibling) {
        editorRef.current.insertBefore(p, activeBlockEl.nextSibling);
      } else {
        editorRef.current.appendChild(p);
      }
    }
    handleEditorInput();
    setShowMoreMenu(false);
  };

  // Eliminar bloque activo
  const deleteActiveBlock = () => {
    if (!activeBlockEl || !editorRef.current) return;
    activeBlockEl.remove();
    handleEditorInput();
    setBlockToolbar({ visible: false, top: 0, left: 0, blockType: "p", hasSelection: false });
    setShowMoreMenu(false);
  };

  // Insertar Enlace
  const handleInsertLink = () => {
    if (!linkUrl) return;
    if (linkText && editorRef.current) {
      const a = `<a href="${linkUrl}" target="_blank" rel="noopener noreferrer" style="color: #16c96f; text-decoration: underline;">${linkText}</a>`;
      document.execCommand("insertHTML", false, a);
    } else {
      formatDoc("createLink", linkUrl);
    }
    setShowLinkModal(false);
    setLinkUrl("");
    setLinkText("");
    setBlockToolbar((prev) => ({ ...prev, visible: false }));
  };

  // Insertar Video
  const handleInsertVideo = () => {
    if (!videoUrl) return;
    let embedSrc = videoUrl;
    const ytMatch = videoUrl.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))([\w-]{11})/);
    if (ytMatch && ytMatch[1]) {
      embedSrc = `https://www.youtube-nocookie.com/embed/${ytMatch[1]}`;
    }

    const videoHtml = `<div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; max-width: 100%; border-radius: 8px; margin: 18px 0; border: 1px solid rgba(255,255,255,0.1);"><iframe src="${embedSrc}" style="position: absolute; top:0; left: 0; width: 100%; height: 100%; border:0;" allowfullscreen></iframe></div><p><br></p>`;

    if (editorRef.current) {
      editorRef.current.focus();
      document.execCommand("insertHTML", false, videoHtml);
      handleEditorInput();
    }
    setShowVideoModal(false);
    setVideoUrl("");
  };

  // Insertar bloque específico desde el Inserter
  const handleInsertBlock = (blockType: string) => {
    if (!editorRef.current) return;
    editorRef.current.focus();

    switch (blockType) {
      case "p":
        formatDoc("formatBlock", "<p>");
        break;
      case "h2":
      case "heading":
        formatDoc("formatBlock", "<h2>");
        break;
      case "h3":
        formatDoc("formatBlock", "<h3>");
        break;
      case "h4":
        formatDoc("formatBlock", "<h4>");
        break;
      case "list":
        formatDoc("insertUnorderedList");
        break;
      case "quote":
        formatDoc("formatBlock", "<blockquote>");
        break;
      case "code":
        formatDoc("formatBlock", "<pre>");
        break;
      case "image":
        editorImageInputRef.current?.click();
        break;
      case "video":
        setShowVideoModal(true);
        break;
      default:
        break;
    }

    setShowInlineInserter(false);
    setShowFullInserterDrawer(false);
  };

  // Manejador de teclado en el editor (Enter abre un nuevo bloque de párrafo)
  const handleEditorKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      const sel = window.getSelection();
      if (sel && sel.rangeCount > 0) {
        const node = sel.anchorNode;
        const parentBlock = node instanceof HTMLElement ? node : node?.parentElement;
        const tag = parentBlock?.tagName?.toUpperCase();
        if (parentBlock && ["H1", "H2", "H3", "H4", "BLOCKQUOTE", "PRE"].includes(tag || "")) {
          e.preventDefault();
          const newP = document.createElement("p");
          newP.innerHTML = "<br>";
          if (parentBlock.nextSibling) {
            parentBlock.parentNode?.insertBefore(newP, parentBlock.nextSibling);
          } else {
            parentBlock.parentNode?.appendChild(newP);
          }
          const range = document.createRange();
          range.setStart(newP, 0);
          range.collapse(true);
          sel.removeAllRanges();
          sel.addRange(range);
          handleEditorInput();
          setTimeout(updateBlockToolbar, 40);
        }
      }
    }
  };

  // Drag & Drop de Bloques desde el Inserter Drawer
  const handleCanvasDragOver = (e: React.DragEvent) => {
    if (e.dataTransfer.types.includes("application/techlab-block")) {
      e.preventDefault();
      e.dataTransfer.dropEffect = "copy";
      setIsCanvasDragOver(true);
    }
  };

  const handleCanvasDragLeave = () => {
    setIsCanvasDragOver(false);
  };

  const handleCanvasDrop = (e: React.DragEvent) => {
    if (e.dataTransfer.types.includes("application/techlab-block")) {
      e.preventDefault();
      setIsCanvasDragOver(false);
      const blockType = e.dataTransfer.getData("application/techlab-block");
      if (blockType) {
        handleInsertBlock(blockType);
        showToast(`Bloque ${blockType} insertado`, "success");
      }
    }
  };

  // Subir imagen para el contenido del editor
  const handleUploadEditorImage = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);
    formData.append("attachedToTitle", title.trim() || "(sin título)");
    formData.append("attachedToType", "post");
    formData.append("attachedToUrl", editParam ? `/dashboard/posts/nuevo?id=${editParam}` : "/dashboard/posts/nuevo");
    if (editParam) formData.append("attachedToId", editParam);

    try {
      showToast("Subiendo imagen al servidor...", "success");
      const res = await fetch("/api/upload", { method: "POST", body: formData });
      const data = await res.json();
      if (data.url) {
        const imgHtml = `<p><img src="${data.url}" alt="${file.name}" style="max-width: 100%; border-radius: 8px; margin: 16px 0; border: 1px solid rgba(255,255,255,0.1);" /></p><p><br></p>`;
        if (editorRef.current) {
          editorRef.current.focus();
          document.execCommand("insertHTML", false, imgHtml);
          handleEditorInput();
        }
        showToast("Imagen insertada correctamente.", "success");
      }
    } catch {
      showToast("Error al subir la imagen.", "error");
    }
  };

  // Subir imagen destacada (con Drag & Drop y tamaño fijo permanente)
  const processFeaturedImageUpload = async (file: File) => {
    setIsUploadingImage(true);
    const formData = new FormData();
    formData.append("file", file);
    formData.append("attachedToTitle", title.trim() || "(sin título)");
    formData.append("attachedToType", "post");
    formData.append("attachedToUrl", editParam ? `/dashboard/posts/nuevo?id=${editParam}` : "/dashboard/posts/nuevo");
    if (editParam) formData.append("attachedToId", editParam);

    try {
      const res = await fetch("/api/upload", { method: "POST", body: formData });
      const data = await res.json();
      if (data.url) {
        setFeaturedImage(data.url);
        showToast("Imagen destacada guardada en /uploads/.", "success");
      } else {
        showToast(data.error || "Error al subir imagen", "error");
      }
    } catch {
      showToast("Error al procesar la imagen.", "error");
    } finally {
      setIsUploadingImage(false);
    }
  };

  // Drag & Drop
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };
  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith("image/")) {
      processFeaturedImageUpload(file);
    } else {
      showToast("Por favor arrastra un archivo de imagen válido.", "error");
    }
  };

  // Crear categoría real en MySQL con Padre/Hijo
  const handleCreateCategory = async () => {
    if (!newCatName.trim()) return;
    setIsCreatingCat(true);

    try {
      const res = await fetch("/api/categories", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newCatName.trim(),
          parentId: newCatParentId || null,
        }),
      });
      const data = await res.json();
      if (data.success && data.category) {
        await loadCategories();
        setSelectedCategories((prev) => [...prev, data.category.id]);
        setNewCatName("");
        setNewCatParentId("");
        setShowAddCatForm(false);
        showToast(`Categoría "${data.category.name}" creada en base de datos.`, "success");
      }
    } catch {
      showToast("Error al crear categoría.", "error");
    } finally {
      setIsCreatingCat(false);
    }
  };

  const toggleCategorySelection = (id: string) => {
    setSelectedCategories((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  // Etiquetas
  const handleAddTag = () => {
    const raw = tagInput.replace(/#/g, "").trim();
    if (!raw) return;
    if (!tags.includes(raw)) {
      setTags([...tags, raw]);
    }
    setTagInput("");
  };

  const handleRemoveTag = (tToRemove: string) => {
    setTags(tags.filter((t) => t !== tToRemove));
  };

  // Toast
  const showToast = (msg: string, type: "success" | "error" = "success") => {
    setToastMessage(msg);
    setToastType(type);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handleCopyUrl = (urlToCopy: string) => {
    navigator.clipboard.writeText(urlToCopy);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
    showToast("¡Enlace copiado al portapapeles!", "success");
  };

  // Cálculo SEO en tiempo real
  const calculateSeo = useCallback(() => {
    let score = 0;
    const checks: { label: string; category: string; pass: boolean; hint: string }[] = [];

    const kw = focusKeyword.trim().toLowerCase();
    const cleanTitle = title.trim();
    const cleanDesc = seoDescription.trim();
    const plainText = contentHtml.replace(/<[^>]*>?/gm, " ").trim();
    const wordCount = plainText.split(/\s+/).filter(Boolean).length;
    const readingTime = Math.max(1, Math.ceil(wordCount / 200));

    const hasKwInTitle = Boolean(kw && cleanTitle.toLowerCase().includes(kw));
    checks.push({
      label: "Palabra clave en el título",
      category: "Palabra Clave",
      pass: hasKwInTitle,
      hint: hasKwInTitle ? "Excelente inclusión." : "Añade la palabra clave al título principal.",
    });
    if (hasKwInTitle) score += 20;

    const titleLengthGood = cleanTitle.length >= 35 && cleanTitle.length <= 70;
    checks.push({
      label: "Longitud del título SEO",
      category: "Básico",
      pass: titleLengthGood,
      hint: `${cleanTitle.length}/60 caracteres (Recomendado: 40-60).`,
    });
    if (titleLengthGood) score += 15;

    const hasKwInSlug = Boolean(kw && slug.toLowerCase().includes(generateSlug(kw)));
    checks.push({
      label: "Palabra clave en el slug",
      category: "URL / Slug",
      pass: hasKwInSlug,
      hint: hasKwInSlug ? "URL limpia y optimizada." : "Incluye palabras clave en la URL.",
    });
    if (hasKwInSlug) score += 15;

    const descLengthGood = cleanDesc.length >= 100 && cleanDesc.length <= 165;
    checks.push({
      label: "Meta descripción",
      category: "Básico",
      pass: descLengthGood,
      hint: `${cleanDesc.length}/160 caracteres (Recomendado: 120-160).`,
    });
    if (descLengthGood) score += 15;

    const hasHeadings = /<h[234]/i.test(contentHtml);
    checks.push({
      label: "Subtítulos (H2, H3)",
      category: "Estructura",
      pass: hasHeadings,
      hint: hasHeadings ? "Buena jerarquía visual." : "Organiza tu artículo con subtítulos.",
    });
    if (hasHeadings) score += 15;

    const hasImages = Boolean(featuredImage || /<img/i.test(contentHtml));
    checks.push({
      label: "Imagen destacada / Multimedia",
      category: "Medios",
      pass: hasImages,
      hint: hasImages ? "Contenido visual presente." : "Añade una imagen destacada.",
    });
    if (hasImages) score += 10;

    const goodWordCount = wordCount >= 100;
    checks.push({
      label: "Extensión del texto",
      category: "Contenido",
      pass: goodWordCount,
      hint: `${wordCount} palabras redactadas.`,
    });
    if (goodWordCount) score += 10;

    return { score: Math.min(100, score), checks, wordCount, readingTime };
  }, [focusKeyword, title, seoDescription, contentHtml, slug, featuredImage]);

  const { score: currentSeoScore, checks: seoChecks, wordCount, readingTime } = calculateSeo();

  // Guardar / Publicar vía AJAX en MySQL
  const handleSubmit = async (publishStatus: "Publicado" | "Borrador" | "Privado") => {
    if (!title.trim()) {
      showToast("Por favor escribe un título para la publicación.", "error");
      return;
    }

    setIsSubmitting(true);

    const payload = {
      id: editId || undefined,
      title,
      slug: slug || generateSlug(title),
      excerpt,
      content: contentHtml || "<p></p>",
      featuredImage,
      seoTitle: seoTitle || title,
      seoDescription: seoDescription || excerpt,
      focusKeyword,
      seoScore: currentSeoScore,
      status: publishStatus,
      tags: tags.join(","),
      categoryId: selectedCategories[0] || null,
    };

    try {
      const res = await fetch("/api/posts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (data.success) {
        if (data.post?.id) {
          setEditId(data.post.id);
        }
        setStatus(publishStatus);
        setPublishedUrl(data.fullUrl || `https://techlab.com/posts/${data.post.slug}`);
        setLastSavedTime("hace un segundo");
        showToast(
          editId
            ? "¡Publicación actualizada correctamente en MySQL!"
            : publishStatus === "Publicado"
            ? "¡Entrada publicada en TechLab!"
            : "Borrador guardado.",
          "success"
        );
      } else {
        showToast(data.error || "Error al guardar.", "error");
      }
    } catch {
      showToast("Error de conexión al servidor.", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Auto-Guardado Inteligente como Borrador al dejar de escribir (Debounce 1500ms)
  useEffect(() => {
    if (isInitialLoadRef.current) {
      isInitialLoadRef.current = false;
      return;
    }
    if (isLoadingPost || !title.trim()) return;

    if (autoSaveTimerRef.current) {
      clearTimeout(autoSaveTimerRef.current);
    }

    autoSaveTimerRef.current = setTimeout(async () => {
      if (!title.trim() || isSubmitting || isAutoSavingRef.current) return;

      const payloadStr = JSON.stringify({
        id: editId || null,
        title: title.trim(),
        excerpt,
        content: contentHtml || "<p></p>",
        featuredImage,
        selectedCategories,
        tags,
        seoTitle,
        seoDescription,
        focusKeyword,
        status,
      });

      if (payloadStr === lastSavedPayloadRef.current) return;

      isAutoSavingRef.current = true;
      setAutoSaveState("saving");

      const payload = {
        id: editId || undefined,
        title,
        slug: slug || generateSlug(title),
        excerpt,
        content: contentHtml || "<p></p>",
        featuredImage,
        seoTitle: seoTitle || title,
        seoDescription: seoDescription || excerpt,
        focusKeyword,
        seoScore: currentSeoScore,
        status: status,
        tags: tags.join(","),
        categoryId: selectedCategories[0] || null,
      };

      try {
        const res = await fetch("/api/posts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        const data = await res.json();
        if (data.success) {
          lastSavedPayloadRef.current = payloadStr;
          if (data.post?.id && !editId) {
            setEditId(data.post.id);
            window.history.replaceState({}, "", `/dashboard/posts/nuevo?edit=${data.post.id}`);
          }
          setLastSavedTime("hace unos segundos");
          setAutoSaveState("saved");
          setTimeout(() => {
            setAutoSaveState("idle");
          }, 3000);
        } else {
          setAutoSaveState("idle");
        }
      } catch {
        setAutoSaveState("idle");
      } finally {
        isAutoSavingRef.current = false;
      }
    }, 3500);

    return () => {
      if (autoSaveTimerRef.current) {
        clearTimeout(autoSaveTimerRef.current);
      }
    };
  }, [title, contentHtml, excerpt, featuredImage, selectedCategories, tags, seoTitle, seoDescription, focusKeyword]);

  // Categorías Jerárquicas
  const rootCategories = categories.filter((c) => !c.parentId);
  const getChildCategories = (parentId: string) => categories.filter((c) => c.parentId === parentId);

  const displayDomain = origin ? origin.replace(/^https?:\/\//, "") : "localhost:3000";

  return (
    <div className={`techlab-gutenberg-root ${theme === "light" ? "theme-light" : ""}`} data-theme={theme}>
      {/* Toast Notification */}
      {toastMessage && (
        <div className={`techlab-toast ${toastType}`}>
          {toastType === "success" ? <CheckCircle2 /> : <AlertTriangle />}
          <span>{toastMessage}</span>
        </div>
      )}

      {/* =================================================================
          BARRA SUPERIOR (HEADER ESTILO WORDPRESS CON TEMA TECHLAB CYBER)
          ================================================================= */}
      <header className="techlab-editor-header">
        <div className="teh-left">
          <Link href="/dashboard/posts" className="teh-back-btn" title="Volver a Posts">
            <ChevronLeft />
          </Link>

          {/* Botón Inserter [+] Principal */}
          <button
            type="button"
            className={`teh-inserter-main-btn ${showFullInserterDrawer ? "active" : ""}`}
            onClick={() => setShowFullInserterDrawer(!showFullInserterDrawer)}
            title="Añadir bloque"
          >
            <Plus />
          </button>

          <div className="teh-undo-redo">
            <button type="button" className="teh-icon-btn" onClick={() => formatDoc("undo")} title="Deshacer (Ctrl+Z)">
              <Undo2 />
            </button>
            <button type="button" className="teh-icon-btn" onClick={() => formatDoc("redo")} title="Rehacer (Ctrl+Y)">
              <Redo2 />
            </button>
          </div>

          <button
            type="button"
            className="teh-icon-btn"
            onClick={() => setShowFullInserterDrawer(!showFullInserterDrawer)}
            title="Vista de bloques"
          >
            <Menu />
          </button>
        </div>

        <div className="teh-center">
          <div className="teh-doc-badge">
            <span className="doc-name">{title ? (title.length > 30 ? title.slice(0, 30) + "..." : title) : "Sin título"}</span>
            <span className="doc-dot">·</span>
            <span className="doc-status">{status}</span>
          </div>
        </div>

        <div className="teh-right">
          {/* Switch Modo Claro / Modo Oscuro */}
          <button
            type="button"
            className={`teh-icon-btn teh-theme-toggle ${theme === "light" ? "is-light" : ""}`}
            onClick={toggleTheme}
            title={theme === "light" ? "Cambiar a Modo Oscuro" : "Cambiar a Modo Claro"}
          >
            {theme === "light" ? <Moon style={{ color: "#6366f1" }} /> : <Sun style={{ color: "#f59e0b" }} />}
          </button>

          <button
            type="button"
            className={`teh-draft-btn ${autoSaveState}`}
            onClick={() => handleSubmit("Borrador")}
            disabled={isSubmitting || autoSaveState === "saving"}
          >
            {autoSaveState === "saving" ? (
              <span className="btn-autosave-indicator saving">
                <Loader2 className="animate-spin" />
                <span>Guardando...</span>
              </span>
            ) : autoSaveState === "saved" ? (
              <span className="btn-autosave-indicator saved">
                <Check />
                <span>Guardado como borrador</span>
              </span>
            ) : (
              <span>Guardar como borrador</span>
            )}
          </button>

          <button type="button" className="teh-icon-btn" title="Vista previa">
            <Monitor />
          </button>

          <button
            type="button"
            className={`teh-sidebar-toggle ${isSidebarOpen ? "active" : ""}`}
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            title={isSidebarOpen ? "Ocultar panel lateral" : "Mostrar panel lateral"}
          >
            <SidebarIcon />
          </button>

          <button
            type="button"
            className="teh-publish-neon-btn"
            onClick={() => handleSubmit("Publicado")}
            disabled={isSubmitting}
          >
            {isSubmitting && status === "Publicado" ? (
              <>
                <Loader2 className="animate-spin" />
                <span>Publicando...</span>
              </>
            ) : (
              <>
                <Sparkles />
                <span>Publicar</span>
              </>
            )}
          </button>

          <button type="button" className="teh-icon-btn" title="Opciones">
            <MoreVertical />
          </button>
        </div>
      </header>

      {/* =================================================================
          DRAWER LATERAL COMPLETO DE BLOQUES (TIPO WORDPRESS - PATRONES Y MEDIOS CON DRAG & DROP)
          ================================================================= */}
      {showFullInserterDrawer && (
        <div className="full-inserter-drawer">
          <div className="drawer-header">
            <div className="drawer-tabs">
              <span className="active">Bloques</span>
              <span>Medios</span>
            </div>
            <button onClick={() => setShowFullInserterDrawer(false)} className="close-drawer-btn">
              <X />
            </button>
          </div>

          <div className="drawer-search-wrap">
            <Search />
            <input
              type="text"
              placeholder="Buscar bloques..."
              value={inserterSearch}
              onChange={(e) => setInserterSearch(e.target.value)}
            />
          </div>

          <div className="drawer-scroll-content">
            {/* Categoría: Texto */}
            <div className="drawer-category">
              <span className="category-heading">TEXTO</span>
              <div className="blocks-grid-3">
                <button
                  type="button"
                  className="block-tile"
                  draggable={true}
                  onDragStart={(e) => {
                    e.dataTransfer.setData("application/techlab-block", "p");
                    e.dataTransfer.effectAllowed = "copy";
                  }}
                  onClick={() => handleInsertBlock("p")}
                  title="Haz clic o arrastra al lienzo"
                >
                  <Pilcrow />
                  <span>Párrafo</span>
                </button>
                <button
                  type="button"
                  className="block-tile"
                  draggable={true}
                  onDragStart={(e) => {
                    e.dataTransfer.setData("application/techlab-block", "h2");
                    e.dataTransfer.effectAllowed = "copy";
                  }}
                  onClick={() => handleInsertBlock("h2")}
                  title="Haz clic o arrastra al lienzo"
                >
                  <Heading2 />
                  <span>Encabezado</span>
                </button>
                <button
                  type="button"
                  className="block-tile"
                  draggable={true}
                  onDragStart={(e) => {
                    e.dataTransfer.setData("application/techlab-block", "list");
                    e.dataTransfer.effectAllowed = "copy";
                  }}
                  onClick={() => handleInsertBlock("list")}
                  title="Haz clic o arrastra al lienzo"
                >
                  <List />
                  <span>Lista</span>
                </button>
                <button
                  type="button"
                  className="block-tile"
                  draggable={true}
                  onDragStart={(e) => {
                    e.dataTransfer.setData("application/techlab-block", "quote");
                    e.dataTransfer.effectAllowed = "copy";
                  }}
                  onClick={() => handleInsertBlock("quote")}
                  title="Haz clic o arrastra al lienzo"
                >
                  <Quote />
                  <span>Cita</span>
                </button>
                <button
                  type="button"
                  className="block-tile"
                  draggable={true}
                  onDragStart={(e) => {
                    e.dataTransfer.setData("application/techlab-block", "code");
                    e.dataTransfer.effectAllowed = "copy";
                  }}
                  onClick={() => handleInsertBlock("code")}
                  title="Haz clic o arrastra al lienzo"
                >
                  <FileCode />
                  <span>Código</span>
                </button>
                <button
                  type="button"
                  className="block-tile"
                  draggable={true}
                  onDragStart={(e) => {
                    e.dataTransfer.setData("application/techlab-block", "h3");
                    e.dataTransfer.effectAllowed = "copy";
                  }}
                  onClick={() => handleInsertBlock("h3")}
                  title="Haz clic o arrastra al lienzo"
                >
                  <Heading3 />
                  <span>Subtítulo</span>
                </button>
              </div>
            </div>

            {/* Categoría: Medios */}
            <div className="drawer-category">
              <span className="category-heading">MEDIOS</span>
              <div className="blocks-grid-3">
                <button
                  type="button"
                  className="block-tile"
                  draggable={true}
                  onDragStart={(e) => {
                    e.dataTransfer.setData("application/techlab-block", "image");
                    e.dataTransfer.effectAllowed = "copy";
                  }}
                  onClick={() => handleInsertBlock("image")}
                  title="Haz clic o arrastra al lienzo"
                >
                  <ImageIcon />
                  <span>Imagen</span>
                </button>
                <button
                  type="button"
                  className="block-tile"
                  draggable={true}
                  onDragStart={(e) => {
                    e.dataTransfer.setData("application/techlab-block", "video");
                    e.dataTransfer.effectAllowed = "copy";
                  }}
                  onClick={() => handleInsertBlock("video")}
                  title="Haz clic o arrastra al lienzo"
                >
                  <Video />
                  <span>Video</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Banner de URL pública generada (después de publicar) */}
      {publishedUrl && (
        <div className="techlab-published-banner">
          <div className="banner-left-info">
            <CheckCircle2 />
            <div>
              <strong>¡Entrada publicada en TechLab y lista para Google!</strong>
              <a href={publishedUrl} target="_blank" rel="noopener noreferrer" className="published-link-url">
                {publishedUrl} <ExternalLink />
              </a>
            </div>
          </div>
          <button className="copy-link-neon-btn" onClick={() => handleCopyUrl(publishedUrl)}>
            {isCopied ? "¡Copiado!" : "Copiar Enlace"}
          </button>
        </div>
      )}

      {/* =================================================================
          CUERPO DEL EDITOR (CANVAS CENTRAL + BARRA FLOTANTE + SIDEBAR)
          ================================================================= */}
      <div className={`techlab-editor-body ${isSidebarOpen ? "sidebar-visible" : "sidebar-hidden"}`}>
        {/* LIENZO DE REDACCIÓN */}
        <main className="editor-canvas-container">
          <div className="editor-canvas">
            {/* Título Principal (Sin barra inferior) */}
            <div className="editor-title-row">
              <input
                type="text"
                placeholder="Escribe un título"
                value={title}
                onChange={(e) => handleTitleChange(e.target.value)}
                className="techlab-title-input"
                autoFocus
              />
            </div>

            {/* Área editable de bloques con botón [+] a la derecha del primer bloque */}
            <div className="editor-blocks-zone">
              <div className="editor-block-stream-container">
                <div
                  ref={editorRef}
                  className={`techlab-content-editable ${isCanvasDragOver ? "is-drag-over" : ""}`}
                  contentEditable
                  suppressContentEditableWarning
                  onInput={handleEditorInput}
                  onKeyDown={handleEditorKeyDown}
                  onMouseUp={updateBlockToolbar}
                  onKeyUp={updateBlockToolbar}
                  onClick={updateBlockToolbar}
                  onDragOver={handleCanvasDragOver}
                  onDragLeave={handleCanvasDragLeave}
                  onDrop={handleCanvasDrop}
                  data-placeholder="Teclea / para elegir un bloque"
                />

                {/* Botón inline [+] en el lado DERECHO del primer bloque / bloque activo */}
                <div className="block-right-inserter-anchor">
                  <button
                    type="button"
                    className="inline-plus-btn-right"
                    onClick={(e) => {
                      e.stopPropagation();
                      setShowInlineInserter(!showInlineInserter);
                    }}
                    title="Añadir bloque [+]"
                  >
                    <Plus />
                  </button>

                  {/* Popover al hacer clic en [+] */}
                  {showInlineInserter && (
                    <div className="inline-blocks-popover-right">
                      <div className="popover-search-box">
                        <Search />
                        <input
                          type="text"
                          placeholder="Buscar..."
                          value={inserterSearch}
                          onChange={(e) => setInserterSearch(e.target.value)}
                          autoFocus
                        />
                      </div>

                      <div className="popover-blocks-grid">
                        <button type="button" className="grid-item" onClick={() => handleInsertBlock("p")}>
                          <Pilcrow />
                          <span>Párrafo</span>
                        </button>
                        <button type="button" className="grid-item" onClick={() => handleInsertBlock("image")}>
                          <ImageIcon />
                          <span>Imagen</span>
                        </button>
                        <button type="button" className="grid-item" onClick={() => handleInsertBlock("h2")}>
                          <Heading2 />
                          <span>Encabezado 2</span>
                        </button>
                        <button type="button" className="grid-item" onClick={() => handleInsertBlock("h3")}>
                          <Heading3 />
                          <span>Encabezado 3</span>
                        </button>
                        <button type="button" className="grid-item" onClick={() => handleInsertBlock("quote")}>
                          <Quote />
                          <span>Cita</span>
                        </button>
                        <button type="button" className="grid-item" onClick={() => handleInsertBlock("code")}>
                          <Code />
                          <span>Código</span>
                        </button>
                      </div>

                      <button
                        type="button"
                        className="popover-view-all-btn"
                        onClick={() => {
                          setShowInlineInserter(false);
                          setShowFullInserterDrawer(true);
                        }}
                      >
                        Ver todos
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* =================================================================
                SUITE DE OPTIMIZACIÓN SEO PARA GOOGLE (ESTILO RANK MATH PRO)
                FORMATO AMPLIO, ORGANIZADO EN PESTAÑAS Y PROFESIONAL
                ================================================================= */}
            <section className="techlab-pro-seo-suite">
              {/* Header Principal de la Suite SEO */}
              <div className="seo-suite-top-bar">
                <div className="suite-title-area">
                  <div className="suite-icon-badge">
                    <Globe />
                  </div>
                  <div>
                    <h3>Optimización SEO para Google</h3>
                    <p>Gestiona los metadatos de búsqueda, vista previa en tiempo real y checklist de auditoría</p>
                  </div>
                </div>

                {/* Tarjeta de Puntuación SEO */}
                <div className="suite-score-badge-card">
                  <div className="score-text-group">
                    <span className="score-lbl">Puntuación SEO</span>
                    <strong className={currentSeoScore >= 80 ? "good" : currentSeoScore >= 50 ? "avg" : "bad"}>
                      {currentSeoScore >= 80 ? "Excelente" : currentSeoScore >= 50 ? "Aceptable" : "Por Mejorar"}
                    </strong>
                  </div>
                  <div className={`score-radial-tag ${currentSeoScore >= 80 ? "good" : currentSeoScore >= 50 ? "avg" : "bad"}`}>
                    <Gauge />
                    <span>{currentSeoScore}%</span>
                  </div>
                </div>
              </div>

              {/* Barra de Pestañas de Navegación SEO */}
              <div className="seo-suite-tabs-nav">
                <button
                  type="button"
                  className={`seo-nav-tab ${seoActiveTab === "general" ? "active" : ""}`}
                  onClick={() => setSeoActiveTab("general")}
                >
                  <Search />
                  <span>Google Snippet & Metadatos</span>
                </button>

                <button
                  type="button"
                  className={`seo-nav-tab ${seoActiveTab === "analysis" ? "active" : ""}`}
                  onClick={() => setSeoActiveTab("analysis")}
                >
                  <ShieldCheck />
                  <span>Auditoría & Checklist</span>
                  <span className="tab-pill-count">
                    {seoChecks.filter((c) => c.pass).length}/{seoChecks.length}
                  </span>
                </button>

                <button
                  type="button"
                  className={`seo-nav-tab ${seoActiveTab === "social" ? "active" : ""}`}
                  onClick={() => setSeoActiveTab("social")}
                >
                  <Share2 />
                  <span>Previsualización Social (OpenGraph)</span>
                </button>
              </div>

              {/* CONTENIDO DE PESTAÑAS */}
              <div className="seo-suite-content-body">
                {/* ---------------- PESTAÑA 1: GENERAL & SNIPPET ---------------- */}
                {seoActiveTab === "general" && (
                  <div className="tab-pane-general">
                    {/* Tarjeta Visual de Previsualización Google */}
                    <div className="google-serp-master-card">
                      <div className="serp-toolbar-header">
                        <div className="serp-badge-title">
                          <span className="g-logo">G</span>
                          <strong>Vista previa en Google Search</strong>
                        </div>

                        <div className="serp-view-mode-buttons">
                          <button
                            type="button"
                            className={serpView === "desktop" ? "active" : ""}
                            onClick={() => setSerpView("desktop")}
                          >
                            <Monitor />
                            <span>Escritorio</span>
                          </button>
                          <button
                            type="button"
                            className={serpView === "mobile" ? "active" : ""}
                            onClick={() => setSerpView("mobile")}
                          >
                            <Smartphone />
                            <span>Móvil</span>
                          </button>
                        </div>
                      </div>

                      {/* Snippet Real de Google */}
                      <div className={`google-snippet-frame ${serpView === "mobile" ? "mobile-mode" : ""}`}>
                        <div className="snippet-top-row">
                          <div className="google-favicon-circle">🌐</div>
                          <div className="snippet-hierarchy">
                            <span className="brand-name">TechLab</span>
                            <span className="sep">›</span>
                            <span className="url-path">{displayDomain} › posts › {slug || "mi-entrada"}</span>
                          </div>
                        </div>
                        <h4 className="snippet-heading">
                          {seoTitle || title || "Título de tu publicación | TechLab"}
                        </h4>
                        <p className="snippet-text">
                          {seoDescription || excerpt || "Escribe una meta descripción persuasiva y optimizada para aumentar los clics orgánicos en los resultados de Google..."}
                        </p>
                      </div>
                    </div>

                    {/* Formulario Amplio de Metadatos */}
                    <div className="seo-form-spacious-grid">
                      {/* Campo 1: Palabra Clave Objetivo */}
                      <div className="form-field-row">
                        <div className="field-meta-info">
                          <label>
                            <KeyRound />
                            <span>Palabra clave objetivo</span>
                          </label>
                          <p>Término principal con el que los clientes encontrarán este artículo en Google.</p>
                        </div>
                        <div className="field-input-box">
                          <input
                            type="text"
                            value={focusKeyword}
                            onChange={(e) => setFocusKeyword(e.target.value)}
                            placeholder="ej. ciberseguridad industrial"
                            className="wide-seo-input"
                          />
                        </div>
                      </div>

                      {/* Campo 2: Título SEO */}
                      <div className="form-field-row">
                        <div className="field-meta-info">
                          <label>
                            <FileText />
                            <span>Título SEO (Meta Title)</span>
                          </label>
                          <p>El título visible en los resultados de búsqueda. Recomendado entre 45 y 60 caracteres.</p>
                        </div>
                        <div className="field-input-box">
                          <div className="input-with-counter-wrap">
                            <input
                              type="text"
                              value={seoTitle}
                              onChange={(e) => setSeoTitle(e.target.value)}
                              placeholder="Título optimizado para Google..."
                              className="wide-seo-input"
                            />
                            <span className={`counter-pill ${seoTitle.length > 60 ? "warn" : seoTitle.length >= 35 ? "good" : "neutral"}`}>
                              {seoTitle.length} / 60 car.
                            </span>
                          </div>
                          {/* Barra de progreso de caracteres */}
                          <div className="char-progress-bar">
                            <div
                              className={`progress-fill ${seoTitle.length > 60 ? "warn" : seoTitle.length >= 35 ? "good" : "neutral"}`}
                              style={{ width: `${Math.min(100, (seoTitle.length / 60) * 100)}%` }}
                            />
                          </div>
                        </div>
                      </div>

                      {/* Campo 3: Meta Descripción */}
                      <div className="form-field-row">
                        <div className="field-meta-info">
                          <label>
                            <SlidersHorizontal />
                            <span>Meta Descripción (Snippet)</span>
                          </label>
                          <p>Resumen atractivo del contenido para convencer a los usuarios de hacer clic.</p>
                        </div>
                        <div className="field-input-box">
                          <div className="input-with-counter-wrap">
                            <textarea
                              rows={3}
                              value={seoDescription}
                              onChange={(e) => setSeoDescription(e.target.value)}
                              placeholder="Resumen atractivo que describa los puntos clave de esta publicación..."
                              className="wide-seo-textarea"
                            />
                            <span className={`counter-pill ${seoDescription.length > 160 ? "warn" : seoDescription.length >= 100 ? "good" : "neutral"}`}>
                              {seoDescription.length} / 160 car.
                            </span>
                          </div>
                          {/* Barra de progreso de caracteres */}
                          <div className="char-progress-bar">
                            <div
                              className={`progress-fill ${seoDescription.length > 160 ? "warn" : seoDescription.length >= 100 ? "good" : "neutral"}`}
                              style={{ width: `${Math.min(100, (seoDescription.length / 160) * 100)}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* ---------------- PESTAÑA 2: AUDITORÍA & CHECKLIST ---------------- */}
                {seoActiveTab === "analysis" && (
                  <div className="tab-pane-analysis">
                    <div className="analysis-summary-banner">
                      <div className="banner-icon">
                        <CheckCheck />
                      </div>
                      <div className="banner-texts">
                        <h4>Auditoría Técnica de Posicionamiento</h4>
                        <p>
                          Tu artículo cumple <strong>{seoChecks.filter((c) => c.pass).length} de {seoChecks.length}</strong> criterios recomendados por las directrices para webmasters de Google.
                        </p>
                      </div>
                    </div>

                    <div className="audit-cards-grid">
                      {seoChecks.map((chk) => (
                        <div key={chk.label} className={`audit-card-item ${chk.pass ? "pass" : "fail"}`}>
                          <div className="audit-status-icon">
                            {chk.pass ? <CheckCircle2 /> : <XCircle />}
                          </div>
                          <div className="audit-info">
                            <span className="audit-category">{chk.category}</span>
                            <strong>{chk.label}</strong>
                            <p>{chk.hint}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* ---------------- PESTAÑA 3: PREVIEW REDES SOCIALES (OPEN GRAPH) ---------------- */}
                {seoActiveTab === "social" && (
                  <div className="tab-pane-social">
                    <div className="social-preview-container">
                      <div className="social-header-row">
                        <span>VISTA PREVIA EN REDES SOCIALES (FACEBOOK / TWITTER / WHATSAPP)</span>
                      </div>

                      <div className="social-card-simulation">
                        {featuredImage ? (
                          <div className="social-img-box">
                            <img src={featuredImage} alt="Preview social" />
                          </div>
                        ) : (
                          <div className="social-img-placeholder">
                            <UploadCloud />
                            <span>Asigna una Imagen Destacada para que aparezca aquí</span>
                          </div>
                        )}
                        <div className="social-card-body">
                          <span className="social-domain">{displayDomain}</span>
                          <h5>{seoTitle || title || "Título de la publicación"}</h5>
                          <p>{seoDescription || excerpt || "La meta descripción del artículo aparecerá aquí cuando lo compartas en redes sociales."}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </section>

            {/* Pie del Canvas */}
            <footer className="editor-canvas-footer">
              <span>Entrada</span>
              <span>·</span>
              <span>{wordCount} palabras</span>
              <span>·</span>
              <span>{readingTime} min de lectura</span>
              <span>·</span>
              <span>SEO Score: <b style={{ color: currentSeoScore >= 80 ? "#16c96f" : "#fbbf24" }}>{currentSeoScore}%</b></span>
            </footer>
          </div>
        </main>

        {/* =================================================================
            BARRA DE HERRAMIENTAS FLOTANTE DE BLOQUE / SELECCIÓN (ESTILO GUTENBERG)
            APARECE TANTO AL MARCAR/SEÑALAR TEXTO COMO AL SITUARSE EN EL BLOQUE
            ================================================================= */}
        {blockToolbar.visible && (
          <div
            className="gutenberg-floating-block-toolbar"
            style={{
              top: `${blockToolbar.top}px`,
              left: `${blockToolbar.left}px`,
            }}
            onMouseDown={(e) => {
              e.stopPropagation();
            }}
          >
            {/* Grupo 1: Selector de tipo de bloque + Movers */}
            <div className="toolbar-btn-group">
              <button
                type="button"
                className="tb-btn tb-block-type-btn"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => {
                  setShowBlockTypeMenu(!showBlockTypeMenu);
                  setShowAlignMenu(false);
                  setShowColorPicker(false);
                  setShowLinkInput(false);
                  setShowMoreMenu(false);
                }}
                title="Cambiar tipo de bloque"
              >
                {blockToolbar.blockType === "h2" && <Heading2 />}
                {blockToolbar.blockType === "h3" && <Heading3 />}
                {blockToolbar.blockType === "h4" && <Heading4 />}
                {blockToolbar.blockType === "blockquote" && <Quote />}
                {blockToolbar.blockType === "ul" && <List />}
                {blockToolbar.blockType === "ol" && <ListOrdered />}
                {blockToolbar.blockType === "pre" && <Code />}
                {["p", "div", "figure"].includes(blockToolbar.blockType) && <Pilcrow />}
                <ChevronDown className="tb-chevron-icon" />
              </button>

              <div className="tb-movers-duo">
                <button
                  type="button"
                  className="tb-icon-mini-btn"
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={() => moveActiveBlock("up")}
                  title="Mover bloque arriba"
                >
                  <ChevronUp />
                </button>
                <button
                  type="button"
                  className="tb-icon-mini-btn"
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={() => moveActiveBlock("down")}
                  title="Mover bloque abajo"
                >
                  <ChevronDown />
                </button>
              </div>
            </div>

            <span className="tb-divider" />

            {/* Grupo 2: Alineación */}
            <div className="toolbar-btn-group">
              <button
                type="button"
                className="tb-btn"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => {
                  setShowAlignMenu(!showAlignMenu);
                  setShowBlockTypeMenu(false);
                  setShowColorPicker(false);
                  setShowLinkInput(false);
                  setShowMoreMenu(false);
                }}
                title="Alineación"
              >
                <AlignLeft />
                <ChevronDown className="tb-chevron-icon" />
              </button>
            </div>

            <span className="tb-divider" />

            {/* Grupo 3: Formato de Texto (Negrita, Cursiva, Subrayado, Tachado, Enlace) */}
            <div className="toolbar-btn-group">
              <button
                type="button"
                className="tb-btn tb-text-btn"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => formatDoc("bold")}
                title="Negrita (Ctrl+B)"
              >
                <Bold />
              </button>
              <button
                type="button"
                className="tb-btn tb-text-btn"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => formatDoc("italic")}
                title="Cursiva (Ctrl+I)"
              >
                <Italic />
              </button>
              <button
                type="button"
                className="tb-btn tb-text-btn"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => formatDoc("underline")}
                title="Subrayado (Ctrl+U)"
              >
                <Underline />
              </button>
              <button
                type="button"
                className="tb-btn tb-text-btn"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => formatDoc("strikeThrough")}
                title="Tachado"
              >
                <Strikethrough />
              </button>
              <button
                type="button"
                className="tb-btn"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => {
                  setShowLinkInput(!showLinkInput);
                  setShowBlockTypeMenu(false);
                  setShowAlignMenu(false);
                  setShowColorPicker(false);
                  setShowMoreMenu(false);
                }}
                title="Insertar enlace (Ctrl+K)"
              >
                <Link2 />
              </button>
            </div>

            <span className="tb-divider" />

            {/* Grupo 4: Paleta de Colores y Resaltado */}
            <div className="toolbar-btn-group">
              <button
                type="button"
                className={`tb-btn tb-color-btn ${showColorPicker ? "active" : ""}`}
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => {
                  setShowColorPicker(!showColorPicker);
                  setShowBlockTypeMenu(false);
                  setShowAlignMenu(false);
                  setShowLinkInput(false);
                  setShowMoreMenu(false);
                }}
                title="Color de texto y fondo / resaltado"
              >
                <Palette />
                <span className="tb-color-indicator" style={{ background: activeColorPreview || "#38bdf8" }} />
                <ChevronDown className="tb-chevron-icon" />
              </button>
            </div>

            <span className="tb-divider" />

            {/* Grupo 5: Más Opciones ⋮ */}
            <div className="toolbar-btn-group">
              <button
                type="button"
                className="tb-btn"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => {
                  setShowMoreMenu(!showMoreMenu);
                  setShowBlockTypeMenu(false);
                  setShowAlignMenu(false);
                  setShowColorPicker(false);
                  setShowLinkInput(false);
                }}
                title="Más opciones del bloque"
              >
                <MoreVertical />
              </button>
            </div>

            {/* POPOVER 1: TIPOS DE BLOQUE */}
            {showBlockTypeMenu && (
              <div className="gutenberg-tb-popover block-types-popover" onMouseDown={(e) => e.preventDefault()}>
                <span className="popover-header-title">Transformar bloque en:</span>
                <button type="button" className="popover-item" onClick={() => transformBlockType("p")}>
                  <Pilcrow /> <span>Párrafo</span>
                </button>
                <button type="button" className="popover-item" onClick={() => transformBlockType("h2")}>
                  <Heading2 /> <span>Encabezado 2 (H2)</span>
                </button>
                <button type="button" className="popover-item" onClick={() => transformBlockType("h3")}>
                  <Heading3 /> <span>Encabezado 3 (H3)</span>
                </button>
                <button type="button" className="popover-item" onClick={() => transformBlockType("h4")}>
                  <Heading4 /> <span>Encabezado 4 (H4)</span>
                </button>
                <button type="button" className="popover-item" onClick={() => transformBlockType("blockquote")}>
                  <Quote /> <span>Cita</span>
                </button>
                <button type="button" className="popover-item" onClick={() => transformBlockType("ul")}>
                  <List /> <span>Lista con viñetas</span>
                </button>
                <button type="button" className="popover-item" onClick={() => transformBlockType("ol")}>
                  <ListOrdered /> <span>Lista numerada</span>
                </button>
                <button type="button" className="popover-item" onClick={() => transformBlockType("pre")}>
                  <Code /> <span>Código</span>
                </button>
              </div>
            )}

            {/* POPOVER 2: ALINEACIÓN */}
            {showAlignMenu && (
              <div className="gutenberg-tb-popover align-popover" onMouseDown={(e) => e.preventDefault()}>
                <button type="button" className="popover-item" onClick={() => applyAlignment("justifyLeft")}>
                  <AlignLeft /> <span>Alinear a la izquierda</span>
                </button>
                <button type="button" className="popover-item" onClick={() => applyAlignment("justifyCenter")}>
                  <AlignCenter /> <span>Centrar</span>
                </button>
                <button type="button" className="popover-item" onClick={() => applyAlignment("justifyRight")}>
                  <AlignRight /> <span>Alinear a la derecha</span>
                </button>
                <button type="button" className="popover-item" onClick={() => applyAlignment("justifyFull")}>
                  <AlignJustify /> <span>Justificar</span>
                </button>
              </div>
            )}

            {/* POPOVER 3: INPUT DE ENLACE RÁPIDO */}
            {showLinkInput && (
              <div className="gutenberg-tb-popover link-input-popover" onMouseDown={(e) => e.stopPropagation()}>
                <input
                  type="url"
                  placeholder="https://tu-enlace.com..."
                  value={linkInputUrl}
                  onChange={(e) => setLinkInputUrl(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      handleApplyLink();
                    }
                  }}
                  autoFocus
                  className="tb-url-input"
                />
                <button type="button" className="tb-url-submit-btn" onClick={handleApplyLink}>
                  Aplicar
                </button>
              </div>
            )}

            {/* POPOVER 4: PALETA DE COLORES Y RESALTADO */}
            {showColorPicker && (
              <div className="gutenberg-tb-popover color-picker-popover" onMouseDown={(e) => e.preventDefault()}>
                <div className="color-tabs-switcher">
                  <button
                    type="button"
                    className={`color-tab-btn ${colorTab === "text" ? "active" : ""}`}
                    onClick={() => setColorTab("text")}
                  >
                    Color de Texto
                  </button>
                  <button
                    type="button"
                    className={`color-tab-btn ${colorTab === "background" ? "active" : ""}`}
                    onClick={() => setColorTab("background")}
                  >
                    Resaltado / Fondo
                  </button>
                </div>

                {colorTab === "text" ? (
                  <div className="color-palette-section">
                    <span className="color-palette-title">
                      {blockToolbar.hasSelection ? "Color para el texto marcado:" : "Color de texto del bloque:"}
                    </span>
                    <div className="colors-grid-dots">
                      {[
                        { name: "Blanco", hex: "#ffffff" },
                        { name: "Cyan", hex: "#38bdf8" },
                        { name: "Verde Neón", hex: "#16c96f" },
                        { name: "Amarillo", hex: "#fbbf24" },
                        { name: "Naranja", hex: "#f97316" },
                        { name: "Rojo", hex: "#ef4444" },
                        { name: "Púrpura", hex: "#a855f7" },
                        { name: "Gris Suave", hex: "#94a3b8" },
                      ].map((c) => (
                        <button
                          key={c.hex}
                          type="button"
                          className="color-circle-dot"
                          style={{ backgroundColor: c.hex }}
                          onClick={() => applyColor("text", c.hex)}
                          title={c.name}
                        />
                      ))}
                    </div>

                    <div className="custom-color-picker-row">
                      <label>Personalizado:</label>
                      <input
                        type="color"
                        className="native-color-picker"
                        onChange={(e) => applyColor("text", e.target.value)}
                      />
                      <button
                        type="button"
                        className="reset-color-btn"
                        onClick={() => applyColor("text", "inherit")}
                        title="Restablecer color predeterminado"
                      >
                        <RotateCcw />
                        <span>Restablecer</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="color-palette-section">
                    <span className="color-palette-title">
                      {blockToolbar.hasSelection ? "Resaltado para el texto marcado:" : "Color de fondo del bloque:"}
                    </span>
                    <div className="colors-grid-dots">
                      {[
                        { name: "Transparente", hex: "transparent" },
                        { name: "Cyan Suave", hex: "rgba(56, 189, 248, 0.25)" },
                        { name: "Verde Suave", hex: "rgba(22, 201, 111, 0.25)" },
                        { name: "Amarillo Suave", hex: "rgba(251, 191, 36, 0.25)" },
                        { name: "Rojo Suave", hex: "rgba(239, 68, 68, 0.25)" },
                        { name: "Púrpura Suave", hex: "rgba(168, 85, 247, 0.25)" },
                        { name: "Naranja Suave", hex: "rgba(249, 115, 22, 0.25)" },
                        { name: "Fondo Oscuro", hex: "#07131e" },
                      ].map((c) => (
                        <button
                          key={c.hex}
                          type="button"
                          className={`color-circle-dot ${c.hex === "transparent" ? "transparent-dot" : ""}`}
                          style={{ backgroundColor: c.hex }}
                          onClick={() => applyColor("background", c.hex)}
                          title={c.name}
                        />
                      ))}
                    </div>

                    <div className="custom-color-picker-row">
                      <label>Personalizado:</label>
                      <input
                        type="color"
                        className="native-color-picker"
                        onChange={(e) => applyColor("background", e.target.value)}
                      />
                      <button
                        type="button"
                        className="reset-color-btn"
                        onClick={() => applyColor("background", "transparent")}
                        title="Quitar fondo / resaltado"
                      >
                        <RotateCcw />
                        <span>Quitar</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* POPOVER 5: MÁS OPCIONES */}
            {showMoreMenu && (
              <div className="gutenberg-tb-popover more-menu-popover" onMouseDown={(e) => e.preventDefault()}>
                <button type="button" className="popover-item" onClick={duplicateBlock}>
                  <Copy /> <span>Duplicar bloque</span>
                </button>
                <button type="button" className="popover-item" onClick={() => insertBlockRelative("before")}>
                  <Plus /> <span>Añadir bloque antes</span>
                </button>
                <button type="button" className="popover-item" onClick={() => insertBlockRelative("after")}>
                  <Plus /> <span>Añadir bloque después</span>
                </button>
                <button type="button" className="popover-item" onClick={() => formatDoc("removeFormat")}>
                  <RotateCcw /> <span>Limpiar formato</span>
                </button>
                <span className="popover-divider" />
                <button type="button" className="popover-item danger" onClick={deleteActiveBlock}>
                  <Trash2 /> <span>Eliminar bloque</span>
                </button>
              </div>
            )}
          </div>
        )}

        {/* Input oculto para subir imágenes al editor */}
        <input
          type="file"
          ref={editorImageInputRef}
          onChange={handleUploadEditorImage}
          accept="image/*"
          style={{ display: "none" }}
        />

        {/* =================================================================
            PANEL LATERAL DE AJUSTES (ESTILO WORDPRESS CON TEMA TECHLAB CYBER)
            ================================================================= */}
        {isSidebarOpen && (
          <aside className="techlab-sidebar-panel">
            {/* Cabecera del Sidebar con Pestañas Entrada | Bloque */}
            <div className="sidebar-header-tabs">
              <div className="tabs-nav-group">
                <button
                  type="button"
                  className={`sb-tab-item ${sidebarTab === "post" ? "active" : ""}`}
                  onClick={() => setSidebarTab("post")}
                >
                  Entrada
                </button>
                <button
                  type="button"
                  className={`sb-tab-item ${sidebarTab === "block" ? "active" : ""}`}
                  onClick={() => setSidebarTab("block")}
                >
                  Bloque
                </button>
              </div>
              <button
                type="button"
                className="sb-close-icon-btn"
                onClick={() => setIsSidebarOpen(false)}
                title="Cerrar ajustes"
              >
                <X />
              </button>
            </div>

            {/* Contenido scrolleable del Sidebar */}
            <div className="sidebar-scrollable-body">
              {sidebarTab === "post" && (
                <>
                  {/* Resumen del documento */}
                  <div className="sb-doc-summary-bar">
                    <div className="doc-icon-title">
                      <Edit2 />
                      <span>{title || "Sin título"}</span>
                    </div>
                    <button className="more-dots-btn"><MoreVertical /></button>
                  </div>

                  {/* 1. IMAGEN DESTACADA (CON DRAG & DROP Y TAMAÑO FIJO PERMANENTE) */}
                  <div className="sb-featured-image-container">
                    {featuredImage ? (
                      <div className="featured-image-fixed-box">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img src={featuredImage} alt="Imagen destacada" />
                        <div className="featured-image-hover-actions">
                          <button
                            type="button"
                            className="btn-action-replace"
                            onClick={() => fileInputRef.current?.click()}
                          >
                            Reemplazar
                          </button>
                          <button
                            type="button"
                            className="btn-action-delete"
                            onClick={() => setFeaturedImage("")}
                          >
                            Eliminar
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div
                        className={`featured-image-placeholder-btn ${isDragging ? "dragging" : ""}`}
                        onClick={() => fileInputRef.current?.click()}
                        onDragOver={handleDragOver}
                        onDragLeave={handleDragLeave}
                        onDrop={handleDrop}
                      >
                        {isUploadingImage ? (
                          <div className="upload-loading-view">
                            <Loader2 className="animate-spin text-green" />
                            <span>Subiendo imagen...</span>
                          </div>
                        ) : (
                          <span>{isDragging ? "¡Suelta la imagen aquí!" : "Establecer la imagen destacada"}</span>
                        )}
                      </div>
                    )}
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        if (f) processFeaturedImageUpload(f);
                      }}
                      accept="image/*"
                      style={{ display: "none" }}
                    />
                  </div>

                  {/* Extracto */}
                  <div className="sb-excerpt-action-row">
                    {!showExcerptField && !excerpt ? (
                      <button
                        type="button"
                        className="btn-action-link"
                        onClick={() => setShowExcerptField(true)}
                      >
                        Añade un extracto...
                      </button>
                    ) : (
                      <div className="excerpt-field-wrap">
                        <label className="meta-item-label">Extracto:</label>
                        <textarea
                          rows={2}
                          value={excerpt}
                          onChange={(e) => setExcerpt(e.target.value)}
                          placeholder="Escribe un extracto..."
                          className="techlab-textarea-sm"
                        />
                      </div>
                    )}
                  </div>

                  {/* Texto de última edición */}
                  <div className="sb-last-edited-label">
                    Editado por última vez {lastSavedTime}.
                  </div>

                  {/* Tabla de Metadatos */}
                  <div className="sb-metadata-list">
                    {/* Estado */}
                    <div className="meta-list-row">
                      <span className="meta-row-name">Estado</span>
                      <div className="meta-row-val">
                        <select
                          value={status}
                          onChange={(e) => setStatus(e.target.value as "Borrador" | "Publicado" | "Privado")}
                          className="techlab-meta-select"
                        >
                          <option value="Borrador">🔵 Borrador</option>
                          <option value="Publicado">🟢 Publicado</option>
                          <option value="Privado">🟣 Privado</option>
                        </select>
                      </div>
                    </div>

                    {/* Publicar */}
                    <div className="meta-list-row">
                      <span className="meta-row-name">Publicar</span>
                      <span className="meta-row-link">{publishDate}</span>
                    </div>

                    {/* Slug */}
                    <div className="meta-list-row">
                      <span className="meta-row-name">Slug</span>
                      <button
                        type="button"
                        className="meta-row-link"
                        onClick={() => setShowSlugModal(true)}
                      >
                        {slug || "slug-del-post"}
                      </button>
                    </div>

                    {/* Autor */}
                    <div className="meta-list-row">
                      <span className="meta-row-name">Autor</span>
                      <span className="meta-row-link">{authorName}</span>
                    </div>

                    {/* Plantilla */}
                    <div className="meta-list-row">
                      <span className="meta-row-name">Plantilla</span>
                      <span className="meta-row-link">Entradas individuales</span>
                    </div>

                    {/* Comentarios */}
                    <div className="meta-list-row">
                      <span className="meta-row-name">Comentarios</span>
                      <button
                        type="button"
                        className="meta-row-link"
                        onClick={() => setCommentsOpen(!commentsOpen)}
                      >
                        {commentsOpen ? "Abiertos" : "Cerrados"}
                      </button>
                    </div>

                    {/* Formato */}
                    <div className="meta-list-row">
                      <span className="meta-row-name">Formato</span>
                      <span className="meta-row-link">Estándar</span>
                    </div>
                  </div>

                  {/* =========================================================
                      ACORDEÓN 1: CATEGORÍAS (JERARQUÍA PADRE E HIJO EN MYSQL)
                      ========================================================= */}
                  <div className="sb-accordion-card">
                    <button
                      type="button"
                      className="accordion-toggle-btn"
                      onClick={() => setCategoriesOpen(!categoriesOpen)}
                    >
                      <span>Categorías</span>
                      {categoriesOpen ? <ChevronUp /> : <ChevronDown />}
                    </button>

                    {categoriesOpen && (
                      <div className="accordion-content-box">
                        {/* Lista con checkboxes y sangría jerárquica */}
                        <div className="categories-scroll-area">
                          {categories.length === 0 ? (
                            <label className="cat-checkbox-item">
                              <input type="checkbox" defaultChecked />
                              <span>Sin categoría</span>
                            </label>
                          ) : (
                            rootCategories.map((rootCat) => {
                              const children = getChildCategories(rootCat.id);
                              const isChecked = selectedCategories.includes(rootCat.id);

                              return (
                                <div key={rootCat.id} className="category-tree-block">
                                  {/* Categoría Padre */}
                                  <label className="cat-checkbox-item parent">
                                    <input
                                      type="checkbox"
                                      checked={isChecked}
                                      onChange={() => toggleCategorySelection(rootCat.id)}
                                    />
                                    <span>{rootCat.name}</span>
                                  </label>

                                  {/* Categorías Hijas */}
                                  {children.map((childCat) => {
                                    const isChildChecked = selectedCategories.includes(childCat.id);
                                    return (
                                      <label key={childCat.id} className="cat-checkbox-item child">
                                        <CornerDownRight className="tree-arrow" />
                                        <input
                                          type="checkbox"
                                          checked={isChildChecked}
                                          onChange={() => toggleCategorySelection(childCat.id)}
                                        />
                                        <span>{childCat.name}</span>
                                      </label>
                                    );
                                  })}
                                </div>
                              );
                            })
                          )}
                        </div>

                        {/* Botón Añadir categoría */}
                        {!showAddCatForm ? (
                          <button
                            type="button"
                            className="btn-action-link add-cat-btn"
                            onClick={() => setShowAddCatForm(true)}
                          >
                            Añadir categoría
                          </button>
                        ) : (
                          <div className="inline-create-cat-form">
                            <label className="field-hint-label">Nombre de nueva categoría:</label>
                            <input
                              type="text"
                              value={newCatName}
                              onChange={(e) => setNewCatName(e.target.value)}
                              placeholder="Nombre de categoría..."
                              className="techlab-input-sm"
                            />

                            <label className="field-hint-label" style={{ marginTop: 8 }}>
                              Categoría superior:
                            </label>
                            <select
                              value={newCatParentId}
                              onChange={(e) => setNewCatParentId(e.target.value)}
                              className="techlab-select-sm"
                            >
                              <option value="">— Ninguna —</option>
                              {categories.map((c) => (
                                <option key={c.id} value={c.id}>
                                  {c.parent ? `— ${c.name}` : c.name}
                                </option>
                              ))}
                            </select>

                            <div className="create-cat-btn-row">
                              <button
                                type="button"
                                className="btn-save-cat"
                                onClick={handleCreateCategory}
                                disabled={isCreatingCat}
                              >
                                {isCreatingCat ? "Guardando..." : "Añadir nueva categoría"}
                              </button>
                              <button
                                type="button"
                                className="btn-cancel-cat"
                                onClick={() => setShowAddCatForm(false)}
                              >
                                Cancelar
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* =========================================================
                      ACORDEÓN 2: ETIQUETAS
                      ========================================================= */}
                  <div className="sb-accordion-card">
                    <button
                      type="button"
                      className="accordion-toggle-btn"
                      onClick={() => setTagsOpen(!tagsOpen)}
                    >
                      <span>Etiquetas</span>
                      {tagsOpen ? <ChevronUp /> : <ChevronDown />}
                    </button>

                    {tagsOpen && (
                      <div className="accordion-content-box">
                        <label className="field-header-text">AÑADIR ETIQUETA</label>
                        <input
                          type="text"
                          value={tagInput}
                          onChange={(e) => setTagInput(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter" || e.key === ",") {
                              e.preventDefault();
                              handleAddTag();
                            }
                          }}
                          className="techlab-input-tags"
                        />
                        <p className="field-help-text">Separar con comas o la tecla Intro.</p>

                        <div className="tags-badge-cloud">
                          {tags.map((t) => (
                            <span key={t} className="techlab-tag-chip">
                              {t}
                              <button type="button" onClick={() => handleRemoveTag(t)}>
                                <X />
                              </button>
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </>
              )}

              {/* PESTAÑA 2: BLOQUE */}
              {sidebarTab === "block" && (
                <div className="sb-block-tab-content">
                  <div className="block-type-badge">
                    <Pilcrow />
                    <div>
                      <strong>Párrafo</strong>
                      <small>Bloque de texto estándar</small>
                    </div>
                  </div>
                  <div className="block-control-group">
                    <label className="field-hint-label">Tamaño de tipografía:</label>
                    <select className="techlab-select-sm">
                      <option>Predeterminado (16px)</option>
                      <option>Pequeño (14px)</option>
                      <option>Medio (18px)</option>
                      <option>Grande (24px)</option>
                    </select>
                  </div>
                </div>
              )}
            </div>
          </aside>
        )}
      </div>

      {/* =================================================================
          MODALES (SLUG, ENLACE & VIDEO)
          ================================================================= */}
      {showSlugModal && (
        <div className="techlab-modal-backdrop">
          <div className="techlab-modal-card">
            <div className="modal-top">
              <h3>Editar enlace permanente</h3>
              <button onClick={() => setShowSlugModal(false)}><X /></button>
            </div>
            <div className="modal-body-content">
              <label>Slug de la URL:</label>
              <input
                type="text"
                value={slug}
                onChange={(e) => {
                  setSlug(e.target.value);
                  setIsSlugEdited(true);
                }}
                className="techlab-input-sm"
              />
              <small style={{ color: "#94a3b8", display: "block", marginTop: 6 }}>
                URL final: {origin || "http://localhost:3000"}/posts/{slug || "mi-post"}
              </small>
            </div>
            <div className="modal-actions-bar">
              <button className="btn-modal-green" onClick={() => setShowSlugModal(false)}>
                Guardar Slug
              </button>
            </div>
          </div>
        </div>
      )}

      {showLinkModal && (
        <div className="techlab-modal-backdrop">
          <div className="techlab-modal-card">
            <div className="modal-top">
              <h3>Insertar enlace</h3>
              <button onClick={() => setShowLinkModal(false)}><X /></button>
            </div>
            <div className="modal-body-content">
              <label>Texto:</label>
              <input
                type="text"
                placeholder="ej. Visitar sitio web"
                value={linkText}
                onChange={(e) => setLinkText(e.target.value)}
                className="techlab-input-sm"
              />
              <label style={{ marginTop: 10 }}>URL de destino:</label>
              <input
                type="url"
                placeholder="https://ejemplo.com"
                value={linkUrl}
                onChange={(e) => setLinkUrl(e.target.value)}
                className="techlab-input-sm"
              />
            </div>
            <div className="modal-actions-bar">
              <button className="btn-modal-ghost" onClick={() => setShowLinkModal(false)}>
                Cancelar
              </button>
              <button className="btn-modal-green" onClick={handleInsertLink}>
                Insertar Enlace
              </button>
            </div>
          </div>
        </div>
      )}

      {showVideoModal && (
        <div className="techlab-modal-backdrop">
          <div className="techlab-modal-card">
            <div className="modal-top">
              <h3>Insertar video embed</h3>
              <button onClick={() => setShowVideoModal(false)}><X /></button>
            </div>
            <div className="modal-body-content">
              <label>URL de YouTube / Vimeo:</label>
              <input
                type="url"
                placeholder="https://www.youtube.com/watch?v=..."
                value={videoUrl}
                onChange={(e) => setVideoUrl(e.target.value)}
                className="techlab-input-sm"
              />
            </div>
            <div className="modal-actions-bar">
              <button className="btn-modal-ghost" onClick={() => setShowVideoModal(false)}>
                Cancelar
              </button>
              <button className="btn-modal-green" onClick={handleInsertVideo}>
                Insertar Video
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ESTILOS TECHLAB CYBER DARK CON EXPERIENCIA GUTENBERG FLUIDA */}
      <style jsx>{`
        .techlab-gutenberg-root {
          min-height: 100vh;
          display: flex;
          flex-direction: column;
          background: #03070b;
          color: #f1f5f9;
          margin: -24px -28px;
          position: relative;
        }

        /* Toast */
        .techlab-toast {
          position: fixed;
          top: 70px;
          right: 24px;
          z-index: 1000;
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 12px 18px;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 600;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.6);
          animation: slideIn 0.25s ease;
        }

        .techlab-toast.success {
          background: #062316;
          border: 1px solid #16c96f;
          color: #a7f3d0;
        }

        .techlab-toast.error {
          background: #270d0d;
          border: 1px solid #ef4444;
          color: #fca5a5;
        }

        @keyframes slideIn {
          from { transform: translateY(-20px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }

        /* Header Bar */
        .techlab-editor-header {
          height: 56px;
          background: #040c14;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 0 16px;
          position: sticky;
          top: 0;
          z-index: 40;
        }

        .teh-left {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .teh-back-btn {
          width: 32px;
          height: 32px;
          border-radius: 6px;
          background: rgba(255, 255, 255, 0.04);
          border: 1px solid rgba(255, 255, 255, 0.08);
          color: #cbd5e1;
          display: grid;
          place-items: center;
          text-decoration: none;
          transition: all 0.15s;
        }

        .teh-back-btn:hover {
          background: rgba(255, 255, 255, 0.1);
          color: #16c96f;
        }

        .teh-back-btn :global(svg) {
          width: 16px;
          height: 16px;
        }

        .teh-inserter-main-btn {
          width: 32px;
          height: 32px;
          background: #16c96f;
          color: #030b12;
          border: none;
          border-radius: 6px;
          display: grid;
          place-items: center;
          cursor: pointer;
          transition: all 0.2s;
          box-shadow: 0 0 12px rgba(22, 201, 111, 0.3);
        }

        .teh-inserter-main-btn:hover,
        .teh-inserter-main-btn.active {
          background: #20df7b;
          transform: scale(1.05);
        }

        .teh-inserter-main-btn :global(svg) {
          width: 17px;
          height: 17px;
          stroke-width: 2.5;
        }

        .teh-undo-redo {
          display: flex;
          align-items: center;
          gap: 2px;
          margin-left: 2px;
        }

        .teh-icon-btn {
          width: 32px;
          height: 32px;
          background: transparent;
          border: none;
          color: #94a3b8;
          border-radius: 6px;
          display: grid;
          place-items: center;
          cursor: pointer;
          transition: all 0.15s;
        }

        .teh-icon-btn:hover {
          color: #ffffff;
          background: rgba(255, 255, 255, 0.06);
        }

        .teh-icon-btn :global(svg) {
          width: 15px;
          height: 15px;
        }

        .teh-center {
          display: flex;
          align-items: center;
        }

        .teh-doc-badge {
          background: rgba(255, 255, 255, 0.04);
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 6px;
          padding: 4px 14px;
          font-size: 12px;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .doc-name {
          color: #ffffff;
          font-weight: 600;
        }

        .doc-dot {
          color: #64748b;
        }

        .doc-status {
          color: #16c96f;
          font-weight: 500;
          font-size: 11px;
        }

        .teh-right {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .teh-draft-btn {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 6px 14px;
          height: 34px;
          background: rgba(255, 255, 255, 0.04);
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: #94a3b8;
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
          border-radius: 6px;
          transition: all 0.25s ease;
        }

        .teh-draft-btn:hover:not(:disabled) {
          background: rgba(255, 255, 255, 0.08);
          color: #38bdf8;
          border-color: rgba(56, 189, 248, 0.3);
        }

        .teh-draft-btn.saving {
          background: rgba(56, 189, 248, 0.12) !important;
          border-color: rgba(56, 189, 248, 0.4) !important;
          color: #38bdf8 !important;
        }

        .teh-draft-btn.saved {
          background: rgba(22, 201, 111, 0.15) !important;
          border-color: rgba(22, 201, 111, 0.4) !important;
          color: #16c96f !important;
          animation: pulse-saved 0.35s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        @keyframes pulse-saved {
          0% { transform: scale(0.96); }
          50% { transform: scale(1.04); }
          100% { transform: scale(1); }
        }

        .btn-autosave-indicator {
          display: inline-flex;
          align-items: center;
          gap: 6px;
        }

        .btn-autosave-indicator :global(svg) {
          width: 14px;
          height: 14px;
        }

        .teh-sidebar-toggle {
          width: 32px;
          height: 32px;
          background: rgba(255, 255, 255, 0.03);
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 6px;
          color: #94a3b8;
          display: grid;
          place-items: center;
          cursor: pointer;
        }

        .teh-sidebar-toggle.active {
          background: rgba(22, 201, 111, 0.1);
          color: #16c96f;
          border-color: rgba(22, 201, 111, 0.3);
        }

        .teh-sidebar-toggle :global(svg) {
          width: 15px;
          height: 15px;
        }

        .teh-publish-neon-btn {
          height: 34px;
          padding: 0 16px;
          border-radius: 6px;
          background: linear-gradient(110deg, #12b85f, #18d878);
          border: 1px solid rgba(67, 255, 147, 0.4);
          color: #030b12;
          font-size: 12px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
          box-shadow: 0 0 16px rgba(22, 201, 111, 0.35);
          transition: all 0.2s;
        }

        .teh-publish-neon-btn:hover:not(:disabled) {
          background: #20df7b;
          transform: translateY(-1px);
        }

        .teh-publish-neon-btn :global(svg) {
          width: 14px;
          height: 14px;
        }

        /* Banner de Publicación */
        .techlab-published-banner {
          background: linear-gradient(135deg, rgba(6, 35, 22, 0.98), rgba(4, 20, 14, 0.98));
          border-bottom: 1px solid rgba(22, 201, 111, 0.4);
          padding: 10px 20px;
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .banner-left-info {
          display: flex;
          align-items: center;
          gap: 10px;
          font-size: 12px;
        }

        .banner-left-info :global(svg) {
          color: #16c96f;
          width: 18px;
          height: 18px;
        }

        .published-link-url {
          color: #38bdf8;
          margin-left: 8px;
          text-decoration: underline;
          display: inline-flex;
          align-items: center;
          gap: 4px;
        }

        .copy-link-neon-btn {
          height: 28px;
          padding: 0 12px;
          border-radius: 4px;
          background: rgba(22, 201, 111, 0.15);
          border: 1px solid rgba(22, 201, 111, 0.35);
          color: #16c96f;
          font-size: 11px;
          font-weight: 600;
          cursor: pointer;
        }

        /* Full Inserter Drawer */
        .full-inserter-drawer {
          position: fixed;
          top: 56px;
          left: 0;
          bottom: 0;
          width: 320px;
          background: #040c14;
          border-right: 1px solid rgba(255, 255, 255, 0.08);
          z-index: 90;
          display: flex;
          flex-direction: column;
          box-shadow: 10px 0 30px rgba(0, 0, 0, 0.5);
          animation: slideDrawer 0.2s ease;
        }

        @keyframes slideDrawer {
          from { transform: translateX(-100%); }
          to { transform: translateX(0); }
        }

        .drawer-header {
          height: 48px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 0 16px;
        }

        .drawer-tabs {
          display: flex;
          gap: 16px;
          font-size: 13px;
          font-weight: 600;
        }

        .drawer-tabs .active {
          color: #16c96f;
        }

        .drawer-tabs span:not(.active) {
          color: #64748b;
          cursor: pointer;
        }

        .close-drawer-btn {
          background: none;
          border: none;
          color: #94a3b8;
          cursor: pointer;
        }

        .drawer-search-wrap {
          padding: 12px 16px;
          position: relative;
          display: flex;
          align-items: center;
        }

        .drawer-search-wrap :global(svg) {
          position: absolute;
          left: 26px;
          width: 14px;
          height: 14px;
          color: #64748b;
        }

        .drawer-search-wrap input {
          width: 100%;
          height: 34px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 6px;
          padding: 0 12px 0 34px;
          color: #ffffff;
          font-size: 12px;
          outline: none;
        }

        .drawer-search-wrap input:focus {
          border-color: #16c96f;
        }

        .drawer-scroll-content {
          flex: 1;
          overflow-y: auto;
          padding: 0 16px 20px;
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        .category-heading {
          font-size: 10px;
          font-weight: 700;
          color: #64748b;
          letter-spacing: 0.5px;
          margin-bottom: 8px;
          display: block;
        }

        .blocks-grid-3 {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 8px;
        }

        .block-tile {
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.06);
          border-radius: 8px;
          padding: 12px 6px;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 6px;
          color: #cbd5e1;
          cursor: grab;
          transition: all 0.15s;
          user-select: none;
        }

        .block-tile:active {
          cursor: grabbing;
        }

        .block-tile:hover {
          border-color: rgba(22, 201, 111, 0.4);
          background: rgba(22, 201, 111, 0.08);
          color: #16c96f;
        }

        .block-tile :global(svg) {
          width: 18px;
          height: 18px;
        }

        .block-tile span {
          font-size: 11px;
        }

        /* Body Layout */
        .techlab-editor-body {
          display: grid;
          flex: 1;
          background: #03070b;
          min-height: calc(100vh - 56px);
        }

        .techlab-editor-body.sidebar-visible {
          grid-template-columns: 1fr 340px;
        }

        .techlab-editor-body.sidebar-hidden {
          grid-template-columns: 1fr;
        }

        /* Canvas Adaptable & Espacioso */
        .editor-canvas-container {
          padding: 40px clamp(20px, 4vw, 60px) 120px;
          display: flex;
          justify-content: center;
          overflow-y: auto;
          width: 100%;
        }

        .editor-canvas {
          width: 100%;
          max-width: min(1180px, 100%);
          display: flex;
          flex-direction: column;
          gap: 28px;
          transition: max-width 0.2s ease;
        }

        .techlab-editor-body.sidebar-hidden .editor-canvas {
          max-width: min(1320px, 100%);
        }

        .editor-title-row {
          position: relative;
          border: none !important;
          outline: none !important;
        }

        .techlab-title-input {
          width: 100%;
          background: transparent;
          border: none !important;
          border-bottom: none !important;
          outline: none !important;
          box-shadow: none !important;
          font-size: 38px;
          font-weight: 800;
          color: #ffffff;
          line-height: 1.25;
          padding: 4px 0;
          letter-spacing: -0.5px;
        }

        .techlab-title-input:focus,
        .techlab-title-input:hover,
        .techlab-title-input:active {
          border: none !important;
          border-bottom: none !important;
          outline: none !important;
          box-shadow: none !important;
        }

        .techlab-title-input::placeholder {
          color: #334155;
        }

        .editor-blocks-zone {
          position: relative;
          min-height: 120px;
        }

        .editor-block-stream-container {
          position: relative;
          display: flex;
          align-items: flex-start;
          width: 100%;
        }

        .techlab-content-editable {
          flex: 1;
          min-height: 80px;
          font-size: 15px;
          line-height: 1.75;
          color: #e2e8f0;
          outline: none;
          border: none;
          padding-right: 42px;
          border-radius: 6px;
          transition: background 0.15s ease;
        }

        .techlab-content-editable.is-drag-over {
          background: rgba(22, 201, 111, 0.05) !important;
          outline: 2px dashed #16c96f !important;
          outline-offset: 4px;
        }

        .techlab-content-editable:empty:before {
          content: attr(data-placeholder);
          color: #475569;
          pointer-events: none;
        }

        /* Inserter [+] Alineado a la Derecha del bloque */
        .block-right-inserter-anchor {
          position: absolute;
          right: 0;
          top: 0;
          z-index: 50;
        }

        .inline-plus-btn-right {
          width: 28px;
          height: 28px;
          border-radius: 6px;
          background: #07131e;
          border: 1px solid rgba(56, 189, 248, 0.3);
          color: #38bdf8;
          display: grid;
          place-items: center;
          cursor: pointer;
          transition: all 0.2s;
          flex-shrink: 0;
        }

        .inline-plus-btn-right:hover {
          background: #0284c7;
          border-color: #38bdf8;
          color: #ffffff;
          transform: scale(1.08);
          box-shadow: 0 0 12px rgba(56, 189, 248, 0.4);
        }

        .inline-plus-btn-right :global(svg) {
          width: 15px;
          height: 15px;
        }

        .inline-blocks-popover-right {
          position: absolute;
          top: 36px;
          right: 0;
          width: 240px;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          padding: 12px;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.7);
          z-index: 80;
        }

        .inline-plus-btn :global(svg) {
          width: 15px;
          height: 15px;
        }

        .inline-plus-hint {
          font-size: 12px;
          color: #475569;
          font-weight: 500;
        }

        .inline-blocks-popover {
          position: absolute;
          top: 38px;
          left: 0;
          width: 240px;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          padding: 12px;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.7);
          z-index: 80;
        }

        .popover-search-box {
          position: relative;
          display: flex;
          align-items: center;
          margin-bottom: 10px;
        }

        .popover-search-box :global(svg) {
          position: absolute;
          left: 8px;
          width: 12px;
          height: 12px;
          color: #64748b;
        }

        .popover-search-box input {
          width: 100%;
          height: 30px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 4px;
          padding: 0 8px 0 26px;
          color: #ffffff;
          font-size: 11px;
          outline: none;
        }

        .popover-blocks-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 6px;
          margin-bottom: 8px;
        }

        .grid-item {
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.05);
          border-radius: 6px;
          padding: 8px 4px;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
          color: #cbd5e1;
          cursor: pointer;
        }

        .grid-item:hover {
          background: rgba(56, 189, 248, 0.1);
          border-color: rgba(56, 189, 248, 0.4);
          color: #38bdf8;
        }

        .grid-item :global(svg) {
          width: 16px;
          height: 16px;
        }

        .grid-item span {
          font-size: 10px;
        }

        .popover-view-all-btn {
          width: 100%;
          height: 28px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 4px;
          color: #cbd5e1;
          font-size: 11px;
          font-weight: 600;
          cursor: pointer;
        }

        .popover-view-all-btn:hover {
          background: #38bdf8;
          color: #030b12;
        }

        /* =================================================================
            SUITE DE OPTIMIZACIÓN SEO PARA GOOGLE (ESTILO RANK MATH PRO)
            FORMATO AMPLIO, ORGANIZADO Y DE ALTA CALIDAD
            ================================================================= */
        .techlab-pro-seo-suite {
          margin-top: 36px;
          background: #050f18;
          border: 1px solid rgba(56, 189, 248, 0.3);
          border-radius: 14px;
          overflow: hidden;
          box-shadow: 0 20px 50px rgba(0, 0, 0, 0.6), 0 0 30px rgba(56, 189, 248, 0.08);
        }

        .seo-suite-top-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 20px 24px;
          background: #030a10;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .suite-title-area {
          display: flex;
          align-items: center;
          gap: 14px;
        }

        .suite-icon-badge {
          width: 44px;
          height: 44px;
          border-radius: 10px;
          background: rgba(56, 189, 248, 0.12);
          border: 1px solid rgba(56, 189, 248, 0.4);
          color: #38bdf8;
          display: grid;
          place-items: center;
          box-shadow: 0 0 16px rgba(56, 189, 248, 0.2);
        }

        .suite-icon-badge :global(svg) {
          width: 22px;
          height: 22px;
        }

        .suite-title-area h3 {
          font-size: 17px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 4px;
          letter-spacing: -0.3px;
        }

        .suite-title-area p {
          font-size: 12px;
          color: #94a3b8;
          margin: 0;
        }

        .suite-score-badge-card {
          display: flex;
          align-items: center;
          gap: 14px;
          background: #071522;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          padding: 8px 16px;
        }

        .score-text-group {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
        }

        .score-lbl {
          font-size: 10px;
          font-weight: 600;
          color: #64748b;
          text-transform: uppercase;
        }

        .score-text-group strong {
          font-size: 13px;
          font-weight: 800;
        }

        .score-text-group strong.good { color: #16c96f; }
        .score-text-group strong.avg { color: #f59e0b; }
        .score-text-group strong.bad { color: #ef4444; }

        .score-radial-tag {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 6px 14px;
          border-radius: 20px;
          font-size: 14px;
          font-weight: 800;
        }

        .score-radial-tag.good {
          background: rgba(22, 201, 111, 0.15);
          border: 1px solid rgba(22, 201, 111, 0.4);
          color: #16c96f;
          box-shadow: 0 0 12px rgba(22, 201, 111, 0.2);
        }

        .score-radial-tag.avg {
          background: rgba(245, 158, 11, 0.15);
          border: 1px solid rgba(245, 158, 11, 0.4);
          color: #f59e0b;
        }

        .score-radial-tag.bad {
          background: rgba(239, 68, 68, 0.15);
          border: 1px solid rgba(239, 68, 68, 0.4);
          color: #ef4444;
        }

        .score-radial-tag :global(svg) {
          width: 16px;
          height: 16px;
        }

        /* Tabs Nav */
        .seo-suite-tabs-nav {
          display: flex;
          background: #03080e;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
          padding: 0 16px;
          gap: 6px;
        }

        .seo-nav-tab {
          height: 46px;
          padding: 0 16px;
          background: transparent;
          border: none;
          border-bottom: 2px solid transparent;
          color: #94a3b8;
          font-size: 12px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          transition: all 0.15s;
        }

        .seo-nav-tab:hover {
          color: #ffffff;
        }

        .seo-nav-tab.active {
          color: #38bdf8;
          border-bottom-color: #38bdf8;
          background: rgba(56, 189, 248, 0.04);
        }

        .seo-nav-tab :global(svg) {
          width: 15px;
          height: 15px;
        }

        .tab-pill-count {
          font-size: 10px;
          background: rgba(56, 189, 248, 0.15);
          border: 1px solid rgba(56, 189, 248, 0.3);
          color: #38bdf8;
          padding: 2px 6px;
          border-radius: 10px;
        }

        .seo-suite-content-body {
          padding: 24px;
        }

        /* Pestaña 1: General */
        .tab-pane-general {
          display: flex;
          flex-direction: column;
          gap: 24px;
        }

        /* Google SERP Master Card */
        .google-serp-master-card {
          background: #03080e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          padding: 16px 20px;
          display: flex;
          flex-direction: column;
          gap: 14px;
        }

        .serp-toolbar-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          border-bottom: 1px solid rgba(255, 255, 255, 0.06);
          padding-bottom: 10px;
        }

        .serp-badge-title {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 12px;
          color: #cbd5e1;
        }

        .g-logo {
          width: 20px;
          height: 20px;
          border-radius: 50%;
          background: #ffffff;
          color: #1a73e8;
          font-weight: 900;
          font-size: 12px;
          display: grid;
          place-items: center;
        }

        .serp-view-mode-buttons {
          display: flex;
          gap: 4px;
          background: #071522;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 6px;
          padding: 2px;
        }

        .serp-view-mode-buttons button {
          height: 28px;
          padding: 0 12px;
          background: none;
          border: none;
          border-radius: 4px;
          color: #94a3b8;
          font-size: 11px;
          font-weight: 600;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
          transition: all 0.15s;
        }

        .serp-view-mode-buttons button.active {
          background: #0284c7;
          color: #ffffff;
        }

        .serp-view-mode-buttons button :global(svg) {
          width: 13px;
          height: 13px;
        }

        .google-snippet-frame {
          padding: 14px 18px;
          background: #181a1b;
          border: 1px solid rgba(255, 255, 255, 0.06);
          border-radius: 8px;
          display: flex;
          flex-direction: column;
          gap: 6px;
          font-family: Arial, sans-serif;
        }

        .google-snippet-frame.mobile-mode {
          max-width: 420px;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
          border-left: 3px solid #38bdf8;
        }

        .snippet-top-row {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .google-favicon-circle {
          font-size: 13px;
        }

        .snippet-hierarchy {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 12px;
          color: #bdc1c6;
        }

        .brand-name {
          font-weight: 600;
          color: #e8eaed;
        }

        .sep { color: #5f6368; }
        .url-path { color: #9aa0a6; font-size: 11px; }

        .snippet-heading {
          font-size: 18px;
          font-weight: 400;
          color: #8ab4f8;
          margin: 4px 0 2px;
          line-height: 1.35;
          cursor: pointer;
        }

        .snippet-heading:hover {
          text-decoration: underline;
        }

        .snippet-text {
          font-size: 13px;
          color: #bdc1c6;
          line-height: 1.5;
          margin: 0;
        }

        /* Formulario Espacioso */
        .seo-form-spacious-grid {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        .form-field-row {
          display: grid;
          grid-template-columns: 280px 1fr;
          gap: 20px;
          padding: 16px 0;
          border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        .form-field-row:last-child {
          border-bottom: none;
        }

        .field-meta-info {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .field-meta-info label {
          font-size: 13px;
          font-weight: 700;
          color: #f1f5f9;
          display: inline-flex;
          align-items: center;
          gap: 8px;
        }

        .field-meta-info label :global(svg) {
          width: 15px;
          height: 15px;
          color: #38bdf8;
        }

        .field-meta-info p {
          font-size: 11px;
          color: #64748b;
          margin: 0;
          line-height: 1.4;
        }

        .field-input-box {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .input-with-counter-wrap {
          position: relative;
          display: flex;
          align-items: center;
        }

        .wide-seo-input {
          width: 100%;
          height: 42px;
          background: #03080e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          padding: 0 100px 0 14px;
          color: #ffffff;
          font-size: 13px;
          outline: none;
          transition: border-color 0.2s, box-shadow 0.2s;
        }

        .wide-seo-input:focus {
          border-color: #38bdf8;
          box-shadow: 0 0 16px rgba(56, 189, 248, 0.2);
        }

        .wide-seo-textarea {
          width: 100%;
          background: #03080e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          padding: 12px 14px;
          color: #ffffff;
          font-size: 13px;
          outline: none;
          resize: vertical;
          font-family: inherit;
          line-height: 1.5;
          transition: border-color 0.2s, box-shadow 0.2s;
        }

        .wide-seo-textarea:focus {
          border-color: #38bdf8;
          box-shadow: 0 0 16px rgba(56, 189, 248, 0.2);
        }

        .counter-pill {
          position: absolute;
          right: 10px;
          top: 10px;
          font-size: 11px;
          font-weight: 700;
          padding: 3px 8px;
          border-radius: 4px;
        }

        .counter-pill.good { background: rgba(22, 201, 111, 0.15); color: #16c96f; }
        .counter-pill.neutral { background: rgba(255, 255, 255, 0.06); color: #94a3b8; }
        .counter-pill.warn { background: rgba(245, 158, 11, 0.15); color: #f59e0b; }

        .char-progress-bar {
          width: 100%;
          height: 3px;
          background: rgba(255, 255, 255, 0.06);
          border-radius: 2px;
          overflow: hidden;
        }

        .progress-fill {
          height: 100%;
          transition: width 0.2s;
        }

        .progress-fill.good { background: #16c96f; }
        .progress-fill.neutral { background: #38bdf8; }
        .progress-fill.warn { background: #f59e0b; }

        /* Pestaña 2: Auditoría */
        .tab-pane-analysis {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        .analysis-summary-banner {
          display: flex;
          align-items: center;
          gap: 16px;
          background: #03080e;
          border: 1px solid rgba(22, 201, 111, 0.3);
          border-radius: 10px;
          padding: 16px 20px;
        }

        .banner-icon {
          width: 40px;
          height: 40px;
          border-radius: 8px;
          background: rgba(22, 201, 111, 0.12);
          color: #16c96f;
          display: grid;
          place-items: center;
          flex-shrink: 0;
        }

        .banner-icon :global(svg) {
          width: 20px;
          height: 20px;
        }

        .banner-texts h4 {
          font-size: 14px;
          font-weight: 700;
          color: #ffffff;
          margin: 0 0 2px;
        }

        .banner-texts p {
          font-size: 12px;
          color: #94a3b8;
          margin: 0;
        }

        .banner-texts strong {
          color: #16c96f;
        }

        .audit-cards-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 14px;
        }

        .audit-card-item {
          background: #03080e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          padding: 16px;
          display: flex;
          align-items: flex-start;
          gap: 14px;
        }

        .audit-card-item.pass {
          border-left: 3px solid #16c96f;
        }

        .audit-card-item.fail {
          border-left: 3px solid #64748b;
        }

        .audit-status-icon {
          margin-top: 2px;
        }

        .audit-card-item.pass .audit-status-icon { color: #16c96f; }
        .audit-card-item.fail .audit-status-icon { color: #64748b; }

        .audit-status-icon :global(svg) {
          width: 18px;
          height: 18px;
        }

        .audit-info {
          display: flex;
          flex-direction: column;
          gap: 2px;
        }

        .audit-category {
          font-size: 10px;
          font-weight: 700;
          color: #38bdf8;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .audit-info strong {
          font-size: 13px;
          color: #f1f5f9;
        }

        .audit-info p {
          font-size: 11px;
          color: #94a3b8;
          margin: 2px 0 0;
          line-height: 1.4;
        }

        /* Pestaña 3: Social */
        .tab-pane-social {
          display: flex;
          justify-content: center;
          padding: 10px 0;
        }

        .social-preview-container {
          width: 100%;
          max-width: 520px;
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .social-header-row {
          font-size: 11px;
          font-weight: 700;
          color: #64748b;
          letter-spacing: 0.5px;
        }

        .social-card-simulation {
          background: #03080e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 10px;
          overflow: hidden;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        }

        .social-img-box {
          width: 100%;
          height: 240px;
          overflow: hidden;
        }

        .social-img-box img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .social-img-placeholder {
          width: 100%;
          height: 180px;
          background: #071522;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          gap: 8px;
          color: #64748b;
          font-size: 12px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.06);
        }

        .social-img-placeholder :global(svg) {
          width: 32px;
          height: 32px;
          color: #38bdf8;
        }

        .social-card-body {
          padding: 14px 16px;
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .social-domain {
          font-size: 11px;
          color: #94a3b8;
          text-transform: uppercase;
        }

        .social-card-body h5 {
          font-size: 15px;
          font-weight: 700;
          color: #ffffff;
          margin: 0;
          line-height: 1.3;
        }

        .social-card-body p {
          font-size: 12px;
          color: #94a3b8;
          margin: 0;
          line-height: 1.4;
        }

        /* =================================================================
            BARRA DE HERRAMIENTAS FLOTANTE GUTENBERG Y PALETA DE COLORES
            ================================================================= */
        .gutenberg-floating-block-toolbar {
          position: fixed;
          z-index: 120;
          display: flex;
          align-items: center;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.16);
          border-radius: 8px;
          box-shadow: 0 12px 36px rgba(0, 0, 0, 0.8), 0 0 20px rgba(56, 189, 248, 0.12);
          padding: 4px 6px;
          gap: 2px;
          animation: floatInTb 0.15s ease;
        }

        @keyframes floatInTb {
          from { opacity: 0; transform: translateY(4px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .toolbar-btn-group {
          display: flex;
          align-items: center;
          gap: 2px;
          position: relative;
        }

        .tb-btn {
          height: 32px;
          padding: 0 8px;
          background: transparent;
          border: none;
          border-radius: 5px;
          color: #cbd5e1;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 4px;
          cursor: pointer;
          font-size: 12px;
          font-weight: 700;
          transition: all 0.12s ease;
        }

        .tb-btn:hover,
        .tb-btn.active {
          background: rgba(56, 189, 248, 0.12);
          color: #38bdf8;
        }

        .tb-btn :global(svg) {
          width: 15px;
          height: 15px;
        }

        .tb-chevron-icon {
          width: 10px !important;
          height: 10px !important;
          opacity: 0.6;
          margin-left: 2px;
        }

        .tb-movers-duo {
          display: flex;
          flex-direction: column;
          gap: 1px;
          margin-left: 2px;
        }

        .tb-icon-mini-btn {
          width: 16px;
          height: 14px;
          background: transparent;
          border: none;
          border-radius: 3px;
          color: #64748b;
          display: grid;
          place-items: center;
          cursor: pointer;
          padding: 0;
        }

        .tb-icon-mini-btn:hover {
          background: rgba(255, 255, 255, 0.1);
          color: #ffffff;
        }

        .tb-icon-mini-btn :global(svg) {
          width: 10px;
          height: 10px;
        }

        .tb-divider {
          width: 1px;
          height: 20px;
          background: rgba(255, 255, 255, 0.1);
          margin: 0 4px;
        }

        .tb-color-indicator {
          width: 10px;
          height: 10px;
          border-radius: 50%;
          border: 1px solid rgba(255, 255, 255, 0.4);
          display: inline-block;
          margin-left: 2px;
        }

        /* Popovers Comunes */
        .gutenberg-tb-popover {
          position: absolute;
          top: 38px;
          left: 0;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.15);
          border-radius: 8px;
          box-shadow: 0 12px 36px rgba(0, 0, 0, 0.8), 0 0 20px rgba(0, 0, 0, 0.5);
          z-index: 150;
          animation: popoverFade 0.12s ease;
        }

        @keyframes popoverFade {
          from { opacity: 0; transform: translateY(-4px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .popover-header-title {
          display: block;
          padding: 8px 12px 4px;
          font-size: 10px;
          font-weight: 700;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .popover-item {
          width: 100%;
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 8px 14px;
          background: transparent;
          border: none;
          color: #cbd5e1;
          font-size: 12px;
          font-weight: 600;
          text-align: left;
          cursor: pointer;
          transition: background 0.1s;
        }

        .popover-item:hover {
          background: rgba(56, 189, 248, 0.12);
          color: #38bdf8;
        }

        .popover-item :global(svg) {
          width: 14px;
          height: 14px;
          color: #94a3b8;
        }

        .popover-item:hover :global(svg) {
          color: #38bdf8;
        }

        .popover-item.danger {
          color: #ef4444;
        }

        .popover-item.danger:hover {
          background: rgba(239, 68, 68, 0.12);
          color: #f87171;
        }

        .popover-item.danger :global(svg) {
          color: #ef4444;
        }

        .popover-divider {
          display: block;
          height: 1px;
          background: rgba(255, 255, 255, 0.08);
          margin: 4px 0;
        }

        .block-types-popover {
          width: 200px;
          padding: 4px 0;
        }

        .align-popover {
          width: 180px;
          padding: 4px 0;
        }

        .more-menu-popover {
          width: 200px;
          right: 0;
          left: auto;
          padding: 4px 0;
        }

        /* Link Input Popover */
        .link-input-popover {
          width: 280px;
          padding: 8px;
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .tb-url-input {
          flex: 1;
          height: 32px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 5px;
          padding: 0 10px;
          color: #ffffff;
          font-size: 12px;
          outline: none;
        }

        .tb-url-input:focus {
          border-color: #38bdf8;
        }

        .tb-url-submit-btn {
          height: 32px;
          padding: 0 12px;
          background: #0284c7;
          border: none;
          border-radius: 5px;
          color: #ffffff;
          font-size: 11px;
          font-weight: 700;
          cursor: pointer;
        }

        .tb-url-submit-btn:hover {
          background: #38bdf8;
          color: #030a10;
        }

        /* Color Picker Popover */
        .color-picker-popover {
          width: 260px;
          padding: 12px;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .color-tabs-switcher {
          display: flex;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 6px;
          padding: 2px;
        }

        .color-tab-btn {
          flex: 1;
          height: 28px;
          background: transparent;
          border: none;
          border-radius: 4px;
          color: #94a3b8;
          font-size: 11px;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.15s;
        }

        .color-tab-btn.active {
          background: #0284c7;
          color: #ffffff;
        }

        .color-palette-section {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .color-palette-title {
          font-size: 10px;
          color: #94a3b8;
          font-weight: 600;
        }

        .colors-grid-dots {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 8px;
        }

        .color-circle-dot {
          width: 100%;
          height: 28px;
          border-radius: 6px;
          border: 1px solid rgba(255, 255, 255, 0.15);
          cursor: pointer;
          transition: transform 0.15s, border-color 0.15s;
        }

        .color-circle-dot:hover {
          transform: scale(1.08);
          border-color: #ffffff;
        }

        .color-circle-dot.transparent-dot {
          background-image: repeating-linear-gradient(45deg, #333 0, #333 4px, #222 0, #222 8px);
        }

        .custom-color-picker-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding-top: 6px;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
        }

        .custom-color-picker-row label {
          font-size: 11px;
          color: #cbd5e1;
        }

        .native-color-picker {
          width: 28px;
          height: 28px;
          border: none;
          background: transparent;
          cursor: pointer;
          border-radius: 4px;
        }

        .reset-color-btn {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          background: transparent;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 4px;
          padding: 4px 8px;
          color: #94a3b8;
          font-size: 10px;
          cursor: pointer;
        }

        .reset-color-btn:hover {
          background: rgba(255, 255, 255, 0.06);
          color: #ffffff;
        }

        .reset-color-btn :global(svg) {
          width: 10px;
          height: 10px;
        }

        .color-dot:hover {
          transform: scale(1.2);
        }

        .editor-canvas-footer {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 11px;
          color: #64748b;
          border-top: 1px solid rgba(255, 255, 255, 0.06);
          padding-top: 16px;
        }

        /* Sidebar TechLab */
        .techlab-sidebar-panel {
          background: #040c14;
          border-left: 1px solid rgba(255, 255, 255, 0.08);
          display: flex;
          flex-direction: column;
          height: calc(100vh - 56px);
          position: sticky;
          top: 56px;
          font-size: 12px;
        }

        .sidebar-header-tabs {
          height: 46px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 0 12px 0 16px;
        }

        .tabs-nav-group {
          display: flex;
          gap: 16px;
          height: 100%;
        }

        .sb-tab-item {
          background: transparent;
          border: none;
          border-bottom: 2px solid transparent;
          font-size: 12px;
          font-weight: 600;
          color: #94a3b8;
          cursor: pointer;
          height: 100%;
          padding: 0;
        }

        .sb-tab-item.active {
          color: #16c96f;
          border-bottom-color: #16c96f;
        }

        .sb-close-icon-btn {
          width: 28px;
          height: 28px;
          background: transparent;
          border: none;
          color: #64748b;
          display: grid;
          place-items: center;
          cursor: pointer;
        }

        .sb-close-icon-btn:hover {
          color: #ffffff;
        }

        .sidebar-scrollable-body {
          flex: 1;
          overflow-y: auto;
          scrollbar-width: thin;
        }

        .sb-doc-summary-bar {
          padding: 10px 16px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          border-bottom: 1px solid rgba(255, 255, 255, 0.04);
        }

        .doc-icon-title {
          display: flex;
          align-items: center;
          gap: 6px;
          font-weight: 600;
          color: #f1f5f9;
        }

        .doc-icon-title :global(svg) {
          width: 14px;
          height: 14px;
          color: #16c96f;
        }

        .more-dots-btn {
          background: none;
          border: none;
          color: #64748b;
          cursor: pointer;
        }

        /* Imagen Destacada (Contenedor Fijo) */
        .sb-featured-image-container {
          padding: 14px 16px;
        }

        .featured-image-placeholder-btn {
          width: 100%;
          height: 38px;
          border: 1px dashed rgba(255, 255, 255, 0.15);
          border-radius: 6px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #cbd5e1;
          font-size: 12px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s;
          background: #03080e;
        }

        .featured-image-placeholder-btn:hover,
        .featured-image-placeholder-btn.dragging {
          border-color: #16c96f;
          color: #16c96f;
          background: rgba(22, 201, 111, 0.05);
        }

        .upload-loading-view {
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .featured-image-fixed-box {
          width: 100%;
          height: 140px;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          overflow: hidden;
          position: relative;
          background: #03080e;
        }

        .featured-image-fixed-box img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          object-position: center;
          display: block;
        }

        .featured-image-hover-actions {
          position: absolute;
          inset: 0;
          background: rgba(0, 0, 0, 0.7);
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          opacity: 0;
          transition: opacity 0.15s;
        }

        .featured-image-fixed-box:hover .featured-image-hover-actions {
          opacity: 1;
        }

        .btn-action-replace {
          padding: 4px 10px;
          background: #040c14;
          color: #ffffff;
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 4px;
          font-size: 11px;
          cursor: pointer;
        }

        .btn-action-delete {
          padding: 4px 10px;
          background: #ef4444;
          color: #ffffff;
          border: none;
          border-radius: 4px;
          font-size: 11px;
          cursor: pointer;
        }

        .sb-excerpt-action-row {
          padding: 0 16px 8px;
        }

        .btn-action-link {
          background: none;
          border: none;
          color: #38bdf8;
          font-size: 12px;
          cursor: pointer;
          padding: 0;
          text-decoration: underline;
        }

        .btn-action-link:hover {
          color: #16c96f;
        }

        .sb-last-edited-label {
          padding: 6px 16px;
          font-size: 11px;
          color: #64748b;
        }

        /* Tabla de Metadatos */
        .sb-metadata-list {
          padding: 4px 16px 14px;
          display: flex;
          flex-direction: column;
          gap: 10px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.06);
        }

        .meta-list-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          font-size: 12px;
        }

        .meta-row-name {
          color: #94a3b8;
        }

        .meta-row-link {
          color: #38bdf8;
          background: none;
          border: none;
          cursor: pointer;
          font-size: 12px;
          padding: 0;
        }

        .meta-row-link:hover {
          color: #16c96f;
        }

        .techlab-meta-select {
          border: none;
          background: transparent;
          color: #38bdf8;
          font-size: 12px;
          cursor: pointer;
          outline: none;
        }

        /* Acordeones */
        .sb-accordion-card {
          border-bottom: 1px solid rgba(255, 255, 255, 0.06);
        }

        .accordion-toggle-btn {
          width: 100%;
          height: 44px;
          padding: 0 16px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: none;
          border: none;
          font-size: 12px;
          font-weight: 600;
          color: #f1f5f9;
          cursor: pointer;
        }

        .accordion-toggle-btn:hover {
          background: rgba(255, 255, 255, 0.02);
        }

        .accordion-toggle-btn :global(svg) {
          width: 14px;
          height: 14px;
          color: #64748b;
        }

        .seo-title-group {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .seo-score-badge {
          font-size: 9px;
          padding: 1px 6px;
          border-radius: 10px;
        }
        .seo-score-badge.good { background: rgba(22, 201, 111, 0.2); color: #16c96f; }
        .seo-score-badge.avg { background: rgba(245, 158, 11, 0.2); color: #f59e0b; }
        .seo-score-badge.bad { background: rgba(239, 68, 68, 0.2); color: #ef4444; }

        .accordion-content-box {
          padding: 0 16px 14px;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        /* Categorías Jerárquicas */
        .categories-scroll-area {
          max-height: 240px;
          overflow-y: auto;
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .category-tree-block {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .cat-checkbox-item {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 12px;
          color: #cbd5e1;
          cursor: pointer;
        }

        .cat-checkbox-item.child {
          margin-left: 18px;
        }

        .tree-arrow {
          width: 12px;
          height: 12px;
          color: #64748b;
        }

        .cat-checkbox-item input {
          accent-color: #16c96f;
          cursor: pointer;
        }

        .inline-create-cat-form {
          background: #03080e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 6px;
          padding: 10px;
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .field-hint-label {
          font-size: 10px;
          color: #94a3b8;
        }

        .techlab-input-sm,
        .techlab-select-sm {
          width: 100%;
          height: 30px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 4px;
          padding: 0 8px;
          font-size: 11px;
          color: #ffffff;
          outline: none;
        }

        .techlab-input-sm:focus,
        .techlab-select-sm:focus {
          border-color: #16c96f;
        }

        .create-cat-btn-row {
          display: flex;
          align-items: center;
          gap: 8px;
          margin-top: 6px;
        }

        .btn-save-cat {
          padding: 5px 10px;
          background: #16c96f;
          color: #030b12;
          border: none;
          border-radius: 4px;
          font-size: 11px;
          font-weight: 600;
          cursor: pointer;
        }

        .btn-cancel-cat {
          background: none;
          border: none;
          color: #ef4444;
          font-size: 11px;
          cursor: pointer;
        }

        /* Etiquetas */
        .field-header-text {
          font-size: 10px;
          font-weight: 700;
          color: #cbd5e1;
          letter-spacing: 0.2px;
        }

        .techlab-input-tags {
          width: 100%;
          height: 32px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 4px;
          padding: 0 8px;
          font-size: 12px;
          color: #ffffff;
          outline: none;
        }

        .field-help-text {
          font-size: 10px;
          color: #64748b;
          margin: 0;
        }

        .tags-badge-cloud {
          display: flex;
          flex-wrap: wrap;
          gap: 4px;
          margin-top: 4px;
        }

        .techlab-tag-chip {
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 4px;
          padding: 2px 6px;
          font-size: 11px;
          display: inline-flex;
          align-items: center;
          gap: 4px;
          color: #cbd5e1;
        }

        .techlab-tag-chip button {
          background: none;
          border: none;
          color: #94a3b8;
          cursor: pointer;
          padding: 0;
          display: grid;
          place-items: center;
        }

        .techlab-tag-chip button :global(svg) {
          width: 10px;
          height: 10px;
        }

        /* SEO Dark Preview */
        .google-serp-dark-preview {
          background: #03080e;
          border: 1px solid rgba(255, 255, 255, 0.06);
          border-radius: 6px;
          padding: 10px;
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .serp-top-bar {
          display: flex;
          justify-content: space-between;
          font-size: 10px;
          color: #64748b;
        }

        .serp-view-switch {
          display: flex;
          gap: 3px;
        }

        .serp-view-switch button {
          background: none;
          border: none;
          color: #64748b;
          cursor: pointer;
          padding: 0;
        }

        .serp-view-switch button.active {
          color: #38bdf8;
        }

        .serp-view-switch button :global(svg) {
          width: 12px;
          height: 12px;
        }

        .serp-url-line {
          font-size: 10px;
          color: #94a3b8;
        }

        .serp-title-line {
          font-size: 13px;
          color: #38bdf8;
          font-weight: 600;
          line-height: 1.3;
        }

        .serp-desc-line {
          font-size: 11px;
          color: #94a3b8;
          line-height: 1.4;
        }

        .seo-field-group {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .field-counter-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .field-counter-row .counter-ok { font-size: 10px; color: #16c96f; }
        .field-counter-row .counter-warn { font-size: 10px; color: #f59e0b; }

        .techlab-textarea-sm {
          width: 100%;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 4px;
          padding: 6px 8px;
          font-size: 11px;
          color: #ffffff;
          outline: none;
          resize: vertical;
        }

        .seo-checks-list {
          display: flex;
          flex-direction: column;
          gap: 6px;
          margin-top: 6px;
        }

        .seo-check-item {
          display: flex;
          align-items: flex-start;
          gap: 6px;
          font-size: 11px;
        }

        .seo-check-item :global(svg) {
          width: 13px;
          height: 13px;
          flex-shrink: 0;
          margin-top: 2px;
        }

        .seo-check-item.pass :global(svg) { color: #16c96f; }
        .seo-check-item.fail :global(svg) { color: #64748b; }

        .seo-check-item b { display: block; color: #f1f5f9; font-size: 11px; }
        .seo-check-item small { color: #64748b; font-size: 10px; }

        .sb-block-tab-content {
          padding: 16px;
          display: flex;
          flex-direction: column;
          gap: 14px;
        }

        .block-type-badge {
          display: flex;
          align-items: center;
          gap: 8px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.06);
          padding-bottom: 10px;
        }

        .block-type-badge :global(svg) {
          width: 18px;
          height: 18px;
          color: #16c96f;
        }

        .block-type-badge strong { display: block; font-size: 12px; color: #ffffff; }
        .block-type-badge small { color: #64748b; font-size: 10px; }

        /* Modales */
        .techlab-modal-backdrop {
          position: fixed;
          inset: 0;
          z-index: 1000;
          background: rgba(0, 0, 0, 0.7);
          display: grid;
          place-items: center;
          padding: 16px;
        }

        .techlab-modal-card {
          width: 100%;
          max-width: 400px;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.12);
          border-radius: 8px;
          padding: 18px;
          box-shadow: 0 10px 40px rgba(0, 0, 0, 0.7);
        }

        .modal-top {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 12px;
        }

        .modal-top h3 {
          font-size: 13px;
          font-weight: 600;
          margin: 0;
          color: #ffffff;
        }

        .modal-top button {
          background: none;
          border: none;
          color: #94a3b8;
          cursor: pointer;
        }

        .modal-body-content label {
          font-size: 11px;
          color: #cbd5e1;
          display: block;
          margin-bottom: 4px;
        }

        .modal-actions-bar {
          display: flex;
          justify-content: flex-end;
          gap: 8px;
          margin-top: 16px;
        }

        .btn-modal-ghost {
          padding: 5px 12px;
          background: transparent;
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: #cbd5e1;
          font-size: 11px;
          border-radius: 4px;
          cursor: pointer;
        }

        .btn-modal-green {
          padding: 5px 14px;
          background: #16c96f;
          color: #030b12;
          border: none;
          font-size: 11px;
          font-weight: 700;
          border-radius: 4px;
          cursor: pointer;
        }

        /* =================================================================
           GUTENBERG LIGHT MODE (theme-light & :global(.theme-light))
           ================================================================= */
        .techlab-gutenberg-root.theme-light,
        :global(.theme-light) .techlab-gutenberg-root {
          background: #f8fafc !important;
          color: #0f172a !important;
        }

        /* Top Header */
        .techlab-gutenberg-root.theme-light .techlab-editor-header,
        :global(.theme-light) .techlab-editor-header {
          background: #ffffff !important;
          border-bottom: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .teh-back-btn,
        .techlab-gutenberg-root.theme-light .teh-icon-btn,
        .techlab-gutenberg-root.theme-light .teh-sidebar-toggle,
        :global(.theme-light) .teh-back-btn,
        :global(.theme-light) .teh-icon-btn,
        :global(.theme-light) .teh-sidebar-toggle {
          background: #f8fafc !important;
          border: 1px solid #cbd5e1 !important;
          color: #334155 !important;
        }

        .techlab-gutenberg-root.theme-light .teh-back-btn:hover,
        .techlab-gutenberg-root.theme-light .teh-icon-btn:hover,
        .techlab-gutenberg-root.theme-light .teh-sidebar-toggle:hover,
        :global(.theme-light) .teh-back-btn:hover,
        :global(.theme-light) .teh-icon-btn:hover,
        :global(.theme-light) .teh-sidebar-toggle:hover {
          background: #f1f5f9 !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .teh-doc-badge,
        :global(.theme-light) .teh-doc-badge {
          background: #f8fafc !important;
          border: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .doc-name,
        :global(.theme-light) .doc-name {
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .doc-status,
        :global(.theme-light) .doc-status {
          color: #64748b !important;
        }

        .techlab-gutenberg-root.theme-light .teh-draft-btn,
        :global(.theme-light) .teh-draft-btn {
          background: #f8fafc !important;
          border: 1px solid #cbd5e1 !important;
          color: #334155 !important;
        }

        .techlab-gutenberg-root.theme-light .teh-draft-btn:hover,
        :global(.theme-light) .teh-draft-btn:hover {
          background: #f1f5f9 !important;
          color: #0f172a !important;
        }

        /* Inserter Drawer */
        .techlab-gutenberg-root.theme-light .techlab-inserter-drawer,
        :global(.theme-light) .techlab-inserter-drawer {
          background: #ffffff !important;
          border-right: 1px solid #e2e8f0 !important;
          box-shadow: 10px 0 30px rgba(0, 0, 0, 0.08) !important;
        }

        .techlab-gutenberg-root.theme-light .drawer-header,
        :global(.theme-light) .drawer-header {
          background: #f8fafc !important;
          border-bottom: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .drawer-tabs span:not(.active),
        :global(.theme-light) .drawer-tabs span:not(.active) {
          color: #64748b !important;
        }

        .techlab-gutenberg-root.theme-light .drawer-search-wrap input,
        :global(.theme-light) .drawer-search-wrap input {
          background: #f8fafc !important;
          border: 1px solid #cbd5e1 !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .block-tile,
        :global(.theme-light) .block-tile {
          background: #f8fafc !important;
          border: 1px solid #e2e8f0 !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .block-tile:hover,
        :global(.theme-light) .block-tile:hover {
          background: #f0fdf4 !important;
          border-color: #16c96f !important;
          color: #15803d !important;
        }

        .techlab-gutenberg-root.theme-light .teh-draft-btn.saving,
        :global(.theme-light) .teh-draft-btn.saving {
          background: #f0f9ff !important;
          border-color: #7dd3fc !important;
          color: #0284c7 !important;
        }

        .techlab-gutenberg-root.theme-light .teh-draft-btn.saved,
        :global(.theme-light) .teh-draft-btn.saved {
          background: #f0fdf4 !important;
          border-color: #86efac !important;
          color: #16a34a !important;
        }

        /* Editor Body & Canvas */
        .techlab-gutenberg-root.theme-light .techlab-editor-body,
        :global(.theme-light) .techlab-editor-body {
          background: #f8fafc !important;
        }

        .techlab-gutenberg-root.theme-light .editor-canvas-container,
        :global(.theme-light) .editor-canvas-container {
          background: #f8fafc !important;
        }

        .techlab-gutenberg-root.theme-light .editor-title-row,
        :global(.theme-light) .editor-title-row {
          border: none !important;
          outline: none !important;
        }

        .techlab-gutenberg-root.theme-light .techlab-title-input,
        :global(.theme-light) .techlab-title-input {
          color: #0f172a !important;
          border: none !important;
          border-bottom: none !important;
          outline: none !important;
          box-shadow: none !important;
          background: transparent !important;
        }

        .techlab-gutenberg-root.theme-light .techlab-title-input:focus,
        .techlab-gutenberg-root.theme-light .techlab-title-input:hover,
        :global(.theme-light) .techlab-title-input:focus,
        :global(.theme-light) .techlab-title-input:hover {
          border: none !important;
          border-bottom: none !important;
          outline: none !important;
          box-shadow: none !important;
        }

        .techlab-gutenberg-root.theme-light .techlab-title-input::placeholder,
        :global(.theme-light) .techlab-title-input::placeholder {
          color: #94a3b8 !important;
        }

        .techlab-gutenberg-root.theme-light .techlab-content-editable,
        :global(.theme-light) .techlab-content-editable {
          color: #1e293b !important;
          border: none !important;
        }

        .techlab-gutenberg-root.theme-light .techlab-content-editable.is-drag-over,
        :global(.theme-light) .techlab-content-editable.is-drag-over {
          background: #f0fdf4 !important;
          outline-color: #16a34a !important;
        }

        .techlab-gutenberg-root.theme-light .techlab-content-editable:empty:before,
        :global(.theme-light) .techlab-content-editable:empty:before {
          color: #94a3b8 !important;
        }

        .techlab-gutenberg-root.theme-light .inline-plus-btn-right,
        :global(.theme-light) .inline-plus-btn-right {
          background: #ffffff !important;
          border: 1px solid #cbd5e1 !important;
          color: #0284c7 !important;
        }

        .techlab-gutenberg-root.theme-light .inline-plus-btn-right:hover,
        :global(.theme-light) .inline-plus-btn-right:hover {
          background: #0284c7 !important;
          color: #ffffff !important;
        }

        .techlab-gutenberg-root.theme-light .inline-blocks-popover-right,
        :global(.theme-light) .inline-blocks-popover-right {
          background: #ffffff !important;
          border: 1px solid #e2e8f0 !important;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1) !important;
        }

        .techlab-gutenberg-root.theme-light .popover-search-box input,
        :global(.theme-light) .popover-search-box input {
          background: #f8fafc !important;
          border: 1px solid #cbd5e1 !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .grid-item,
        :global(.theme-light) .grid-item {
          background: #f8fafc !important;
          border: 1px solid #e2e8f0 !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .grid-item:hover,
        :global(.theme-light) .grid-item:hover {
          background: #f0fdf4 !important;
          border-color: #16c96f !important;
          color: #15803d !important;
        }

        /* SEO Suite in Editor */
        .techlab-gutenberg-root.theme-light .techlab-pro-seo-suite,
        :global(.theme-light) .techlab-pro-seo-suite {
          background: #ffffff !important;
          border: 1px solid #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        .techlab-gutenberg-root.theme-light .seo-suite-top-bar,
        :global(.theme-light) .seo-suite-top-bar {
          background: #f8fafc !important;
          border-bottom: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .suite-icon-badge,
        :global(.theme-light) .suite-icon-badge {
          background: #ffffff !important;
          border: 1px solid #cbd5e1 !important;
        }

        .techlab-gutenberg-root.theme-light .suite-title-area h3,
        :global(.theme-light) .suite-title-area h3 {
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .suite-title-area p,
        :global(.theme-light) .suite-title-area p {
          color: #64748b !important;
        }

        .techlab-gutenberg-root.theme-light .suite-score-badge-card,
        :global(.theme-light) .suite-score-badge-card {
          background: #ffffff !important;
          border: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .score-lbl,
        :global(.theme-light) .score-lbl {
          color: #64748b !important;
        }

        .techlab-gutenberg-root.theme-light .seo-suite-tabs-nav,
        :global(.theme-light) .seo-suite-tabs-nav {
          background: #f8fafc !important;
          border-bottom: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .seo-nav-tab,
        :global(.theme-light) .seo-nav-tab {
          color: #64748b !important;
        }

        .techlab-gutenberg-root.theme-light .seo-nav-tab:hover,
        :global(.theme-light) .seo-nav-tab:hover {
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .seo-nav-tab.active,
        :global(.theme-light) .seo-nav-tab.active {
          color: #0d9651 !important;
          background: #ffffff !important;
          border-bottom: 2px solid #16c96f !important;
        }

        .techlab-gutenberg-root.theme-light .google-serp-master-card,
        :global(.theme-light) .google-serp-master-card {
          background: #ffffff !important;
          border: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .serp-toolbar-header,
        :global(.theme-light) .serp-toolbar-header {
          border-bottom: 1px solid #f1f5f9 !important;
        }

        .techlab-gutenberg-root.theme-light .serp-badge-title strong,
        :global(.theme-light) .serp-badge-title strong {
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .serp-view-mode-buttons button,
        :global(.theme-light) .serp-view-mode-buttons button {
          background: #f8fafc !important;
          border: 1px solid #cbd5e1 !important;
          color: #475569 !important;
        }

        .techlab-gutenberg-root.theme-light .serp-view-mode-buttons button.active,
        :global(.theme-light) .serp-view-mode-buttons button.active {
          background: #0284c7 !important;
          border-color: #0284c7 !important;
          color: #ffffff !important;
        }

        .techlab-gutenberg-root.theme-light .google-snippet-frame,
        :global(.theme-light) .google-snippet-frame {
          background: #f8fafc !important;
          border: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .brand-name,
        :global(.theme-light) .brand-name {
          color: #1e293b !important;
        }

        .techlab-gutenberg-root.theme-light .url-path,
        :global(.theme-light) .url-path {
          color: #475569 !important;
        }

        .techlab-gutenberg-root.theme-light .snippet-heading,
        :global(.theme-light) .snippet-heading {
          color: #1a0dab !important;
        }

        .techlab-gutenberg-root.theme-light .snippet-text,
        :global(.theme-light) .snippet-text {
          color: #4d5156 !important;
        }

        .techlab-gutenberg-root.theme-light .field-meta-info label,
        :global(.theme-light) .field-meta-info label {
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .field-meta-info p,
        :global(.theme-light) .field-meta-info p {
          color: #64748b !important;
        }

        .techlab-gutenberg-root.theme-light .wide-seo-input,
        .techlab-gutenberg-root.theme-light .wide-seo-textarea,
        :global(.theme-light) .wide-seo-input,
        :global(.theme-light) .wide-seo-textarea {
          background: #ffffff !important;
          border: 1px solid #cbd5e1 !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .char-progress-bar,
        :global(.theme-light) .char-progress-bar {
          background: #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .counter-pill,
        :global(.theme-light) .counter-pill {
          background: #f1f5f9 !important;
          color: #475569 !important;
        }

        .techlab-gutenberg-root.theme-light .analysis-summary-banner,
        :global(.theme-light) .analysis-summary-banner {
          background: #f0fdf4 !important;
          border: 1px solid #bbf7d0 !important;
        }

        .techlab-gutenberg-root.theme-light .banner-texts h4,
        :global(.theme-light) .banner-texts h4 {
          color: #14532d !important;
        }

        .techlab-gutenberg-root.theme-light .banner-texts p,
        :global(.theme-light) .banner-texts p {
          color: #166534 !important;
        }

        .techlab-gutenberg-root.theme-light .seo-check-item-row,
        :global(.theme-light) .seo-check-item-row {
          border-bottom: 1px solid #f1f5f9 !important;
        }

        .techlab-gutenberg-root.theme-light .check-info h5,
        :global(.theme-light) .check-info h5 {
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .check-info p,
        :global(.theme-light) .check-info p {
          color: #64748b !important;
        }

        .techlab-gutenberg-root.theme-light .social-og-master-card,
        :global(.theme-light) .social-og-master-card {
          background: #ffffff !important;
          border: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .social-preview-render-box,
        :global(.theme-light) .social-preview-render-box {
          background: #f8fafc !important;
          border: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .social-card-body h5,
        :global(.theme-light) .social-card-body h5 {
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .social-card-body p,
        :global(.theme-light) .social-card-body p {
          color: #64748b !important;
        }

        /* Floating Toolbar & Popovers */
        .techlab-gutenberg-root.theme-light .gutenberg-floating-block-toolbar,
        :global(.theme-light) .gutenberg-floating-block-toolbar {
          background: #ffffff !important;
          border: 1px solid #e2e8f0 !important;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1) !important;
        }

        .techlab-gutenberg-root.theme-light .tb-btn,
        :global(.theme-light) .tb-btn {
          color: #334155 !important;
        }

        .techlab-gutenberg-root.theme-light .tb-btn:hover,
        :global(.theme-light) .tb-btn:hover {
          background: #f1f5f9 !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .tb-divider,
        :global(.theme-light) .tb-divider {
          background: #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .gutenberg-tb-popover,
        :global(.theme-light) .gutenberg-tb-popover {
          background: #ffffff !important;
          border: 1px solid #e2e8f0 !important;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12) !important;
        }

        .techlab-gutenberg-root.theme-light .popover-item,
        :global(.theme-light) .popover-item {
          color: #334155 !important;
        }

        .techlab-gutenberg-root.theme-light .popover-item:hover,
        :global(.theme-light) .popover-item:hover {
          background: #f1f5f9 !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .popover-divider,
        :global(.theme-light) .popover-divider {
          background: #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .tb-url-input,
        :global(.theme-light) .tb-url-input {
          background: #f8fafc !important;
          border: 1px solid #cbd5e1 !important;
          color: #0f172a !important;
        }

        /* Bottom Status Bar */
        .techlab-gutenberg-root.theme-light .editor-footer-status-bar,
        :global(.theme-light) .editor-footer-status-bar {
          background: #ffffff !important;
          border-top: 1px solid #e2e8f0 !important;
          color: #64748b !important;
        }

        .techlab-gutenberg-root.theme-light .footer-doc-info,
        :global(.theme-light) .footer-doc-info {
          color: #64748b !important;
        }

        .techlab-gutenberg-root.theme-light .footer-doc-info strong,
        :global(.theme-light) .footer-doc-info strong {
          color: #0f172a !important;
        }

        /* Sidebar Panel */
        .techlab-gutenberg-root.theme-light .techlab-sidebar-panel,
        :global(.theme-light) .techlab-sidebar-panel {
          background: #ffffff !important;
          border-left: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .sidebar-header-tabs,
        :global(.theme-light) .sidebar-header-tabs {
          background: #f8fafc !important;
          border-bottom: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .sb-tab-item,
        :global(.theme-light) .sb-tab-item {
          color: #64748b !important;
        }

        .techlab-gutenberg-root.theme-light .sb-tab-item.active,
        :global(.theme-light) .sb-tab-item.active {
          color: #0d9651 !important;
          border-bottom: 2px solid #16c96f !important;
        }

        .techlab-gutenberg-root.theme-light .meta-list-row,
        :global(.theme-light) .meta-list-row {
          border-bottom: 1px solid #f1f5f9 !important;
        }

        .techlab-gutenberg-root.theme-light .meta-row-name,
        :global(.theme-light) .meta-row-name {
          color: #64748b !important;
        }

        .techlab-gutenberg-root.theme-light .meta-row-link,
        :global(.theme-light) .meta-row-link {
          color: #0284c7 !important;
        }

        .techlab-gutenberg-root.theme-light .techlab-meta-select,
        :global(.theme-light) .techlab-meta-select {
          background: #f8fafc !important;
          border: 1px solid #cbd5e1 !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .sb-accordion-card,
        :global(.theme-light) .sb-accordion-card {
          background: #ffffff !important;
          border: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .accordion-toggle-btn,
        :global(.theme-light) .accordion-toggle-btn {
          background: #f8fafc !important;
          color: #0f172a !important;
          border-bottom: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .categories-scroll-area,
        :global(.theme-light) .categories-scroll-area {
          background: #ffffff !important;
        }

        .techlab-gutenberg-root.theme-light .cat-checkbox-item,
        :global(.theme-light) .cat-checkbox-item {
          color: #1e293b !important;
        }

        .techlab-gutenberg-root.theme-light .techlab-input-sm,
        .techlab-gutenberg-root.theme-light .techlab-select-sm,
        .techlab-gutenberg-root.theme-light .techlab-textarea-sm,
        :global(.theme-light) .techlab-input-sm,
        :global(.theme-light) .techlab-select-sm,
        :global(.theme-light) .techlab-textarea-sm {
          background: #f8fafc !important;
          border: 1px solid #cbd5e1 !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .tag-pill-badge-item,
        :global(.theme-light) .tag-pill-badge-item {
          background: #f1f5f9 !important;
          border: 1px solid #cbd5e1 !important;
          color: #334155 !important;
        }

        .techlab-gutenberg-root.theme-light .tag-input-field,
        :global(.theme-light) .tag-input-field {
          background: #f8fafc !important;
          border: 1px solid #cbd5e1 !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .techlab-modal-card,
        :global(.theme-light) .techlab-modal-card {
          background: #ffffff !important;
          border: 1px solid #e2e8f0 !important;
          box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15) !important;
        }

        .techlab-gutenberg-root.theme-light .modal-top h3,
        :global(.theme-light) .modal-top h3 {
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .modal-body-content label,
        :global(.theme-light) .modal-body-content label {
          color: #1e293b !important;
        }

        .techlab-gutenberg-root.theme-light .btn-modal-ghost,
        :global(.theme-light) .btn-modal-ghost {
          background: #f8fafc !important;
          border: 1px solid #cbd5e1 !important;
          color: #475569 !important;
        }

        @media (max-width: 900px) {
          .techlab-editor-body.sidebar-visible {
            grid-template-columns: 1fr;
          }
          .techlab-sidebar-panel {
            position: fixed;
            inset: 56px 0 0 0;
            z-index: 60;
          }
        }
      `}</style>
    </div>
  );
}

export default function CesarGutenbergEditor() {
  return (
    <Suspense
      fallback={
        <div
          style={{
            minHeight: "100vh",
            display: "grid",
            placeItems: "center",
            background: "#030a10",
            color: "#16c96f",
            fontSize: "14px",
            fontWeight: 600,
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <Loader2 className="animate-spin" style={{ width: 20, height: 20 }} />
            <span>Cargando Editor de Publicaciones...</span>
          </div>
        </div>
      }
    >
      <CesarGutenbergEditorContent />
    </Suspense>
  );
}
