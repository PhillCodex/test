"use client";

import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import {
  FolderTree,
  Plus,
  Search,
  Pencil,
  Trash2,
  ExternalLink,
  Layers,
  FileText,
  CornerDownRight,
  CheckCircle2,
  AlertTriangle,
  X,
  Loader2,
  RefreshCw,
  FolderPlus,
  ShieldAlert,
} from "lucide-react";

interface CategoryData {
  id: string;
  name: string;
  slug: string;
  color: string;
  parentId?: string | null;
  parent?: { id: string; name: string; slug: string } | null;
  children?: { id: string; name: string; slug: string }[];
  _count?: { posts: number };
}

export default function CategoriasPage() {
  const [categories, setCategories] = useState<CategoryData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterType, setFilterType] = useState<"ALL" | "ROOT" | "CHILD">("ALL");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [origin, setOrigin] = useState("");

  // Estados del Formulario (Crear / Editar)
  const [editingId, setEditingId] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [isSlugManuallyEdited, setIsSlugManuallyEdited] = useState(false);
  const [parentId, setParentId] = useState("");
  const [color, setColor] = useState("green");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Estado del Modal Animado de Eliminación
  const [deleteModal, setDeleteModal] = useState<{
    isOpen: boolean;
    id: string;
    name: string;
    isDeleting: boolean;
  }>({
    isOpen: false,
    id: "",
    name: "",
    isDeleting: false,
  });

  // Estados de Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<"success" | "error">("success");

  useEffect(() => {
    if (typeof window !== "undefined") {
      setOrigin(window.location.origin);
    }
  }, []);

  // Cargar categorías reales desde MySQL RDS
  const fetchCategories = useCallback(async () => {
    setIsLoading(true);
    try {
      const res = await fetch("/api/categories");
      const data = await res.json();
      if (data.categories) {
        setCategories(data.categories);
      }
    } catch (e) {
      console.error("Error al cargar categorías:", e);
      showToast("Error de conexión al cargar categorías de MySQL", "error");
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchCategories();
  }, [fetchCategories]);

  // Generador de Slug SEO
  const generateSlug = (text: string) => {
    return text
      .toLowerCase()
      .trim()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "");
  };

  const handleNameChange = (val: string) => {
    setName(val);
    if (!isSlugManuallyEdited) {
      setSlug(generateSlug(val));
    }
  };

  const showToast = (msg: string, type: "success" | "error" = "success") => {
    setToastMessage(msg);
    setToastType(type);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const resetForm = () => {
    setEditingId(null);
    setName("");
    setSlug("");
    setIsSlugManuallyEdited(false);
    setParentId("");
    setColor("green");
  };

  // Cargar categoría en el formulario para editar
  const handleStartEdit = (cat: CategoryData) => {
    setEditingId(cat.id);
    setName(cat.name);
    setSlug(cat.slug);
    setIsSlugManuallyEdited(true);
    setParentId(cat.parentId || "");
    setColor(cat.color || "green");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Guardar (Crear o Actualizar) en MySQL RDS vía AJAX
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      showToast("El nombre de la categoría es obligatorio.", "error");
      return;
    }

    setIsSubmitting(true);

    const payload = {
      id: editingId,
      name: name.trim(),
      slug: slug || generateSlug(name),
      color,
      parentId: parentId || null,
    };

    try {
      const url = "/api/categories";
      const method = editingId ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (data.success) {
        showToast(
          editingId
            ? `Categoría "${name}" actualizada correctamente.`
            : `Categoría "${name}" creada correctamente.`,
          "success"
        );
        resetForm();
        await fetchCategories();
      } else {
        showToast(data.error || "Ocurrió un error al guardar.", "error");
      }
    } catch {
      showToast("Error de conexión al comunicarse con el servidor.", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Abrir Modal de Confirmación Animado
  const openDeleteConfirmation = (id: string, catName: string) => {
    setDeleteModal({
      isOpen: true,
      id,
      name: catName,
      isDeleting: false,
    });
  };

  // Eliminar categoría en MySQL RDS vía AJAX
  const executeDeleteConfirmed = async () => {
    if (!deleteModal.id) return;
    setDeleteModal((prev) => ({ ...prev, isDeleting: true }));

    try {
      const res = await fetch(`/api/categories?id=${deleteModal.id}`, { method: "DELETE" });
      const data = await res.json();

      if (data.success) {
        showToast(`Categoría "${deleteModal.name}" eliminada correctamente.`, "success");
        if (editingId === deleteModal.id) resetForm();
        await fetchCategories();
        setDeleteModal({ isOpen: false, id: "", name: "", isDeleting: false });
      } else {
        showToast(data.error || "Error al eliminar categoría.", "error");
        setDeleteModal((prev) => ({ ...prev, isDeleting: false }));
      }
    } catch {
      showToast("Error al procesar la solicitud de eliminación.", "error");
      setDeleteModal((prev) => ({ ...prev, isDeleting: false }));
    }
  };

  // Métricas calculadas en tiempo real
  const totalCategories = categories.length;
  const rootCount = categories.filter((c) => !c.parentId).length;
  const childCount = categories.filter((c) => !!c.parentId).length;
  const totalPostsLinked = categories.reduce((acc, c) => acc + (c._count?.posts || 0), 0);

  // Filtrado reactivo de categorías
  const filteredCategories = categories.filter((cat) => {
    const matchesSearch =
      search === "" ||
      cat.name.toLowerCase().includes(search.toLowerCase()) ||
      cat.slug.toLowerCase().includes(search.toLowerCase()) ||
      (cat.parent?.name && cat.parent.name.toLowerCase().includes(search.toLowerCase()));

    const matchesType =
      filterType === "ALL" ||
      (filterType === "ROOT" && !cat.parentId) ||
      (filterType === "CHILD" && !!cat.parentId);

    return matchesSearch && matchesType;
  });

  const handleSelectAll = () => {
    if (selectedIds.length === filteredCategories.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredCategories.map((c) => c.id));
    }
  };

  const handleSelectRow = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  return (
    <div className="categorias-admin-container">
      {/* Toast Notification */}
      {toastMessage && (
        <div className={`techlab-toast ${toastType}`}>
          {toastType === "success" ? <CheckCircle2 /> : <AlertTriangle />}
          <span>{toastMessage}</span>
        </div>
      )}

      {/* =================================================================
          MODAL ANIMADO EN EL CENTRO: CONFIRMACIÓN DE ELIMINACIÓN
          ================================================================= */}
      {deleteModal.isOpen && (
        <div
          className="modal-delete-backdrop"
          onClick={() => !deleteModal.isDeleting && setDeleteModal({ isOpen: false, id: "", name: "", isDeleting: false })}
        >
          <div className="modal-delete-card" onClick={(e) => e.stopPropagation()}>
            <div className="modal-danger-icon-wrap">
              <ShieldAlert />
            </div>

            <div className="modal-delete-content">
              <h3>¿Seguro que quieres eliminar?</h3>
              <p className="modal-danger-desc">
                Este dato es <strong>irreversible</strong> y se desvinculará de las publicaciones permanentemente.
              </p>

              <div className="modal-target-item-box">
                <FolderTree />
                <span>{deleteModal.name}</span>
              </div>
            </div>

            <div className="modal-delete-actions">
              <button
                type="button"
                className="btn-modal-cancel"
                onClick={() => setDeleteModal({ isOpen: false, id: "", name: "", isDeleting: false })}
                disabled={deleteModal.isDeleting}
              >
                Cancelar
              </button>

              <button
                type="button"
                className="btn-modal-danger-confirm"
                onClick={executeDeleteConfirmed}
                disabled={deleteModal.isDeleting}
              >
                {deleteModal.isDeleting ? (
                  <>
                    <Loader2 className="animate-spin" />
                    <span>Eliminando...</span>
                  </>
                ) : (
                  <>
                    <Trash2 />
                    <span>Sí, eliminar</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Encabezado Principal */}
      <div className="categorias-page-header">
        <div>
          <h1>Administración de Categorías</h1>
          <p>Crea, organiza jerarquías Padre e Hijo y gestiona las categorías de tus publicaciones</p>
        </div>
        <button
          type="button"
          onClick={fetchCategories}
          className="refresh-db-btn"
          title="Actualizar categorías"
        >
          <RefreshCw className={isLoading ? "animate-spin" : ""} />
          <span>Actualizar</span>
        </button>
      </div>

      {/* Tarjetas de Resumen Métrico */}
      <section className="categories-metrics-panel">
        <div className="metrics-grid">
          {/* Card 1: Total Categorías */}
          <div className="metric-card green-card">
            <div className="metric-info">
              <span>Total Categorías</span>
              <strong>{totalCategories}</strong>
            </div>
            <div className="metric-icon-box green">
              <Layers />
            </div>
          </div>

          {/* Card 2: Categorías Principales */}
          <div className="metric-card cyan-card">
            <div className="metric-info">
              <span>Categorías Principales</span>
              <strong>{rootCount}</strong>
            </div>
            <div className="metric-icon-box cyan">
              <FolderTree />
            </div>
          </div>

          {/* Card 3: Subcategorías (Hijas) */}
          <div className="metric-card purple-card">
            <div className="metric-info">
              <span>Subcategorías (Hijas)</span>
              <strong>{childCount}</strong>
            </div>
            <div className="metric-icon-box purple">
              <CornerDownRight />
            </div>
          </div>

          {/* Card 4: Posts Vinculados */}
          <div className="metric-card orange-card">
            <div className="metric-info">
              <span>Posts Vinculados</span>
              <strong>{totalPostsLinked}</strong>
            </div>
            <div className="metric-icon-box orange">
              <FileText />
            </div>
          </div>
        </div>
      </section>

      {/* =================================================================
          ARQUITECTURA DE 2 COLUMNAS (CREAR/EDITAR + TABLA DE GESTIÓN)
          ================================================================= */}
      <div className="categorias-layout-grid">
        {/* COLUMNA 1: FORMULARIO DE AÑADIR / EDITAR CATEGORÍA */}
        <div className="form-column-card">
          <div className="card-header-title">
            <FolderPlus />
            <h2>{editingId ? "Editar Categoría" : "Añadir Nueva Categoría"}</h2>
          </div>

          <form onSubmit={handleSubmit} className="category-crud-form">
            {/* Nombre */}
            <div className="form-field">
              <label htmlFor="cat-name">
                Nombre <span>*</span>
              </label>
              <input
                id="cat-name"
                type="text"
                value={name}
                onChange={(e) => handleNameChange(e.target.value)}
                placeholder="ej. Seguridad en la Nube"
                className="techlab-input"
                required
              />
              <small className="field-hint">El nombre visible que aparecerá en tu sitio y blog.</small>
            </div>

            {/* Slug */}
            <div className="form-field">
              <label htmlFor="cat-slug">Slug (URL amigable)</label>
              <div className="slug-input-wrapper">
                <span className="slug-prefix">/categoria/</span>
                <input
                  id="cat-slug"
                  type="text"
                  value={slug}
                  onChange={(e) => {
                    setSlug(e.target.value);
                    setIsSlugManuallyEdited(true);
                  }}
                  placeholder="seguridad-en-la-nube"
                  className="techlab-input slug"
                />
              </div>
              <small className="field-hint">El slug es la versión en minúsculas y con guiones de la URL.</small>
            </div>

            {/* Categoría Superior / Padre (Jerarquía) */}
            <div className="form-field">
              <label htmlFor="cat-parent">Categoría Superior (Padre)</label>
              <select
                id="cat-parent"
                value={parentId}
                onChange={(e) => setParentId(e.target.value)}
                className="techlab-select"
              >
                <option value="">— Ninguna (Categoría Principal) —</option>
                {categories
                  .filter((c) => c.id !== editingId)
                  .map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.parent ? `— ${c.name} (Hija de ${c.parent.name})` : c.name}
                    </option>
                  ))}
              </select>
              <small className="field-hint">
                Asigna una categoría superior para crear una jerarquía (subcategoría).
              </small>
            </div>

            {/* Selector de Color de Badge */}
            <div className="form-field">
              <label>Color del Badge</label>
              <div className="color-palette-selector">
                {[
                  { key: "green", label: "Verde Neón", hex: "#16c96f" },
                  { key: "blue", label: "Cyan Eléctrico", hex: "#38bdf8" },
                  { key: "purple", label: "Púrpura Cyber", hex: "#a855f7" },
                  { key: "orange", label: "Naranja Ámbar", hex: "#f59e0b" },
                  { key: "brown", label: "Marrón", hex: "#b45309" },
                ].map((c) => (
                  <button
                    key={c.key}
                    type="button"
                    className={`palette-color-btn ${color === c.key ? "active" : ""}`}
                    onClick={() => setColor(c.key)}
                    title={c.label}
                  >
                    <span className="dot" style={{ backgroundColor: c.hex }} />
                    <span className="name">{c.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Botones de Acción */}
            <div className="form-actions-row">
              <button
                type="submit"
                className="neon-submit-btn"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="animate-spin" />
                    <span>Guardando...</span>
                  </>
                ) : editingId ? (
                  <>
                    <Pencil />
                    <span>Actualizar Categoría</span>
                  </>
                ) : (
                  <>
                    <Plus />
                    <span>Añadir nueva categoría</span>
                  </>
                )}
              </button>

              {editingId && (
                <button
                  type="button"
                  onClick={resetForm}
                  className="cancel-edit-btn"
                >
                  <X /> Cancelar
                </button>
              )}
            </div>
          </form>
        </div>

        {/* COLUMNA 2: TABLA DE CATEGORÍAS REALES */}
        <div className="table-column-card">
          {/* Barra de Búsqueda y Filtros */}
          <div className="categories-table-toolbar">
            <div className="search-bar-wrap">
              <Search />
              <input
                type="text"
                placeholder="Buscar por nombre, slug o categoría padre..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
              {search && (
                <button
                  className="clear-search-btn"
                  onClick={() => setSearch("")}
                  aria-label="Limpiar búsqueda"
                >
                  <X />
                </button>
              )}
            </div>

            <div className="filter-chips-group">
              <button
                className={`filter-btn ${filterType === "ALL" ? "active" : ""}`}
                onClick={() => setFilterType("ALL")}
              >
                Todas ({totalCategories})
              </button>
              <button
                className={`filter-btn green ${filterType === "ROOT" ? "active" : ""}`}
                onClick={() => setFilterType("ROOT")}
              >
                Principales ({rootCount})
              </button>
              <button
                className={`filter-btn purple ${filterType === "CHILD" ? "active" : ""}`}
                onClick={() => setFilterType("CHILD")}
              >
                Subcategorías ({childCount})
              </button>
            </div>
          </div>

          {/* Tabla de Datos */}
          <div className="table-scroll-container">
            <table className="techlab-data-table">
              <thead>
                <tr>
                  <th className="th-checkbox">
                    <input
                      type="checkbox"
                      checked={
                        filteredCategories.length > 0 &&
                        selectedIds.length === filteredCategories.length
                      }
                      onChange={handleSelectAll}
                      aria-label="Seleccionar todas"
                    />
                  </th>
                  <th className="th-name">Nombre / Jerarquía</th>
                  <th className="th-slug">Slug</th>
                  <th className="th-parent">Categoría Superior</th>
                  <th className="th-badge">Badge</th>
                  <th className="th-count">Posts</th>
                  <th className="th-actions">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr>
                    <td colSpan={7} className="loading-table-state">
                      <div className="loading-inner">
                        <Loader2 className="animate-spin" />
                        <span>Cargando categorías...</span>
                      </div>
                    </td>
                  </tr>
                ) : filteredCategories.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="empty-table-state">
                      No se encontraron categorías que coincidan con la búsqueda.
                    </td>
                  </tr>
                ) : (
                  filteredCategories.map((cat) => {
                    const isSelected = selectedIds.includes(cat.id);
                    const isEditingThis = editingId === cat.id;
                    const isChild = !!cat.parentId;

                    return (
                      <tr
                        key={cat.id}
                        className={`${isSelected ? "row-selected" : ""} ${
                          isEditingThis ? "row-editing" : ""
                        }`}
                      >
                        {/* Checkbox */}
                        <td className="td-checkbox">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => handleSelectRow(cat.id)}
                            aria-label={`Seleccionar ${cat.name}`}
                          />
                        </td>

                        {/* Nombre con Jerarquía */}
                        <td className="td-name">
                          <div className={`category-name-cell ${isChild ? "is-child" : "is-parent"}`}>
                            {isChild && <CornerDownRight className="tree-sub-icon" />}
                            <div className="name-details">
                              <strong className="cat-title-text">{cat.name}</strong>
                              <small className="cat-id-sub">ID: {cat.id.slice(0, 8)}...</small>
                            </div>
                          </div>
                        </td>

                        {/* Slug */}
                        <td className="td-slug">
                          <span className="slug-badge">{cat.slug}</span>
                        </td>

                        {/* Categoría Superior */}
                        <td className="td-parent">
                          {cat.parent ? (
                            <span className="parent-badge-pill">
                              {cat.parent.name}
                            </span>
                          ) : (
                            <span className="no-parent-text">— Principal —</span>
                          )}
                        </td>

                        {/* Badge / Color */}
                        <td className="td-badge">
                          <span className={`cat-pill pill-${cat.color || "green"}`}>
                            {cat.name}
                          </span>
                        </td>

                        {/* Posts Vinculados */}
                        <td className="td-count">
                          <span className="posts-count-badge">
                            {cat._count?.posts || 0}
                          </span>
                        </td>

                        {/* Acciones */}
                        <td className="td-actions">
                          <div className="table-actions-group">
                            <button
                              onClick={() => handleStartEdit(cat)}
                              className="action-btn edit"
                              title="Editar categoría"
                              aria-label="Editar categoría"
                            >
                              <Pencil />
                            </button>
                            <Link
                              href={`/dashboard/posts`}
                              className="action-btn view"
                              title="Ver posts de esta categoría"
                              aria-label="Ver posts de esta categoría"
                            >
                              <ExternalLink />
                            </Link>
                            <button
                              onClick={() => openDeleteConfirmation(cat.id, cat.name)}
                              className="action-btn delete"
                              title="Eliminar categoría"
                              aria-label="Eliminar categoría"
                            >
                              <Trash2 />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          {/* Pie de Tabla */}
          <div className="categories-table-footer">
            <span className="table-count-text">
              Mostrando {filteredCategories.length} de {totalCategories} categorías
            </span>
          </div>
        </div>
      </div>

      {/* ESTILOS TECHLAB CYBER DARK */}
      <style jsx>{`
        .categorias-admin-container {
          display: flex;
          flex-direction: column;
          gap: 20px;
          color: #f1f5f9;
        }

        /* Modal Animado en el Centro */
        .modal-delete-backdrop {
          position: fixed;
          inset: 0;
          z-index: 2000;
          background: rgba(0, 0, 0, 0.75);
          backdrop-filter: blur(4px);
          display: grid;
          place-items: center;
          padding: 16px;
          animation: modalFadeIn 0.2s ease;
        }

        .modal-delete-card {
          width: 100%;
          max-width: 440px;
          background: #040c14;
          border: 1px solid rgba(239, 68, 68, 0.35);
          border-radius: 12px;
          padding: 24px;
          box-shadow: 0 20px 50px rgba(0, 0, 0, 0.8), 0 0 30px rgba(239, 68, 68, 0.15);
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          gap: 16px;
          animation: modalScaleIn 0.25s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes modalFadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        @keyframes modalScaleIn {
          from { transform: scale(0.92); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }

        .modal-danger-icon-wrap {
          width: 58px;
          height: 58px;
          border-radius: 50%;
          background: rgba(239, 68, 68, 0.12);
          border: 2px solid rgba(239, 68, 68, 0.4);
          display: grid;
          place-items: center;
          color: #ef4444;
          box-shadow: 0 0 20px rgba(239, 68, 68, 0.25);
          animation: iconPulse 2s infinite ease-in-out;
        }

        @keyframes iconPulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.06); }
        }

        .modal-danger-icon-wrap :global(svg) {
          width: 28px;
          height: 28px;
        }

        .modal-delete-content {
          display: flex;
          flex-direction: column;
          gap: 8px;
          width: 100%;
        }

        .modal-delete-content h3 {
          font-size: 18px;
          font-weight: 800;
          color: #ffffff;
          margin: 0;
          letter-spacing: -0.3px;
        }

        .modal-danger-desc {
          font-size: 13px;
          color: #94a3b8;
          margin: 0;
          line-height: 1.5;
        }

        .modal-danger-desc strong {
          color: #ef4444;
        }

        .modal-target-item-box {
          margin-top: 8px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 8px;
          padding: 10px 14px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          font-size: 12px;
          font-weight: 600;
          color: #f1f5f9;
          word-break: break-word;
        }

        .modal-target-item-box :global(svg) {
          width: 14px;
          height: 14px;
          color: #38bdf8;
          flex-shrink: 0;
        }

        .modal-delete-actions {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 12px;
          width: 100%;
          margin-top: 4px;
        }

        .btn-modal-cancel {
          flex: 1;
          height: 38px;
          border-radius: 6px;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: #cbd5e1;
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.15s;
        }

        .btn-modal-cancel:hover:not(:disabled) {
          background: rgba(255, 255, 255, 0.1);
          color: #ffffff;
        }

        .btn-modal-danger-confirm {
          flex: 1;
          height: 38px;
          border-radius: 6px;
          background: linear-gradient(110deg, #dc2626, #ef4444);
          border: 1px solid rgba(239, 68, 68, 0.5);
          color: #ffffff;
          font-size: 12px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          cursor: pointer;
          box-shadow: 0 0 16px rgba(239, 68, 68, 0.35);
          transition: all 0.2s;
        }

        .btn-modal-danger-confirm:hover:not(:disabled) {
          background: #f87171;
          transform: translateY(-1px);
        }

        .btn-modal-danger-confirm :global(svg) {
          width: 15px;
          height: 15px;
        }

        /* Toast Notification */
        .techlab-toast {
          position: fixed;
          top: 70px;
          right: 24px;
          z-index: 1000;
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 12px 18px;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 600;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.6);
          animation: slideIn 0.25s ease;
        }

        .techlab-toast.success {
          background: #062316;
          border: 1px solid #16c96f;
          color: #a7f3d0;
        }

        .techlab-toast.error {
          background: #270d0d;
          border: 1px solid #ef4444;
          color: #fca5a5;
        }

        @keyframes slideIn {
          from { transform: translateY(-20px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }

        /* Header */
        .categorias-page-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding-bottom: 4px;
        }

        .categorias-page-header h1 {
          font-size: 22px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 4px;
          letter-spacing: -0.5px;
        }

        .categorias-page-header p {
          font-size: 12px;
          color: #94a3b8;
          margin: 0;
        }

        .refresh-db-btn {
          height: 36px;
          padding: 0 14px;
          border-radius: 6px;
          background: rgba(255, 255, 255, 0.04);
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: #cbd5e1;
          font-size: 12px;
          font-weight: 600;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          transition: all 0.15s;
        }

        .refresh-db-btn:hover {
          background: rgba(22, 201, 111, 0.1);
          border-color: rgba(22, 201, 111, 0.4);
          color: #16c96f;
        }

        .refresh-db-btn :global(svg) {
          width: 14px;
          height: 14px;
        }

        /* Metrics Panel */
        .categories-metrics-panel {
          margin-bottom: 4px;
        }

        .metrics-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 16px;
        }

        .metric-card {
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          padding: 16px 18px;
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .metric-info span {
          display: block;
          font-size: 11px;
          font-weight: 600;
          color: #94a3b8;
          margin-bottom: 4px;
        }

        .metric-info strong {
          font-size: 22px;
          font-weight: 800;
          color: #ffffff;
        }

        .metric-icon-box {
          width: 38px;
          height: 38px;
          border-radius: 8px;
          display: grid;
          place-items: center;
        }

        .metric-icon-box :global(svg) {
          width: 18px;
          height: 18px;
        }

        .metric-icon-box.green { background: rgba(22, 201, 111, 0.12); color: #16c96f; }
        .metric-icon-box.cyan { background: rgba(56, 189, 248, 0.12); color: #38bdf8; }
        .metric-icon-box.purple { background: rgba(168, 85, 247, 0.12); color: #c084fc; }
        .metric-icon-box.orange { background: rgba(245, 158, 11, 0.12); color: #fbbf24; }

        /* 2-Column Layout */
        .categorias-layout-grid {
          display: grid;
          grid-template-columns: 340px 1fr;
          gap: 20px;
          align-items: start;
        }

        /* Form Card */
        .form-column-card {
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          padding: 20px;
        }

        .card-header-title {
          display: flex;
          align-items: center;
          gap: 8px;
          margin-bottom: 16px;
          padding-bottom: 12px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.06);
        }

        .card-header-title :global(svg) {
          width: 18px;
          height: 18px;
          color: #16c96f;
        }

        .card-header-title h2 {
          font-size: 15px;
          font-weight: 700;
          color: #ffffff;
          margin: 0;
        }

        .category-crud-form {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .form-field {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .form-field label {
          font-size: 11px;
          font-weight: 600;
          color: #cbd5e1;
        }

        .form-field label span {
          color: #ef4444;
        }

        .techlab-input {
          height: 36px;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 0 12px;
          color: #ffffff;
          font-size: 12px;
          outline: none;
          transition: border-color 0.15s;
        }

        .techlab-input:focus {
          border-color: #16c96f;
        }

        .slug-input-wrapper {
          display: flex;
          align-items: center;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          overflow: hidden;
        }

        .slug-prefix {
          font-size: 11px;
          color: #64748b;
          padding: 0 8px 0 10px;
          background: rgba(255, 255, 255, 0.02);
          border-right: 1px solid rgba(255, 255, 255, 0.06);
          height: 36px;
          display: flex;
          align-items: center;
        }

        .techlab-input.slug {
          border: none;
          background: transparent;
          flex: 1;
          height: 36px;
        }

        .techlab-select {
          height: 36px;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 0 12px;
          color: #ffffff;
          font-size: 12px;
          outline: none;
        }

        .techlab-select:focus {
          border-color: #16c96f;
        }

        .field-hint {
          font-size: 10px;
          color: #64748b;
          line-height: 1.3;
        }

        .color-palette-selector {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .palette-color-btn {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 6px 10px;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 6px;
          color: #cbd5e1;
          font-size: 11px;
          cursor: pointer;
          transition: all 0.15s;
          text-align: left;
        }

        .palette-color-btn:hover {
          background: rgba(255, 255, 255, 0.05);
        }

        .palette-color-btn.active {
          border-color: #16c96f;
          background: rgba(22, 201, 111, 0.08);
          color: #ffffff;
        }

        .palette-color-btn .dot {
          width: 10px;
          height: 10px;
          border-radius: 50%;
          flex-shrink: 0;
        }

        .form-actions-row {
          display: flex;
          flex-direction: column;
          gap: 8px;
          margin-top: 6px;
        }

        .neon-submit-btn {
          height: 38px;
          border-radius: 6px;
          background: linear-gradient(110deg, #12b85f, #18d878);
          border: 1px solid rgba(67, 255, 147, 0.4);
          color: #030b12;
          font-size: 12px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          cursor: pointer;
          box-shadow: 0 0 16px rgba(22, 201, 111, 0.25);
          transition: all 0.2s;
        }

        .neon-submit-btn:hover:not(:disabled) {
          background: #20df7b;
          transform: translateY(-1px);
        }

        .neon-submit-btn :global(svg) {
          width: 15px;
          height: 15px;
        }

        .cancel-edit-btn {
          height: 32px;
          background: transparent;
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: #94a3b8;
          border-radius: 6px;
          font-size: 11px;
          cursor: pointer;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 4px;
        }

        .cancel-edit-btn:hover {
          color: #ef4444;
          border-color: rgba(239, 68, 68, 0.3);
        }

        /* Table Card */
        .table-column-card {
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          padding: 16px;
          display: flex;
          flex-direction: column;
          gap: 14px;
        }

        .categories-table-toolbar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          flex-wrap: wrap;
        }

        .search-bar-wrap {
          flex: 1;
          min-width: 240px;
          position: relative;
          display: flex;
          align-items: center;
        }

        .search-bar-wrap :global(svg) {
          position: absolute;
          left: 12px;
          width: 14px;
          height: 14px;
          color: #64748b;
        }

        .search-bar-wrap input {
          width: 100%;
          height: 36px;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 6px;
          padding: 0 32px 0 34px;
          color: #ffffff;
          font-size: 12px;
          outline: none;
        }

        .search-bar-wrap input:focus {
          border-color: #16c96f;
        }

        .clear-search-btn {
          position: absolute;
          right: 10px;
          background: none;
          border: none;
          color: #64748b;
          cursor: pointer;
        }

        .clear-search-btn :global(svg) {
          width: 12px;
          height: 12px;
        }

        .filter-chips-group {
          display: flex;
          gap: 6px;
        }

        .filter-btn {
          height: 32px;
          padding: 0 12px;
          border-radius: 6px;
          background: rgba(255, 255, 255, 0.03);
          border: 1px solid rgba(255, 255, 255, 0.08);
          color: #94a3b8;
          font-size: 11px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.15s;
        }

        .filter-btn:hover {
          color: #ffffff;
          background: rgba(255, 255, 255, 0.06);
        }

        .filter-btn.active {
          background: rgba(22, 201, 111, 0.12);
          border-color: rgba(22, 201, 111, 0.4);
          color: #16c96f;
        }

        .table-scroll-container {
          overflow-x: auto;
        }

        .techlab-data-table {
          width: 100%;
          border-collapse: collapse;
          font-size: 12px;
        }

        .techlab-data-table th {
          background: #040c14;
          color: #94a3b8;
          font-size: 11px;
          font-weight: 700;
          text-align: left;
          padding: 10px 12px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .techlab-data-table td {
          padding: 12px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.04);
          color: #cbd5e1;
        }

        .techlab-data-table tr:hover td {
          background: rgba(255, 255, 255, 0.02);
        }

        .techlab-data-table tr.row-selected td {
          background: rgba(22, 201, 111, 0.04);
        }

        .techlab-data-table tr.row-editing td {
          background: rgba(56, 189, 248, 0.06);
          border-bottom-color: rgba(56, 189, 248, 0.3);
        }

        .th-checkbox, .td-checkbox {
          width: 32px;
          text-align: center;
        }

        .th-checkbox input, .td-checkbox input {
          accent-color: #16c96f;
          cursor: pointer;
        }

        /* Name with Tree Hierarchy */
        .category-name-cell {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .category-name-cell.is-child {
          padding-left: 18px;
        }

        .tree-sub-icon {
          width: 14px;
          height: 14px;
          color: #64748b;
          flex-shrink: 0;
        }

        .name-details {
          display: flex;
          flex-direction: column;
        }

        .cat-title-text {
          font-size: 13px;
          font-weight: 700;
          color: #ffffff;
        }

        .cat-id-sub {
          font-size: 10px;
          color: #64748b;
        }

        .slug-badge {
          background: #040c14;
          padding: 2px 8px;
          border-radius: 4px;
          font-size: 11px;
          color: #94a3b8;
          font-family: monospace;
          border: 1px solid rgba(255, 255, 255, 0.06);
        }

        .parent-badge-pill {
          background: rgba(56, 189, 248, 0.08);
          border: 1px solid rgba(56, 189, 248, 0.2);
          color: #38bdf8;
          padding: 2px 8px;
          border-radius: 4px;
          font-size: 11px;
          font-weight: 600;
        }

        .no-parent-text {
          font-size: 11px;
          color: #64748b;
        }

        .cat-pill {
          font-size: 11px;
          font-weight: 600;
          padding: 2px 8px;
          border-radius: 4px;
          display: inline-block;
        }

        .cat-pill.pill-green { background: rgba(22, 201, 111, 0.12); color: #16c96f; }
        .cat-pill.pill-blue { background: rgba(56, 189, 248, 0.12); color: #38bdf8; }
        .cat-pill.pill-purple { background: rgba(168, 85, 247, 0.12); color: #c084fc; }
        .cat-pill.pill-orange { background: rgba(245, 158, 11, 0.12); color: #fbbf24; }
        .cat-pill.pill-brown { background: rgba(180, 83, 9, 0.15); color: #f97316; }

        .posts-count-badge {
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: #ffffff;
          font-weight: 700;
          font-size: 11px;
          padding: 2px 8px;
          border-radius: 12px;
        }

        .table-actions-group {
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .action-btn {
          width: 28px;
          height: 28px;
          border-radius: 4px;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          color: #94a3b8;
          display: grid;
          place-items: center;
          cursor: pointer;
          text-decoration: none;
          transition: all 0.15s;
        }

        .action-btn.edit:hover {
          color: #38bdf8;
          border-color: rgba(56, 189, 248, 0.4);
          background: rgba(56, 189, 248, 0.08);
        }

        .action-btn.view:hover {
          color: #16c96f;
          border-color: rgba(22, 201, 111, 0.4);
          background: rgba(22, 201, 111, 0.08);
        }

        .action-btn.delete:hover {
          color: #ef4444;
          border-color: rgba(239, 68, 68, 0.4);
          background: rgba(239, 68, 68, 0.08);
        }

        .action-btn :global(svg) {
          width: 13px;
          height: 13px;
        }

        .loading-table-state,
        .empty-table-state {
          text-align: center;
          padding: 40px !important;
          color: #64748b;
        }

        .loading-inner {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 10px;
          color: #94a3b8;
          font-size: 13px;
        }

        .categories-table-footer {
          padding-top: 8px;
          border-top: 1px solid rgba(255, 255, 255, 0.06);
          font-size: 11px;
          color: #64748b;
        }

        @media (max-width: 1024px) {
          .metrics-grid {
            grid-template-columns: repeat(2, 1fr);
          }
          .categorias-layout-grid {
            grid-template-columns: 1fr;
          }
        }

        @media (max-width: 640px) {
          .metrics-grid {
            grid-template-columns: 1fr;
          }
        }

        /* LIGHT MODE SCOPED OVERRIDES */
        :global(.theme-light) .categorias-admin-container {
          color: #0f172a !important;
        }

        :global(.theme-light) .header-title-box h1 {
          color: #0f172a !important;
        }

        :global(.theme-light) .header-title-box p {
          color: #64748b !important;
        }

        :global(.theme-light) .metric-card {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .metric-icon-wrap {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
        }

        :global(.theme-light) .metric-text-box strong {
          color: #0f172a !important;
        }

        :global(.theme-light) .metric-text-box span {
          color: #64748b !important;
        }

        :global(.theme-light) .form-card-panel,
        :global(.theme-light) .table-card-panel {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .card-head-bar {
          border-bottom-color: #f1f5f9 !important;
        }

        :global(.theme-light) .card-head-bar h2 {
          color: #0f172a !important;
        }

        :global(.theme-light) .card-head-bar p {
          color: #64748b !important;
        }

        :global(.theme-light) .form-group label {
          color: #1e293b !important;
        }

        :global(.theme-light) .cyber-input,
        :global(.theme-light) .cyber-select,
        :global(.theme-light) .cyber-textarea {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .table-toolbar-bar {
          border-bottom-color: #f1f5f9 !important;
        }

        :global(.theme-light) .search-box-input {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
        }

        :global(.theme-light) .search-box-input input {
          color: #0f172a !important;
        }

        :global(.theme-light) .filter-select-box {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .cyber-table th {
          background: #f8fafc !important;
          color: #475569 !important;
          border-bottom-color: #e2e8f0 !important;
        }

        :global(.theme-light) .category-row-item {
          border-bottom-color: #f1f5f9 !important;
        }

        :global(.theme-light) .category-row-item:hover {
          background: #f8fafc !important;
        }

        :global(.theme-light) .category-name-cell strong {
          color: #0f172a !important;
        }

        :global(.theme-light) .category-slug-cell {
          color: #64748b !important;
        }

        :global(.theme-light) .action-btn-small {
          background: #f8fafc !important;
          border-color: #e2e8f0 !important;
          color: #475569 !important;
        }

        :global(.theme-light) .action-btn-small:hover {
          background: #f1f5f9 !important;
          color: #0f172a !important;
          border-color: #cbd5e1 !important;
        }

        :global(.theme-light) .modal-delete-card {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15) !important;
        }

        :global(.theme-light) .modal-delete-content h3 {
          color: #0f172a !important;
        }

        :global(.theme-light) .modal-danger-desc {
          color: #64748b !important;
        }

        :global(.theme-light) .modal-target-item-box {
          background: #f8fafc !important;
          border-color: #e2e8f0 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .btn-modal-cancel {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #475569 !important;
        }
      `}</style>
    </div>
  );
}
