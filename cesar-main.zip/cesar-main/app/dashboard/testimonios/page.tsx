"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import {
  MessageSquareQuote,
  Plus,
  Link2,
  Share2,
  Copy,
  Check,
  Star,
  User,
  Briefcase,
  UploadCloud,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Eye,
  EyeOff,
  Edit2,
  Trash2,
  X,
  Search,
  Filter,
  RefreshCw,
  Loader2,
  Send,
  Sparkles,
  ExternalLink,
  MessageCircle,
  Mail,
  Calendar,
} from "lucide-react";

interface TestimonialItem {
  id: string;
  name: string;
  role?: string | null;
  company?: string | null;
  avatar?: string | null;
  content: string;
  rating: number;
  status: "PUBLICADO" | "PENDIENTE" | "ARCHIVADO";
  token?: string | null;
  tokenExpiry?: string | null;
  isCompleted: boolean;
  clientEmail?: string | null;
  clientNotes?: string | null;
  createdAt: string;
  updatedAt: string;
}

const PRESET_AVATARS = [
  "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80",
];

export default function TestimonialsDashboardPage() {
  const [testimonials, setTestimonials] = useState<TestimonialItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [origin, setOrigin] = useState<string>("");

  // Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<"success" | "error">("success");

  // Modal 1: Generar Enlace Temporal para el Cliente
  const [showLinkModal, setShowLinkModal] = useState<boolean>(false);
  const [linkClientName, setLinkClientName] = useState<string>("");
  const [linkClientRole, setLinkClientRole] = useState<string>("");
  const [linkClientEmail, setLinkClientEmail] = useState<string>("");
  const [linkClientNotes, setLinkClientNotes] = useState<string>("");
  const [linkExpiryDays, setLinkExpiryDays] = useState<string>("0"); // 0 = hasta que complete
  const [isGeneratingLink, setIsGeneratingLink] = useState<boolean>(false);
  const [generatedLinkUrl, setGeneratedLinkUrl] = useState<string | null>(null);
  const [isLinkCopied, setIsLinkCopied] = useState<boolean>(false);

  // Modal 2: Crear / Editar Testimonio Manual
  const [showFormModal, setShowFormModal] = useState<boolean>(false);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formName, setFormName] = useState<string>("");
  const [formRole, setFormRole] = useState<string>("");
  const [formCompany, setFormCompany] = useState<string>("");
  const [formAvatar, setFormAvatar] = useState<string>("");
  const [formContent, setFormContent] = useState<string>("");
  const [formRating, setFormRating] = useState<number>(5);
  const [formStatus, setFormStatus] = useState<"PUBLICADO" | "PENDIENTE" | "ARCHIVADO">("PUBLICADO");
  const [isUploadingAvatar, setIsUploadingAvatar] = useState<boolean>(false);
  const [isSubmittingForm, setIsSubmittingForm] = useState<boolean>(false);
  const avatarInputRef = useRef<HTMLInputElement>(null);

  // Modal 3: Confirmación de Eliminación
  const [showDeleteModal, setShowDeleteModal] = useState<boolean>(false);
  const [itemToDelete, setItemToDelete] = useState<TestimonialItem | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  useEffect(() => {
    if (typeof window !== "undefined") {
      setOrigin(window.location.origin);
    }
  }, []);

  const showToast = (msg: string, type: "success" | "error" = "success") => {
    setToastMessage(msg);
    setToastType(type);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Cargar Testimonios
  const loadTestimonials = useCallback(async () => {
    setIsLoading(true);
    try {
      let url = "/api/testimonials";
      const params = new URLSearchParams();
      if (searchQuery.trim()) params.append("q", searchQuery.trim());
      if (statusFilter !== "ALL") params.append("status", statusFilter);
      if (params.toString()) url += `?${params.toString()}`;

      const res = await fetch(url);
      const data = await res.json();
      if (data.success) {
        setTestimonials(data.testimonials || []);
      } else {
        showToast(data.error || "Error al cargar testimonios.", "error");
      }
    } catch (e) {
      console.error(e);
      showToast("Error de conexión al cargar testimonios.", "error");
    } finally {
      setIsLoading(false);
    }
  }, [searchQuery, statusFilter]);

  useEffect(() => {
    loadTestimonials();
  }, [loadTestimonials]);

  // Abrir Modal de Enlace para Cliente
  const handleOpenLinkModal = () => {
    setLinkClientName("");
    setLinkClientRole("");
    setLinkClientEmail("");
    setLinkClientNotes("");
    setLinkExpiryDays("0");
    setGeneratedLinkUrl(null);
    setIsLinkCopied(false);
    setShowLinkModal(true);
  };

  // Generar Enlace de Invitación
  const handleGenerateClientLink = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsGeneratingLink(true);
    try {
      const payload = {
        generateLink: true,
        name: linkClientName.trim() || "Cliente Invitado",
        role: linkClientRole.trim() || null,
        clientEmail: linkClientEmail.trim() || null,
        clientNotes: linkClientNotes.trim() || null,
        expiryDays: Number(linkExpiryDays),
      };

      const res = await fetch("/api/testimonials", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();

      if (data.success && data.token) {
        const fullUrl = `${origin}/testimonio/${data.token}`;
        setGeneratedLinkUrl(fullUrl);
        showToast("¡Enlace temporal para cliente generado!", "success");
        loadTestimonials();
      } else {
        showToast(data.error || "Error al generar enlace.", "error");
      }
    } catch (err) {
      console.error(err);
      showToast("Error al conectar con el servidor.", "error");
    } finally {
      setIsGeneratingLink(false);
    }
  };

  // Copiar Enlace al Portapapeles
  const handleCopyLink = (url: string) => {
    navigator.clipboard.writeText(url);
    setIsLinkCopied(true);
    showToast("Enlace copiado al portapapeles.", "success");
    setTimeout(() => setIsLinkCopied(false), 3000);
  };

  // Abrir Modal Manual (Crear)
  const handleOpenCreateManual = () => {
    setIsEditing(false);
    setEditingId(null);
    setFormName("");
    setFormRole("");
    setFormCompany("");
    setFormAvatar("");
    setFormContent("");
    setFormRating(5);
    setFormStatus("PUBLICADO");
    setShowFormModal(true);
  };

  // Abrir Modal Manual (Editar)
  const handleOpenEditManual = (t: TestimonialItem) => {
    setIsEditing(true);
    setEditingId(t.id);
    setFormName(t.name || "");
    setFormRole(t.role || "");
    setFormCompany(t.company || "");
    setFormAvatar(t.avatar || "");
    setFormContent(t.content || "");
    setFormRating(t.rating || 5);
    setFormStatus(t.status || "PUBLICADO");
    setShowFormModal(true);
  };

  // Subir Foto Avatar
  const handleUploadAvatar = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingAvatar(true);
    try {
      const formData = new FormData();
      formData.append("file", file);

      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      if (data.url) {
        setFormAvatar(data.url);
        showToast("Foto subida correctamente.", "success");
      }
    } catch (err) {
      console.error(err);
      showToast("Error al subir archivo.", "error");
    } finally {
      setIsUploadingAvatar(false);
      if (avatarInputRef.current) avatarInputRef.current.value = "";
    }
  };

  // Guardar Testimonio Manual
  const handleSubmitManual = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formName.trim()) {
      showToast("El nombre del cliente es obligatorio.", "error");
      return;
    }
    if (!formContent.trim()) {
      showToast("El contenido de la reseña es obligatorio.", "error");
      return;
    }

    setIsSubmittingForm(true);
    try {
      const payload: any = {
        name: formName.trim(),
        role: formRole.trim() || null,
        company: formCompany.trim() || null,
        avatar: formAvatar || null,
        content: formContent.trim(),
        rating: formRating,
        status: formStatus,
      };

      let res;
      if (isEditing && editingId) {
        payload.id = editingId;
        res = await fetch("/api/testimonials", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      } else {
        res = await fetch("/api/testimonials", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      }

      const data = await res.json();
      if (data.success) {
        showToast(data.message || "Testimonio guardado con éxito.", "success");
        setShowFormModal(false);
        loadTestimonials();
      } else {
        showToast(data.error || "Error al guardar el testimonio.", "error");
      }
    } catch (err) {
      console.error(err);
      showToast("Error de conexión al servidor.", "error");
    } finally {
      setIsSubmittingForm(false);
    }
  };

  // Cambiar Estado Rápido (Publicar / Despublicar)
  const handleToggleStatus = async (t: TestimonialItem) => {
    const nextStatus = t.status === "PUBLICADO" ? "PENDIENTE" : "PUBLICADO";
    try {
      const res = await fetch("/api/testimonials", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: t.id, status: nextStatus }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(
          nextStatus === "PUBLICADO" ? "Testimonio publicado en el Home." : "Testimonio puesto en borrador/pendiente.",
          "success"
        );
        loadTestimonials();
      }
    } catch (err) {
      console.error(err);
      showToast("Error al actualizar estado.", "error");
    }
  };

  // Eliminar Testimonio
  const handleConfirmDelete = async () => {
    if (!itemToDelete) return;
    setIsDeleting(true);
    try {
      const res = await fetch(`/api/testimonials?id=${itemToDelete.id}`, {
        method: "DELETE",
      });
      const data = await res.json();
      if (data.success) {
        showToast("Testimonio eliminado de la base de datos.", "success");
        setShowDeleteModal(false);
        setItemToDelete(null);
        loadTestimonials();
      } else {
        showToast(data.error || "Error al eliminar testimonio.", "error");
      }
    } catch (err) {
      console.error(err);
      showToast("Error al conectar con el servidor.", "error");
    } finally {
      setIsDeleting(false);
    }
  };

  // Métricas
  const totalCount = testimonials.length;
  const publishedCount = testimonials.filter((t) => t.status === "PUBLICADO" && t.isCompleted).length;
  const pendingCount = testimonials.filter((t) => t.status === "PENDIENTE" && t.isCompleted).length;
  const activeLinksCount = testimonials.filter((t) => !t.isCompleted && t.token).length;

  return (
    <div className="techlab-testimonials-dashboard">
      {/* Toast Notification */}
      {toastMessage && (
        <div className={`techlab-toast ${toastType}`}>
          {toastType === "success" ? <CheckCircle2 /> : <AlertTriangle />}
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Cabecera Superior */}
      <div className="testimonials-header-bar">
        <div className="header-title-group">
          <div className="header-icon-badge">
            <MessageSquareQuote />
          </div>
          <div>
            <h1>Gestión de Testimonios y Reseñas</h1>
            <p>Genera enlaces temporales para tus clientes o administra reseñas directamente para el Home</p>
          </div>
        </div>

        <div className="header-actions-group">
          <button
            type="button"
            className="btn-generate-link-neon"
            onClick={handleOpenLinkModal}
          >
            <Link2 />
            <span>Generar Enlace para Cliente</span>
          </button>

          <button
            type="button"
            className="btn-create-manual"
            onClick={handleOpenCreateManual}
          >
            <Plus />
            <span>Crear Reseña Manual</span>
          </button>
        </div>
      </div>

      {/* Tarjetas KPI */}
      <section className="testimonials-kpi-grid">
        <div className="kpi-card total">
          <div className="kpi-icon-box">
            <MessageSquareQuote />
          </div>
          <div className="kpi-info">
            <span className="kpi-num">{totalCount}</span>
            <span className="kpi-label">Total Testimonios</span>
          </div>
        </div>

        <div className="kpi-card published">
          <div className="kpi-icon-box">
            <CheckCircle2 />
          </div>
          <div className="kpi-info">
            <span className="kpi-num">{publishedCount}</span>
            <span className="kpi-label">Publicados en Home</span>
          </div>
        </div>

        <div className="kpi-card pending">
          <div className="kpi-icon-box">
            <Clock />
          </div>
          <div className="kpi-info">
            <span className="kpi-num">{pendingCount}</span>
            <span className="kpi-label">Pendientes por Revisar</span>
          </div>
        </div>

        <div className="kpi-card active-links">
          <div className="kpi-icon-box">
            <Link2 />
          </div>
          <div className="kpi-info">
            <span className="kpi-num">{activeLinksCount}</span>
            <span className="kpi-label">Enlaces de Cliente Activos</span>
          </div>
        </div>
      </section>

      {/* Barra de Búsqueda y Filtros */}
      <div className="testimonials-filter-bar">
        <div className="search-input-wrapper">
          <Search />
          <input
            type="text"
            placeholder="Buscar por nombre, cargo, empresa o contenido de reseña..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <button
              type="button"
              className="clear-search-btn"
              onClick={() => setSearchQuery("")}
            >
              <X />
            </button>
          )}
        </div>

        <div className="filter-controls-group">
          <div className="status-filter-select-wrapper">
            <Filter />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="status-dropdown-select"
            >
              <option value="ALL">Todos los estados</option>
              <option value="PUBLICADO">Publicados</option>
              <option value="PENDIENTE">Pendientes / Enlaces</option>
              <option value="ARCHIVADO">Archivados</option>
            </select>
          </div>

          <button
            type="button"
            className="btn-refresh-data"
            onClick={loadTestimonials}
            title="Refrescar lista"
          >
            <RefreshCw className={isLoading ? "animate-spin" : ""} />
          </button>
        </div>
      </div>

      {/* Grid de Tarjetas de Testimonios */}
      {isLoading ? (
        <div className="loading-state-container">
          <Loader2 className="animate-spin" />
          <span>Cargando...</span>
        </div>
      ) : testimonials.length === 0 ? (
        <div className="empty-state-box">
          <MessageSquareQuote />
          <h3>No hay testimonios registrados</h3>
          <p>Genera un enlace para tu cliente o agrega un testimonio manualmente para mostrarlo en el Home.</p>
          <div className="empty-actions-row">
            <button
              type="button"
              className="btn-empty-link"
              onClick={handleOpenLinkModal}
            >
              <Link2 />
              <span>Generar Enlace para Cliente</span>
            </button>
            <button
              type="button"
              className="btn-empty-manual"
              onClick={handleOpenCreateManual}
            >
              <Plus />
              <span>Agregar Testimonio Manual</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="testimonials-cards-grid">
          {testimonials.map((t) => {
            const initials = t.name
              ? t.name
                  .split(" ")
                  .map((w) => w[0])
                  .slice(0, 2)
                  .join("")
                  .toUpperCase()
              : "CL";

            const clientLinkUrl = t.token ? `${origin}/testimonio/${t.token}` : null;

            return (
              <div
                key={t.id}
                className={`testimonial-master-card ${t.status.toLowerCase()} ${
                  !t.isCompleted ? "is-waiting-client" : ""
                }`}
              >
                {/* Cabecera de la Tarjeta */}
                <div className="card-top-row">
                  <div className="client-author-box">
                    <div className="client-avatar-circle">
                      {t.avatar ? (
                        <img src={t.avatar} alt={t.name} />
                      ) : (
                        <span>{initials}</span>
                      )}
                    </div>
                    <div className="client-text-info">
                      <strong>{t.name}</strong>
                      <small>{t.role || t.company || "Cliente"}</small>
                    </div>
                  </div>

                  {/* Badges de Estado */}
                  <div className="card-status-badges">
                    {!t.isCompleted && t.token ? (
                      <span className="status-badge link-sent">
                        <Clock />
                        <span>Esperando Cliente</span>
                      </span>
                    ) : t.status === "PUBLICADO" ? (
                      <span className="status-badge published">
                        <CheckCircle2 />
                        <span>Publicado en Home</span>
                      </span>
                    ) : (
                      <span className="status-badge pending">
                        <Clock />
                        <span>Borrador / Pendiente</span>
                      </span>
                    )}
                  </div>
                </div>

                {/* Estrellas y Contenido de la Reseña */}
                {t.isCompleted ? (
                  <>
                    <div className="card-stars-row">
                      {"★".repeat(t.rating)}
                      {"☆".repeat(5 - t.rating)}
                    </div>
                    <p className="card-quote-text">“{t.content}”</p>
                  </>
                ) : (
                  <div className="waiting-client-box">
                    <p>
                      <strong>Enlace de invitación generado:</strong> El cliente aún no ha completado el formulario de
                      testimonio.
                    </p>
                    {clientLinkUrl && (
                      <div className="invite-link-copy-row">
                        <input type="text" readOnly value={clientLinkUrl} />
                        <button
                          type="button"
                          onClick={() => handleCopyLink(clientLinkUrl)}
                          title="Copiar enlace para el cliente"
                        >
                          <Copy />
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* Pie de Tarjeta y Botones de Acción */}
                <div className="card-footer-actions">
                  <div className="footer-left-info">
                    {t.token && !t.isCompleted && clientLinkUrl && (
                      <a
                        href={`https://api.whatsapp.com/send?text=${encodeURIComponent(
                          `¡Hola ${t.name !== "Cliente Invitado" ? t.name : ""}! Por favor déjanos tu opinión sobre nuestro servicio en este enlace: ${clientLinkUrl}`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn-whatsapp-share"
                        title="Enviar por WhatsApp"
                      >
                        <MessageCircle />
                        <span>WhatsApp</span>
                      </a>
                    )}
                  </div>

                  <div className="footer-action-buttons">
                    {t.isCompleted && (
                      <button
                        type="button"
                        className={`btn-toggle-publish ${t.status === "PUBLICADO" ? "is-pub" : ""}`}
                        onClick={() => handleToggleStatus(t)}
                        title={t.status === "PUBLICADO" ? "Ocultar del Home" : "Publicar en el Home"}
                      >
                        {t.status === "PUBLICADO" ? <EyeOff /> : <Eye />}
                        <span>{t.status === "PUBLICADO" ? "Ocultar" : "Publicar"}</span>
                      </button>
                    )}

                    <button
                      type="button"
                      className="btn-card-edit"
                      onClick={() => handleOpenEditManual(t)}
                      title="Editar testimonio"
                    >
                      <Edit2 />
                    </button>

                    <button
                      type="button"
                      className="btn-card-delete"
                      onClick={() => {
                        setItemToDelete(t);
                        setShowDeleteModal(true);
                      }}
                      title="Eliminar testimonio"
                    >
                      <Trash2 />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* =================================================================
          MODAL 1: GENERAR ENLACE TEMPORAL PARA EL CLIENTE
          ================================================================= */}
      {showLinkModal && (
        <div className="techlab-modal-backdrop" onClick={() => setShowLinkModal(false)}>
          <div className="testimonial-modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="modal-top-header">
              <div className="modal-title-row">
                <div className="modal-header-icon link-icon">
                  <Link2 />
                </div>
                <div>
                  <h3>Generar Enlace Temporal para Cliente</h3>
                  <p>Envía este enlace a tu cliente para que escriba su reseña, califique con estrellas y suba su foto</p>
                </div>
              </div>
              <button
                type="button"
                className="btn-close-modal"
                onClick={() => setShowLinkModal(false)}
              >
                <X />
              </button>
            </div>

            {generatedLinkUrl ? (
              /* Enlace Generado Exitosamente */
              <div className="link-success-container">
                <div className="link-success-badge">
                  <CheckCircle2 />
                  <span>¡Enlace de Testimonio Listo!</span>
                </div>
                <p>
                  Comparte este enlace con tu cliente. El formulario permanecerá activo hasta que el cliente envíe su
                  testimonio.
                </p>

                <div className="generated-url-box">
                  <input type="text" readOnly value={generatedLinkUrl} />
                  <button
                    type="button"
                    className="btn-copy-generated"
                    onClick={() => handleCopyLink(generatedLinkUrl)}
                  >
                    {isLinkCopied ? <Check /> : <Copy />}
                    <span>{isLinkCopied ? "Copiado" : "Copiar"}</span>
                  </button>
                </div>

                <div className="share-shortcut-buttons">
                  <a
                    href={`https://api.whatsapp.com/send?text=${encodeURIComponent(
                      `¡Hola ${linkClientName || ""}! Por favor déjanos tu opinión sobre nuestro servicio y trabajo juntos en este enlace: ${generatedLinkUrl}`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-share-whatsapp"
                  >
                    <MessageCircle />
                    <span>Enviar por WhatsApp</span>
                  </a>

                  <a
                    href={`mailto:${linkClientEmail}?subject=${encodeURIComponent(
                      "Tu opinión sobre nuestro servicio - TechLab"
                    )}&body=${encodeURIComponent(
                      `Hola ${linkClientName || ""},\n\nNos encantaría conocer tu experiencia y opinión sobre nuestro trabajo juntos. Puedes dejar tu reseña y foto en este enlace:\n\n${generatedLinkUrl}\n\n¡Muchas gracias!`
                    )}`}
                    className="btn-share-email"
                  >
                    <Mail />
                    <span>Enviar por Correo</span>
                  </a>
                </div>

                <div className="modal-bottom-actions right-align">
                  <button
                    type="button"
                    className="btn-cancel-modal"
                    onClick={() => setShowLinkModal(false)}
                  >
                    Cerrar
                  </button>
                </div>
              </div>
            ) : (
              /* Formulario para Generar Enlace */
              <form onSubmit={handleGenerateClientLink} className="modal-form-body">
                <div className="form-fields-grid">
                  <div className="form-field-group">
                    <label>Nombre del Cliente (opcional):</label>
                    <div className="input-icon-box">
                      <User />
                      <input
                        type="text"
                        placeholder="ej. María López"
                        value={linkClientName}
                        onChange={(e) => setLinkClientName(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="form-field-group">
                    <label>Cargo o Empresa (opcional):</label>
                    <div className="input-icon-box">
                      <Briefcase />
                      <input
                        type="text"
                        placeholder="ej. Emprendedora"
                        value={linkClientRole}
                        onChange={(e) => setLinkClientRole(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="form-field-group full-width">
                    <label>Correo del Cliente (opcional):</label>
                    <div className="input-icon-box">
                      <Mail />
                      <input
                        type="email"
                        placeholder="cliente@empresa.com"
                        value={linkClientEmail}
                        onChange={(e) => setLinkClientEmail(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="form-field-group full-width">
                    <label>Duración / Vigencia del Formulario:</label>
                    <div className="input-icon-box">
                      <Clock />
                      <select
                        value={linkExpiryDays}
                        onChange={(e) => setLinkExpiryDays(e.target.value)}
                        className="modal-select-field"
                      >
                        <option value="0">Sin límite (activo hasta que el cliente complete el formulario)</option>
                        <option value="1">1 día</option>
                        <option value="3">3 días</option>
                        <option value="7">7 días (1 semana)</option>
                        <option value="30">30 días (1 mes)</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="modal-bottom-actions">
                  <button
                    type="button"
                    className="btn-cancel-modal"
                    onClick={() => setShowLinkModal(false)}
                    disabled={isGeneratingLink}
                  >
                    Cancelar
                  </button>

                  <button
                    type="submit"
                    className="btn-submit-link-neon"
                    disabled={isGeneratingLink}
                  >
                    {isGeneratingLink ? <Loader2 className="animate-spin" /> : <Link2 />}
                    <span>{isGeneratingLink ? "Generando..." : "Crear Enlace de Invitación"}</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* =================================================================
          MODAL 2: CREAR / EDITAR TESTIMONIO MANUAL
          ================================================================= */}
      {showFormModal && (
        <div className="techlab-modal-backdrop" onClick={() => setShowFormModal(false)}>
          <div className="testimonial-modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="modal-top-header">
              <div className="modal-title-row">
                <div className="modal-header-icon">
                  <MessageSquareQuote />
                </div>
                <div>
                  <h3>{isEditing ? "Editar Testimonio" : "Agregar Testimonio Manual"}</h3>
                  <p>Publica una reseña directamente en la base de datos para mostrarla en el Home</p>
                </div>
              </div>
              <button
                type="button"
                className="btn-close-modal"
                onClick={() => setShowFormModal(false)}
              >
                <X />
              </button>
            </div>

            <form onSubmit={handleSubmitManual} className="modal-form-body">
              {/* Foto de Perfil */}
              <div className="avatar-picker-mini-row">
                <div className="avatar-preview-box">
                  {formAvatar ? (
                    <img src={formAvatar} alt="Preview" />
                  ) : (
                    <User />
                  )}
                </div>
                <div className="avatar-controls">
                  <div className="avatar-btns-row">
                    <button
                      type="button"
                      className="btn-upload-pic"
                      onClick={() => avatarInputRef.current?.click()}
                      disabled={isUploadingAvatar}
                    >
                      {isUploadingAvatar ? <Loader2 className="animate-spin" /> : <UploadCloud />}
                      <span>{isUploadingAvatar ? "Subiendo..." : "Subir Foto"}</span>
                    </button>
                    <input
                      ref={avatarInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleUploadAvatar}
                      style={{ display: "none" }}
                    />
                    {formAvatar && (
                      <button
                        type="button"
                        className="btn-clear-photo"
                        onClick={() => setFormAvatar("")}
                      >
                        Quitar foto
                      </button>
                    )}
                  </div>
                  <div className="preset-dots-row">
                    {PRESET_AVATARS.map((url, idx) => (
                      <img
                        key={idx}
                        src={url}
                        alt="Preset"
                        className={`preset-thumb ${formAvatar === url ? "selected" : ""}`}
                        onClick={() => setFormAvatar(url)}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Campos */}
              <div className="form-fields-grid">
                <div className="form-field-group">
                  <label>Nombre del Cliente: *</label>
                  <input
                    type="text"
                    placeholder="ej. Carlos Méndez"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    required
                    className="modal-text-input"
                  />
                </div>

                <div className="form-field-group">
                  <label>Cargo o Profesión (ej. Emprendedora, CEO):</label>
                  <input
                    type="text"
                    placeholder="ej. Emprendedora"
                    value={formRole}
                    onChange={(e) => setFormRole(e.target.value)}
                    className="modal-text-input"
                  />
                </div>

                <div className="form-field-group">
                  <label>Calificación en Estrellas:</label>
                  <select
                    value={formRating}
                    onChange={(e) => setFormRating(Number(e.target.value))}
                    className="modal-select-field"
                  >
                    <option value="5">★★★★★ (5 Estrellas - Excelente)</option>
                    <option value="4">★★★★☆ (4 Estrellas - Muy Bueno)</option>
                    <option value="3">★★★☆☆ (3 Estrellas - Bueno)</option>
                    <option value="2">★★☆☆☆ (2 Estrellas - Regular)</option>
                    <option value="1">★☆☆☆☆ (1 Estrella - Malo)</option>
                  </select>
                </div>

                <div className="form-field-group">
                  <label>Estado en la Web:</label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as any)}
                    className="modal-select-field"
                  >
                    <option value="PUBLICADO">Publicado en el Home</option>
                    <option value="PENDIENTE">Borrador / Pendiente</option>
                    <option value="ARCHIVADO">Archivado</option>
                  </select>
                </div>

                <div className="form-field-group full-width">
                  <label>Contenido del Testimonio / Reseña: *</label>
                  <textarea
                    rows={4}
                    placeholder="Escribe aquí el testimonio del cliente..."
                    value={formContent}
                    onChange={(e) => setFormContent(e.target.value)}
                    required
                    className="modal-textarea-field"
                  />
                </div>
              </div>

              <div className="modal-bottom-actions">
                <button
                  type="button"
                  className="btn-cancel-modal"
                  onClick={() => setShowFormModal(false)}
                  disabled={isSubmittingForm}
                >
                  Cancelar
                </button>

                <button
                  type="submit"
                  className="btn-submit-manual-neon"
                  disabled={isSubmittingForm}
                >
                  {isSubmittingForm ? <Loader2 className="animate-spin" /> : <Check />}
                  <span>{isSubmittingForm ? "Guardando..." : isEditing ? "Actualizar Testimonio" : "Guardar Testimonio"}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =================================================================
          MODAL 3: CONFIRMACIÓN DE ELIMINACIÓN
          ================================================================= */}
      {showDeleteModal && itemToDelete && (
        <div className="techlab-modal-backdrop" onClick={() => setShowDeleteModal(false)}>
          <div className="delete-modal-card-animated" onClick={(e) => e.stopPropagation()}>
            <div className="delete-icon-animated-badge">
              <Trash2 />
            </div>
            <h3>¿Eliminar este testimonio?</h3>
            <p>
              Esta acción es irreversible y eliminará el testimonio de <strong>"{itemToDelete.name}"</strong> de la base
              de datos.
            </p>

            <div className="delete-modal-buttons">
              <button
                type="button"
                className="btn-cancel-delete"
                onClick={() => setShowDeleteModal(false)}
                disabled={isDeleting}
              >
                Cancelar
              </button>
              <button
                type="button"
                className="btn-confirm-delete"
                onClick={handleConfirmDelete}
                disabled={isDeleting}
              >
                {isDeleting ? "Eliminando..." : "Sí, eliminar testimonio"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ESTILOS TECHLAB CYBER DARK PRO */}
      <style jsx>{`
        .techlab-testimonials-dashboard {
          padding: 0 0 40px;
          color: inherit;
        }

        /* Toast */
        .techlab-toast {
          position: fixed;
          top: 70px;
          right: 24px;
          z-index: 1000;
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 12px 18px;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 600;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.6);
          animation: slideIn 0.25s ease;
        }

        .techlab-toast.success {
          background: #062316;
          border: 1px solid #16c96f;
          color: #a7f3d0;
        }

        .techlab-toast.error {
          background: #270d0d;
          border: 1px solid #ef4444;
          color: #fca5a5;
        }

        @keyframes slideIn {
          from { opacity: 0; transform: translateY(-16px); }
          to { opacity: 1; transform: translateY(0); }
        }

        /* Header */
        .testimonials-header-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 24px;
          gap: 16px;
        }

        .header-title-group {
          display: flex;
          align-items: center;
          gap: 14px;
        }

        .header-icon-badge {
          width: 48px;
          height: 48px;
          border-radius: 12px;
          background: rgba(22, 201, 111, 0.12);
          border: 1px solid rgba(22, 201, 111, 0.4);
          color: #16c96f;
          display: grid;
          place-items: center;
          box-shadow: 0 0 20px rgba(22, 201, 111, 0.2);
        }

        .header-icon-badge :global(svg) {
          width: 24px;
          height: 24px;
        }

        .header-title-group h1 {
          font-size: 22px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 4px;
          letter-spacing: -0.4px;
        }

        .header-title-group p {
          font-size: 13px;
          color: #94a3b8;
          margin: 0;
        }

        .header-actions-group {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .btn-generate-link-neon {
          height: 42px;
          padding: 0 18px;
          border-radius: 8px;
          background: linear-gradient(110deg, #12b85f, #18d878);
          border: 1px solid rgba(67, 255, 147, 0.4);
          color: #030b12;
          font-size: 13px;
          font-weight: 800;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          box-shadow: 0 0 20px rgba(22, 201, 111, 0.3);
          transition: all 0.15s ease;
        }

        .btn-generate-link-neon:hover {
          transform: translateY(-2px);
          box-shadow: 0 0 26px rgba(22, 201, 111, 0.5);
        }

        .btn-generate-link-neon :global(svg) {
          width: 16px;
          height: 16px;
        }

        .btn-create-manual {
          height: 42px;
          padding: 0 16px;
          border-radius: 8px;
          background: #07131e;
          border: 1px solid rgba(56, 189, 248, 0.3);
          color: #38bdf8;
          font-size: 13px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
        }

        .btn-create-manual:hover {
          background: rgba(56, 189, 248, 0.12);
        }

        .btn-create-manual :global(svg) {
          width: 16px;
          height: 16px;
        }

        /* KPI Grid */
        .testimonials-kpi-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 16px;
          margin-bottom: 24px;
        }

        .kpi-card {
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          padding: 16px;
          display: flex;
          align-items: center;
          gap: 14px;
        }

        .kpi-icon-box {
          width: 42px;
          height: 42px;
          border-radius: 8px;
          display: grid;
          place-items: center;
        }

        .kpi-icon-box :global(svg) {
          width: 20px;
          height: 20px;
        }

        .kpi-card.total .kpi-icon-box { background: rgba(56, 189, 248, 0.12); color: #38bdf8; }
        .kpi-card.published .kpi-icon-box { background: rgba(22, 201, 111, 0.12); color: #16c96f; }
        .kpi-card.pending .kpi-icon-box { background: rgba(245, 158, 11, 0.12); color: #f59e0b; }
        .kpi-card.active-links .kpi-icon-box { background: rgba(168, 85, 247, 0.12); color: #c084fc; }

        .kpi-info {
          display: flex;
          flex-direction: column;
        }

        .kpi-num {
          font-size: 22px;
          font-weight: 800;
          color: #ffffff;
        }

        .kpi-label {
          font-size: 11px;
          color: #94a3b8;
          font-weight: 600;
          text-transform: uppercase;
        }

        /* Filter Bar */
        .testimonials-filter-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          padding: 12px 18px;
          margin-bottom: 24px;
        }

        .search-input-wrapper {
          flex: 1;
          position: relative;
          display: flex;
          align-items: center;
        }

        .search-input-wrapper :global(svg) {
          position: absolute;
          left: 12px;
          width: 15px;
          height: 15px;
          color: #64748b;
        }

        .search-input-wrapper input {
          width: 100%;
          height: 38px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 0 36px;
          color: #ffffff;
          font-size: 13px;
          outline: none;
        }

        .clear-search-btn {
          position: absolute;
          right: 10px;
          background: none;
          border: none;
          color: #64748b;
          cursor: pointer;
        }

        .filter-controls-group {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .status-filter-select-wrapper {
          position: relative;
          display: flex;
          align-items: center;
        }

        .status-filter-select-wrapper :global(svg) {
          position: absolute;
          left: 10px;
          width: 13px;
          height: 13px;
          color: #64748b;
        }

        .status-dropdown-select {
          height: 38px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 0 14px 0 30px;
          color: #cbd5e1;
          font-size: 12px;
          font-weight: 600;
          outline: none;
        }

        .btn-refresh-data {
          width: 38px;
          height: 38px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          color: #94a3b8;
          display: grid;
          place-items: center;
          cursor: pointer;
        }

        /* Testimonials Cards Grid */
        .testimonials-cards-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 20px;
        }

        .testimonial-master-card {
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 12px;
          padding: 20px;
          display: flex;
          flex-direction: column;
          gap: 14px;
          transition: transform 0.15s, border-color 0.15s;
        }

        .testimonial-master-card:hover {
          border-color: rgba(56, 189, 248, 0.3);
          transform: translateY(-2px);
        }

        .testimonial-master-card.is-waiting-client {
          border-style: dashed;
          border-color: rgba(168, 85, 247, 0.35);
        }

        .card-top-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .client-author-box {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .client-avatar-circle {
          width: 42px;
          height: 42px;
          border-radius: 50%;
          background: linear-gradient(135deg, #167e8d, #16c96f);
          overflow: hidden;
          display: grid;
          place-items: center;
          font-size: 13px;
          font-weight: 800;
          color: #ffffff;
        }

        .client-avatar-circle img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .client-text-info {
          display: flex;
          flex-direction: column;
        }

        .client-text-info strong {
          font-size: 14px;
          color: #ffffff;
        }

        .client-text-info small {
          font-size: 11px;
          color: #94a3b8;
        }

        .status-badge {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          padding: 3px 10px;
          border-radius: 20px;
          font-size: 11px;
          font-weight: 700;
        }

        .status-badge :global(svg) {
          width: 12px;
          height: 12px;
        }

        .status-badge.published {
          background: rgba(22, 201, 111, 0.12);
          border: 1px solid rgba(22, 201, 111, 0.3);
          color: #16c96f;
        }

        .status-badge.pending {
          background: rgba(245, 158, 11, 0.12);
          border: 1px solid rgba(245, 158, 11, 0.3);
          color: #f59e0b;
        }

        .status-badge.link-sent {
          background: rgba(168, 85, 247, 0.12);
          border: 1px solid rgba(168, 85, 247, 0.3);
          color: #c084fc;
        }

        .card-stars-row {
          color: #16c96f;
          font-size: 14px;
          letter-spacing: 2px;
        }

        .card-quote-text {
          font-size: 13px;
          line-height: 1.6;
          color: #cbd5e1;
          font-style: italic;
          margin: 0;
          min-height: 48px;
        }

        .waiting-client-box {
          background: #07131e;
          border: 1px solid rgba(168, 85, 247, 0.2);
          border-radius: 8px;
          padding: 12px 14px;
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .waiting-client-box p {
          font-size: 11px;
          color: #cbd5e1;
          margin: 0;
        }

        .invite-link-copy-row {
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .invite-link-copy-row input {
          flex: 1;
          height: 30px;
          background: #03080e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 4px;
          padding: 0 8px;
          font-size: 11px;
          color: #38bdf8;
          outline: none;
        }

        .invite-link-copy-row button {
          width: 30px;
          height: 30px;
          background: #38bdf8;
          border: none;
          border-radius: 4px;
          color: #030a10;
          display: grid;
          place-items: center;
          cursor: pointer;
        }

        .invite-link-copy-row button :global(svg) {
          width: 14px;
          height: 14px;
        }

        /* Card Footer */
        .card-footer-actions {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding-top: 12px;
          border-top: 1px solid rgba(255, 255, 255, 0.06);
        }

        .btn-whatsapp-share {
          height: 28px;
          padding: 0 10px;
          border-radius: 5px;
          background: rgba(37, 211, 102, 0.12);
          border: 1px solid rgba(37, 211, 102, 0.35);
          color: #25d366;
          font-size: 11px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          gap: 6px;
        }

        .btn-whatsapp-share :global(svg) {
          width: 13px;
          height: 13px;
        }

        .footer-action-buttons {
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .btn-toggle-publish {
          height: 28px;
          padding: 0 10px;
          border-radius: 4px;
          background: rgba(255, 255, 255, 0.06);
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: #cbd5e1;
          font-size: 11px;
          font-weight: 600;
          display: inline-flex;
          align-items: center;
          gap: 4px;
          cursor: pointer;
        }

        .btn-toggle-publish.is-pub {
          background: rgba(22, 201, 111, 0.1);
          border-color: rgba(22, 201, 111, 0.3);
          color: #16c96f;
        }

        .btn-toggle-publish :global(svg) {
          width: 12px;
          height: 12px;
        }

        .btn-card-edit,
        .btn-card-delete {
          width: 28px;
          height: 28px;
          border-radius: 4px;
          display: grid;
          place-items: center;
          cursor: pointer;
        }

        .btn-card-edit {
          background: rgba(56, 189, 248, 0.08);
          border: 1px solid rgba(56, 189, 248, 0.25);
          color: #38bdf8;
        }

        .btn-card-delete {
          background: transparent;
          border: 1px solid rgba(239, 68, 68, 0.25);
          color: #ef4444;
        }

        .btn-card-edit :global(svg),
        .btn-card-delete :global(svg) {
          width: 12px;
          height: 12px;
        }

        /* Loading / Empty States */
        .loading-state-container,
        .empty-state-box {
          padding: 80px 20px;
          text-align: center;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 12px;
          color: #64748b;
        }

        .empty-state-box :global(svg) {
          width: 44px;
          height: 44px;
          color: #16c96f;
          opacity: 0.5;
        }

        .empty-state-box h3 {
          font-size: 17px;
          font-weight: 700;
          color: #cbd5e1;
          margin: 0;
        }

        .empty-state-box p {
          font-size: 13px;
          max-width: 440px;
          margin: 0;
        }

        .empty-actions-row {
          display: flex;
          gap: 10px;
          margin-top: 10px;
        }

        .btn-empty-link {
          height: 38px;
          padding: 0 16px;
          background: #16c96f;
          border: none;
          border-radius: 6px;
          color: #030b12;
          font-size: 12px;
          font-weight: 800;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
        }

        .btn-empty-manual {
          height: 38px;
          padding: 0 16px;
          background: #07131e;
          border: 1px solid rgba(56, 189, 248, 0.3);
          border-radius: 6px;
          color: #38bdf8;
          font-size: 12px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
        }

        /* Modal Backdrop */
        .techlab-modal-backdrop {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.82);
          backdrop-filter: blur(5px);
          display: grid;
          place-items: center;
          z-index: 1000;
          padding: 20px;
          animation: fadeIn 0.15s ease;
        }

        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        .testimonial-modal-card {
          width: 100%;
          max-width: 560px;
          max-height: 90vh;
          overflow-y: auto;
          background: #040c14;
          border: 1px solid rgba(22, 201, 111, 0.3);
          border-radius: 14px;
          box-shadow: 0 24px 70px rgba(0, 0, 0, 0.8), 0 0 30px rgba(22, 201, 111, 0.15);
          display: flex;
          flex-direction: column;
        }

        .modal-top-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 18px 24px;
          background: #07131e;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .modal-title-row {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .modal-header-icon {
          width: 40px;
          height: 40px;
          border-radius: 8px;
          background: rgba(22, 201, 111, 0.12);
          color: #16c96f;
          display: grid;
          place-items: center;
        }

        .modal-header-icon.link-icon {
          background: rgba(56, 189, 248, 0.12);
          color: #38bdf8;
        }

        .modal-header-icon :global(svg) {
          width: 20px;
          height: 20px;
        }

        .modal-title-row h3 {
          font-size: 16px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 2px;
        }

        .modal-title-row p {
          font-size: 12px;
          color: #94a3b8;
          margin: 0;
        }

        .btn-close-modal {
          background: none;
          border: none;
          color: #64748b;
          cursor: pointer;
        }

        .modal-form-body {
          padding: 24px;
          display: flex;
          flex-direction: column;
          gap: 18px;
        }

        .form-fields-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 14px;
        }

        .full-width {
          grid-column: span 2;
        }

        .form-field-group {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .form-field-group label {
          font-size: 11px;
          font-weight: 700;
          color: #cbd5e1;
        }

        .input-icon-box {
          position: relative;
          display: flex;
          align-items: center;
        }

        .input-icon-box :global(svg) {
          position: absolute;
          left: 12px;
          width: 15px;
          height: 15px;
          color: #64748b;
        }

        .input-icon-box input,
        .modal-text-input {
          width: 100%;
          height: 38px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 0 12px;
          color: #ffffff;
          font-size: 13px;
          outline: none;
        }

        .input-icon-box input {
          padding-left: 36px;
        }

        .modal-select-field {
          width: 100%;
          height: 38px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 0 12px;
          color: #ffffff;
          font-size: 13px;
          outline: none;
        }

        .input-icon-box select {
          padding-left: 36px;
        }

        .modal-textarea-field {
          width: 100%;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 12px;
          color: #ffffff;
          font-size: 13px;
          outline: none;
          font-family: inherit;
        }

        /* Avatar Picker Mini */
        .avatar-picker-mini-row {
          display: flex;
          align-items: center;
          gap: 16px;
          padding: 12px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.06);
          border-radius: 8px;
        }

        .avatar-preview-box {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          background: #03080e;
          border: 1px solid rgba(56, 189, 248, 0.4);
          overflow: hidden;
          display: grid;
          place-items: center;
          color: #64748b;
        }

        .avatar-preview-box img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .avatar-controls {
          flex: 1;
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .avatar-btns-row {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .btn-upload-pic {
          height: 28px;
          padding: 0 10px;
          background: rgba(56, 189, 248, 0.12);
          border: 1px solid rgba(56, 189, 248, 0.3);
          border-radius: 4px;
          color: #38bdf8;
          font-size: 11px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          gap: 4px;
          cursor: pointer;
        }

        .btn-clear-photo {
          background: none;
          border: none;
          color: #ef4444;
          font-size: 11px;
          cursor: pointer;
        }

        .preset-dots-row {
          display: flex;
          gap: 4px;
        }

        .preset-thumb {
          width: 22px;
          height: 22px;
          border-radius: 50%;
          object-fit: cover;
          border: 1px solid rgba(255, 255, 255, 0.2);
          cursor: pointer;
        }

        .preset-thumb.selected {
          border-color: #16c96f;
        }

        /* Link Success Card */
        .link-success-container {
          padding: 24px;
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .link-success-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 4px 12px;
          border-radius: 20px;
          background: rgba(22, 201, 111, 0.12);
          border: 1px solid rgba(22, 201, 111, 0.35);
          color: #16c96f;
          font-size: 12px;
          font-weight: 700;
          width: fit-content;
        }

        .link-success-badge :global(svg) {
          width: 14px;
          height: 14px;
        }

        .link-success-container p {
          font-size: 13px;
          color: #94a3b8;
          line-height: 1.5;
          margin: 0;
        }

        .generated-url-box {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .generated-url-box input {
          flex: 1;
          height: 40px;
          background: #07131e;
          border: 1px solid rgba(56, 189, 248, 0.3);
          border-radius: 6px;
          padding: 0 12px;
          color: #38bdf8;
          font-size: 12px;
          font-family: monospace;
          outline: none;
        }

        .btn-copy-generated {
          height: 40px;
          padding: 0 16px;
          background: #38bdf8;
          border: none;
          border-radius: 6px;
          color: #030a10;
          font-size: 12px;
          font-weight: 800;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
        }

        .share-shortcut-buttons {
          display: flex;
          gap: 10px;
        }

        .btn-share-whatsapp {
          flex: 1;
          height: 38px;
          border-radius: 6px;
          background: rgba(37, 211, 102, 0.15);
          border: 1px solid rgba(37, 211, 102, 0.4);
          color: #25d366;
          font-size: 12px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
        }

        .btn-share-email {
          flex: 1;
          height: 38px;
          border-radius: 6px;
          background: rgba(56, 189, 248, 0.12);
          border: 1px solid rgba(56, 189, 248, 0.3);
          color: #38bdf8;
          font-size: 12px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
        }

        /* Modal Actions */
        .modal-bottom-actions {
          display: flex;
          align-items: center;
          justify-content: flex-end;
          gap: 10px;
          padding-top: 10px;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
        }

        .modal-bottom-actions.right-align {
          justify-content: flex-end;
        }

        .btn-cancel-modal {
          height: 38px;
          padding: 0 16px;
          background: transparent;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          color: #cbd5e1;
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
        }

        .btn-submit-link-neon,
        .btn-submit-manual-neon {
          height: 40px;
          padding: 0 20px;
          background: linear-gradient(110deg, #12b85f, #18d878);
          border: 1px solid rgba(67, 255, 147, 0.4);
          border-radius: 6px;
          color: #030b12;
          font-size: 12px;
          font-weight: 800;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          box-shadow: 0 0 18px rgba(22, 201, 111, 0.3);
        }

        /* Delete Modal */
        .delete-modal-card-animated {
          width: 90%;
          max-width: 420px;
          background: #040c14;
          border: 1px solid rgba(239, 68, 68, 0.4);
          border-radius: 12px;
          padding: 24px;
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.8), 0 0 30px rgba(239, 68, 68, 0.2);
        }

        .delete-icon-animated-badge {
          width: 52px;
          height: 52px;
          border-radius: 50%;
          background: rgba(239, 68, 68, 0.15);
          border: 1px solid #ef4444;
          color: #ef4444;
          display: grid;
          place-items: center;
          margin-bottom: 14px;
        }

        .delete-icon-animated-badge :global(svg) {
          width: 24px;
          height: 24px;
        }

        .delete-modal-card-animated h3 {
          font-size: 17px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 8px;
        }

        .delete-modal-card-animated p {
          font-size: 13px;
          color: #94a3b8;
          line-height: 1.5;
          margin: 0 0 20px;
        }

        .delete-modal-buttons {
          width: 100%;
          display: flex;
          gap: 10px;
        }

        .btn-cancel-delete {
          flex: 1;
          height: 38px;
          background: transparent;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          color: #cbd5e1;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
        }

        .btn-confirm-delete {
          flex: 1;
          height: 38px;
          background: #ef4444;
          border: none;
          border-radius: 6px;
          color: #ffffff;
          font-size: 13px;
          font-weight: 700;
          cursor: pointer;
        }

        @media (max-width: 960px) {
          .techlab-testimonials-dashboard {
            padding: 16px;
          }
          .testimonials-kpi-grid {
            grid-template-columns: repeat(2, 1fr);
          }
          .testimonials-cards-grid {
            grid-template-columns: 1fr;
          }
          .testimonials-header-bar {
            flex-direction: column;
            align-items: flex-start;
          }
        }

        /* LIGHT MODE SCOPED OVERRIDES */
        :global(.theme-light) .techlab-testimonials-dashboard {
          color: #0f172a !important;
        }

        :global(.theme-light) .testimonials-header-bar {
          background: transparent !important;
          border: none !important;
        }

        :global(.theme-light) .header-title-group h1 {
          color: #0f172a !important;
        }

        :global(.theme-light) .header-title-group p {
          color: #64748b !important;
        }

        :global(.theme-light) .header-icon-badge {
          background: #ffffff !important;
          border-color: #cbd5e1 !important;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05) !important;
        }

        :global(.theme-light) .btn-create-manual {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .kpi-card {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .kpi-icon-box {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
        }

        :global(.theme-light) .kpi-info-text strong {
          color: #0f172a !important;
        }

        :global(.theme-light) .kpi-info-text span {
          color: #64748b !important;
        }

        :global(.theme-light) .testimonials-filter-bar {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .search-input-wrapper input {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .filter-dropdown-select {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .btn-refresh-data {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #475569 !important;
        }

        :global(.theme-light) .btn-refresh-data:hover {
          background: #f1f5f9 !important;
          color: #0f172a !important;
        }

        /* TESTIMONIAL CARDS IN LIGHT MODE */
        :global(.theme-light) .testimonial-master-card {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .testimonial-master-card.is-waiting-client {
          border-color: #cbd5e1 !important;
          background: #f8fafc !important;
        }

        :global(.theme-light) .client-text-info strong {
          color: #0f172a !important;
        }

        :global(.theme-light) .client-text-info small {
          color: #64748b !important;
        }

        :global(.theme-light) .card-quote-text {
          color: #334155 !important;
        }

        :global(.theme-light) .card-actions-bottom {
          border-top: 1px solid #f1f5f9 !important;
        }

        :global(.theme-light) .btn-action-small {
          background: #f8fafc !important;
          border-color: #e2e8f0 !important;
          color: #475569 !important;
        }

        :global(.theme-light) .btn-action-small:hover {
          background: #f1f5f9 !important;
          color: #0f172a !important;
          border-color: #cbd5e1 !important;
        }

        :global(.theme-light) .btn-action-small.btn-visibility {
          background: #f0fdf4 !important;
          border-color: #bbf7d0 !important;
          color: #16a34a !important;
        }

        :global(.theme-light) .btn-action-small.btn-visibility.hidden {
          background: #fffbeb !important;
          border-color: #fde68a !important;
          color: #d97706 !important;
        }

        :global(.theme-light) .modal-card,
        :global(.theme-light) .delete-modal-card-animated {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15) !important;
        }

        :global(.theme-light) .modal-header h3,
        :global(.theme-light) .delete-modal-card-animated h3 {
          color: #0f172a !important;
        }

        :global(.theme-light) .modal-header p,
        :global(.theme-light) .delete-modal-card-animated p {
          color: #64748b !important;
        }

        :global(.theme-light) .form-group label {
          color: #1e293b !important;
        }

        :global(.theme-light) .form-group input,
        :global(.theme-light) .form-group textarea,
        :global(.theme-light) .form-group select {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .btn-cancel,
        :global(.theme-light) .btn-cancel-delete {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #475569 !important;
        }
      `}</style>
    </div>
  );
}
