"use client";

import { useState, useEffect, useRef } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import {
  ArrowLeft,
  Send,
  Plus,
  Trash2,
  MoveUp,
  MoveDown,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Heading,
  Quote,
  List,
  Code2,
  CheckCircle2,
  AlertTriangle,
  Loader2,
  DollarSign,
  Box,
  Layers,
  UploadCloud,
  CodeXml,
  Globe2,
  ShieldCheck,
  CloudCog,
  Headphones,
  Lightbulb,
} from "lucide-react";

interface Block {
  id: string;
  type: "paragraph" | "heading" | "image" | "quote" | "list" | "code";
  content: string;
  level?: 1 | 2 | 3 | 4;
  align?: "left" | "center" | "right";
  textColor?: string;
  bgColor?: string;
}

interface ServiceCategory {
  id: string;
  name: string;
  slug: string;
  color?: string | null;
}

const AVAILABLE_ICONS = [
  { name: "CodeXml", label: "Desarrollo", icon: CodeXml },
  { name: "Globe2", label: "Web / CMS", icon: Globe2 },
  { name: "ShieldCheck", label: "Seguridad", icon: ShieldCheck },
  { name: "CloudCog", label: "Cloud & DevOps", icon: CloudCog },
  { name: "Headphones", label: "Soporte 24/7", icon: Headphones },
  { name: "Lightbulb", label: "Consultoría", icon: Lightbulb },
  { name: "Box", label: "General", icon: Box },
];

export default function EditServicePage() {
  const params = useParams();
  const router = useRouter();
  const id = params?.id as string;

  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  const [title, setTitle] = useState("");
  const [slug, setSlug] = useState("");
  const [status, setStatus] = useState<"PUBLICADO" | "BORRADOR">("PUBLICADO");
  const [excerpt, setExcerpt] = useState("");
  const [featuredImage, setFeaturedImage] = useState("");

  // Detalles
  const [price, setPrice] = useState("");
  const [priceLabel, setPriceLabel] = useState("Por proyecto");
  const [selectedIcon, setSelectedIcon] = useState("CodeXml");
  const [categoryId, setCategoryId] = useState("");

  // Categorías
  const [categories, setCategories] = useState<ServiceCategory[]>([]);
  const [isUploadingImage, setIsUploadingImage] = useState(false);

  // Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<"success" | "error">("success");

  // Bloques
  const [blocks, setBlocks] = useState<Block[]>([]);
  const [activeBlockId, setActiveBlockId] = useState<string | null>(null);
  const [focusedBlockId, setFocusedBlockId] = useState<string | null>(null);
  const [openInserterId, setOpenInserterId] = useState<string | null>(null);

  const imageInputRef = useRef<HTMLInputElement>(null);

  const showToast = (msg: string, type: "success" | "error" = "success") => {
    setToastMessage(msg);
    setToastType(type);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Cargar Servicio y Categorías
  useEffect(() => {
    if (!id) return;

    const loadData = async () => {
      setIsLoading(true);
      try {
        const [catsRes, servRes] = await Promise.all([
          fetch("/api/services/categories"),
          fetch(`/api/services/${id}`),
        ]);

        const catsData = await catsRes.json();
        if (catsData.success) {
          setCategories(catsData.categories || []);
        }

        const servData = await servRes.json();
        if (servData.success && servData.service) {
          const current = servData.service;
          setTitle(current.title || "");
          setSlug(current.slug || "");
          setStatus(current.status || "PUBLICADO");
          setExcerpt(current.excerpt || "");
          setFeaturedImage(current.featuredImage || "");
          setPrice(current.price || "");
          setPriceLabel(current.priceLabel || "Por proyecto");
          setSelectedIcon(current.icon || "Box");
          setCategoryId(current.categoryId || "");

          // Parsear contenido
          try {
            if (current.content && current.content.startsWith("[")) {
              const parsed = JSON.parse(current.content);
              setBlocks(parsed);
            } else {
              setBlocks([
                {
                  id: "b-1",
                  type: "paragraph",
                  content: current.content || "",
                  align: "left",
                },
              ]);
            }
          } catch {
            setBlocks([
              {
                id: "b-1",
                type: "paragraph",
                content: current.content || "",
                align: "left",
              },
            ]);
          }
        } else {
          showToast("Servicio no encontrado.", "error");
        }
      } catch (err) {
        console.error(err);
        showToast("Error al cargar servicio.", "error");
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, [id]);

  // Subir imagen
  const handleUploadFeatured = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingImage(true);
    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("attachedToTitle", title.trim() || "(sin título)");
      formData.append("attachedToType", "service");
      formData.append("attachedToUrl", `/dashboard/servicios/editar/${id}`);
      formData.append("attachedToId", id);

      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      if (data.url) {
        setFeaturedImage(data.url);
        showToast("Imagen destacada cargada.", "success");
      }
    } catch (err) {
      console.error(err);
      showToast("Error al subir imagen.", "error");
    } finally {
      setIsUploadingImage(false);
      if (imageInputRef.current) imageInputRef.current.value = "";
    }
  };

  // Manipulación de Bloques
  const addBlock = (type: Block["type"]) => {
    const newBlock: Block = {
      id: "b-" + Date.now(),
      type,
      content: "",
      level: type === "heading" ? 2 : undefined,
      align: "left",
    };
    setBlocks([...blocks, newBlock]);
    setFocusedBlockId(newBlock.id);
    setActiveBlockId(newBlock.id);
  };

  const addBlockAfter = (index: number, type: Block["type"]) => {
    const newBlock: Block = {
      id: "b-" + Date.now(),
      type,
      content: "",
      level: type === "heading" ? 2 : undefined,
      align: "left",
    };
    const newBlocks = [...blocks];
    newBlocks.splice(index + 1, 0, newBlock);
    setBlocks(newBlocks);
    setFocusedBlockId(newBlock.id);
    setActiveBlockId(newBlock.id);
    setOpenInserterId(null);
  };

  const handleBlockKeyDown = (
    e: React.KeyboardEvent<HTMLInputElement | HTMLTextAreaElement>,
    index: number,
    block: Block
  ) => {
    if (e.key === "Enter" && !e.shiftKey) {
      if (block.type === "paragraph" || block.type === "heading") {
        e.preventDefault();
        addBlockAfter(index, "paragraph");
      }
    }
  };

  const updateBlock = (blockId: string, updates: Partial<Block>) => {
    setBlocks(blocks.map((b) => (b.id === blockId ? { ...b, ...updates } : b)));
  };

  const removeBlock = (blockId: string) => {
    if (blocks.length <= 1) {
      setBlocks([{ id: "b-" + Date.now(), type: "paragraph", content: "", align: "left" }]);
      return;
    }
    setBlocks(blocks.filter((b) => b.id !== blockId));
    setFocusedBlockId(null);
    setActiveBlockId(null);
  };

  const moveBlock = (index: number, direction: "up" | "down") => {
    const newIdx = direction === "up" ? index - 1 : index + 1;
    if (newIdx < 0 || newIdx >= blocks.length) return;
    const newBlocks = [...blocks];
    const temp = newBlocks[index];
    newBlocks[index] = newBlocks[newIdx];
    newBlocks[newIdx] = temp;
    setBlocks(newBlocks);
  };

  // Guardar Cambios
  const handleUpdateService = async (targetStatus?: "PUBLICADO" | "BORRADOR") => {
    if (!title.trim()) {
      showToast("El título del servicio es obligatorio.", "error");
      return;
    }

    const finalStatus = targetStatus || status;
    setIsSaving(true);
    try {
      const contentJson = JSON.stringify(blocks);
      const payload = {
        title: title.trim(),
        slug: slug.trim() || title.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
        excerpt: excerpt.trim() || null,
        featuredImage: featuredImage.trim() || null,
        price: price.trim() || null,
        priceLabel: priceLabel.trim() || null,
        iconName: selectedIcon || null,
        categoryId: categoryId || null,
        status: finalStatus,
        content: contentJson,
      };

      const res = await fetch(`/api/services/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (data.success) {
        showToast("¡Servicio actualizado correctamente!", "success");
        setTimeout(() => router.push("/dashboard/servicios"), 1200);
      } else {
        showToast(data.error || "Error al actualizar servicio.", "error");
      }
    } catch (err) {
      console.error(err);
      showToast("Error de conexión con el servidor.", "error");
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="loading-screen-wrap">
        <Loader2 className="animate-spin" />
        <span>Cargando servicio...</span>
        <style jsx>{`
          .loading-screen-wrap {
            min-height: 80vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 12px;
            color: #94a3b8;
            font-size: 14px;
          }
        `}</style>
      </div>
    );
  }

  return (
    <div className="service-editor-page">
      {/* Toast */}
      {toastMessage && (
        <div className={`techlab-toast ${toastType}`}>
          {toastType === "success" ? <CheckCircle2 /> : <AlertTriangle />}
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Navbar */}
      <header className="editor-top-navbar">
        <div className="navbar-left">
          <Link href="/dashboard/servicios" className="btn-back-link">
            <ArrowLeft />
            <span>Volver a Servicios</span>
          </Link>
          <span className="navbar-badge">Editar Servicio</span>
        </div>

        <div className="navbar-right">
          <button
            type="button"
            className="btn-save-draft"
            onClick={() => handleUpdateService("BORRADOR")}
            disabled={isSaving}
          >
            Guardar Borrador
          </button>

          <button
            type="button"
            className="btn-publish-neon"
            onClick={() => handleUpdateService("PUBLICADO")}
            disabled={isSaving}
          >
            {isSaving ? <Loader2 className="animate-spin" /> : <Send />}
            <span>{isSaving ? "Guardando..." : "Actualizar Servicio"}</span>
          </button>
        </div>
      </header>

      {/* Workspace */}
      <div className="editor-workspace-layout">
        {/* Canvas Izquierda */}
        <main className="editor-canvas-container" onClick={() => setOpenInserterId(null)}>
          <div className="editor-document-sheet">
            <input
              type="text"
              placeholder="Escribe el nombre del servicio aquí..."
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              onFocus={() => {
                setFocusedBlockId(null);
                setActiveBlockId(null);
              }}
              className="service-title-input"
            />

            <div className="permalink-box">
              <span className="permalink-prefix">Enlace permanente: /servicios/</span>
              <input
                type="text"
                value={slug}
                onChange={(e) => setSlug(e.target.value)}
                placeholder="slug-del-servicio"
                className="permalink-input"
              />
            </div>

            {/* Bloques */}
            <div className="blocks-render-list">
              {blocks.map((block, idx) => {
                const isFocused = focusedBlockId === block.id;
                const isHovered = activeBlockId === block.id;

                return (
                  <div
                    key={block.id}
                    className={`editor-block-wrapper ${isFocused ? "is-focused" : isHovered ? "is-hovered" : ""}`}
                    onMouseEnter={() => setActiveBlockId(block.id)}
                    onMouseLeave={() => {
                      if (focusedBlockId !== block.id) setActiveBlockId(null);
                    }}
                  >
                    {/* Barra Flotante de Herramientas de Bloque (SOLO CUANDO ESTÁ EN FOCO / ESCRIBIENDO) */}
                    {isFocused && (
                      <div className="floating-block-toolbar" onMouseDown={(e) => e.preventDefault()}>
                        <div className="toolbar-group">
                          <button
                            type="button"
                            onClick={() => moveBlock(idx, "up")}
                            disabled={idx === 0}
                            title="Mover arriba"
                          >
                            <MoveUp />
                          </button>
                          <button
                            type="button"
                            onClick={() => moveBlock(idx, "down")}
                            disabled={idx === blocks.length - 1}
                            title="Mover abajo"
                          >
                            <MoveDown />
                          </button>
                        </div>

                        <div className="toolbar-divider" />

                        <div className="toolbar-group">
                          <button
                            type="button"
                            className={block.align === "left" ? "active" : ""}
                            onClick={() => updateBlock(block.id, { align: "left" })}
                            title="Alinear a la izquierda"
                          >
                            <AlignLeft />
                          </button>
                          <button
                            type="button"
                            className={block.align === "center" ? "active" : ""}
                            onClick={() => updateBlock(block.id, { align: "center" })}
                            title="Alinear al centro"
                          >
                            <AlignCenter />
                          </button>
                          <button
                            type="button"
                            className={block.align === "right" ? "active" : ""}
                            onClick={() => updateBlock(block.id, { align: "right" })}
                            title="Alinear a la derecha"
                          >
                            <AlignRight />
                          </button>
                        </div>

                        <div className="toolbar-divider" />

                        <button
                          type="button"
                          className="btn-trash-block"
                          onClick={() => removeBlock(block.id)}
                          title="Eliminar bloque"
                        >
                          <Trash2 />
                        </button>
                      </div>
                    )}

                    <div
                      className="block-content-area"
                      style={{
                        textAlign: block.align || "left",
                        color: block.textColor || "inherit",
                        backgroundColor: block.bgColor || "transparent",
                      }}
                    >
                      {block.type === "heading" ? (
                        <input
                          type="text"
                          value={block.content}
                          onChange={(e) => updateBlock(block.id, { content: e.target.value })}
                          onFocus={() => {
                            setFocusedBlockId(block.id);
                            setActiveBlockId(block.id);
                          }}
                          onBlur={() => {
                            setTimeout(() => {
                              setFocusedBlockId(null);
                            }, 200);
                          }}
                          onKeyDown={(e) => handleBlockKeyDown(e, idx, block)}
                          className="heading-block-input"
                          placeholder="Escribe un encabezado..."
                        />
                      ) : block.type === "quote" ? (
                        <textarea
                          rows={2}
                          value={block.content}
                          onChange={(e) => updateBlock(block.id, { content: e.target.value })}
                          onFocus={() => {
                            setFocusedBlockId(block.id);
                            setActiveBlockId(block.id);
                          }}
                          onBlur={() => {
                            setTimeout(() => {
                              setFocusedBlockId(null);
                            }, 200);
                          }}
                          className="quote-block-textarea"
                          placeholder="Escribe una cita o beneficio clave..."
                        />
                      ) : block.type === "code" ? (
                        <textarea
                          rows={4}
                          value={block.content}
                          onChange={(e) => updateBlock(block.id, { content: e.target.value })}
                          onFocus={() => {
                            setFocusedBlockId(block.id);
                            setActiveBlockId(block.id);
                          }}
                          onBlur={() => {
                            setTimeout(() => {
                              setFocusedBlockId(null);
                            }, 200);
                          }}
                          className="code-block-textarea"
                          placeholder="// Especificación técnica..."
                        />
                      ) : (
                        <textarea
                          rows={block.content ? Math.max(2, block.content.split("\n").length) : 2}
                          value={block.content}
                          onChange={(e) => updateBlock(block.id, { content: e.target.value })}
                          onFocus={() => {
                            setFocusedBlockId(block.id);
                            setActiveBlockId(block.id);
                          }}
                          onBlur={() => {
                            setTimeout(() => {
                              setFocusedBlockId(null);
                            }, 200);
                          }}
                          onKeyDown={(e) => handleBlockKeyDown(e, idx, block)}
                          className="paragraph-block-textarea"
                          placeholder="Teclea / para elegir un bloque o pulsa [+]"
                        />
                      )}
                    </div>

                    {/* Botón rápido [+] a la derecha del bloque */}
                    <div className="block-right-inserter">
                      <button
                        type="button"
                        className="btn-quick-plus"
                        onClick={(e) => {
                          e.stopPropagation();
                          setOpenInserterId(openInserterId === block.id ? null : block.id);
                        }}
                        title="Añadir bloque debajo"
                      >
                        <Plus />
                      </button>

                      {openInserterId === block.id && (
                        <div className="quick-inserter-dropdown" onClick={(e) => e.stopPropagation()}>
                          <div className="inserter-header">Añadir bloque</div>
                          <button type="button" onClick={() => addBlockAfter(idx, "paragraph")}>
                            <AlignLeft className="ico" /> <span>Párrafo</span>
                          </button>
                          <button type="button" onClick={() => addBlockAfter(idx, "heading")}>
                            <Heading className="ico" /> <span>Encabezado</span>
                          </button>
                          <button type="button" onClick={() => addBlockAfter(idx, "quote")}>
                            <Quote className="ico" /> <span>Cita</span>
                          </button>
                          <button type="button" onClick={() => addBlockAfter(idx, "list")}>
                            <List className="ico" /> <span>Lista</span>
                          </button>
                          <button type="button" onClick={() => addBlockAfter(idx, "code")}>
                            <Code2 className="ico" /> <span>Código</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Botón discreto al pie para añadir más bloques */}
            <div className="bottom-add-block-row">
              <button
                type="button"
                className="btn-bottom-add-block"
                onClick={() => addBlock("paragraph")}
              >
                <Plus />
                <span>Añadir bloque</span>
              </button>
            </div>
          </div>
        </main>

        {/* Sidebar Derecha */}
        <aside className="editor-settings-sidebar">
          <div className="sidebar-section-card">
            <h3>Estado & Visibilidad</h3>
            <div className="sidebar-card-body">
              <label>Estado del Servicio:</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as any)}
                className="sidebar-select-input"
              >
                <option value="PUBLICADO">Publicado en la Web</option>
                <option value="BORRADOR">Borrador Privado</option>
              </select>
            </div>
          </div>

          <div className="sidebar-section-card">
            <h3>Categoría del Servicio</h3>
            <div className="sidebar-card-body">
              <select
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value)}
                className="sidebar-select-input"
              >
                <option value="">Sin categoría</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="sidebar-section-card">
            <h3>Icono Representativo</h3>
            <div className="sidebar-card-body">
              <div className="icons-selection-grid">
                {AVAILABLE_ICONS.map((ico) => {
                  const IconComp = ico.icon;
                  const isSelected = selectedIcon === ico.name;
                  return (
                    <button
                      key={ico.name}
                      type="button"
                      className={`icon-choice-btn ${isSelected ? "selected" : ""}`}
                      onClick={() => setSelectedIcon(ico.name)}
                      title={ico.label}
                    >
                      <IconComp />
                      <span>{ico.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="sidebar-section-card">
            <h3>Precios & Tarifas</h3>
            <div className="sidebar-card-body">
              <div className="field-group">
                <label>
                  <DollarSign /> Precio / Tarifa:
                </label>
                <input
                  type="text"
                  placeholder="ej. Desde $299 USD o S/ 1,200"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  className="sidebar-text-input"
                />
              </div>

              <div className="field-group">
                <label>Etiqueta de Pago:</label>
                <select
                  value={priceLabel}
                  onChange={(e) => setPriceLabel(e.target.value)}
                  className="sidebar-select-input"
                >
                  <option value="Por proyecto">Por proyecto</option>
                  <option value="/mes">/mes (Mensual)</option>
                  <option value="/año">/año (Anual)</option>
                  <option value="Pago único">Pago único</option>
                  <option value="Por hora">Por hora</option>
                  <option value="A cotizar">A cotizar</option>
                </select>
              </div>
            </div>
          </div>

          <div className="sidebar-section-card">
            <h3>Imagen Destacada (Opcional)</h3>
            <div className="sidebar-card-body">
              {featuredImage ? (
                <div className="featured-image-preview-box">
                  <img src={featuredImage} alt="Featured" />
                  <button
                    type="button"
                    className="btn-remove-featured"
                    onClick={() => setFeaturedImage("")}
                  >
                    Eliminar imagen
                  </button>
                </div>
              ) : (
                <div
                  className="featured-upload-dropzone"
                  onClick={() => imageInputRef.current?.click()}
                >
                  {isUploadingImage ? <Loader2 className="animate-spin" /> : <UploadCloud />}
                  <span>{isUploadingImage ? "Subiendo..." : "Subir imagen"}</span>
                </div>
              )}
              <input
                ref={imageInputRef}
                type="file"
                accept="image/*"
                onChange={handleUploadFeatured}
                style={{ display: "none" }}
              />
            </div>
          </div>

          <div className="sidebar-section-card">
            <h3>Extracto del Servicio</h3>
            <div className="sidebar-card-body">
              <textarea
                rows={3}
                placeholder="Resumen corto del servicio..."
                value={excerpt}
                onChange={(e) => setExcerpt(e.target.value)}
                className="sidebar-textarea-input"
              />
            </div>
          </div>
        </aside>
      </div>

      <style jsx>{`
        .service-editor-page {
          min-height: 100vh;
          background: #03070b;
          color: #f1f5f9;
          display: flex;
          flex-direction: column;
        }

        .editor-top-navbar {
          height: 60px;
          background: #07131e;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 0 24px;
          position: sticky;
          top: 0;
          z-index: 100;
        }

        .navbar-left {
          display: flex;
          align-items: center;
          gap: 14px;
        }

        .btn-back-link {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          color: #94a3b8;
          font-size: 13px;
          font-weight: 600;
          text-decoration: none;
        }

        .btn-back-link:hover {
          color: #ffffff;
        }

        .btn-back-link :global(svg) {
          width: 16px;
          height: 16px;
        }

        .navbar-badge {
          font-size: 11px;
          font-weight: 700;
          color: #38bdf8;
          background: rgba(56, 189, 248, 0.12);
          border: 1px solid rgba(56, 189, 248, 0.3);
          padding: 3px 8px;
          border-radius: 4px;
        }

        .navbar-right {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .btn-save-draft {
          height: 36px;
          padding: 0 14px;
          background: transparent;
          border: 1px solid rgba(255, 255, 255, 0.15);
          border-radius: 6px;
          color: #cbd5e1;
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
        }

        .btn-publish-neon {
          height: 36px;
          padding: 0 16px;
          background: linear-gradient(110deg, #12b85f, #18d878);
          border: 1px solid rgba(67, 255, 147, 0.4);
          border-radius: 6px;
          color: #030b12;
          font-size: 12px;
          font-weight: 800;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
          box-shadow: 0 0 16px rgba(22, 201, 111, 0.3);
        }

        .btn-publish-neon :global(svg) {
          width: 14px;
          height: 14px;
        }

        .editor-workspace-layout {
          display: flex;
          flex: 1;
        }

        .editor-canvas-container {
          flex: 1;
          padding: 40px clamp(20px, 4vw, 60px) 120px;
          display: flex;
          justify-content: center;
          overflow-y: auto;
        }

        .editor-document-sheet {
          width: 100%;
          max-width: min(1180px, 100%);
          display: flex;
          flex-direction: column;
          gap: 24px;
        }

        .service-title-input {
          width: 100%;
          font-size: 32px;
          font-weight: 800;
          color: #ffffff;
          background: transparent;
          border: none;
          outline: none;
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
          padding-bottom: 12px;
        }

        .permalink-box {
          display: flex;
          align-items: center;
          gap: 4px;
          font-size: 12px;
          color: #64748b;
        }

        .permalink-box input {
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 4px;
          padding: 2px 8px;
          color: #38bdf8;
          font-size: 12px;
          outline: none;
        }

        /* Blocks */
        .blocks-render-list {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .editor-block-wrapper {
          position: relative;
          border: 1px solid transparent;
          border-radius: 6px;
          padding: 8px 36px 8px 12px;
          transition: border-color 0.15s, background-color 0.15s;
        }

        .editor-block-wrapper.is-hovered {
          border-color: rgba(255, 255, 255, 0.08);
        }

        .editor-block-wrapper.is-focused {
          border-color: rgba(56, 189, 248, 0.4);
          background: rgba(56, 189, 248, 0.02);
        }

        /* Floating Toolbar (SOLO CUANDO ESTÁ EN FOCO / ESCRIBIENDO) */
        .floating-block-toolbar {
          position: absolute;
          top: -46px;
          left: 12px;
          background: #0b1928;
          border: 1px solid rgba(56, 189, 248, 0.5);
          border-radius: 6px;
          padding: 4px 8px;
          display: flex;
          align-items: center;
          gap: 6px;
          z-index: 50;
          box-shadow: 0 10px 25px rgba(0, 0, 0, 0.7), 0 0 12px rgba(56, 189, 248, 0.15);
          animation: fadeInFast 0.15s ease-out;
        }

        @keyframes fadeInFast {
          from { opacity: 0; transform: translateY(4px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .toolbar-group {
          display: flex;
          align-items: center;
          gap: 3px;
        }

        .toolbar-divider {
          width: 1px;
          height: 18px;
          background: rgba(255, 255, 255, 0.15);
          margin: 0 2px;
        }

        .floating-block-toolbar button {
          background: none;
          border: none;
          color: #cbd5e1;
          padding: 5px;
          border-radius: 4px;
          cursor: pointer;
          display: grid;
          place-items: center;
          transition: color 0.15s, background-color 0.15s;
        }

        .floating-block-toolbar button:hover,
        .floating-block-toolbar button.active {
          color: #38bdf8;
          background: rgba(56, 189, 248, 0.15);
        }

        .floating-block-toolbar button:disabled {
          opacity: 0.3;
          cursor: not-allowed;
        }

        .floating-block-toolbar button :global(svg) {
          width: 14px;
          height: 14px;
        }

        .btn-trash-block:hover {
          color: #ef4444 !important;
          background: rgba(239, 68, 68, 0.15) !important;
        }

        /* Right Quick Inserter Button */
        .block-right-inserter {
          position: absolute;
          top: 10px;
          right: 8px;
          opacity: 0;
          transition: opacity 0.15s;
          z-index: 20;
        }

        .editor-block-wrapper:hover .block-right-inserter,
        .editor-block-wrapper.is-focused .block-right-inserter {
          opacity: 1;
        }

        .btn-quick-plus {
          width: 24px;
          height: 24px;
          border-radius: 50%;
          background: #0f2236;
          border: 1px solid rgba(56, 189, 248, 0.4);
          color: #38bdf8;
          display: grid;
          place-items: center;
          cursor: pointer;
          transition: transform 0.15s, background-color 0.15s;
        }

        .btn-quick-plus:hover {
          background: #38bdf8;
          color: #03080e;
          transform: scale(1.1);
        }

        .btn-quick-plus :global(svg) {
          width: 13px;
          height: 13px;
        }

        .quick-inserter-dropdown {
          position: absolute;
          top: 30px;
          right: 0;
          background: #0b1928;
          border: 1px solid rgba(56, 189, 248, 0.4);
          border-radius: 8px;
          padding: 6px;
          min-width: 160px;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.7);
          display: flex;
          flex-direction: column;
          gap: 2px;
          z-index: 60;
        }

        .inserter-header {
          font-size: 10px;
          font-weight: 700;
          color: #64748b;
          text-transform: uppercase;
          padding: 4px 8px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
          margin-bottom: 2px;
        }

        .quick-inserter-dropdown button {
          display: flex;
          align-items: center;
          gap: 8px;
          background: none;
          border: none;
          padding: 6px 8px;
          border-radius: 4px;
          color: #cbd5e1;
          font-size: 12px;
          font-weight: 500;
          cursor: pointer;
          text-align: left;
          width: 100%;
          transition: background 0.15s, color 0.15s;
        }

        .quick-inserter-dropdown button:hover {
          background: rgba(56, 189, 248, 0.15);
          color: #38bdf8;
        }

        .quick-inserter-dropdown button :global(.ico) {
          width: 14px;
          height: 14px;
          color: #38bdf8;
        }

        /* Bottom Add Block Row */
        .bottom-add-block-row {
          padding-top: 8px;
        }

        .btn-bottom-add-block {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          background: rgba(255, 255, 255, 0.03);
          border: 1px dashed rgba(255, 255, 255, 0.15);
          border-radius: 6px;
          padding: 6px 14px;
          color: #94a3b8;
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
          transition: border-color 0.15s, color 0.15s;
        }

        .btn-bottom-add-block:hover {
          border-color: #38bdf8;
          color: #38bdf8;
          background: rgba(56, 189, 248, 0.05);
        }

        .btn-bottom-add-block :global(svg) {
          width: 14px;
          height: 14px;
        }

        /* Typography & Inputs */
        .service-title-input {
          width: 100%;
          font-size: 32px;
          font-weight: 800;
          color: #ffffff;
          background: transparent;
          border: none;
          outline: none;
          padding: 8px 0;
        }

        .service-title-input::placeholder {
          color: #64748b;
        }

        .permalink-box {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 12px;
          color: #64748b;
          margin-top: -12px;
          margin-bottom: 8px;
        }

        .permalink-prefix {
          color: #64748b;
          font-size: 12px;
        }

        .permalink-input {
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.12);
          border-radius: 4px;
          padding: 3px 8px;
          color: #38bdf8;
          font-size: 12px;
          outline: none;
        }

        .permalink-input:focus {
          border-color: #38bdf8;
        }

        .heading-block-input {
          width: 100%;
          font-size: 22px;
          font-weight: 700;
          color: #ffffff;
          background: transparent;
          border: none;
          outline: none;
        }

        .heading-block-input::placeholder {
          color: #64748b;
        }

        .paragraph-block-textarea,
        .quote-block-textarea,
        .code-block-textarea {
          width: 100%;
          background: transparent;
          border: none;
          outline: none;
          color: #f8fafc;
          font-size: 15px;
          line-height: 1.6;
          font-family: inherit;
          resize: none;
        }

        .paragraph-block-textarea::placeholder,
        .quote-block-textarea::placeholder,
        .code-block-textarea::placeholder {
          color: #64748b;
        }

        .quote-block-textarea {
          font-style: italic;
          border-left: 3px solid #16c96f;
          padding-left: 12px;
        }

        .code-block-textarea {
          background: #02060a;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 10px;
          font-family: monospace;
          color: #38bdf8;
        }

        .editor-settings-sidebar {
          width: 320px;
          background: #040c14;
          border-left: 1px solid rgba(255, 255, 255, 0.08);
          padding: 20px;
          display: flex;
          flex-direction: column;
          gap: 16px;
          overflow-y: auto;
        }

        .sidebar-section-card {
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.06);
          border-radius: 8px;
          overflow: hidden;
        }

        .sidebar-section-card h3 {
          font-size: 12px;
          font-weight: 700;
          color: #cbd5e1;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          padding: 12px 14px;
          background: rgba(255, 255, 255, 0.02);
          border-bottom: 1px solid rgba(255, 255, 255, 0.06);
          margin: 0;
        }

        .sidebar-card-body {
          padding: 14px;
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .sidebar-card-body label {
          font-size: 11px;
          font-weight: 600;
          color: #94a3b8;
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .sidebar-card-body label :global(svg) {
          width: 12px;
          height: 12px;
          color: #38bdf8;
        }

        .sidebar-select-input,
        .sidebar-text-input,
        .sidebar-textarea-input {
          width: 100%;
          background: #03080e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 8px 10px;
          color: #ffffff;
          font-size: 12px;
          outline: none;
        }

        .field-group {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .icons-selection-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 6px;
        }

        .icon-choice-btn {
          background: #03080e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 8px 6px;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
          color: #94a3b8;
          cursor: pointer;
        }

        .icon-choice-btn:hover,
        .icon-choice-btn.selected {
          border-color: #38bdf8;
          color: #38bdf8;
          background: rgba(56, 189, 248, 0.08);
        }

        .icon-choice-btn :global(svg) {
          width: 18px;
          height: 18px;
        }

        .icon-choice-btn span {
          font-size: 10px;
          font-weight: 600;
        }

        .featured-upload-dropzone {
          padding: 24px;
          background: #03080e;
          border: 1px dashed rgba(255, 255, 255, 0.15);
          border-radius: 6px;
          text-align: center;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          color: #64748b;
          font-size: 12px;
        }

        .featured-image-preview-box {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .featured-image-preview-box img {
          width: 100%;
          border-radius: 6px;
          object-fit: cover;
          max-height: 160px;
        }

        .btn-remove-featured {
          background: none;
          border: none;
          color: #ef4444;
          font-size: 11px;
          cursor: pointer;
          text-align: left;
        }

        /* Toast */
        .techlab-toast {
          position: fixed;
          top: 70px;
          right: 24px;
          z-index: 1000;
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 12px 18px;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 600;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.6);
        }

        .techlab-toast.success {
          background: #062316;
          border: 1px solid #16c96f;
          color: #a7f3d0;
        }

        .techlab-toast.error {
          background: #270d0d;
          border: 1px solid #ef4444;
          color: #fca5a5;
        }

        /* Light Mode Support */
        :global(.theme-light) .service-editor-page {
          background: #f8fafc;
          color: #0f172a;
        }

        :global(.theme-light) .editor-top-navbar {
          background: #ffffff;
          border-bottom-color: #e2e8f0;
        }

        :global(.theme-light) .btn-back-link {
          color: #64748b;
        }

        :global(.theme-light) .btn-back-link:hover {
          color: #0f172a;
        }

        :global(.theme-light) .service-title-input {
          color: #0f172a;
        }

        :global(.theme-light) .heading-block-input {
          color: #0f172a;
        }

        :global(.theme-light) .paragraph-block-textarea,
        :global(.theme-light) .quote-block-textarea {
          color: #0f172a;
        }

        :global(.theme-light) .floating-block-toolbar,
        :global(.theme-light) .quick-inserter-dropdown {
          background: #ffffff;
          border-color: #cbd5e1;
          box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        }

        :global(.theme-light) .floating-block-toolbar button,
        :global(.theme-light) .quick-inserter-dropdown button {
          color: #475569;
        }

        :global(.theme-light) .floating-block-toolbar button:hover,
        :global(.theme-light) .quick-inserter-dropdown button:hover {
          background: #f1f5f9;
          color: #0284c7;
        }

        :global(.theme-light) .toolbar-divider {
          background: #e2e8f0;
        }

        :global(.theme-light) .editor-settings-sidebar {
          background: #f8fafc;
          border-left-color: #e2e8f0;
        }

        :global(.theme-light) .sidebar-section-card {
          background: #ffffff;
          border-color: #e2e8f0;
        }

        :global(.theme-light) .sidebar-section-card h3 {
          background: #f8fafc;
          border-bottom-color: #e2e8f0;
          color: #334155;
        }

        :global(.theme-light) .sidebar-select-input,
        :global(.theme-light) .sidebar-text-input,
        :global(.theme-light) .sidebar-textarea-input {
          background: #ffffff;
          border-color: #cbd5e1;
          color: #0f172a;
        }
      `}</style>
    </div>
  );
}
