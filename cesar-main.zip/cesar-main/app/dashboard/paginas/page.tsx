"use client";

import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import {
  Plus,
  Search,
  SlidersHorizontal,
  Pencil,
  Eye,
  Trash2,
  Files,
  FilePlus2,
  Lock,
  ChevronLeft,
  ChevronRight,
  X,
  RefreshCw,
  Loader2,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  Sparkles,
  ShieldAlert,
  FolderTree,
  LayoutTemplate,
} from "lucide-react";

interface PageItem {
  id: string;
  slug: string;
  title: string;
  template: string;
  status: "Publicado" | "Borrador" | "Privado";
  seoScore: number | null;
  views: number;
  date: string;
  timeAgo?: string;
  author: string;
  parent?: { id: string; title: string; slug: string } | null;
}

export default function PaginasPage() {
  const [pages, setPages] = useState<PageItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [showFilters, setShowFilters] = useState(false);
  const [page, setPage] = useState(1);
  const [origin, setOrigin] = useState("");
  const itemsPerPage = 10;

  // Estado del Modal Animado de Confirmación de Eliminación
  const [deleteModal, setDeleteModal] = useState<{
    isOpen: boolean;
    id: string;
    title: string;
    isDeleting: boolean;
  }>({
    isOpen: false,
    id: "",
    title: "",
    isDeleting: false,
  });

  // Estados de Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<"success" | "error">("success");

  // Obtener origen/dominio actual del navegador
  useEffect(() => {
    if (typeof window !== "undefined") {
      setOrigin(window.location.origin);
    }
  }, []);

  const showToast = (msg: string, type: "success" | "error" = "success") => {
    setToastMessage(msg);
    setToastType(type);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Cargar páginas 100% REALES desde MySQL AWS RDS
  const fetchRealPages = useCallback(async () => {
    setIsLoading(true);
    try {
      const res = await fetch("/api/pages");
      const data = await res.json();

      if (data.pages && Array.isArray(data.pages)) {
        const mapped: PageItem[] = data.pages.map((p: any) => {
          const createdDate = new Date(p.createdAt);

          return {
            id: p.id,
            slug: p.slug,
            title: p.title,
            template: p.template || "default",
            status: (p.status as "Publicado" | "Borrador" | "Privado") || "Publicado",
            seoScore: typeof p.seoScore === "number" ? p.seoScore : null,
            views: p.views || 0,
            date: createdDate.toLocaleDateString("es-ES", {
              day: "2-digit",
              month: "short",
              year: "numeric",
            }),
            timeAgo: getTimeAgo(createdDate),
            author: p.author?.name || "Cesar Fuentes",
            parent: p.parent || null,
          };
        });

        setPages(mapped);
      } else {
        setPages([]);
      }
    } catch (e) {
      console.error("Error al cargar páginas desde MySQL RDS:", e);
      showToast("Error de conexión al cargar páginas de la base de datos.", "error");
      setPages([]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchRealPages();
  }, [fetchRealPages]);

  const getTimeAgo = (date: Date) => {
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
    if (seconds < 60) return "hace un momento";
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `hace ${minutes}m`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `hace ${hours}h`;
    const days = Math.floor(hours / 24);
    return `hace ${days}d`;
  };

  // Métricas calculadas en vivo desde los datos de la base de datos
  const totalPagesCount = pages.length;
  const publishedCount = pages.filter((p) => p.status === "Publicado").length;
  const draftCount = pages.filter((p) => p.status === "Borrador").length;
  const totalViews = pages.reduce((acc, p) => acc + p.views, 0);

  // Filtrado reactivo
  const filteredPages = pages.filter((p) => {
    const matchesSearch =
      search === "" ||
      p.title.toLowerCase().includes(search.toLowerCase()) ||
      p.author.toLowerCase().includes(search.toLowerCase()) ||
      p.slug.toLowerCase().includes(search.toLowerCase());

    const matchesStatus = statusFilter === "ALL" || p.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  // Paginación
  const totalPageCount = Math.max(1, Math.ceil(filteredPages.length / itemsPerPage));
  const paginatedPages = filteredPages.slice(
    (page - 1) * itemsPerPage,
    page * itemsPerPage
  );

  const handleSelectAll = () => {
    if (selectedIds.length === paginatedPages.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(paginatedPages.map((p) => p.id));
    }
  };

  const handleSelectRow = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  // Abrir Modal de Confirmación Animado
  const openDeleteConfirmation = (id: string, title: string) => {
    setDeleteModal({
      isOpen: true,
      id,
      title,
      isDeleting: false,
    });
  };

  // Ejecutar eliminación confirmada vía AJAX
  const executeDeleteConfirmed = async () => {
    if (!deleteModal.id) return;
    setDeleteModal((prev) => ({ ...prev, isDeleting: true }));

    try {
      const res = await fetch(`/api/pages?id=${deleteModal.id}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) {
        showToast(`Página "${deleteModal.title}" eliminada correctamente.`, "success");
        setPages((prev) => prev.filter((p) => p.id !== deleteModal.id));
        setSelectedIds((prev) => prev.filter((item) => item !== deleteModal.id));
        setDeleteModal({ isOpen: false, id: "", title: "", isDeleting: false });
      } else {
        showToast(data.error || "Error al eliminar página.", "error");
        setDeleteModal((prev) => ({ ...prev, isDeleting: false }));
      }
    } catch (e) {
      console.error("Error al eliminar en base de datos:", e);
      showToast("Error de conexión al eliminar página.", "error");
      setDeleteModal((prev) => ({ ...prev, isDeleting: false }));
    }
  };

  const getTemplateLabel = (tmpl: string) => {
    switch (tmpl) {
      case "landing":
        return "Landing Page";
      case "fullwidth":
        return "Ancho Completo";
      case "blank":
        return "En Blanco";
      default:
        return "Página Estándar";
    }
  };

  const displayDomain = origin ? origin.replace(/^https?:\/\//, "") : "localhost:3000";

  return (
    <div className="paginas-admin-container">
      {/* Toast Notification */}
      {toastMessage && (
        <div className={`techlab-toast ${toastType}`}>
          {toastType === "success" ? <CheckCircle2 /> : <AlertTriangle />}
          <span>{toastMessage}</span>
        </div>
      )}

      {/* =================================================================
          MODAL ANIMADO EN EL CENTRO: CONFIRMACIÓN DE ELIMINACIÓN
          ================================================================= */}
      {deleteModal.isOpen && (
        <div
          className="modal-delete-backdrop"
          onClick={() => !deleteModal.isDeleting && setDeleteModal({ isOpen: false, id: "", title: "", isDeleting: false })}
        >
          <div className="modal-delete-card" onClick={(e) => e.stopPropagation()}>
            <div className="modal-danger-icon-wrap">
              <ShieldAlert />
            </div>

            <div className="modal-delete-content">
              <h3>¿Seguro que quieres eliminar?</h3>
              <p className="modal-danger-desc">
                Este dato es <strong>irreversible</strong> y se eliminará permanentemente de la base de datos.
              </p>

              <div className="modal-target-item-box">
                <Files />
                <span>{deleteModal.title}</span>
              </div>
            </div>

            <div className="modal-delete-actions">
              <button
                type="button"
                className="btn-modal-cancel"
                onClick={() => setDeleteModal({ isOpen: false, id: "", title: "", isDeleting: false })}
                disabled={deleteModal.isDeleting}
              >
                Cancelar
              </button>

              <button
                type="button"
                className="btn-modal-danger-confirm"
                onClick={executeDeleteConfirmed}
                disabled={deleteModal.isDeleting}
              >
                {deleteModal.isDeleting ? (
                  <>
                    <Loader2 className="animate-spin" />
                    <span>Eliminando...</span>
                  </>
                ) : (
                  <>
                    <Trash2 />
                    <span>Sí, eliminar</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Encabezado principal */}
      <div className="paginas-page-header">
        <div>
          <h1>Administración de Páginas</h1>
          <p>Gestiona, diseña y analiza el rendimiento de las páginas de tu sitio web</p>
        </div>
        <div className="header-actions-group">
          <button
            type="button"
            onClick={fetchRealPages}
            className="refresh-sync-btn"
            title="Actualizar listado"
          >
            <RefreshCw className={isLoading ? "animate-spin" : ""} />
            <span>Actualizar</span>
          </button>
          <Link href="/dashboard/paginas/nuevo" className="neon-add-btn">
            <Plus />
            <span>Nueva Página</span>
          </Link>
        </div>
      </div>

      {/* Panel Summary (Métricas Reales) */}
      <section className="paginas-summary-panel">
        <div className="summary-cards-grid">
          {/* Card 1: Total Páginas */}
          <div className="summary-metric-card cyan-card">
            <div className="card-info">
              <span>Total Páginas</span>
              <strong>{isLoading ? "..." : totalPagesCount}</strong>
            </div>
            <div className="metric-icon-box cyan">
              <Files />
            </div>
          </div>

          {/* Card 2: Publicadas Activas */}
          <div className="summary-metric-card green-card">
            <div className="card-info">
              <span>Publicadas Activas</span>
              <strong>{isLoading ? "..." : publishedCount}</strong>
            </div>
            <div className="metric-icon-box green">
              <Sparkles />
            </div>
          </div>

          {/* Card 3: Borradores */}
          <div className="summary-metric-card orange-card">
            <div className="card-info">
              <span>Borradores</span>
              <strong>{isLoading ? "..." : draftCount}</strong>
            </div>
            <div className="metric-icon-box orange">
              <LayoutTemplate />
            </div>
          </div>

          {/* Card 4: Vistas Totales */}
          <div className="summary-metric-card purple-card">
            <div className="card-info">
              <span>Vistas Totales</span>
              <strong>{isLoading ? "..." : totalViews}</strong>
            </div>
            <div className="metric-icon-box purple">
              <Eye />
            </div>
          </div>
        </div>
      </section>

      {/* Barra de Búsqueda y Filtros */}
      <div className="paginas-toolbar-card">
        <div className="toolbar-search-wrapper">
          <Search />
          <input
            type="text"
            placeholder="Buscar por título, autor o slug de la página..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
          />
          {search && (
            <button
              className="clear-search-btn"
              onClick={() => setSearch("")}
              aria-label="Limpiar búsqueda"
            >
              <X />
            </button>
          )}
        </div>

        <button
          className={`advanced-filters-btn ${showFilters ? "active" : ""}`}
          onClick={() => setShowFilters(!showFilters)}
        >
          <SlidersHorizontal />
          <span>Filtros</span>
        </button>
      </div>

      {/* Desplegable de Filtros */}
      {showFilters && (
        <div className="filters-drawer">
          <span>Filtrar por Estado:</span>
          <button
            className={`filter-chip ${statusFilter === "ALL" ? "selected" : ""}`}
            onClick={() => {
              setStatusFilter("ALL");
              setPage(1);
            }}
          >
            Todas ({totalPagesCount})
          </button>
          <button
            className={`filter-chip green ${statusFilter === "Publicado" ? "selected" : ""}`}
            onClick={() => {
              setStatusFilter("Publicado");
              setPage(1);
            }}
          >
            Publicadas ({publishedCount})
          </button>
          <button
            className={`filter-chip orange ${statusFilter === "Borrador" ? "selected" : ""}`}
            onClick={() => {
              setStatusFilter("Borrador");
              setPage(1);
            }}
          >
            Borradores ({draftCount})
          </button>
          <button
            className={`filter-chip purple ${statusFilter === "Privado" ? "selected" : ""}`}
            onClick={() => {
              setStatusFilter("Privado");
              setPage(1);
            }}
          >
            Privadas ({pages.filter((p) => p.status === "Privado").length})
          </button>
        </div>
      )}

      {/* Tabla de Datos o Estado Vacío */}
      <div className="paginas-table-container">
        {isLoading ? (
          <div className="loading-state-container">
            <Loader2 className="animate-spin" />
            <span>Cargando páginas...</span>
          </div>
        ) : filteredPages.length === 0 ? (
          /* ESTADO: SIN PÁGINAS AÚN */
          <div className="empty-pages-wrapper">
            <div className="empty-icon-circle">
              <FilePlus2 />
            </div>
            <h3>Sin páginas aún</h3>
            <p>
              {search || statusFilter !== "ALL"
                ? "No se encontraron páginas que coincidan con los filtros aplicados."
                : "No hay páginas registradas aún. Diseña tu primera página para comenzar a estructurar tu sitio."}
            </p>
            {search || statusFilter !== "ALL" ? (
              <button
                type="button"
                className="btn-reset-filters"
                onClick={() => {
                  setSearch("");
                  setStatusFilter("ALL");
                }}
              >
                Limpiar filtros
              </button>
            ) : (
              <Link href="/dashboard/paginas/nuevo" className="neon-create-first-btn">
                <Plus />
                <span>Crear mi primera página</span>
              </Link>
            )}
          </div>
        ) : (
          <>
            <div className="table-responsive-scroll">
              <table className="paginas-data-table">
                <thead>
                  <tr>
                    <th className="th-checkbox">
                      <input
                        type="checkbox"
                        checked={
                          paginatedPages.length > 0 && selectedIds.length === paginatedPages.length
                        }
                        onChange={handleSelectAll}
                        aria-label="Seleccionar todas las páginas"
                      />
                    </th>
                    <th className="th-title">Título</th>
                    <th className="th-template">Plantilla</th>
                    <th className="th-parent">Página Superior</th>
                    <th className="th-status">Estado</th>
                    <th className="th-seo">SEO Score</th>
                    <th className="th-views">Vistas</th>
                    <th className="th-date">Fecha de Creación</th>
                    <th className="th-author">Autor</th>
                    <th className="th-actions">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {paginatedPages.map((p) => {
                    const isSelected = selectedIds.includes(p.id);

                    return (
                      <tr key={p.id} className={isSelected ? "row-selected" : ""}>
                        {/* Checkbox */}
                        <td className="td-checkbox">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => handleSelectRow(p.id)}
                            aria-label={`Seleccionar ${p.title}`}
                          />
                        </td>

                        {/* Título y URL corta */}
                        <td className="td-title">
                          <div className="title-cell-wrap">
                            <div className="title-row">
                              <span className="page-title-text">{p.title}</span>
                              {p.status === "Privado" && <Lock className="title-mini-icon lock" />}
                            </div>
                            <small className="page-url-sub">{displayDomain}/paginas/{p.slug}</small>
                          </div>
                        </td>

                        {/* Plantilla */}
                        <td className="td-template">
                          <span className="template-pill">
                            {getTemplateLabel(p.template)}
                          </span>
                        </td>

                        {/* Página Superior (Jerarquía) */}
                        <td className="td-parent">
                          {p.parent ? (
                            <span className="parent-page-badge">
                              {p.parent.title}
                            </span>
                          ) : (
                            <span className="no-parent-text">— Principal —</span>
                          )}
                        </td>

                        {/* Estado */}
                        <td className="td-status">
                          <span
                            className={`status-pill ${
                              p.status === "Publicado"
                                ? "published"
                                : p.status === "Borrador"
                                ? "draft"
                                : "private"
                            }`}
                          >
                            {p.status}
                          </span>
                        </td>

                        {/* SEO Score */}
                        <td className="td-seo">
                          {p.seoScore !== null && p.seoScore > 0 ? (
                            <div className="seo-gauge-cell">
                              <div
                                className={`seo-mini-donut ${
                                  p.seoScore >= 80 ? "good" : "warning"
                                }`}
                              >
                                <svg viewBox="0 0 36 36">
                                  <path
                                    className="circle-bg"
                                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                                  />
                                  <path
                                    className="circle"
                                    strokeDasharray={`${p.seoScore}, 100`}
                                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                                  />
                                </svg>
                              </div>
                              <span className="seo-pct">{p.seoScore}%</span>
                            </div>
                          ) : (
                            <div className="seo-gauge-cell na">
                              <span className="seo-pct muted">—</span>
                            </div>
                          )}
                        </td>

                        {/* Vistas */}
                        <td className="td-views">{p.views}</td>

                        {/* Última Modificación */}
                        <td className="td-date">
                          <div className="date-cell">
                            <b>{p.date}</b>
                            {p.timeAgo && <small>{p.timeAgo}</small>}
                          </div>
                        </td>

                        {/* Autor */}
                        <td className="td-author">{p.author}</td>

                        {/* Acciones */}
                        <td className="td-actions">
                          <div className="table-actions-group">
                            <Link
                              href={`/dashboard/paginas/nuevo?edit=${p.id}`}
                              className="action-btn edit"
                              title="Editar página"
                              aria-label="Editar página"
                            >
                              <Pencil />
                            </Link>
                            <Link
                              href={`/dashboard/elementor/editor?id=${p.id}`}
                              className="action-btn elementor"
                              title="Editar con Elementor Pro"
                              aria-label="Editar con Elementor Pro"
                              style={{ color: "#f43f5e" }}
                            >
                              <Sparkles />
                            </Link>
                            <a
                              href={`/paginas/${p.slug}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="action-btn view"
                              title="Ver página en vivo"
                              aria-label="Ver página en vivo"
                            >
                              <ExternalLink />
                            </a>
                            <button
                              onClick={() => openDeleteConfirmation(p.id, p.title)}
                              className="action-btn delete"
                              title="Eliminar página"
                              aria-label="Eliminar página"
                            >
                              <Trash2 />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Paginador */}
            <div className="table-pagination-bar">
              <span className="pagination-info">
                Mostrando {(page - 1) * itemsPerPage + 1}-
                {Math.min(page * itemsPerPage, filteredPages.length)} de {filteredPages.length} páginas
              </span>
              <div className="pagination-controls">
                <button
                  className="page-nav-btn"
                  disabled={page === 1}
                  onClick={() => setPage((pg) => Math.max(1, pg - 1))}
                  aria-label="Página anterior"
                >
                  <ChevronLeft />
                </button>
                {Array.from({ length: totalPageCount }, (_, i) => i + 1).map((num) => (
                  <button
                    key={num}
                    className={`page-number-btn ${page === num ? "active" : ""}`}
                    onClick={() => setPage(num)}
                  >
                    {num}
                  </button>
                ))}
                <button
                  className="page-nav-btn"
                  disabled={page === totalPageCount}
                  onClick={() => setPage((pg) => Math.min(totalPageCount, pg + 1))}
                  aria-label="Página siguiente"
                >
                  <ChevronRight />
                </button>
              </div>
            </div>
          </>
        )}
      </div>

      {/* ESTILOS TECHLAB CYBER DARK */}
      <style jsx>{`
        .paginas-admin-container {
          display: flex;
          flex-direction: column;
          gap: 20px;
          color: #f1f5f9;
        }

        /* Modal Animado en el Centro */
        .modal-delete-backdrop {
          position: fixed;
          inset: 0;
          z-index: 2000;
          background: rgba(0, 0, 0, 0.75);
          backdrop-filter: blur(4px);
          display: grid;
          place-items: center;
          padding: 16px;
          animation: modalFadeIn 0.2s ease;
        }

        .modal-delete-card {
          width: 100%;
          max-width: 440px;
          background: #040c14;
          border: 1px solid rgba(239, 68, 68, 0.35);
          border-radius: 12px;
          padding: 24px;
          box-shadow: 0 20px 50px rgba(0, 0, 0, 0.8), 0 0 30px rgba(239, 68, 68, 0.15);
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          gap: 16px;
          animation: modalScaleIn 0.25s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes modalFadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        @keyframes modalScaleIn {
          from { transform: scale(0.92); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }

        .modal-danger-icon-wrap {
          width: 58px;
          height: 58px;
          border-radius: 50%;
          background: rgba(239, 68, 68, 0.12);
          border: 2px solid rgba(239, 68, 68, 0.4);
          display: grid;
          place-items: center;
          color: #ef4444;
          box-shadow: 0 0 20px rgba(239, 68, 68, 0.25);
          animation: iconPulse 2s infinite ease-in-out;
        }

        @keyframes iconPulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.06); }
        }

        .modal-danger-icon-wrap :global(svg) {
          width: 28px;
          height: 28px;
        }

        .modal-delete-content {
          display: flex;
          flex-direction: column;
          gap: 8px;
          width: 100%;
        }

        .modal-delete-content h3 {
          font-size: 18px;
          font-weight: 800;
          color: #ffffff;
          margin: 0;
          letter-spacing: -0.3px;
        }

        .modal-danger-desc {
          font-size: 13px;
          color: #94a3b8;
          margin: 0;
          line-height: 1.5;
        }

        .modal-danger-desc strong {
          color: #ef4444;
        }

        .modal-target-item-box {
          margin-top: 8px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 8px;
          padding: 10px 14px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          font-size: 12px;
          font-weight: 600;
          color: #f1f5f9;
          word-break: break-word;
        }

        .modal-target-item-box :global(svg) {
          width: 14px;
          height: 14px;
          color: #38bdf8;
          flex-shrink: 0;
        }

        .modal-delete-actions {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 12px;
          width: 100%;
          margin-top: 4px;
        }

        .btn-modal-cancel {
          flex: 1;
          height: 38px;
          border-radius: 6px;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: #cbd5e1;
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.15s;
        }

        .btn-modal-cancel:hover:not(:disabled) {
          background: rgba(255, 255, 255, 0.1);
          color: #ffffff;
        }

        .btn-modal-danger-confirm {
          flex: 1;
          height: 38px;
          border-radius: 6px;
          background: linear-gradient(110deg, #dc2626, #ef4444);
          border: 1px solid rgba(239, 68, 68, 0.5);
          color: #ffffff;
          font-size: 12px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          cursor: pointer;
          box-shadow: 0 0 16px rgba(239, 68, 68, 0.35);
          transition: all 0.2s;
        }

        .btn-modal-danger-confirm:hover:not(:disabled) {
          background: #f87171;
          transform: translateY(-1px);
        }

        .btn-modal-danger-confirm :global(svg) {
          width: 15px;
          height: 15px;
        }

        /* Toast */
        .techlab-toast {
          position: fixed;
          top: 70px;
          right: 24px;
          z-index: 1000;
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 12px 18px;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 600;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.6);
          animation: slideIn 0.25s ease;
        }

        .techlab-toast.success {
          background: #062316;
          border: 1px solid #16c96f;
          color: #a7f3d0;
        }

        .techlab-toast.error {
          background: #270d0d;
          border: 1px solid #ef4444;
          color: #fca5a5;
        }

        @keyframes slideIn {
          from { transform: translateY(-20px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }

        /* Header */
        .paginas-page-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding-bottom: 4px;
        }

        .paginas-page-header h1 {
          font-size: 22px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 4px;
          letter-spacing: -0.5px;
        }

        .paginas-page-header p {
          font-size: 12px;
          color: #94a3b8;
          margin: 0;
        }

        .header-actions-group {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .refresh-sync-btn {
          height: 36px;
          padding: 0 14px;
          border-radius: 6px;
          background: rgba(255, 255, 255, 0.04);
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: #cbd5e1;
          font-size: 12px;
          font-weight: 600;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          transition: all 0.15s;
        }

        .refresh-sync-btn:hover {
          background: rgba(56, 189, 248, 0.1);
          border-color: rgba(56, 189, 248, 0.4);
          color: #38bdf8;
        }

        .refresh-sync-btn :global(svg) {
          width: 14px;
          height: 14px;
        }

        /* Botón Verde Neón Header */
        :global(.neon-add-btn) {
          height: 36px;
          padding: 0 16px;
          border-radius: 6px;
          background: linear-gradient(110deg, #12b85f, #18d878) !important;
          border: 1px solid rgba(67, 255, 147, 0.4) !important;
          color: #030b12 !important;
          font-size: 12px !important;
          font-weight: 700 !important;
          display: inline-flex !important;
          flex-direction: row !important;
          align-items: center !important;
          justify-content: center !important;
          gap: 6px !important;
          text-decoration: none !important;
          cursor: pointer !important;
          box-shadow: 0 0 16px rgba(22, 201, 111, 0.3) !important;
          transition: all 0.2s ease !important;
        }

        :global(.neon-add-btn:hover) {
          background: #20df7b !important;
          transform: translateY(-1px) !important;
        }

        :global(.neon-add-btn svg) {
          width: 15px !important;
          height: 15px !important;
        }

        /* Metrics Summary Panel */
        .paginas-summary-panel {
          margin-bottom: 4px;
        }

        .summary-cards-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 16px;
        }

        .summary-metric-card {
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          padding: 16px 18px;
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .card-info span {
          display: block;
          font-size: 11px;
          font-weight: 600;
          color: #94a3b8;
          margin-bottom: 4px;
        }

        .card-info strong {
          font-size: 22px;
          font-weight: 800;
          color: #ffffff;
        }

        .metric-icon-box {
          width: 38px;
          height: 38px;
          border-radius: 8px;
          display: grid;
          place-items: center;
        }

        .metric-icon-box :global(svg) {
          width: 18px;
          height: 18px;
        }

        .metric-icon-box.cyan { background: rgba(56, 189, 248, 0.12); color: #38bdf8; }
        .metric-icon-box.green { background: rgba(22, 201, 111, 0.12); color: #16c96f; }
        .metric-icon-box.orange { background: rgba(245, 158, 11, 0.12); color: #fbbf24; }
        .metric-icon-box.purple { background: rgba(168, 85, 247, 0.12); color: #c084fc; }

        /* Toolbar */
        .paginas-toolbar-card {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .toolbar-search-wrapper {
          flex: 1;
          position: relative;
          display: flex;
          align-items: center;
        }

        .toolbar-search-wrapper :global(svg) {
          position: absolute;
          left: 12px;
          width: 14px;
          height: 14px;
          color: #64748b;
        }

        .toolbar-search-wrapper input {
          width: 100%;
          height: 38px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 8px;
          padding: 0 32px 0 36px;
          color: #ffffff;
          font-size: 12px;
          outline: none;
        }

        .toolbar-search-wrapper input:focus {
          border-color: #38bdf8;
        }

        .clear-search-btn {
          position: absolute;
          right: 10px;
          background: none;
          border: none;
          color: #64748b;
          cursor: pointer;
        }

        .clear-search-btn :global(svg) {
          width: 12px;
          height: 12px;
        }

        .advanced-filters-btn {
          height: 38px;
          padding: 0 14px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 8px;
          color: #cbd5e1;
          font-size: 12px;
          font-weight: 600;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
        }

        .advanced-filters-btn.active {
          border-color: #38bdf8;
          color: #38bdf8;
          background: rgba(56, 189, 248, 0.06);
        }

        .advanced-filters-btn :global(svg) {
          width: 14px;
          height: 14px;
        }

        .filters-drawer {
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 8px;
          padding: 10px 14px;
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 12px;
          color: #94a3b8;
        }

        .filter-chip {
          padding: 4px 10px;
          border-radius: 4px;
          background: rgba(255, 255, 255, 0.04);
          border: 1px solid rgba(255, 255, 255, 0.08);
          color: #cbd5e1;
          font-size: 11px;
          font-weight: 600;
          cursor: pointer;
        }

        .filter-chip.selected {
          background: rgba(56, 189, 248, 0.15);
          border-color: #38bdf8;
          color: #38bdf8;
        }

        /* Container de Tabla / Empty State */
        .paginas-table-container {
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          overflow: hidden;
        }

        .loading-state-container {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 12px;
          padding: 70px 20px;
          color: #94a3b8;
          font-size: 13px;
        }

        /* ESTADO VACÍO (SIN PÁGINAS AÚN) */
        .empty-pages-wrapper {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          text-align: center;
          padding: 60px 24px;
          max-width: 460px;
          margin: 0 auto;
          gap: 12px;
        }

        .empty-icon-circle {
          width: 60px;
          height: 60px;
          border-radius: 50%;
          background: rgba(56, 189, 248, 0.1);
          border: 1.5px dashed rgba(56, 189, 248, 0.4);
          display: grid;
          place-items: center;
          color: #38bdf8;
          box-shadow: 0 0 24px rgba(56, 189, 248, 0.15);
          margin-bottom: 4px;
        }

        .empty-icon-circle :global(svg) {
          width: 28px;
          height: 28px;
        }

        .empty-pages-wrapper h3 {
          font-size: 20px;
          font-weight: 800;
          color: #ffffff;
          margin: 0;
          letter-spacing: -0.3px;
        }

        .empty-pages-wrapper p {
          font-size: 13px;
          color: #94a3b8;
          margin: 0 0 6px;
          line-height: 1.5;
        }

        .btn-reset-filters {
          height: 36px;
          padding: 0 16px;
          border-radius: 6px;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: #cbd5e1;
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
        }

        /* Botón Neón Crear Primera Página */
        :global(.neon-create-first-btn) {
          height: 42px !important;
          padding: 0 22px !important;
          border-radius: 8px !important;
          background: linear-gradient(110deg, #12b85f, #18d878) !important;
          border: 1px solid rgba(67, 255, 147, 0.4) !important;
          color: #030b12 !important;
          font-size: 13px !important;
          font-weight: 800 !important;
          display: inline-flex !important;
          flex-direction: row !important;
          align-items: center !important;
          justify-content: center !important;
          gap: 8px !important;
          text-decoration: none !important;
          cursor: pointer !important;
          box-shadow: 0 0 24px rgba(22, 201, 111, 0.35) !important;
          transition: all 0.2s ease !important;
        }

        :global(.neon-create-first-btn:hover) {
          background: #20df7b !important;
          transform: translateY(-2px) !important;
          box-shadow: 0 0 30px rgba(22, 201, 111, 0.5) !important;
        }

        :global(.neon-create-first-btn svg) {
          width: 16px !important;
          height: 16px !important;
          stroke-width: 2.5px !important;
        }

        /* Table */
        .table-responsive-scroll {
          overflow-x: auto;
        }

        .paginas-data-table {
          width: 100%;
          border-collapse: collapse;
          font-size: 12px;
        }

        .paginas-data-table th {
          background: #040c14;
          color: #94a3b8;
          font-size: 11px;
          font-weight: 700;
          text-align: left;
          padding: 12px 14px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .paginas-data-table td {
          padding: 14px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.04);
          color: #cbd5e1;
        }

        .paginas-data-table tr:hover td {
          background: rgba(255, 255, 255, 0.02);
        }

        .paginas-data-table tr.row-selected td {
          background: rgba(56, 189, 248, 0.04);
        }

        .th-checkbox, .td-checkbox {
          width: 32px;
          text-align: center;
        }

        .th-checkbox input, .td-checkbox input {
          accent-color: #38bdf8;
          cursor: pointer;
        }

        .title-cell-wrap {
          display: flex;
          flex-direction: column;
          gap: 2px;
        }

        .title-row {
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .page-title-text {
          font-size: 13px;
          font-weight: 700;
          color: #ffffff;
        }

        .title-mini-icon {
          width: 13px;
          height: 13px;
          color: #94a3b8;
        }

        .page-url-sub {
          font-size: 10px;
          color: #64748b;
          font-family: monospace;
        }

        .template-pill {
          background: rgba(56, 189, 248, 0.08);
          border: 1px solid rgba(56, 189, 248, 0.2);
          color: #38bdf8;
          padding: 2px 8px;
          border-radius: 4px;
          font-size: 11px;
          font-weight: 600;
          display: inline-block;
        }

        .parent-page-badge {
          background: rgba(168, 85, 247, 0.08);
          border: 1px solid rgba(168, 85, 247, 0.2);
          color: #c084fc;
          padding: 2px 8px;
          border-radius: 4px;
          font-size: 11px;
          font-weight: 600;
          display: inline-block;
        }

        .no-parent-text {
          font-size: 11px;
          color: #64748b;
        }

        .status-pill {
          font-size: 10px;
          font-weight: 700;
          padding: 3px 8px;
          border-radius: 12px;
          display: inline-block;
        }

        .status-pill.published {
          background: rgba(22, 201, 111, 0.15);
          color: #16c96f;
          border: 1px solid rgba(22, 201, 111, 0.3);
        }

        .status-pill.draft {
          background: rgba(245, 158, 11, 0.15);
          color: #f59e0b;
          border: 1px solid rgba(245, 158, 11, 0.3);
        }

        .status-pill.private {
          background: rgba(168, 85, 247, 0.15);
          color: #c084fc;
          border: 1px solid rgba(168, 85, 247, 0.3);
        }

        .seo-gauge-cell {
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .seo-mini-donut {
          width: 22px;
          height: 22px;
        }

        .seo-mini-donut svg {
          width: 100%;
          height: 100%;
          transform: rotate(-90deg);
        }

        .circle-bg {
          fill: none;
          stroke: rgba(255, 255, 255, 0.1);
          stroke-width: 3.8;
        }

        .circle {
          fill: none;
          stroke-width: 3.8;
          stroke-linecap: round;
        }

        .seo-mini-donut.good .circle { stroke: #16c96f; }
        .seo-mini-donut.warning .circle { stroke: #f59e0b; }

        .seo-pct {
          font-size: 11px;
          font-weight: 700;
          color: #ffffff;
        }

        .seo-pct.muted {
          color: #475569;
        }

        .date-cell b {
          display: block;
          font-size: 11px;
          color: #f1f5f9;
        }

        .date-cell small {
          font-size: 10px;
          color: #64748b;
        }

        .table-actions-group {
          display: flex;
          align-items: center;
          gap: 6px;
        }

        :global(.action-btn) {
          width: 28px !important;
          height: 28px !important;
          border-radius: 4px !important;
          background: #040c14 !important;
          border: 1px solid rgba(255, 255, 255, 0.08) !important;
          color: #94a3b8 !important;
          display: grid !important;
          place-items: center !important;
          cursor: pointer !important;
          text-decoration: none !important;
          transition: all 0.15s !important;
        }

        :global(.action-btn.edit:hover) {
          color: #38bdf8 !important;
          border-color: rgba(56, 189, 248, 0.4) !important;
          background: rgba(56, 189, 248, 0.08) !important;
        }

        :global(.action-btn.view:hover) {
          color: #16c96f !important;
          border-color: rgba(22, 201, 111, 0.4) !important;
          background: rgba(22, 201, 111, 0.08) !important;
        }

        :global(.action-btn.delete:hover) {
          color: #ef4444 !important;
          border-color: rgba(239, 68, 68, 0.4) !important;
          background: rgba(239, 68, 68, 0.08) !important;
        }

        :global(.action-btn svg) {
          width: 13px !important;
          height: 13px !important;
        }

        /* Pagination */
        .table-pagination-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 12px 16px;
          border-top: 1px solid rgba(255, 255, 255, 0.06);
          font-size: 11px;
          color: #64748b;
        }

        .pagination-controls {
          display: flex;
          gap: 4px;
        }

        .page-nav-btn, .page-number-btn {
          width: 28px;
          height: 28px;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 4px;
          color: #cbd5e1;
          font-size: 11px;
          display: grid;
          place-items: center;
          cursor: pointer;
        }

        .page-nav-btn:disabled {
          opacity: 0.3;
          cursor: not-allowed;
        }

        .page-number-btn.active {
          background: rgba(56, 189, 248, 0.15);
          border-color: #38bdf8;
          color: #38bdf8;
          font-weight: 700;
        }

        /* LIGHT MODE SCOPED OVERRIDES */
        :global(.theme-light) .paginas-page-header h1 {
          color: #0f172a !important;
        }

        :global(.theme-light) .paginas-page-header p {
          color: #64748b !important;
        }

        :global(.theme-light) .refresh-sync-btn {
          background: #ffffff !important;
          border-color: #cbd5e1 !important;
          color: #334155 !important;
        }

        :global(.theme-light) .refresh-sync-btn:hover {
          background: #f1f5f9 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .summary-metric-card {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .card-info span {
          color: #64748b !important;
        }

        :global(.theme-light) .card-info strong {
          color: #0f172a !important;
        }

        :global(.theme-light) .paginas-toolbar-card,
        :global(.theme-light) .filters-drawer {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
        }

        :global(.theme-light) .toolbar-search-wrapper {
          background: transparent !important;
          border: none !important;
          box-shadow: none !important;
        }

        :global(.theme-light) .toolbar-search-wrapper input {
          background: #ffffff !important;
          border: 1px solid #cbd5e1 !important;
          color: #0f172a !important;
          box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .toolbar-search-wrapper input::placeholder {
          color: #94a3b8 !important;
        }

        :global(.theme-light) .advanced-filters-btn {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #334155 !important;
        }

        :global(.theme-light) .filter-chip {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #475569 !important;
        }

        :global(.theme-light) .paginas-table-container {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .paginas-data-table th,
        :global(.theme-light) .pages-data-table th {
          background: #f8fafc !important;
          color: #475569 !important;
          border-bottom-color: #e2e8f0 !important;
        }

        :global(.theme-light) .paginas-data-table td,
        :global(.theme-light) .pages-data-table td {
          border-bottom-color: #f1f5f9 !important;
          color: #334155 !important;
        }

        :global(.theme-light) .paginas-data-table tr:hover td,
        :global(.theme-light) .pages-data-table tr:hover td {
          background: #f8fafc !important;
        }

        :global(.theme-light) .page-title-text,
        :global(.theme-light) .page-title-link {
          color: #0f172a !important;
        }

        :global(.theme-light) .page-url-sub,
        :global(.theme-light) .page-slug-preview,
        :global(.theme-light) .date-sub-text,
        :global(.theme-light) .no-parent-text {
          color: #64748b !important;
        }

        :global(.theme-light) .template-pill {
          background: #f1f5f9 !important;
          border: 1px solid #e2e8f0 !important;
          color: #475569 !important;
        }

        :global(.theme-light) .parent-page-badge {
          background: rgba(14, 165, 233, 0.1) !important;
          border: 1px solid rgba(14, 165, 233, 0.25) !important;
          color: #0284c7 !important;
        }

        :global(.theme-light) .action-btn,
        :global(.theme-light) :global(.action-btn),
        :global(.theme-light) .action-btn-square {
          background: #f8fafc !important;
          border: 1px solid #cbd5e1 !important;
          color: #475569 !important;
        }

        :global(.theme-light) .action-btn:hover,
        :global(.theme-light) :global(.action-btn:hover),
        :global(.theme-light) .action-btn-square:hover {
          background: #f1f5f9 !important;
          color: #0f172a !important;
          border-color: #94a3b8 !important;
        }

        :global(.theme-light) .table-pagination-bar {
          border-top-color: #e2e8f0 !important;
          color: #64748b !important;
        }

        :global(.theme-light) .page-nav-btn,
        :global(.theme-light) .page-number-btn {
          background: #f8fafc !important;
          border-color: #e2e8f0 !important;
          color: #475569 !important;
        }

        @media (max-width: 1024px) {
          .summary-cards-grid {
            grid-template-columns: repeat(2, 1fr);
          }
        }

        @media (max-width: 640px) {
          .summary-cards-grid {
            grid-template-columns: 1fr;
          }
        }
      `}</style>
    </div>
  );
}
