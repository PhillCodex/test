"use client";

import { useState, useRef, useEffect, useCallback, Suspense } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import {
  ChevronLeft,
  Plus,
  Undo2,
  Redo2,
  PanelRightClose,
  PanelRightOpen,
  Sparkles,
  UploadCloud,
  Check,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Copy,
  ExternalLink,
  Image as ImageIcon,
  Heading2,
  Heading3,
  Heading4,
  Pilcrow,
  Quote,
  List,
  ListOrdered,
  Code,
  Trash2,
  Monitor,
  Smartphone,
  Search,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  FileCode,
  X,
  Loader2,
  Files,
  Bold,
  Italic,
  Underline,
  Strikethrough,
  Link2,
  Palette,
  MoreVertical,
  ChevronUp,
  ChevronDown,
  GripVertical,
  RotateCcw,
  Globe,
  Gauge,
  Share2,
  SlidersHorizontal,
  CheckCheck,
  FileText,
  KeyRound,
  ShieldCheck,
  Sun,
  Moon,
} from "lucide-react";

interface PageParentOption {
  id: string;
  title: string;
  slug: string;
}

function NuevoPaginaPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const editId = searchParams.get("edit") || searchParams.get("id");

  // Estado de Tema Light / Dark
  const [theme, setTheme] = useState<"dark" | "light">("dark");

  useEffect(() => {
    const savedTheme = localStorage.getItem("techlab_admin_theme") as "dark" | "light" | null;
    if (savedTheme === "light" || savedTheme === "dark") {
      setTheme(savedTheme);
    }
  }, []);

  const toggleTheme = () => {
    const nextTheme = theme === "dark" ? "light" : "dark";
    setTheme(nextTheme);
    localStorage.setItem("techlab_admin_theme", nextTheme);
  };

  // Estados del Documento
  const [title, setTitle] = useState("");
  const [slug, setSlug] = useState("");
  const [isSlugEdited, setIsSlugEdited] = useState(false);
  const [contentHtml, setContentHtml] = useState("");
  const [featuredImage, setFeaturedImage] = useState<string | null>(null);
  const [status, setStatus] = useState<"Publicado" | "Borrador" | "Privado">("Borrador");
  const [template, setTemplate] = useState("default");
  const [parentId, setParentId] = useState("");
  const [parentPages, setParentPages] = useState<PageParentOption[]>([]);
  const [authorName, setAuthorName] = useState("Cesar Fuentes");
  const [publishDate, setPublishDate] = useState("Inmediatamente");
  const [commentsOpen, setCommentsOpen] = useState(false);

  // Estados de SEO Avanzado (Estilo Rank Math / Yoast)
  const [focusKeyword, setFocusKeyword] = useState("");
  const [seoTitle, setSeoTitle] = useState("");
  const [seoDescription, setSeoDescription] = useState("");
  const [serpView, setSerpView] = useState<"desktop" | "mobile">("desktop");
  const [seoActiveTab, setSeoActiveTab] = useState<"general" | "analysis" | "social">("general");

  // Pestañas y Sidebar
  const [sidebarTab, setSidebarTab] = useState<"page" | "block">("page");
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // Inserter de Bloques [+] estilo WordPress
  const [showInlineInserter, setShowInlineInserter] = useState(false);
  const [showFullInserterDrawer, setShowFullInserterDrawer] = useState(false);
  const [inserterSearch, setInserterSearch] = useState("");

  // Estados de UI y AJAX
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [publishedUrl, setPublishedUrl] = useState<string | null>(null);
  const [publishSidebarState, setPublishSidebarState] = useState<"pre-publish" | "publishing" | "published" | null>(null);
  const [alwaysShowPrePublish, setAlwaysShowPrePublish] = useState<boolean>(true);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<"success" | "error">("success");
  const [isCopied, setIsCopied] = useState(false);
  const [lastSavedTime, setLastSavedTime] = useState<string>("hace un momento");
  const [origin, setOrigin] = useState("");

  // Modales
  const [showSlugModal, setShowSlugModal] = useState(false);
  const [showVideoModal, setShowVideoModal] = useState(false);
  const [videoUrl, setVideoUrl] = useState("");

  // Barra Flotante de Bloque / Selección Gutenberg
  const [blockToolbar, setBlockToolbar] = useState<{
    visible: boolean;
    top: number;
    left: number;
    blockType: string;
    hasSelection: boolean;
  }>({
    visible: false,
    top: 0,
    left: 0,
    blockType: "p",
    hasSelection: false,
  });

  const [activeBlockEl, setActiveBlockEl] = useState<HTMLElement | null>(null);
  const [showBlockTypeMenu, setShowBlockTypeMenu] = useState(false);
  const [showAlignMenu, setShowAlignMenu] = useState(false);
  const [showLinkInput, setShowLinkInput] = useState(false);
  const [linkInputUrl, setLinkInputUrl] = useState("");
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [colorTab, setColorTab] = useState<"text" | "background">("text");
  const [activeColorPreview, setActiveColorPreview] = useState<string>("#38bdf8");
  const [showMoreMenu, setShowMoreMenu] = useState(false);

  // Estado de Auto-Guardado en Borrador
  const [autoSaveState, setAutoSaveState] = useState<"idle" | "saving" | "saved">("idle");
  const autoSaveTimerRef = useRef<NodeJS.Timeout | null>(null);
  const lastSavedPayloadRef = useRef<string>("");
  const isAutoSavingRef = useRef<boolean>(false);
  const isInitialLoadRef = useRef(true);
  const [isCanvasDragOver, setIsCanvasDragOver] = useState(false);

  const editorRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const editorImageInputRef = useRef<HTMLInputElement>(null);

  // Detectar dominio actual
  useEffect(() => {
    if (typeof window !== "undefined") {
      setOrigin(window.location.origin);
    }
  }, []);

  // Cargar páginas existentes para el selector de Página Superior (Padre)
  const loadParentPages = useCallback(async () => {
    try {
      const res = await fetch("/api/pages");
      const data = await res.json();
      if (data.pages && Array.isArray(data.pages)) {
        setParentPages(
          data.pages
            .filter((p: any) => p.id !== editId)
            .map((p: any) => ({ id: p.id, title: p.title, slug: p.slug }))
        );
      }
    } catch (e) {
      console.error("Error al cargar páginas para jerarquía:", e);
    }
  }, [editId]);

  useEffect(() => {
    loadParentPages();
  }, [loadParentPages]);

  // Cargar datos en modo edición
  useEffect(() => {
    if (!editId) return;

    const fetchEditPage = async () => {
      try {
        const res = await fetch(`/api/pages?id=${encodeURIComponent(editId)}`);
        const data = await res.json();
        if (data.success && data.page) {
          const found = data.page;
          setTitle(found.title || "");
          setSlug(found.slug || "");
          setIsSlugEdited(true);
          setContentHtml(found.content || "");
          if (editorRef.current) {
            editorRef.current.innerHTML = found.content || "";
          }
          setFeaturedImage(found.featuredImage || null);
          setStatus(found.status || "Publicado");
          setTemplate(found.template || "default");
          setParentId(found.parentId || "");
          setFocusKeyword(found.focusKeyword || "");
          setSeoTitle(found.seoTitle || "");
          setSeoDescription(found.seoDescription || "");
          if (found.author?.name) setAuthorName(found.author.name);
        }
      } catch (e) {
        console.error("Error al cargar página para edición:", e);
      }
    };

    fetchEditPage();
  }, [editId]);

  // Sincronizar contenido del editor cuando se monte el DOM
  useEffect(() => {
    if (editorRef.current && contentHtml && !editorRef.current.innerHTML) {
      editorRef.current.innerHTML = contentHtml;
    }
  }, [contentHtml]);

  // Generador de Slug SEO automático
  const generateSlug = (text: string) => {
    return text
      .toLowerCase()
      .trim()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/-+/g, "-")
      .replace(/^-+|-+$/g, "");
  };

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setTitle(val);
    if (!isSlugEdited) {
      setSlug(generateSlug(val));
    }
    if (!seoTitle) {
      setSeoTitle(val);
    }
  };

  const showToast = (msg: string, type: "success" | "error" = "success") => {
    setToastMessage(msg);
    setToastType(type);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Conteo de palabras
  const wordCount =
    editorRef.current?.innerText.trim().split(/\s+/).filter(Boolean).length || 0;

  // Cálculo Dinámico de Puntuación SEO para Google
  const calculateSeoScore = () => {
    let score = 0;

    if (title.length >= 10 && title.length <= 70) score += 20;
    else if (title.length > 0) score += 10;

    if (seoDescription.length >= 70 && seoDescription.length <= 160) score += 20;
    else if (seoDescription.length > 0) score += 10;

    if (focusKeyword.trim().length > 2) {
      score += 15;
      if (title.toLowerCase().includes(focusKeyword.toLowerCase())) score += 15;
      if (seoDescription.toLowerCase().includes(focusKeyword.toLowerCase())) score += 10;
    }

    if (wordCount >= 200) score += 10;
    else if (wordCount >= 50) score += 5;

    if (featuredImage) score += 10;

    return Math.min(100, score);
  };

  const currentSeoScore = calculateSeoScore();

  const seoChecks = [
    {
      label: "Longitud del título de la página",
      category: "Básico",
      pass: title.length >= 10 && title.length <= 70,
      hint: `${title.length}/70 caracteres recomendados para posicionamiento.`,
    },
    {
      label: "Meta descripción para Google",
      category: "Básico",
      pass: seoDescription.length >= 70 && seoDescription.length <= 160,
      hint: `${seoDescription.length}/160 caracteres óptimos para visualización en snippets.`,
    },
    {
      label: "Palabra clave principal definida",
      category: "Palabra Clave",
      pass: focusKeyword.trim().length > 2,
      hint: focusKeyword ? `"${focusKeyword}" asignada como objetivo.` : "Agrega una palabra clave estratégica.",
    },
    {
      label: "Palabra clave incluida en el título",
      category: "Palabra Clave",
      pass: !!(focusKeyword && title.toLowerCase().includes(focusKeyword.toLowerCase())),
      hint: "Crucial para indicar la relevancia temática a Google.",
    },
    {
      label: "Extensión del contenido",
      category: "Contenido",
      pass: wordCount >= 150,
      hint: `${wordCount} palabras redactadas (mínimo recomendado: 150 palabras).`,
    },
    {
      label: "Imagen destacada asignada",
      category: "Medios",
      pass: !!featuredImage,
      hint: featuredImage ? "Imagen asignada correctamente." : "Sube una imagen para enriquecer los resultados y previews.",
    },
  ];

  // Subir imagen destacada
  const handleFeaturedImageUpload = async (file: File) => {
    setIsUploadingImage(true);
    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("attachedToTitle", title.trim() || "(sin título)");
      formData.append("attachedToType", "page");
      formData.append("attachedToUrl", editId ? `/dashboard/paginas/nuevo?id=${editId}` : "/dashboard/paginas/nuevo");
      if (editId) formData.append("attachedToId", editId);

      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      const data = await res.json();
      if (data.url) {
        setFeaturedImage(data.url);
        showToast("Imagen destacada subida correctamente", "success");
      } else {
        showToast(data.error || "Error al subir imagen", "error");
      }
    } catch {
      showToast("Error de conexión al subir imagen", "error");
    } finally {
      setIsUploadingImage(false);
    }
  };

  // Subir imagen al cuerpo del editor
  const handleEditorImageUpload = async (file: File) => {
    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("attachedToTitle", title.trim() || "(sin título)");
      formData.append("attachedToType", "page");
      formData.append("attachedToUrl", editId ? `/dashboard/paginas/nuevo?id=${editId}` : "/dashboard/paginas/nuevo");
      if (editId) formData.append("attachedToId", editId);

      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      const data = await res.json();
      if (data.url) {
        insertHtmlAtCursor(
          `<figure class="editor-img-block"><img src="${data.url}" alt="Imagen de página" style="max-width:100%; border-radius:8px; margin: 16px 0;" /><figcaption style="font-size:12px; color:#94a3b8; text-align:center;">Pie de imagen opcional</figcaption></figure><p><br></p>`
        );
        showToast("Imagen insertada en el contenido", "success");
      }
    } catch {
      showToast("Error al insertar imagen", "error");
    }
  };

  const insertHtmlAtCursor = (html: string) => {
    if (!editorRef.current) return;
    editorRef.current.focus();
    document.execCommand("insertHTML", false, html);
    setContentHtml(editorRef.current.innerHTML);
    setLastSavedTime("hace un instante");
  };

  // Detección de bloque activo y posición de la barra flotante Gutenberg
  const updateBlockToolbar = useCallback(() => {
    if (typeof window === "undefined" || !editorRef.current) return;
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) {
      setBlockToolbar((prev) => (prev.visible ? { ...prev, visible: false } : prev));
      return;
    }

    const anchorNode = sel.anchorNode;
    if (!anchorNode || !editorRef.current.contains(anchorNode)) {
      setBlockToolbar((prev) => (prev.visible ? { ...prev, visible: false } : prev));
      return;
    }

    // Buscar el elemento contenedor de bloque activo
    let curr: Node | null = anchorNode;
    let blockElement: HTMLElement | null = null;
    while (curr && curr !== editorRef.current) {
      if (curr.nodeType === Node.ELEMENT_NODE) {
        const tag = (curr as HTMLElement).tagName.toLowerCase();
        if (["p", "h1", "h2", "h3", "h4", "blockquote", "pre", "ul", "ol", "figure", "div"].includes(tag)) {
          blockElement = curr as HTMLElement;
          break;
        }
      }
      curr = curr.parentNode;
    }

    if (!blockElement && anchorNode.nodeType === Node.ELEMENT_NODE && anchorNode !== editorRef.current) {
      blockElement = anchorNode as HTMLElement;
    }

    setActiveBlockEl(blockElement);

    const hasSelection = !sel.isCollapsed && sel.toString().trim().length > 0;

    let rect: DOMRect | null = null;
    if (hasSelection) {
      const range = sel.getRangeAt(0);
      rect = range.getBoundingClientRect();
    } else if (blockElement) {
      rect = blockElement.getBoundingClientRect();
    } else {
      const range = sel.getRangeAt(0);
      rect = range.getBoundingClientRect();
    }

    if (rect && (rect.width > 0 || rect.height > 0 || rect.top > 0)) {
      const editorRect = editorRef.current.getBoundingClientRect();
      const tag = blockElement ? blockElement.tagName.toLowerCase() : "p";

      const targetTop = Math.max(72, rect.top - 46);
      const targetLeft = Math.max(
        editorRect.left + 8,
        Math.min(rect.left, editorRect.right - 360)
      );

      setBlockToolbar({
        visible: true,
        top: targetTop,
        left: targetLeft,
        blockType: tag,
        hasSelection,
      });
    }
  }, []);

  // Listeners de selección y foco
  useEffect(() => {
    const handleDocSelection = () => {
      updateBlockToolbar();
    };

    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (
        !editorRef.current?.contains(target) &&
        !target.closest(".gutenberg-floating-block-toolbar") &&
        !target.closest(".gutenberg-tb-popover")
      ) {
        setBlockToolbar((prev) => (prev.visible ? { ...prev, visible: false } : prev));
        setShowBlockTypeMenu(false);
        setShowAlignMenu(false);
        setShowLinkInput(false);
        setShowColorPicker(false);
        setShowMoreMenu(false);
      }
    };

    document.addEventListener("selectionchange", handleDocSelection);
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("selectionchange", handleDocSelection);
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [updateBlockToolbar]);

  // Formateo de documento
  const formatDoc = (cmd: string, value: string | undefined = undefined) => {
    if (!editorRef.current) return;
    editorRef.current.focus();
    document.execCommand(cmd, false, value);
    setContentHtml(editorRef.current.innerHTML);
    setLastSavedTime("hace un instante");
    setTimeout(updateBlockToolbar, 30);
  };

  const execCmd = formatDoc;

  // Transformar tipo de bloque
  const transformBlockType = (tag: string) => {
    if (!editorRef.current) return;
    editorRef.current.focus();
    if (["p", "h1", "h2", "h3", "blockquote", "pre"].includes(tag)) {
      document.execCommand("formatBlock", false, `<${tag}>`);
    } else if (tag === "ul") {
      document.execCommand("insertUnorderedList");
    } else if (tag === "ol") {
      document.execCommand("insertOrderedList");
    }
    setShowBlockTypeMenu(false);
    setContentHtml(editorRef.current.innerHTML);
    setTimeout(updateBlockToolbar, 50);
  };

  // Mover bloque activo arriba o abajo
  const moveActiveBlock = (dir: "up" | "down") => {
    if (!activeBlockEl || !editorRef.current) return;
    if (dir === "up" && activeBlockEl.previousElementSibling) {
      editorRef.current.insertBefore(activeBlockEl, activeBlockEl.previousElementSibling);
    } else if (dir === "down" && activeBlockEl.nextElementSibling) {
      editorRef.current.insertBefore(activeBlockEl.nextElementSibling, activeBlockEl);
    }
    setContentHtml(editorRef.current.innerHTML);
    setTimeout(updateBlockToolbar, 50);
  };

  // Aplicar alineación
  const applyAlignment = (alignCmd: string) => {
    formatDoc(alignCmd);
    setShowAlignMenu(false);
  };

  // Aplicar enlace
  const handleApplyLink = () => {
    if (!linkInputUrl.trim()) {
      setShowLinkInput(false);
      return;
    }
    let url = linkInputUrl.trim();
    if (!/^https?:\/\//i.test(url)) {
      url = "https://" + url;
    }
    formatDoc("createLink", url);
    setShowLinkInput(false);
    setLinkInputUrl("");
  };

  // Aplicar Color de Texto o Fondo/Resaltado (tanto si hay selección como si está en el bloque)
  const applyColor = (type: "text" | "background", colorHex: string) => {
    if (!editorRef.current) return;
    editorRef.current.focus();

    if (blockToolbar.hasSelection) {
      document.execCommand("styleWithCSS", false, "true");
      if (type === "text") {
        document.execCommand("foreColor", false, colorHex);
        setActiveColorPreview(colorHex);
      } else {
        document.execCommand("hiliteColor", false, colorHex);
      }
    } else {
      if (activeBlockEl) {
        if (type === "text") {
          activeBlockEl.style.color = colorHex === "inherit" ? "" : colorHex;
          setActiveColorPreview(colorHex);
        } else {
          if (colorHex === "transparent") {
            activeBlockEl.style.backgroundColor = "";
            activeBlockEl.style.padding = "";
            activeBlockEl.style.borderRadius = "";
          } else {
            activeBlockEl.style.backgroundColor = colorHex;
            activeBlockEl.style.padding = "6px 12px";
            activeBlockEl.style.borderRadius = "6px";
          }
        }
      } else {
        document.execCommand("styleWithCSS", false, "true");
        if (type === "text") {
          document.execCommand("foreColor", false, colorHex);
        } else {
          document.execCommand("hiliteColor", false, colorHex);
        }
      }
    }

    setContentHtml(editorRef.current.innerHTML);
    setLastSavedTime("hace un instante");
  };

  // Duplicar bloque
  const duplicateBlock = () => {
    if (!activeBlockEl || !editorRef.current) return;
    const clone = activeBlockEl.cloneNode(true) as HTMLElement;
    if (activeBlockEl.nextSibling) {
      editorRef.current.insertBefore(clone, activeBlockEl.nextSibling);
    } else {
      editorRef.current.appendChild(clone);
    }
    setContentHtml(editorRef.current.innerHTML);
    setShowMoreMenu(false);
    setTimeout(updateBlockToolbar, 50);
  };

  // Insertar bloque antes / después
  const insertBlockRelative = (pos: "before" | "after") => {
    if (!activeBlockEl || !editorRef.current) return;
    const p = document.createElement("p");
    p.innerHTML = "<br>";
    if (pos === "before") {
      editorRef.current.insertBefore(p, activeBlockEl);
    } else {
      if (activeBlockEl.nextSibling) {
        editorRef.current.insertBefore(p, activeBlockEl.nextSibling);
      } else {
        editorRef.current.appendChild(p);
      }
    }
    setContentHtml(editorRef.current.innerHTML);
    setShowMoreMenu(false);
  };

  // Eliminar bloque activo
  const deleteActiveBlock = () => {
    if (!activeBlockEl || !editorRef.current) return;
    activeBlockEl.remove();
    setContentHtml(editorRef.current.innerHTML);
    setBlockToolbar({ visible: false, top: 0, left: 0, blockType: "p", hasSelection: false });
    setShowMoreMenu(false);
  };

  // Inserter de Bloques [+]
  const handleInsertBlock = (blockType: string) => {
    setShowInlineInserter(false);
    setShowFullInserterDrawer(false);

    switch (blockType) {
      case "p":
        insertHtmlAtCursor("<p>Comienza a escribir tu párrafo aquí...</p>");
        break;
      case "h2":
      case "heading":
        insertHtmlAtCursor("<h2>Subtítulo de Sección H2</h2><p><br></p>");
        break;
      case "h3":
        insertHtmlAtCursor("<h3>Encabezado H3</h3><p><br></p>");
        break;
      case "h4":
        insertHtmlAtCursor("<h4>Subsección H4</h4><p><br></p>");
        break;
      case "quote":
        insertHtmlAtCursor(
          `<blockquote style="border-left: 3px solid #38bdf8; padding-left: 14px; margin: 16px 0; color: #94a3b8; font-style: italic;">“Inserta una cita destacada aquí.”</blockquote><p><br></p>`
        );
        break;
      case "ul":
        insertHtmlAtCursor("<ul><li>Elemento de lista 1</li><li>Elemento de lista 2</li></ul><p><br></p>");
        break;
      case "ol":
        insertHtmlAtCursor("<ol><li>Paso número uno</li><li>Paso número dos</li></ol><p><br></p>");
        break;
      case "code":
        insertHtmlAtCursor(
          `<pre style="background:#040c14; border:1px solid rgba(255,255,255,0.1); padding:12px; border-radius:6px; font-family:monospace; color:#a7f3d0;"><code>// Escribe tu código aquí\nconst message = "Hola Mundo TechLab";</code></pre><p><br></p>`
        );
        break;
      case "image":
        editorImageInputRef.current?.click();
        break;
      case "video":
        setShowVideoModal(true);
        break;
      default:
        break;
    }
  };

  // Insertar Video Embed
  const handleInsertVideo = () => {
    if (!videoUrl) return;
    let embedUrl = videoUrl;

    if (videoUrl.includes("youtube.com/watch?v=")) {
      const videoId = videoUrl.split("v=")[1]?.split("&")[0];
      embedUrl = `https://www.youtube.com/embed/${videoId}`;
    } else if (videoUrl.includes("youtu.be/")) {
      const videoId = videoUrl.split("youtu.be/")[1]?.split("?")[0];
      embedUrl = `https://www.youtube.com/embed/${videoId}`;
    }

    insertHtmlAtCursor(
      `<div class="video-embed-container" style="position:relative; padding-bottom:56.25%; height:0; overflow:hidden; border-radius:8px; margin:20px 0;"><iframe src="${embedUrl}" style="position:absolute; top:0; left:0; width:100%; height:100%; border:0;" allowfullscreen></iframe></div><p><br></p>`
    );
    setShowVideoModal(false);
    setVideoUrl("");
  };

  // Guardar o Publicar Página vía AJAX
  const handleSavePage = async (newStatus: "Publicado" | "Borrador" | "Privado"): Promise<boolean> => {
    const isElementor = template === "elementor_canvas" || contentHtml.includes("ELEMENTOR_DATA") || contentHtml.trim().startsWith("[");
    const rawContent = isElementor ? contentHtml : (editorRef.current?.innerHTML || contentHtml);
    if (!title.trim()) {
      showToast("El título de la página es obligatorio.", "error");
      return false;
    }
    if (!rawContent.trim() || rawContent === "<p><br></p>") {
      showToast("Escribe contenido en el cuerpo de la página antes de guardar.", "error");
      return false;
    }

    setIsSubmitting(true);

    const payload = {
      id: editId || undefined,
      title: title.trim(),
      slug: slug || generateSlug(title),
      content: rawContent,
      featuredImage,
      seoTitle: seoTitle || title,
      seoDescription,
      focusKeyword,
      seoScore: currentSeoScore,
      status: newStatus,
      template,
      parentId: parentId || null,
    };

    try {
      const res = await fetch("/api/pages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (data.success) {
        setStatus(newStatus);
        setLastSavedTime("hace unos segundos");
        lastSavedPayloadRef.current = JSON.stringify({
          id: editId || data.page?.id || null,
          title: title.trim(),
          content: rawContent,
          featuredImage,
          seoTitle,
          seoDescription,
          focusKeyword,
          template,
          parentId,
          status: newStatus,
        });
        if (data.page?.slug) {
          setSlug(data.page.slug);
        }
        const currentOrigin = typeof window !== "undefined" ? window.location.origin : (origin || "https://techlab.com");
        const finalUrl = data.fullUrl || `${currentOrigin}/paginas/${data.page?.slug || slug || generateSlug(title)}`;
        setPublishedUrl(finalUrl);

        if (newStatus === "Publicado") {
          showToast(editId ? "¡Página actualizada correctamente!" : "¡Página publicada exitosamente!", "success");
        } else {
          showToast("Borrador de página guardado en MySQL.", "success");
        }
        if (data.page?.id && !editId) {
          router.replace(`/dashboard/paginas/nuevo?edit=${data.page.id}`);
        }
        return true;
      } else {
        showToast(data.error || "Ocurrió un error al guardar.", "error");
        return false;
      }
    } catch {
      showToast("Error de conexión con el servidor.", "error");
      return false;
    } finally {
      setIsSubmitting(false);
    }
  };

  // Click en el botón Publicar / Actualizar superior estilo WordPress
  const handleTopPublishClick = () => {
    if (alwaysShowPrePublish && status !== "Publicado") {
      setIsSidebarOpen(true);
      setPublishSidebarState("pre-publish");
    } else {
      setIsSidebarOpen(true);
      setPublishSidebarState("publishing");
      handleSavePage("Publicado").then((ok) => {
        if (ok) {
          setPublishSidebarState("published");
        } else {
          setPublishSidebarState(null);
        }
      });
    }
  };

  // Guardar y abrir Elementor
  const handleOpenElementor = async () => {
    setIsSubmitting(true);
    showToast("Guardando y abriendo Elementor...", "success");

    const rawContent = editorRef.current?.innerHTML || contentHtml;
    const finalTitle = title.trim() || "Página sin título";

    const payload = {
      id: editId || undefined,
      title: finalTitle,
      slug: slug || generateSlug(finalTitle),
      content: rawContent,
      featuredImage,
      seoTitle: seoTitle || finalTitle,
      seoDescription,
      focusKeyword,
      seoScore: currentSeoScore,
      status: status || "Borrador",
      template: "elementor_canvas",
      parentId: parentId || null,
    };

    try {
      const res = await fetch("/api/pages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (data.success && data.page?.id) {
        router.push(`/dashboard/elementor/editor?id=${data.page.id}`);
      } else {
        showToast(data.error || "No se pudo guardar la página antes de abrir Elementor.", "error");
      }
    } catch {
      showToast("Error de conexión al abrir Elementor.", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Manejador de teclado en el editor (Enter abre un nuevo bloque)
  const handleEditorKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      const sel = window.getSelection();
      if (sel && sel.rangeCount > 0) {
        const node = sel.anchorNode;
        const parentBlock = node instanceof HTMLElement ? node : node?.parentElement;
        const tag = parentBlock?.tagName?.toUpperCase();
        if (parentBlock && ["H1", "H2", "H3", "H4", "BLOCKQUOTE", "PRE"].includes(tag || "")) {
          e.preventDefault();
          const newP = document.createElement("p");
          newP.innerHTML = "<br>";
          if (parentBlock.nextSibling) {
            parentBlock.parentNode?.insertBefore(newP, parentBlock.nextSibling);
          } else {
            parentBlock.parentNode?.appendChild(newP);
          }
          const range = document.createRange();
          range.setStart(newP, 0);
          range.collapse(true);
          sel.removeAllRanges();
          sel.addRange(range);
          setContentHtml(editorRef.current?.innerHTML || "");
          setTimeout(updateBlockToolbar, 40);
        }
      }
    }
  };

  // Drag & Drop de Bloques desde el Inserter Drawer
  const handleCanvasDragOver = (e: React.DragEvent) => {
    if (e.dataTransfer.types.includes("application/techlab-block")) {
      e.preventDefault();
      e.dataTransfer.dropEffect = "copy";
      setIsCanvasDragOver(true);
    }
  };

  const handleCanvasDragLeave = () => {
    setIsCanvasDragOver(false);
  };

  const handleCanvasDrop = (e: React.DragEvent) => {
    if (e.dataTransfer.types.includes("application/techlab-block")) {
      e.preventDefault();
      setIsCanvasDragOver(false);
      const blockType = e.dataTransfer.getData("application/techlab-block");
      if (blockType) {
        handleInsertBlock(blockType);
        showToast(`Bloque ${blockType} insertado`, "success");
      }
    }
  };

  // Auto-Guardado Inteligente como Borrador al dejar de escribir (Debounce 3500ms sin bucles)
  useEffect(() => {
    if (isInitialLoadRef.current) {
      isInitialLoadRef.current = false;
      return;
    }
    if (!title.trim()) return;

    if (autoSaveTimerRef.current) {
      clearTimeout(autoSaveTimerRef.current);
    }

    autoSaveTimerRef.current = setTimeout(async () => {
      const isElementor = template === "elementor_canvas" || contentHtml.includes("ELEMENTOR_DATA") || contentHtml.trim().startsWith("[");
      const rawContent = isElementor ? contentHtml : (editorRef.current?.innerHTML || contentHtml);
      if (!title.trim() || !rawContent.trim() || rawContent === "<p><br></p>" || isSubmitting || isAutoSavingRef.current) return;

      const payloadStr = JSON.stringify({
        id: editId || null,
        title: title.trim(),
        content: rawContent,
        featuredImage,
        seoTitle,
        seoDescription,
        focusKeyword,
        template,
        parentId,
        status,
      });

      // Si el contenido no ha cambiado respecto al último guardado, abortar para no saturar conexiones
      if (payloadStr === lastSavedPayloadRef.current) return;

      isAutoSavingRef.current = true;
      setAutoSaveState("saving");

      const payload = {
        id: editId || undefined,
        title: title.trim(),
        slug: slug || generateSlug(title),
        content: rawContent,
        featuredImage,
        seoTitle: seoTitle || title,
        seoDescription,
        focusKeyword,
        seoScore: currentSeoScore,
        status: status, // Preserva el estado actual (Publicado o Borrador)
        template,
        parentId: parentId || null,
      };

      try {
        const res = await fetch("/api/pages", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        const data = await res.json();
        if (data.success) {
          lastSavedPayloadRef.current = payloadStr;
          setLastSavedTime("hace unos segundos");
          setAutoSaveState("saved");
          setTimeout(() => setAutoSaveState("idle"), 3000);
        } else {
          setAutoSaveState("idle");
        }
      } catch {
        setAutoSaveState("idle");
      } finally {
        isAutoSavingRef.current = false;
      }
    }, 3500);

    return () => {
      if (autoSaveTimerRef.current) {
        clearTimeout(autoSaveTimerRef.current);
      }
    };
  }, [title, contentHtml, featuredImage, seoTitle, seoDescription, focusKeyword, template, parentId]);

  const handleCopyUrl = () => {
    if (!publishedUrl) return;
    navigator.clipboard.writeText(publishedUrl);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 3000);
  };

  const displayDomain = origin ? origin.replace(/^https?:\/\//, "") : "localhost:3000";

  return (
    <div className={`techlab-gutenberg-root ${theme === "light" ? "theme-light" : ""}`} data-theme={theme}>
      {/* Toast Notification */}
      {toastMessage && (
        <div className={`techlab-toast ${toastType}`}>
          {toastType === "success" ? <CheckCircle2 /> : <AlertCircle />}
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Input de archivo oculto para imagen destacada */}
      <input
        type="file"
        ref={fileInputRef}
        accept="image/*"
        style={{ display: "none" }}
        onChange={(e) => {
          if (e.target.files?.[0]) handleFeaturedImageUpload(e.target.files[0]);
        }}
      />

      {/* Input de archivo oculto para imagen en el cuerpo del editor */}
      <input
        type="file"
        ref={editorImageInputRef}
        accept="image/*"
        style={{ display: "none" }}
        onChange={(e) => {
          if (e.target.files?.[0]) handleEditorImageUpload(e.target.files[0]);
        }}
      />

      {/* =================================================================
          BARRA SUPERIOR (HEADER ESTILO WORDPRESS GUTENBERG)
          ================================================================= */}
      <header className="gutenberg-top-bar">
        {/* Izquierda: Volver, Añadir Bloque, Deshacer/Rehacer */}
        <div className="top-bar-left">
          <Link href="/dashboard/paginas" className="back-btn-square" title="Volver a Páginas">
            <ChevronLeft />
          </Link>

          <button
            type="button"
            className={`block-inserter-toggle-btn ${showFullInserterDrawer ? "active" : ""}`}
            onClick={() => setShowFullInserterDrawer(!showFullInserterDrawer)}
            title="Añadir bloque"
          >
            <Plus />
          </button>

          <div className="history-btns-group">
            <button type="button" onClick={() => execCmd("undo")} title="Deshacer (Ctrl+Z)">
              <Undo2 />
            </button>
            <button type="button" onClick={() => execCmd("redo")} title="Rehacer (Ctrl+Y)">
              <Redo2 />
            </button>
          </div>

          <div className="document-type-badge">
            <Files />
            <span>Página</span>
          </div>

          <button
            type="button"
            className="elementor-topbar-edit-btn"
            onClick={handleOpenElementor}
            title="Guardar y editar con el constructor visual Elementor"
          >
            <Sparkles />
            <span>Editar con Elementor</span>
          </button>
        </div>

        {/* Centro: Título de referencia rápida */}
        <div className="top-bar-center">
          <span className="doc-live-title">{title || "Sin título - Página"}</span>
          <span className={`doc-live-status-pill ${status.toLowerCase()}`}>{status}</span>
        </div>

        {/* Derecha: Borrador, Publicar, Sidebar Toggle */}
        <div className="top-bar-right">
          {/* Switch Modo Claro / Modo Oscuro */}
          <button
            type="button"
            className={`block-inserter-toggle-btn theme-toggle-btn ${theme === "light" ? "is-light" : ""}`}
            onClick={toggleTheme}
            title={theme === "light" ? "Cambiar a Modo Oscuro" : "Cambiar a Modo Claro"}
          >
            {theme === "light" ? <Moon style={{ color: "#6366f1" }} /> : <Sun style={{ color: "#f59e0b" }} />}
          </button>

          {/* Botón Editar con Elementor */}
          <Link
            href={`/dashboard/elementor/editor?id=${editId || ""}${slug ? `&slug=${encodeURIComponent(slug)}` : ""}`}
            className="topbar-elementor-btn"
            title="Abrir en el constructor visual Elementor"
          >
            <span className="elementor-pill-small">E</span>
            <span>Editar con Elementor</span>
          </Link>

          <button
            type="button"
            className={`draft-save-btn ${autoSaveState}`}
            onClick={() => handleSavePage("Borrador")}
            disabled={isSubmitting || autoSaveState === "saving"}
          >
            {autoSaveState === "saving" ? (
              <span className="btn-autosave-indicator saving">
                <Loader2 className="animate-spin" />
                <span>Guardando...</span>
              </span>
            ) : autoSaveState === "saved" ? (
              <span className="btn-autosave-indicator saved">
                <Check />
                <span>Guardado como borrador</span>
              </span>
            ) : (
              <span>Guardar borrador</span>
            )}
          </button>

          <button
            type="button"
            className="neon-publish-main-btn"
            onClick={handleTopPublishClick}
            disabled={isSubmitting}
          >
            {isSubmitting && status === "Publicado" ? (
              <>
                <Loader2 className="animate-spin" />
                <span>Publicando...</span>
              </>
            ) : (
              <>
                <Sparkles />
                <span>{status === "Publicado" ? "Actualizar" : "Publicar"}</span>
              </>
            )}
          </button>

          <button
            type="button"
            className={`sidebar-toggle-btn ${isSidebarOpen ? "open" : ""}`}
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            title="Ajustes de la página"
          >
            {isSidebarOpen ? <PanelRightClose /> : <PanelRightOpen />}
          </button>
        </div>
      </header>

      {/* =================================================================
          CUERPO PRINCIPAL (DRAWER DE BLOQUES + LIENZO + BARRA LATERAL)
          ================================================================= */}
      <div className="gutenberg-workspace-body">
        {/* DRAWER IZQUIERDO: BIBLIOTECA COMPLETA DE BLOQUES */}
        {showFullInserterDrawer && (
          <aside className="blocks-library-drawer">
            <div className="drawer-header">
              <h3>Añadir un bloque</h3>
              <button onClick={() => setShowFullInserterDrawer(false)}>
                <X />
              </button>
            </div>

            <div className="drawer-search-wrap">
              <Search />
              <input
                type="text"
                placeholder="Buscar bloques..."
                value={inserterSearch}
                onChange={(e) => setInserterSearch(e.target.value)}
                autoFocus
              />
            </div>

            <div className="blocks-category-section">
              <h4>TEXTO</h4>
              <div className="drawer-blocks-grid">
                <button
                  type="button"
                  className="drawer-block-btn"
                  draggable={true}
                  onDragStart={(e) => {
                    e.dataTransfer.setData("application/techlab-block", "p");
                    e.dataTransfer.effectAllowed = "copy";
                  }}
                  onClick={() => handleInsertBlock("p")}
                  title="Haz clic o arrastra al lienzo"
                >
                  <Pilcrow />
                  <span>Párrafo</span>
                </button>
                <button
                  type="button"
                  className="drawer-block-btn"
                  draggable={true}
                  onDragStart={(e) => {
                    e.dataTransfer.setData("application/techlab-block", "h2");
                    e.dataTransfer.effectAllowed = "copy";
                  }}
                  onClick={() => handleInsertBlock("h2")}
                  title="Haz clic o arrastra al lienzo"
                >
                  <Heading2 />
                  <span>Encabezado 2</span>
                </button>
                <button
                  type="button"
                  className="drawer-block-btn"
                  draggable={true}
                  onDragStart={(e) => {
                    e.dataTransfer.setData("application/techlab-block", "h3");
                    e.dataTransfer.effectAllowed = "copy";
                  }}
                  onClick={() => handleInsertBlock("h3")}
                  title="Haz clic o arrastra al lienzo"
                >
                  <Heading3 />
                  <span>Encabezado 3</span>
                </button>
                <button
                  type="button"
                  className="drawer-block-btn"
                  draggable={true}
                  onDragStart={(e) => {
                    e.dataTransfer.setData("application/techlab-block", "h4");
                    e.dataTransfer.effectAllowed = "copy";
                  }}
                  onClick={() => handleInsertBlock("h4")}
                  title="Haz clic o arrastra al lienzo"
                >
                  <Heading4 />
                  <span>Encabezado 4</span>
                </button>
                <button
                  type="button"
                  className="drawer-block-btn"
                  draggable={true}
                  onDragStart={(e) => {
                    e.dataTransfer.setData("application/techlab-block", "quote");
                    e.dataTransfer.effectAllowed = "copy";
                  }}
                  onClick={() => handleInsertBlock("quote")}
                  title="Haz clic o arrastra al lienzo"
                >
                  <Quote />
                  <span>Cita</span>
                </button>
                <button
                  type="button"
                  className="drawer-block-btn"
                  draggable={true}
                  onDragStart={(e) => {
                    e.dataTransfer.setData("application/techlab-block", "ul");
                    e.dataTransfer.effectAllowed = "copy";
                  }}
                  onClick={() => handleInsertBlock("ul")}
                  title="Haz clic o arrastra al lienzo"
                >
                  <List />
                  <span>Lista</span>
                </button>
                <button
                  type="button"
                  className="drawer-block-btn"
                  draggable={true}
                  onDragStart={(e) => {
                    e.dataTransfer.setData("application/techlab-block", "ol");
                    e.dataTransfer.effectAllowed = "copy";
                  }}
                  onClick={() => handleInsertBlock("ol")}
                  title="Haz clic o arrastra al lienzo"
                >
                  <ListOrdered />
                  <span>Lista numerada</span>
                </button>
                <button
                  type="button"
                  className="drawer-block-btn"
                  draggable={true}
                  onDragStart={(e) => {
                    e.dataTransfer.setData("application/techlab-block", "code");
                    e.dataTransfer.effectAllowed = "copy";
                  }}
                  onClick={() => handleInsertBlock("code")}
                  title="Haz clic o arrastra al lienzo"
                >
                  <Code />
                  <span>Código</span>
                </button>
              </div>
            </div>

            <div className="blocks-category-section">
              <h4>MEDIOS</h4>
              <div className="drawer-blocks-grid">
                <button
                  type="button"
                  className="drawer-block-btn"
                  draggable={true}
                  onDragStart={(e) => {
                    e.dataTransfer.setData("application/techlab-block", "image");
                    e.dataTransfer.effectAllowed = "copy";
                  }}
                  onClick={() => handleInsertBlock("image")}
                  title="Haz clic o arrastra al lienzo"
                >
                  <ImageIcon />
                  <span>Imagen</span>
                </button>
                <button
                  type="button"
                  className="drawer-block-btn"
                  draggable={true}
                  onDragStart={(e) => {
                    e.dataTransfer.setData("application/techlab-block", "video");
                    e.dataTransfer.effectAllowed = "copy";
                  }}
                  onClick={() => handleInsertBlock("video")}
                  title="Haz clic o arrastra al lienzo"
                >
                  <FileCode />
                  <span>Video Embed</span>
                </button>
              </div>
            </div>
          </aside>
        )}

        {/* LIENZO CENTRAL DE ESCRITURA (CANVAS ESTILO WORDPRESS) */}
        <main className="gutenberg-canvas-area" onClick={() => setShowInlineInserter(false)}>
          <div className="canvas-document-container" onClick={(e) => e.stopPropagation()}>
            {/* Título Principal (Sin barra inferior) */}
            <div className="title-input-wrapper">
              <input
                type="text"
                placeholder="Escribe un título"
                value={title}
                onChange={handleTitleChange}
                className="gutenberg-main-title"
                autoFocus
              />
            </div>

            {/* Editor de Contenido Editable con botón [+] a la derecha O Banner de Elementor */}
            {(() => {
              const isElementor = template === "elementor_canvas" || contentHtml.includes("ELEMENTOR_DATA") || contentHtml.trim().startsWith("[");
              if (isElementor) {
                return (
                  <div className="elementor-active-canvas-card">
                    <div className="elementor-card-badge-row">
                      <div className="elementor-card-logo">E</div>
                      <span className="elementor-card-tag">Constructor Elementor Activo</span>
                    </div>
                    <h2 className="elementor-card-title">Esta página se está editando con Elementor</h2>
                    <p className="elementor-card-desc">
                      El diseño visual, las secciones flexbox y los widgets de esta página están administrados directamente en el constructor visual de Elementor.
                    </p>
                    <div className="elementor-card-btn-row">
                      <Link
                        href={`/dashboard/elementor/editor?id=${editId || ""}${slug ? `&slug=${encodeURIComponent(slug)}` : ""}`}
                        className="btn-launch-elementor-editor"
                      >
                        <Sparkles style={{ width: 16, height: 16 }} />
                        Editar con Elementor
                      </Link>
                      <button
                        type="button"
                        className="btn-revert-gutenberg"
                        onClick={() => {
                          if (confirm("¿Deseas editar esta página con el editor estándar? El contenido de Elementor se convertirá a bloques editables.")) {
                            setTemplate("default");
                          }
                        }}
                      >
                        Volver al editor estándar
                      </button>
                    </div>
                  </div>
                );
              }

              return (
                <div className="editor-content-wrapper">
                  <div className="editor-block-stream-container">
                    <div
                      ref={editorRef}
                      className={`gutenberg-editable-content ${isCanvasDragOver ? "is-drag-over" : ""}`}
                      contentEditable
                      suppressContentEditableWarning
                      onInput={() => setContentHtml(editorRef.current?.innerHTML || "")}
                      onKeyDown={handleEditorKeyDown}
                      onMouseUp={updateBlockToolbar}
                      onKeyUp={updateBlockToolbar}
                      onClick={updateBlockToolbar}
                      onDragOver={handleCanvasDragOver}
                      onDragLeave={handleCanvasDragLeave}
                      onDrop={handleCanvasDrop}
                      data-placeholder="Teclea o escribe contenido para tu página..."
                    />

                    {/* Botón inline [+] en el lado DERECHO del primer bloque / bloque activo */}
                    <div className="block-right-inserter-anchor">
                      <button
                        type="button"
                        className="inline-plus-btn-right"
                        onClick={(e) => {
                          e.stopPropagation();
                          setShowInlineInserter(!showInlineInserter);
                        }}
                        title="Añadir bloque [+]"
                      >
                        <Plus />
                      </button>

                      {/* Popover al hacer clic en [+] */}
                      {showInlineInserter && (
                        <div className="inline-blocks-popover-right">
                          <div className="popover-search-box">
                            <Search />
                            <input
                              type="text"
                              placeholder="Buscar..."
                              value={inserterSearch}
                              onChange={(e) => setInserterSearch(e.target.value)}
                              autoFocus
                            />
                          </div>

                          <div className="popover-blocks-grid">
                            <button type="button" className="grid-item" onClick={() => handleInsertBlock("p")}>
                              <Pilcrow />
                              <span>Párrafo</span>
                            </button>
                            <button type="button" className="grid-item" onClick={() => handleInsertBlock("image")}>
                              <ImageIcon />
                              <span>Imagen</span>
                            </button>
                            <button type="button" className="grid-item" onClick={() => handleInsertBlock("h2")}>
                              <Heading2 />
                              <span>Encabezado 2</span>
                            </button>
                            <button type="button" className="grid-item" onClick={() => handleInsertBlock("h3")}>
                              <Heading3 />
                              <span>Encabezado 3</span>
                            </button>
                            <button type="button" className="grid-item" onClick={() => handleInsertBlock("quote")}>
                              <Quote />
                              <span>Cita</span>
                            </button>
                            <button type="button" className="grid-item" onClick={() => handleInsertBlock("video")}>
                              <FileCode />
                              <span>Video</span>
                            </button>
                          </div>

                          <button
                            type="button"
                            className="popover-view-all-btn"
                            onClick={() => {
                              setShowInlineInserter(false);
                              setShowFullInserterDrawer(true);
                            }}
                          >
                            Ver todos
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })()}

            {/* =================================================================
                SUITE DE OPTIMIZACIÓN SEO PARA GOOGLE (ESTILO RANK MATH PRO)
                FORMATO AMPLIO, ORGANIZADO EN PESTAÑAS Y PROFESIONAL
                ================================================================= */}
            <section className="techlab-pro-seo-suite">
              {/* Header Principal de la Suite SEO */}
              <div className="seo-suite-top-bar">
                <div className="suite-title-area">
                  <div className="suite-icon-badge">
                    <Globe />
                  </div>
                  <div>
                    <h3>Optimización SEO para Google</h3>
                    <p>Gestiona los metadatos de búsqueda, vista previa en tiempo real y checklist de auditoría</p>
                  </div>
                </div>

                {/* Tarjeta de Puntuación SEO */}
                <div className="suite-score-badge-card">
                  <div className="score-text-group">
                    <span className="score-lbl">Puntuación SEO</span>
                    <strong className={currentSeoScore >= 80 ? "good" : currentSeoScore >= 50 ? "avg" : "bad"}>
                      {currentSeoScore >= 80 ? "Excelente" : currentSeoScore >= 50 ? "Aceptable" : "Por Mejorar"}
                    </strong>
                  </div>
                  <div className={`score-radial-tag ${currentSeoScore >= 80 ? "good" : currentSeoScore >= 50 ? "avg" : "bad"}`}>
                    <Gauge />
                    <span>{currentSeoScore}%</span>
                  </div>
                </div>
              </div>

              {/* Barra de Pestañas de Navegación SEO */}
              <div className="seo-suite-tabs-nav">
                <button
                  type="button"
                  className={`seo-nav-tab ${seoActiveTab === "general" ? "active" : ""}`}
                  onClick={() => setSeoActiveTab("general")}
                >
                  <Search />
                  <span>Google Snippet & Metadatos</span>
                </button>

                <button
                  type="button"
                  className={`seo-nav-tab ${seoActiveTab === "analysis" ? "active" : ""}`}
                  onClick={() => setSeoActiveTab("analysis")}
                >
                  <ShieldCheck />
                  <span>Auditoría & Checklist</span>
                  <span className="tab-pill-count">
                    {seoChecks.filter((c) => c.pass).length}/{seoChecks.length}
                  </span>
                </button>

                <button
                  type="button"
                  className={`seo-nav-tab ${seoActiveTab === "social" ? "active" : ""}`}
                  onClick={() => setSeoActiveTab("social")}
                >
                  <Share2 />
                  <span>Previsualización Social (OpenGraph)</span>
                </button>
              </div>

              {/* CONTENIDO DE PESTAÑAS */}
              <div className="seo-suite-content-body">
                {/* ---------------- PESTAÑA 1: GENERAL & SNIPPET ---------------- */}
                {seoActiveTab === "general" && (
                  <div className="tab-pane-general">
                    {/* Tarjeta Visual de Previsualización Google */}
                    <div className="google-serp-master-card">
                      <div className="serp-toolbar-header">
                        <div className="serp-badge-title">
                          <span className="g-logo">G</span>
                          <strong>Vista previa en Google Search</strong>
                        </div>

                        <div className="serp-view-mode-buttons">
                          <button
                            type="button"
                            className={serpView === "desktop" ? "active" : ""}
                            onClick={() => setSerpView("desktop")}
                          >
                            <Monitor />
                            <span>Escritorio</span>
                          </button>
                          <button
                            type="button"
                            className={serpView === "mobile" ? "active" : ""}
                            onClick={() => setSerpView("mobile")}
                          >
                            <Smartphone />
                            <span>Móvil</span>
                          </button>
                        </div>
                      </div>

                      {/* Snippet Real de Google */}
                      <div className={`google-snippet-frame ${serpView === "mobile" ? "mobile-mode" : ""}`}>
                        <div className="snippet-top-row">
                          <div className="google-favicon-circle">🌐</div>
                          <div className="snippet-hierarchy">
                            <span className="brand-name">TechLab</span>
                            <span className="sep">›</span>
                            <span className="url-path">{displayDomain} › paginas › {slug || "mi-pagina"}</span>
                          </div>
                        </div>
                        <h4 className="snippet-heading">
                          {seoTitle || title || "Título de tu página | TechLab"}
                        </h4>
                        <p className="snippet-text">
                          {seoDescription || "Escribe una meta descripción persuasiva y optimizada para aumentar los clics orgánicos en los resultados de Google..."}
                        </p>
                      </div>
                    </div>

                    {/* Formulario Amplio de Metadatos */}
                    <div className="seo-form-spacious-grid">
                      {/* Campo 1: Palabra Clave Objetivo */}
                      <div className="form-field-row">
                        <div className="field-meta-info">
                          <label>
                            <KeyRound />
                            <span>Palabra clave objetivo</span>
                          </label>
                          <p>Término principal con el que los clientes encontrarán esta página en Google.</p>
                        </div>
                        <div className="field-input-box">
                          <input
                            type="text"
                            value={focusKeyword}
                            onChange={(e) => setFocusKeyword(e.target.value)}
                            placeholder="ej. desarrollo de software en lima"
                            className="wide-seo-input"
                          />
                        </div>
                      </div>

                      {/* Campo 2: Título SEO */}
                      <div className="form-field-row">
                        <div className="field-meta-info">
                          <label>
                            <FileText />
                            <span>Título SEO (Meta Title)</span>
                          </label>
                          <p>El título visible en los resultados de búsqueda. Recomendado entre 45 y 60 caracteres.</p>
                        </div>
                        <div className="field-input-box">
                          <div className="input-with-counter-wrap">
                            <input
                              type="text"
                              value={seoTitle}
                              onChange={(e) => setSeoTitle(e.target.value)}
                              placeholder="Título optimizado para Google..."
                              className="wide-seo-input"
                            />
                            <span className={`counter-pill ${seoTitle.length > 60 ? "warn" : seoTitle.length >= 35 ? "good" : "neutral"}`}>
                              {seoTitle.length} / 60 car.
                            </span>
                          </div>
                          {/* Barra de progreso de caracteres */}
                          <div className="char-progress-bar">
                            <div
                              className={`progress-fill ${seoTitle.length > 60 ? "warn" : seoTitle.length >= 35 ? "good" : "neutral"}`}
                              style={{ width: `${Math.min(100, (seoTitle.length / 60) * 100)}%` }}
                            />
                          </div>
                        </div>
                      </div>

                      {/* Campo 3: Meta Descripción */}
                      <div className="form-field-row">
                        <div className="field-meta-info">
                          <label>
                            <SlidersHorizontal />
                            <span>Meta Descripción (Snippet)</span>
                          </label>
                          <p>Resumen atractivo del contenido para convencer a los usuarios de hacer clic.</p>
                        </div>
                        <div className="field-input-box">
                          <div className="input-with-counter-wrap">
                            <textarea
                              rows={3}
                              value={seoDescription}
                              onChange={(e) => setSeoDescription(e.target.value)}
                              placeholder="Resumen atractivo que describa los puntos clave de esta página..."
                              className="wide-seo-textarea"
                            />
                            <span className={`counter-pill ${seoDescription.length > 160 ? "warn" : seoDescription.length >= 100 ? "good" : "neutral"}`}>
                              {seoDescription.length} / 160 car.
                            </span>
                          </div>
                          {/* Barra de progreso de caracteres */}
                          <div className="char-progress-bar">
                            <div
                              className={`progress-fill ${seoDescription.length > 160 ? "warn" : seoDescription.length >= 100 ? "good" : "neutral"}`}
                              style={{ width: `${Math.min(100, (seoDescription.length / 160) * 100)}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* ---------------- PESTAÑA 2: AUDITORÍA & CHECKLIST ---------------- */}
                {seoActiveTab === "analysis" && (
                  <div className="tab-pane-analysis">
                    <div className="analysis-summary-banner">
                      <div className="banner-icon">
                        <CheckCheck />
                      </div>
                      <div className="banner-texts">
                        <h4>Auditoría Técnica de Posicionamiento</h4>
                        <p>
                          Tu página cumple <strong>{seoChecks.filter((c) => c.pass).length} de {seoChecks.length}</strong> criterios recomendados por las directrices para webmasters de Google.
                        </p>
                      </div>
                    </div>

                    <div className="audit-cards-grid">
                      {seoChecks.map((chk) => (
                        <div key={chk.label} className={`audit-card-item ${chk.pass ? "pass" : "fail"}`}>
                          <div className="audit-status-icon">
                            {chk.pass ? <CheckCircle2 /> : <XCircle />}
                          </div>
                          <div className="audit-info">
                            <span className="audit-category">{chk.category}</span>
                            <strong>{chk.label}</strong>
                            <p>{chk.hint}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* ---------------- PESTAÑA 3: PREVIEW REDES SOCIALES (OPEN GRAPH) ---------------- */}
                {seoActiveTab === "social" && (
                  <div className="tab-pane-social">
                    <div className="social-preview-container">
                      <div className="social-header-row">
                        <span>VISTA PREVIA EN REDES SOCIALES (FACEBOOK / TWITTER / WHATSAPP)</span>
                      </div>

                      <div className="social-card-simulation">
                        {featuredImage ? (
                          <div className="social-img-box">
                            <img src={featuredImage} alt="Preview social" />
                          </div>
                        ) : (
                          <div className="social-img-placeholder">
                            <UploadCloud />
                            <span>Asigna una Imagen Destacada para que aparezca aquí</span>
                          </div>
                        )}
                        <div className="social-card-body">
                          <span className="social-domain">{displayDomain}</span>
                          <h5>{seoTitle || title || "Título de la página"}</h5>
                          <p>{seoDescription || "La meta descripción de la página aparecerá aquí cuando la compartas en redes sociales."}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </section>
          </div>
        </main>

        {/* =================================================================
            BARRA DE HERRAMIENTAS FLOTANTE DE BLOQUE / SELECCIÓN (ESTILO GUTENBERG)
            APARECE TANTO AL MARCAR/SEÑALAR TEXTO COMO AL SITUARSE EN EL BLOQUE
            ================================================================= */}
        {blockToolbar.visible && (
          <div
            className="gutenberg-floating-block-toolbar"
            style={{
              top: `${blockToolbar.top}px`,
              left: `${blockToolbar.left}px`,
            }}
            onMouseDown={(e) => {
              // Evitar que el editor pierda el foco o la selección
              e.stopPropagation();
            }}
          >
            {/* Grupo 1: Selector de tipo de bloque + Movers */}
            <div className="toolbar-btn-group">
              <button
                type="button"
                className="tb-btn tb-block-type-btn"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => {
                  setShowBlockTypeMenu(!showBlockTypeMenu);
                  setShowAlignMenu(false);
                  setShowColorPicker(false);
                  setShowLinkInput(false);
                  setShowMoreMenu(false);
                }}
                title="Cambiar tipo de bloque"
              >
                {blockToolbar.blockType === "h2" && <Heading2 />}
                {blockToolbar.blockType === "h3" && <Heading3 />}
                {blockToolbar.blockType === "h4" && <Heading4 />}
                {blockToolbar.blockType === "blockquote" && <Quote />}
                {blockToolbar.blockType === "ul" && <List />}
                {blockToolbar.blockType === "ol" && <ListOrdered />}
                {blockToolbar.blockType === "pre" && <Code />}
                {["p", "div", "figure"].includes(blockToolbar.blockType) && <Pilcrow />}
                <ChevronDown className="tb-chevron-icon" />
              </button>

              <div className="tb-movers-duo">
                <button
                  type="button"
                  className="tb-icon-mini-btn"
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={() => moveActiveBlock("up")}
                  title="Mover bloque arriba"
                >
                  <ChevronUp />
                </button>
                <button
                  type="button"
                  className="tb-icon-mini-btn"
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={() => moveActiveBlock("down")}
                  title="Mover bloque abajo"
                >
                  <ChevronDown />
                </button>
              </div>
            </div>

            <span className="tb-divider" />

            {/* Grupo 2: Alineación */}
            <div className="toolbar-btn-group">
              <button
                type="button"
                className="tb-btn"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => {
                  setShowAlignMenu(!showAlignMenu);
                  setShowBlockTypeMenu(false);
                  setShowColorPicker(false);
                  setShowLinkInput(false);
                  setShowMoreMenu(false);
                }}
                title="Alineación"
              >
                <AlignLeft />
                <ChevronDown className="tb-chevron-icon" />
              </button>
            </div>

            <span className="tb-divider" />

            {/* Grupo 3: Formato de Texto (Negrita, Cursiva, Subrayado, Tachado, Enlace) */}
            <div className="toolbar-btn-group">
              <button
                type="button"
                className="tb-btn tb-text-btn"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => formatDoc("bold")}
                title="Negrita (Ctrl+B)"
              >
                <Bold />
              </button>
              <button
                type="button"
                className="tb-btn tb-text-btn"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => formatDoc("italic")}
                title="Cursiva (Ctrl+I)"
              >
                <Italic />
              </button>
              <button
                type="button"
                className="tb-btn tb-text-btn"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => formatDoc("underline")}
                title="Subrayado (Ctrl+U)"
              >
                <Underline />
              </button>
              <button
                type="button"
                className="tb-btn tb-text-btn"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => formatDoc("strikeThrough")}
                title="Tachado"
              >
                <Strikethrough />
              </button>
              <button
                type="button"
                className="tb-btn"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => {
                  setShowLinkInput(!showLinkInput);
                  setShowBlockTypeMenu(false);
                  setShowAlignMenu(false);
                  setShowColorPicker(false);
                  setShowMoreMenu(false);
                }}
                title="Insertar enlace (Ctrl+K)"
              >
                <Link2 />
              </button>
            </div>

            <span className="tb-divider" />

            {/* Grupo 4: Paleta de Colores y Resaltado (Herramienta solicitada por el usuario) */}
            <div className="toolbar-btn-group">
              <button
                type="button"
                className={`tb-btn tb-color-btn ${showColorPicker ? "active" : ""}`}
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => {
                  setShowColorPicker(!showColorPicker);
                  setShowBlockTypeMenu(false);
                  setShowAlignMenu(false);
                  setShowLinkInput(false);
                  setShowMoreMenu(false);
                }}
                title="Color de texto y fondo / resaltado"
              >
                <Palette />
                <span className="tb-color-indicator" style={{ background: activeColorPreview || "#38bdf8" }} />
                <ChevronDown className="tb-chevron-icon" />
              </button>
            </div>

            <span className="tb-divider" />

            {/* Grupo 5: Más Opciones ⋮ */}
            <div className="toolbar-btn-group">
              <button
                type="button"
                className="tb-btn"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => {
                  setShowMoreMenu(!showMoreMenu);
                  setShowBlockTypeMenu(false);
                  setShowAlignMenu(false);
                  setShowColorPicker(false);
                  setShowLinkInput(false);
                }}
                title="Más opciones del bloque"
              >
                <MoreVertical />
              </button>
            </div>

            {/* =========================================================
                POPOVER 1: MENÚ DE TIPOS DE BLOQUE
                ========================================================= */}
            {showBlockTypeMenu && (
              <div className="gutenberg-tb-popover block-types-popover" onMouseDown={(e) => e.preventDefault()}>
                <span className="popover-header-title">Transformar bloque en:</span>
                <button type="button" className="popover-item" onClick={() => transformBlockType("p")}>
                  <Pilcrow /> <span>Párrafo</span>
                </button>
                <button type="button" className="popover-item" onClick={() => transformBlockType("h2")}>
                  <Heading2 /> <span>Encabezado 2 (H2)</span>
                </button>
                <button type="button" className="popover-item" onClick={() => transformBlockType("h3")}>
                  <Heading3 /> <span>Encabezado 3 (H3)</span>
                </button>
                <button type="button" className="popover-item" onClick={() => transformBlockType("h4")}>
                  <Heading4 /> <span>Encabezado 4 (H4)</span>
                </button>
                <button type="button" className="popover-item" onClick={() => transformBlockType("blockquote")}>
                  <Quote /> <span>Cita</span>
                </button>
                <button type="button" className="popover-item" onClick={() => transformBlockType("ul")}>
                  <List /> <span>Lista con viñetas</span>
                </button>
                <button type="button" className="popover-item" onClick={() => transformBlockType("ol")}>
                  <ListOrdered /> <span>Lista numerada</span>
                </button>
                <button type="button" className="popover-item" onClick={() => transformBlockType("pre")}>
                  <Code /> <span>Código</span>
                </button>
              </div>
            )}

            {/* =========================================================
                POPOVER 2: MENÚ DE ALINEACIÓN
                ========================================================= */}
            {showAlignMenu && (
              <div className="gutenberg-tb-popover align-popover" onMouseDown={(e) => e.preventDefault()}>
                <button type="button" className="popover-item" onClick={() => applyAlignment("justifyLeft")}>
                  <AlignLeft /> <span>Alinear a la izquierda</span>
                </button>
                <button type="button" className="popover-item" onClick={() => applyAlignment("justifyCenter")}>
                  <AlignCenter /> <span>Centrar</span>
                </button>
                <button type="button" className="popover-item" onClick={() => applyAlignment("justifyRight")}>
                  <AlignRight /> <span>Alinear a la derecha</span>
                </button>
                <button type="button" className="popover-item" onClick={() => applyAlignment("justifyFull")}>
                  <AlignJustify /> <span>Justificar</span>
                </button>
              </div>
            )}

            {/* =========================================================
                POPOVER 3: INPUT DE ENLACE RÁPIDO
                ========================================================= */}
            {showLinkInput && (
              <div className="gutenberg-tb-popover link-input-popover" onMouseDown={(e) => e.stopPropagation()}>
                <input
                  type="url"
                  placeholder="https://tu-enlace.com..."
                  value={linkInputUrl}
                  onChange={(e) => setLinkInputUrl(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      handleApplyLink();
                    }
                  }}
                  autoFocus
                  className="tb-url-input"
                />
                <button type="button" className="tb-url-submit-btn" onClick={handleApplyLink}>
                  Aplicar
                </button>
              </div>
            )}

            {/* =========================================================
                POPOVER 4: PALETA COMPLETA DE COLORES Y RESALTADO
                ========================================================= */}
            {showColorPicker && (
              <div className="gutenberg-tb-popover color-picker-popover" onMouseDown={(e) => e.preventDefault()}>
                {/* Selector de Pestaña: Texto vs Fondo */}
                <div className="color-tabs-switcher">
                  <button
                    type="button"
                    className={`color-tab-btn ${colorTab === "text" ? "active" : ""}`}
                    onClick={() => setColorTab("text")}
                  >
                    Color de Texto
                  </button>
                  <button
                    type="button"
                    className={`color-tab-btn ${colorTab === "background" ? "active" : ""}`}
                    onClick={() => setColorTab("background")}
                  >
                    Resaltado / Fondo
                  </button>
                </div>

                {colorTab === "text" ? (
                  <div className="color-palette-section">
                    <span className="color-palette-title">
                      {blockToolbar.hasSelection ? "Color para el texto marcado:" : "Color de texto del bloque:"}
                    </span>
                    <div className="colors-grid-dots">
                      {[
                        { name: "Blanco", hex: "#ffffff" },
                        { name: "Cyan", hex: "#38bdf8" },
                        { name: "Verde Neón", hex: "#16c96f" },
                        { name: "Amarillo", hex: "#fbbf24" },
                        { name: "Naranja", hex: "#f97316" },
                        { name: "Rojo", hex: "#ef4444" },
                        { name: "Púrpura", hex: "#a855f7" },
                        { name: "Gris Suave", hex: "#94a3b8" },
                      ].map((c) => (
                        <button
                          key={c.hex}
                          type="button"
                          className="color-circle-dot"
                          style={{ backgroundColor: c.hex }}
                          onClick={() => applyColor("text", c.hex)}
                          title={c.name}
                        />
                      ))}
                    </div>

                    <div className="custom-color-picker-row">
                      <label>Personalizado:</label>
                      <input
                        type="color"
                        className="native-color-picker"
                        onChange={(e) => applyColor("text", e.target.value)}
                      />
                      <button
                        type="button"
                        className="reset-color-btn"
                        onClick={() => applyColor("text", "inherit")}
                        title="Restablecer color predeterminado"
                      >
                        <RotateCcw />
                        <span>Restablecer</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="color-palette-section">
                    <span className="color-palette-title">
                      {blockToolbar.hasSelection ? "Resaltado para el texto marcado:" : "Color de fondo del bloque:"}
                    </span>
                    <div className="colors-grid-dots">
                      {[
                        { name: "Transparente", hex: "transparent" },
                        { name: "Cyan Suave", hex: "rgba(56, 189, 248, 0.25)" },
                        { name: "Verde Suave", hex: "rgba(22, 201, 111, 0.25)" },
                        { name: "Amarillo Suave", hex: "rgba(251, 191, 36, 0.25)" },
                        { name: "Rojo Suave", hex: "rgba(239, 68, 68, 0.25)" },
                        { name: "Púrpura Suave", hex: "rgba(168, 85, 247, 0.25)" },
                        { name: "Naranja Suave", hex: "rgba(249, 115, 22, 0.25)" },
                        { name: "Fondo Oscuro", hex: "#07131e" },
                      ].map((c) => (
                        <button
                          key={c.hex}
                          type="button"
                          className={`color-circle-dot ${c.hex === "transparent" ? "transparent-dot" : ""}`}
                          style={{ backgroundColor: c.hex }}
                          onClick={() => applyColor("background", c.hex)}
                          title={c.name}
                        />
                      ))}
                    </div>

                    <div className="custom-color-picker-row">
                      <label>Personalizado:</label>
                      <input
                        type="color"
                        className="native-color-picker"
                        onChange={(e) => applyColor("background", e.target.value)}
                      />
                      <button
                        type="button"
                        className="reset-color-btn"
                        onClick={() => applyColor("background", "transparent")}
                        title="Quitar fondo / resaltado"
                      >
                        <RotateCcw />
                        <span>Quitar</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* =========================================================
                POPOVER 5: MÁS OPCIONES (DUPLICAR, INSERTAR, ELIMINAR)
                ========================================================= */}
            {showMoreMenu && (
              <div className="gutenberg-tb-popover more-menu-popover" onMouseDown={(e) => e.preventDefault()}>
                <button type="button" className="popover-item" onClick={duplicateBlock}>
                  <Copy /> <span>Duplicar bloque</span>
                </button>
                <button type="button" className="popover-item" onClick={() => insertBlockRelative("before")}>
                  <Plus /> <span>Añadir bloque antes</span>
                </button>
                <button type="button" className="popover-item" onClick={() => insertBlockRelative("after")}>
                  <Plus /> <span>Añadir bloque después</span>
                </button>
                <button type="button" className="popover-item" onClick={() => formatDoc("removeFormat")}>
                  <RotateCcw /> <span>Limpiar formato</span>
                </button>
                <span className="popover-divider" />
                <button type="button" className="popover-item danger" onClick={deleteActiveBlock}>
                  <Trash2 /> <span>Eliminar bloque</span>
                </button>
              </div>
            )}
          </div>
        )}

        {/* =================================================================
            BARRA LATERAL DERECHA (AJUSTES DE PÁGINA Y BLOQUE / PANEL PUBLICAR WORDPRESS)
            ================================================================= */}
        {isSidebarOpen && (
          <aside className="gutenberg-right-sidebar">
            {publishSidebarState ? (
              <div className="wp-publish-sidebar-panel">
                {/* 1. PRE-PUBLICACIÓN */}
                {publishSidebarState === "pre-publish" && (
                  <>
                    <div className="wp-pub-top-bar">
                      <button
                        type="button"
                        className="wp-btn-cancel-pub"
                        onClick={() => setPublishSidebarState(null)}
                      >
                        Cancelar
                      </button>
                      <button
                        type="button"
                        className="wp-btn-do-publish"
                        onClick={async () => {
                          setPublishSidebarState("publishing");
                          const ok = await handleSavePage("Publicado");
                          if (ok) {
                            setPublishSidebarState("published");
                          } else {
                            setPublishSidebarState("pre-publish");
                          }
                        }}
                      >
                        Publicar
                      </button>
                    </div>

                    <div className="wp-pub-body-content">
                      <h3 className="wp-pub-main-title">¿Estás listo para publicar?</h3>
                      <p className="wp-pub-sub-desc">Vuelve a comprobar tus ajustes antes de publicar.</p>

                      <div className="wp-pub-site-badge">
                        <div className="wp-pub-site-icon">
                          <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 2C6.486 2 2 6.486 2 12s4.486 10 10 10 10-4.486 10-10S17.514 2 12 2zm0 1.5c4.687 0 8.5 3.813 8.5 8.5 0 2.015-.705 3.869-1.884 5.333L15.344 7.5h-1.688l2.973 8.324a8.47 8.47 0 01-4.629 1.676c-.958 0-1.879-.16-2.738-.452L12 8.785 8.738 17.048A8.468 8.468 0 013.5 12c0-4.687 3.813-8.5 8.5-8.5z"/>
                          </svg>
                        </div>
                        <div className="wp-pub-site-info">
                          <strong>{title || "tester"}</strong>
                          <span>{typeof window !== "undefined" ? window.location.host : "aniwev.com"}</span>
                        </div>
                      </div>

                      <div className="wp-pub-checks-list">
                        <div className="wp-pub-check-item">
                          <div className="wp-pub-check-row">
                            <span className="wp-check-label">Visibilidad:</span>
                            <span className="wp-check-val">Pública</span>
                          </div>
                        </div>
                        <div className="wp-pub-check-item">
                          <div className="wp-pub-check-row">
                            <span className="wp-check-label">Publicado:</span>
                            <span className="wp-check-val">Inmediatamente</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="wp-pub-bottom-footer">
                      <label className="wp-pub-checkbox-label">
                        <input
                          type="checkbox"
                          checked={alwaysShowPrePublish}
                          onChange={(e) => setAlwaysShowPrePublish(e.target.checked)}
                        />
                        <span>Mostrar siempre las comprobaciones previas a la publicación.</span>
                      </label>
                    </div>
                  </>
                )}

                {/* 2. PUBLICANDO (SPINNER) */}
                {publishSidebarState === "publishing" && (
                  <>
                    <div className="wp-pub-top-bar">
                      <button type="button" className="wp-btn-cancel-pub" disabled>
                        Cancelar
                      </button>
                      <button type="button" className="wp-btn-do-publish is-busy" disabled>
                        Publicando...
                      </button>
                    </div>

                    <div className="wp-pub-body-content is-loading-state">
                      <div className="wp-pub-spinner-ring" />
                    </div>

                    <div className="wp-pub-bottom-footer">
                      <label className="wp-pub-checkbox-label">
                        <input
                          type="checkbox"
                          checked={alwaysShowPrePublish}
                          onChange={(e) => setAlwaysShowPrePublish(e.target.checked)}
                        />
                        <span>Mostrar siempre las comprobaciones previas a la publicación.</span>
                      </label>
                    </div>
                  </>
                )}

                {/* 3. PUBLICADO CON ÉXITO */}
                {publishSidebarState === "published" && (
                  <>
                    <div className="wp-pub-top-bar align-right">
                      <button
                        type="button"
                        className="wp-btn-close-x"
                        onClick={() => {
                          setPublishSidebarState(null);
                          setSidebarTab("page");
                        }}
                        title="Cerrar panel"
                      >
                        <X style={{ width: 18, height: 18 }} />
                      </button>
                    </div>

                    <div className="wp-pub-body-content">
                      <div className="wp-published-notice-card">
                        <a
                          href={publishedUrl || `/paginas/${slug || ""}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="wp-published-link-pill"
                        >
                          <span>{title || "Página"}</span>
                          <ExternalLink style={{ width: 13, height: 13 }} />
                        </a>
                        <span className="wp-notice-caption">está ahora visible.</span>
                      </div>

                      <h4 className="wp-whats-next-title">¿Qué es lo siguiente?</h4>

                      <div className="wp-address-box-wrap">
                        <label className="wp-address-heading-label">DIRECCIÓN DEL PÁGINA</label>
                        <div className="wp-address-copy-row">
                          <input
                            type="text"
                            readOnly
                            value={publishedUrl || (typeof window !== "undefined" ? `${window.location.origin}/paginas/${slug || ""}` : `/paginas/${slug || ""}`)}
                            className="wp-address-readonly-input"
                          />
                          <button
                            type="button"
                            className="wp-btn-copy-link"
                            onClick={handleCopyUrl}
                          >
                            {isCopied ? "Copiado" : "Copiar"}
                          </button>
                        </div>
                      </div>

                      <div className="wp-published-buttons-stack">
                        <a
                          href={publishedUrl || `/paginas/${slug || ""}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="wp-btn-view-live-page"
                        >
                          <span>Ver la página</span>
                          <ExternalLink style={{ width: 16, height: 16 }} />
                        </a>

                        <Link
                          href="/dashboard/paginas/nuevo"
                          className="wp-btn-add-new-page"
                          onClick={() => {
                            setTitle("");
                            setSlug("");
                            setContentHtml("");
                            setPublishSidebarState(null);
                          }}
                        >
                          Añadir página
                        </Link>
                      </div>
                    </div>

                    <div className="wp-pub-bottom-footer">
                      <label className="wp-pub-checkbox-label">
                        <input
                          type="checkbox"
                          checked={alwaysShowPrePublish}
                          onChange={(e) => setAlwaysShowPrePublish(e.target.checked)}
                        />
                        <span>Mostrar siempre las comprobaciones previas a la publicación.</span>
                      </label>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <>
                {/* Pestañas: Página | Bloque */}
                <div className="sidebar-tab-switcher">
                  <button
                    type="button"
                    className={`tab-btn ${sidebarTab === "page" ? "active" : ""}`}
                    onClick={() => setSidebarTab("page")}
                  >
                    Página
                  </button>
                  <button
                    type="button"
                    className={`tab-btn ${sidebarTab === "block" ? "active" : ""}`}
                    onClick={() => setSidebarTab("block")}
                  >
                    Bloque
                  </button>
                </div>

                {/* CONTENIDO PESTAÑA 1: PÁGINA */}
                {sidebarTab === "page" && (
                  <div className="sidebar-scrollable-content">
                    {/* 1. Imagen Destacada */}
                    <div className="featured-image-section">
                      <span className="section-label-header">IMAGEN DESTACADA</span>
                      {featuredImage ? (
                        <div className="featured-image-preview-container">
                          <img src={featuredImage} alt="Imagen destacada" className="featured-img" />
                          <div className="image-overlay-actions">
                            <button
                              type="button"
                              className="btn-replace-img"
                              onClick={() => fileInputRef.current?.click()}
                            >
                              Reemplazar
                            </button>
                            <button
                              type="button"
                              className="btn-remove-img"
                              onClick={() => setFeaturedImage(null)}
                            >
                              <Trash2 />
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div
                          className="featured-image-dropzone"
                          onClick={() => fileInputRef.current?.click()}
                          onDragOver={(e) => e.preventDefault()}
                          onDrop={(e) => {
                            e.preventDefault();
                            if (e.dataTransfer.files?.[0]) handleFeaturedImageUpload(e.dataTransfer.files[0]);
                          }}
                        >
                          <div className="dropzone-inner">
                            <UploadCloud />
                            <strong>Establecer la imagen destacada</strong>
                            <small>Arrastra o haz clic para subir</small>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* 2. Metadatos de la Página */}
                    <div className="page-meta-list-group">
                      <div className="meta-list-row">
                        <span className="meta-row-name">Estado</span>
                        <div className="meta-select-wrap">
                          <select
                            value={status}
                            onChange={(e) => setStatus(e.target.value as any)}
                            className="techlab-meta-select"
                          >
                            <option value="Borrador">🔵 Borrador</option>
                            <option value="Publicado">🟢 Publicado</option>
                            <option value="Privado">🟣 Privado</option>
                          </select>
                        </div>
                      </div>

                      <div className="meta-list-row">
                        <span className="meta-row-name">Publicar</span>
                        <span className="meta-row-link">{publishDate}</span>
                      </div>

                      <div className="meta-list-row">
                        <span className="meta-row-name">Slug</span>
                        <button
                          type="button"
                          className="meta-row-link"
                          onClick={() => setShowSlugModal(true)}
                        >
                          {slug || "slug-de-la-pagina"}
                        </button>
                      </div>

                      <div className="meta-list-row">
                        <span className="meta-row-name">Autor</span>
                        <span className="meta-row-link">{authorName}</span>
                      </div>

                      <div className="meta-list-row">
                        <span className="meta-row-name">Plantilla</span>
                        <select
                          value={template}
                          onChange={(e) => setTemplate(e.target.value)}
                          className="techlab-meta-select-inline"
                        >
                          <option value="default">Página Estándar</option>
                          <option value="landing">Landing Page</option>
                          <option value="fullwidth">Ancho Completo</option>
                          <option value="blank">En Blanco</option>
                        </select>
                      </div>

                      <div className="meta-list-row">
                        <span className="meta-row-name">Comentarios</span>
                        <button
                          type="button"
                          className="meta-row-link"
                          onClick={() => setCommentsOpen(!commentsOpen)}
                        >
                          {commentsOpen ? "Abiertos" : "Cerrados"}
                        </button>
                      </div>

                      {/* Selector de Página Superior (Padre) */}
                      <div className="meta-list-row">
                        <span className="meta-row-name">Superior</span>
                        <select
                          value={parentId}
                          onChange={(e) => setParentId(e.target.value)}
                          className="techlab-meta-select-inline"
                        >
                          <option value="">(Ninguna - Principal)</option>
                          {parentPages.map((parent) => (
                            <option key={parent.id} value={parent.id}>
                              {parent.title}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>
                )}

                {/* CONTENIDO PESTAÑA 2: BLOQUE */}
                {sidebarTab === "block" && (
                  <div className="sidebar-scrollable-content">
                    <div className="sidebar-block-info-header">
                      <Pilcrow />
                      <div>
                        <strong>Párrafo</strong>
                        <small>Bloque de texto estándar</small>
                      </div>
                    </div>
                    <div className="block-control-group">
                      <label className="field-hint-label">Tamaño de tipografía:</label>
                      <div className="font-size-chips">
                        <button type="button" onClick={() => execCmd("fontSize", "2")}>S</button>
                        <button type="button" className="active" onClick={() => execCmd("fontSize", "3")}>M</button>
                        <button type="button" onClick={() => execCmd("fontSize", "5")}>L</button>
                        <button type="button" onClick={() => execCmd("fontSize", "6")}>XL</button>
                      </div>
                    </div>
                    <div className="block-control-group">
                      <label className="field-hint-label">Alineación de texto:</label>
                      <div className="align-buttons-row">
                        <button type="button" onClick={() => execCmd("justifyLeft")}><AlignLeft /></button>
                        <button type="button" onClick={() => execCmd("justifyCenter")}><AlignCenter /></button>
                        <button type="button" onClick={() => execCmd("justifyRight")}><AlignRight /></button>
                        <button type="button" onClick={() => execCmd("justifyFull")}><AlignJustify /></button>
                      </div>
                    </div>
                  </div>
                )}
              </>
            )}
          </aside>
        )}
      </div>



      {/* Modal Slug */}
      {showSlugModal && (
        <div className="techlab-modal-backdrop">
          <div className="techlab-modal-card">
            <div className="modal-top">
              <h3>Editar Slug de la Página</h3>
              <button onClick={() => setShowSlugModal(false)}><X /></button>
            </div>
            <div className="modal-body-content">
              <label>Slug de la URL:</label>
              <input
                type="text"
                value={slug}
                onChange={(e) => {
                  setSlug(e.target.value);
                  setIsSlugEdited(true);
                }}
                className="techlab-input-sm"
              />
              <small style={{ color: "#94a3b8", display: "block", marginTop: 6 }}>
                URL final: {origin || "http://localhost:3000"}/paginas/{slug || "mi-pagina"}
              </small>
            </div>
            <div className="modal-actions-bar">
              <button className="btn-modal-green" onClick={() => setShowSlugModal(false)}>
                Guardar Slug
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Video Embed */}
      {showVideoModal && (
        <div className="techlab-modal-backdrop">
          <div className="techlab-modal-card">
            <div className="modal-top">
              <h3>Insertar video embed</h3>
              <button onClick={() => setShowVideoModal(false)}><X /></button>
            </div>
            <div className="modal-body-content">
              <label>URL de YouTube / Vimeo:</label>
              <input
                type="url"
                placeholder="https://www.youtube.com/watch?v=..."
                value={videoUrl}
                onChange={(e) => setVideoUrl(e.target.value)}
                className="techlab-input-sm"
              />
            </div>
            <div className="modal-actions-bar">
              <button className="btn-modal-ghost" onClick={() => setShowVideoModal(false)}>
                Cancelar
              </button>
              <button className="btn-modal-green" onClick={handleInsertVideo}>
                Insertar Video
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ESTILOS TECHLAB CYBER DARK PRO */}
      <style jsx>{`
        .techlab-gutenberg-root {
          min-height: 100vh;
          display: flex;
          flex-direction: column;
          background: #03070b;
          color: #f1f5f9;
          margin: -24px -28px;
          position: relative;
        }

        /* Toast */
        .techlab-toast {
          position: fixed;
          top: 70px;
          right: 24px;
          z-index: 1000;
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 12px 18px;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 600;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.6);
          animation: slideIn 0.25s ease;
        }

        .techlab-toast.success {
          background: #062316;
          border: 1px solid #16c96f;
          color: #a7f3d0;
        }

        .techlab-toast.error {
          background: #270d0d;
          border: 1px solid #ef4444;
          color: #fca5a5;
        }

        @keyframes slideIn {
          from { transform: translateY(-20px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }

        /* Top Bar */
        .gutenberg-top-bar {
          height: 60px;
          background: #040c14;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 0 20px;
          position: sticky;
          top: 0;
          z-index: 100;
        }

        .top-bar-left, .top-bar-right {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .back-btn-square {
          width: 36px;
          height: 36px;
          border-radius: 6px;
          background: rgba(255, 255, 255, 0.04);
          border: 1px solid rgba(255, 255, 255, 0.08);
          color: #94a3b8;
          display: grid;
          place-items: center;
          text-decoration: none;
          transition: all 0.15s;
        }

        .back-btn-square:hover {
          color: #38bdf8;
          border-color: rgba(56, 189, 248, 0.4);
          background: rgba(56, 189, 248, 0.08);
        }

        .back-btn-square :global(svg) {
          width: 18px;
          height: 18px;
        }

        .block-inserter-toggle-btn {
          width: 36px;
          height: 36px;
          border-radius: 6px;
          background: #0284c7;
          border: 1px solid rgba(56, 189, 248, 0.4);
          color: #ffffff;
          display: grid;
          place-items: center;
          cursor: pointer;
          transition: all 0.2s;
        }

        .block-inserter-toggle-btn:hover, .block-inserter-toggle-btn.active {
          background: #0ea5e9;
          transform: scale(1.05);
        }

        .block-inserter-toggle-btn :global(svg) {
          width: 18px;
          height: 18px;
        }

        .history-btns-group {
          display: flex;
          align-items: center;
          gap: 2px;
          background: rgba(255, 255, 255, 0.03);
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 6px;
          padding: 2px;
        }

        .history-btns-group button {
          width: 30px;
          height: 30px;
          background: none;
          border: none;
          color: #94a3b8;
          display: grid;
          place-items: center;
          cursor: pointer;
          border-radius: 4px;
        }

        .history-btns-group button:hover {
          color: #ffffff;
          background: rgba(255, 255, 255, 0.06);
        }

        .history-btns-group button :global(svg) {
          width: 14px;
          height: 14px;
        }

        .document-type-badge {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 12px;
          font-weight: 600;
          color: #38bdf8;
          background: rgba(56, 189, 248, 0.08);
          border: 1px solid rgba(56, 189, 248, 0.2);
          padding: 4px 10px;
          border-radius: 6px;
        }

        .document-type-badge :global(svg) {
          width: 14px;
          height: 14px;
        }

        .elementor-topbar-edit-btn {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 12px;
          font-weight: 700;
          color: #e11d48;
          background: rgba(225, 29, 72, 0.12);
          border: 1px solid rgba(225, 29, 72, 0.35);
          padding: 5px 12px;
          border-radius: 6px;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .elementor-topbar-edit-btn:hover {
          background: rgba(225, 29, 72, 0.22);
          border-color: #f43f5e;
          transform: translateY(-1px);
          box-shadow: 0 0 12px rgba(225, 29, 72, 0.35);
          color: #fb7185;
        }

        .elementor-topbar-edit-btn :global(svg) {
          width: 14px;
          height: 14px;
        }

        .top-bar-center {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .doc-live-title {
          font-size: 13px;
          font-weight: 700;
          color: #f1f5f9;
          max-width: 300px;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        .doc-live-status-pill {
          font-size: 10px;
          font-weight: 700;
          padding: 2px 8px;
          border-radius: 10px;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          transition: all 0.2s ease;
        }

        .doc-live-status-pill.publicado {
          background: rgba(22, 201, 111, 0.15);
          color: #16c96f;
          border: 1px solid rgba(22, 201, 111, 0.4);
        }

        .doc-live-status-pill.borrador {
          background: rgba(56, 189, 248, 0.15);
          color: #38bdf8;
          border: 1px solid rgba(56, 189, 248, 0.3);
        }

        .doc-live-status-pill.privado {
          background: rgba(245, 158, 11, 0.15);
          color: #f59e0b;
          border: 1px solid rgba(245, 158, 11, 0.3);
        }

        .draft-save-btn {
          height: 36px;
          padding: 0 14px;
          border-radius: 6px;
          background: rgba(255, 255, 255, 0.04);
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: #cbd5e1;
          font-size: 12px;
          font-weight: 600;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
          transition: all 0.25s ease;
        }

        .draft-save-btn:hover:not(:disabled) {
          background: rgba(255, 255, 255, 0.08);
          color: #38bdf8;
          border-color: rgba(56, 189, 248, 0.3);
        }

        .draft-save-btn.saving {
          background: rgba(56, 189, 248, 0.12) !important;
          border-color: rgba(56, 189, 248, 0.4) !important;
          color: #38bdf8 !important;
        }

        .draft-save-btn.saved {
          background: rgba(22, 201, 111, 0.15) !important;
          border-color: rgba(22, 201, 111, 0.4) !important;
          color: #16c96f !important;
          animation: pulse-saved 0.35s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        @keyframes pulse-saved {
          0% { transform: scale(0.96); }
          50% { transform: scale(1.04); }
          100% { transform: scale(1); }
        }

        .btn-autosave-indicator {
          display: inline-flex;
          align-items: center;
          gap: 6px;
        }

        .btn-autosave-indicator :global(svg) {
          width: 14px;
          height: 14px;
        }

        .neon-publish-main-btn {
          height: 36px;
          padding: 0 18px;
          border-radius: 6px;
          background: linear-gradient(110deg, #12b85f, #18d878);
          border: 1px solid rgba(67, 255, 147, 0.4);
          color: #030b12;
          font-size: 12px;
          font-weight: 800;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
          box-shadow: 0 0 16px rgba(22, 201, 111, 0.3);
          transition: all 0.2s;
        }

        .neon-publish-main-btn:hover:not(:disabled) {
          background: #20df7b;
          transform: translateY(-1px);
        }

        .neon-publish-main-btn :global(svg) {
          width: 14px;
          height: 14px;
        }

        .sidebar-toggle-btn {
          width: 36px;
          height: 36px;
          border-radius: 6px;
          background: rgba(255, 255, 255, 0.04);
          border: 1px solid rgba(255, 255, 255, 0.08);
          color: #94a3b8;
          display: grid;
          place-items: center;
          cursor: pointer;
          transition: all 0.15s;
        }

        .sidebar-toggle-btn.open {
          background: rgba(56, 189, 248, 0.12);
          border-color: rgba(56, 189, 248, 0.4);
          color: #38bdf8;
        }

        .sidebar-toggle-btn :global(svg) {
          width: 16px;
          height: 16px;
        }

        /* Workspace Body */
        .gutenberg-workspace-body {
          display: flex;
          flex: 1;
          position: relative;
          min-height: calc(100vh - 56px);
        }

        /* Library Drawer */
        .blocks-library-drawer {
          width: 300px;
          background: #040c14;
          border-right: 1px solid rgba(255, 255, 255, 0.08);
          display: flex;
          flex-direction: column;
          gap: 16px;
          padding: 18px;
          z-index: 60;
          overflow-y: auto;
        }

        .drawer-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .drawer-header h3 {
          font-size: 14px;
          font-weight: 700;
          color: #ffffff;
          margin: 0;
        }

        .drawer-header button {
          background: none;
          border: none;
          color: #64748b;
          cursor: pointer;
        }

        .drawer-search-wrap {
          position: relative;
          display: flex;
          align-items: center;
        }

        .drawer-search-wrap :global(svg) {
          position: absolute;
          left: 10px;
          width: 13px;
          height: 13px;
          color: #64748b;
        }

        .drawer-search-wrap input {
          width: 100%;
          height: 34px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 6px;
          padding: 0 10px 0 30px;
          color: #ffffff;
          font-size: 11px;
          outline: none;
        }

        .blocks-category-section h4 {
          font-size: 10px;
          font-weight: 700;
          color: #64748b;
          margin: 0 0 8px;
          letter-spacing: 0.5px;
        }

        .drawer-blocks-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 8px;
        }

        .drawer-block-btn {
          height: 60px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.06);
          border-radius: 6px;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          gap: 4px;
          color: #cbd5e1;
          font-size: 10px;
          cursor: grab;
          transition: all 0.15s;
          user-select: none;
        }

        .drawer-block-btn:active {
          cursor: grabbing;
        }

        .drawer-block-btn:hover {
          background: rgba(56, 189, 248, 0.08);
          border-color: rgba(56, 189, 248, 0.4);
          color: #38bdf8;
        }

        .drawer-block-btn :global(svg) {
          width: 16px;
          height: 16px;
        }

        /* Canvas Area */
        .gutenberg-canvas-area {
          flex: 1;
          display: flex;
          justify-content: center;
          padding: 40px clamp(20px, 4vw, 60px) 120px;
          overflow-y: auto;
          background: #03070b;
        }

        .canvas-document-container {
          width: 100%;
          max-width: min(1180px, 100%);
          display: flex;
          flex-direction: column;
          gap: 28px;
        }

        .title-input-wrapper {
          border: none !important;
          outline: none !important;
        }

        .gutenberg-main-title {
          width: 100%;
          background: transparent;
          border: none !important;
          border-bottom: none !important;
          outline: none !important;
          box-shadow: none !important;
          font-size: 40px;
          font-weight: 800;
          color: #ffffff;
          line-height: 1.2;
          letter-spacing: -0.5px;
          padding: 4px 0;
        }

        .gutenberg-main-title:focus,
        .gutenberg-main-title:hover,
        .gutenberg-main-title:active {
          border: none !important;
          border-bottom: none !important;
          outline: none !important;
          box-shadow: none !important;
        }

        .gutenberg-main-title::placeholder {
          color: rgba(255, 255, 255, 0.25);
        }

        .editor-content-wrapper {
          position: relative;
          min-height: 120px;
        }

        .editor-block-stream-container {
          position: relative;
          display: flex;
          align-items: flex-start;
          width: 100%;
        }

        .gutenberg-editable-content {
          flex: 1;
          outline: none;
          border: none;
          font-size: 16px;
          line-height: 1.8;
          color: #e2e8f0;
          min-height: 80px;
          padding-right: 42px;
          border-radius: 6px;
          transition: background 0.15s ease;
        }

        .gutenberg-editable-content.is-drag-over {
          background: rgba(22, 201, 111, 0.05) !important;
          outline: 2px dashed #16c96f !important;
          outline-offset: 4px;
        }

        .gutenberg-editable-content:empty:before {
          content: attr(data-placeholder);
          color: #475569;
          cursor: text;
        }

        /* Inserter [+] Alineado a la Derecha */
        .block-right-inserter-anchor {
          position: absolute;
          right: 0;
          top: 0;
          z-index: 50;
        }

        .inline-plus-btn-right {
          width: 28px;
          height: 28px;
          border-radius: 6px;
          background: #07131e;
          border: 1px solid rgba(56, 189, 248, 0.35);
          color: #38bdf8;
          display: grid;
          place-items: center;
          cursor: pointer;
          transition: all 0.2s;
          flex-shrink: 0;
        }

        .inline-plus-btn-right:hover {
          background: #0284c7;
          border-color: #38bdf8;
          color: #ffffff;
          transform: scale(1.08);
          box-shadow: 0 0 12px rgba(56, 189, 248, 0.4);
        }

        .inline-plus-btn-right :global(svg) {
          width: 15px;
          height: 15px;
        }

        .inline-blocks-popover-right {
          position: absolute;
          top: 36px;
          right: 0;
          width: 250px;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.12);
          border-radius: 8px;
          padding: 12px;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.7);
          z-index: 80;
        }

        .inline-plus-btn {
          width: 30px;
          height: 30px;
          border-radius: 6px;
          background: #07131e;
          border: 1px solid rgba(56, 189, 248, 0.35);
          color: #38bdf8;
          display: grid;
          place-items: center;
          cursor: pointer;
          transition: all 0.2s;
          flex-shrink: 0;
        }

        .inline-plus-btn:hover {
          background: #0284c7;
          border-color: #38bdf8;
          color: #ffffff;
          transform: scale(1.08);
          box-shadow: 0 0 12px rgba(56, 189, 248, 0.4);
        }

        .inline-plus-btn :global(svg) {
          width: 16px;
          height: 16px;
        }

        .inline-plus-hint {
          font-size: 12px;
          color: #64748b;
          font-weight: 500;
        }

        .inline-blocks-popover {
          position: absolute;
          top: 42px;
          left: 0;
          width: 250px;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.12);
          border-radius: 8px;
          padding: 12px;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.7);
          z-index: 80;
        }

        .popover-search-box {
          position: relative;
          display: flex;
          align-items: center;
          margin-bottom: 10px;
        }

        .popover-search-box :global(svg) {
          position: absolute;
          left: 8px;
          width: 13px;
          height: 13px;
          color: #64748b;
        }

        .popover-search-box input {
          width: 100%;
          height: 32px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 4px;
          padding: 0 8px 0 28px;
          color: #ffffff;
          font-size: 11px;
          outline: none;
        }

        .popover-blocks-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 6px;
          margin-bottom: 8px;
        }

        .popover-blocks-grid .grid-item {
          height: 54px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.06);
          border-radius: 4px;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          gap: 3px;
          color: #cbd5e1;
          font-size: 9px;
          cursor: pointer;
        }

        .popover-blocks-grid .grid-item:hover {
          background: rgba(56, 189, 248, 0.1);
          border-color: rgba(56, 189, 248, 0.4);
          color: #38bdf8;
        }

        .popover-blocks-grid .grid-item :global(svg) {
          width: 15px;
          height: 15px;
        }

        .popover-view-all-btn {
          width: 100%;
          height: 28px;
          background: transparent;
          border: 1px dashed rgba(255, 255, 255, 0.1);
          border-radius: 4px;
          color: #94a3b8;
          font-size: 11px;
          cursor: pointer;
        }

        .popover-view-all-btn:hover {
          color: #38bdf8;
          border-color: #38bdf8;
        }

        /* =================================================================
            SUITE DE OPTIMIZACIÓN SEO PARA GOOGLE (ESTILO RANK MATH PRO)
            FORMATO AMPLIO, ORGANIZADO Y DE ALTA CALIDAD
            ================================================================= */
        .techlab-pro-seo-suite {
          margin-top: 36px;
          background: #050f18;
          border: 1px solid rgba(56, 189, 248, 0.3);
          border-radius: 14px;
          overflow: hidden;
          box-shadow: 0 20px 50px rgba(0, 0, 0, 0.6), 0 0 30px rgba(56, 189, 248, 0.08);
        }

        .seo-suite-top-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 20px 24px;
          background: #030a10;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .suite-title-area {
          display: flex;
          align-items: center;
          gap: 14px;
        }

        .suite-icon-badge {
          width: 44px;
          height: 44px;
          border-radius: 10px;
          background: rgba(56, 189, 248, 0.12);
          border: 1px solid rgba(56, 189, 248, 0.4);
          color: #38bdf8;
          display: grid;
          place-items: center;
          box-shadow: 0 0 16px rgba(56, 189, 248, 0.2);
        }

        .suite-icon-badge :global(svg) {
          width: 22px;
          height: 22px;
        }

        .suite-title-area h3 {
          font-size: 17px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 4px;
          letter-spacing: -0.3px;
        }

        .suite-title-area p {
          font-size: 12px;
          color: #94a3b8;
          margin: 0;
        }

        .suite-score-badge-card {
          display: flex;
          align-items: center;
          gap: 14px;
          background: #071522;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          padding: 8px 16px;
        }

        .score-text-group {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
        }

        .score-lbl {
          font-size: 10px;
          font-weight: 600;
          color: #64748b;
          text-transform: uppercase;
        }

        .score-text-group strong {
          font-size: 13px;
          font-weight: 800;
        }

        .score-text-group strong.good { color: #16c96f; }
        .score-text-group strong.avg { color: #f59e0b; }
        .score-text-group strong.bad { color: #ef4444; }

        .score-radial-tag {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 6px 14px;
          border-radius: 20px;
          font-size: 14px;
          font-weight: 800;
        }

        .score-radial-tag.good {
          background: rgba(22, 201, 111, 0.15);
          border: 1px solid rgba(22, 201, 111, 0.4);
          color: #16c96f;
          box-shadow: 0 0 12px rgba(22, 201, 111, 0.2);
        }

        .score-radial-tag.avg {
          background: rgba(245, 158, 11, 0.15);
          border: 1px solid rgba(245, 158, 11, 0.4);
          color: #f59e0b;
        }

        .score-radial-tag.bad {
          background: rgba(239, 68, 68, 0.15);
          border: 1px solid rgba(239, 68, 68, 0.4);
          color: #ef4444;
        }

        .score-radial-tag :global(svg) {
          width: 16px;
          height: 16px;
        }

        /* Tabs Nav */
        .seo-suite-tabs-nav {
          display: flex;
          background: #03080e;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
          padding: 0 16px;
          gap: 6px;
        }

        .seo-nav-tab {
          height: 46px;
          padding: 0 16px;
          background: transparent;
          border: none;
          border-bottom: 2px solid transparent;
          color: #94a3b8;
          font-size: 12px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          transition: all 0.15s;
        }

        .seo-nav-tab:hover {
          color: #ffffff;
        }

        .seo-nav-tab.active {
          color: #38bdf8;
          border-bottom-color: #38bdf8;
          background: rgba(56, 189, 248, 0.04);
        }

        .seo-nav-tab :global(svg) {
          width: 15px;
          height: 15px;
        }

        .tab-pill-count {
          font-size: 10px;
          background: rgba(56, 189, 248, 0.15);
          border: 1px solid rgba(56, 189, 248, 0.3);
          color: #38bdf8;
          padding: 2px 6px;
          border-radius: 10px;
        }

        .seo-suite-content-body {
          padding: 24px;
        }

        /* Pestaña 1: General */
        .tab-pane-general {
          display: flex;
          flex-direction: column;
          gap: 24px;
        }

        /* Google SERP Master Card */
        .google-serp-master-card {
          background: #03080e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          padding: 16px 20px;
          display: flex;
          flex-direction: column;
          gap: 14px;
        }

        .serp-toolbar-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          border-bottom: 1px solid rgba(255, 255, 255, 0.06);
          padding-bottom: 10px;
        }

        .serp-badge-title {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 12px;
          color: #cbd5e1;
        }

        .g-logo {
          width: 20px;
          height: 20px;
          border-radius: 50%;
          background: #ffffff;
          color: #1a73e8;
          font-weight: 900;
          font-size: 12px;
          display: grid;
          place-items: center;
        }

        .serp-view-mode-buttons {
          display: flex;
          gap: 4px;
          background: #071522;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 6px;
          padding: 2px;
        }

        .serp-view-mode-buttons button {
          height: 28px;
          padding: 0 12px;
          background: none;
          border: none;
          border-radius: 4px;
          color: #94a3b8;
          font-size: 11px;
          font-weight: 600;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
          transition: all 0.15s;
        }

        .serp-view-mode-buttons button.active {
          background: #0284c7;
          color: #ffffff;
        }

        .serp-view-mode-buttons button :global(svg) {
          width: 13px;
          height: 13px;
        }

        .google-snippet-frame {
          padding: 14px 18px;
          background: #181a1b;
          border: 1px solid rgba(255, 255, 255, 0.06);
          border-radius: 8px;
          display: flex;
          flex-direction: column;
          gap: 6px;
          font-family: Arial, sans-serif;
        }

        .google-snippet-frame.mobile-mode {
          max-width: 420px;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
          border-left: 3px solid #38bdf8;
        }

        .snippet-top-row {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .google-favicon-circle {
          font-size: 13px;
        }

        .snippet-hierarchy {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 12px;
          color: #bdc1c6;
        }

        .brand-name {
          font-weight: 600;
          color: #e8eaed;
        }

        .sep { color: #5f6368; }
        .url-path { color: #9aa0a6; font-size: 11px; }

        .snippet-heading {
          font-size: 18px;
          font-weight: 400;
          color: #8ab4f8;
          margin: 4px 0 2px;
          line-height: 1.35;
          cursor: pointer;
        }

        .snippet-heading:hover {
          text-decoration: underline;
        }

        .snippet-text {
          font-size: 13px;
          color: #bdc1c6;
          line-height: 1.5;
          margin: 0;
        }

        /* Formulario Espacioso */
        .seo-form-spacious-grid {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        .form-field-row {
          display: grid;
          grid-template-columns: 280px 1fr;
          gap: 20px;
          padding: 16px 0;
          border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        .form-field-row:last-child {
          border-bottom: none;
        }

        .field-meta-info {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .field-meta-info label {
          font-size: 13px;
          font-weight: 700;
          color: #f1f5f9;
          display: inline-flex;
          align-items: center;
          gap: 8px;
        }

        .field-meta-info label :global(svg) {
          width: 15px;
          height: 15px;
          color: #38bdf8;
        }

        .field-meta-info p {
          font-size: 11px;
          color: #64748b;
          margin: 0;
          line-height: 1.4;
        }

        .field-input-box {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .input-with-counter-wrap {
          position: relative;
          display: flex;
          align-items: center;
        }

        .wide-seo-input {
          width: 100%;
          height: 42px;
          background: #03080e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          padding: 0 100px 0 14px;
          color: #ffffff;
          font-size: 13px;
          outline: none;
          transition: border-color 0.2s, box-shadow 0.2s;
        }

        .wide-seo-input:focus {
          border-color: #38bdf8;
          box-shadow: 0 0 16px rgba(56, 189, 248, 0.2);
        }

        .wide-seo-textarea {
          width: 100%;
          background: #03080e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          padding: 12px 14px;
          color: #ffffff;
          font-size: 13px;
          outline: none;
          resize: vertical;
          font-family: inherit;
          line-height: 1.5;
          transition: border-color 0.2s, box-shadow 0.2s;
        }

        .wide-seo-textarea:focus {
          border-color: #38bdf8;
          box-shadow: 0 0 16px rgba(56, 189, 248, 0.2);
        }

        .counter-pill {
          position: absolute;
          right: 10px;
          top: 10px;
          font-size: 11px;
          font-weight: 700;
          padding: 3px 8px;
          border-radius: 4px;
        }

        .counter-pill.good { background: rgba(22, 201, 111, 0.15); color: #16c96f; }
        .counter-pill.neutral { background: rgba(255, 255, 255, 0.06); color: #94a3b8; }
        .counter-pill.warn { background: rgba(245, 158, 11, 0.15); color: #f59e0b; }

        .char-progress-bar {
          width: 100%;
          height: 3px;
          background: rgba(255, 255, 255, 0.06);
          border-radius: 2px;
          overflow: hidden;
        }

        .progress-fill {
          height: 100%;
          transition: width 0.2s;
        }

        .progress-fill.good { background: #16c96f; }
        .progress-fill.neutral { background: #38bdf8; }
        .progress-fill.warn { background: #f59e0b; }

        /* Pestaña 2: Auditoría */
        .tab-pane-analysis {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        .analysis-summary-banner {
          display: flex;
          align-items: center;
          gap: 16px;
          background: #03080e;
          border: 1px solid rgba(22, 201, 111, 0.3);
          border-radius: 10px;
          padding: 16px 20px;
        }

        .banner-icon {
          width: 40px;
          height: 40px;
          border-radius: 8px;
          background: rgba(22, 201, 111, 0.12);
          color: #16c96f;
          display: grid;
          place-items: center;
          flex-shrink: 0;
        }

        .banner-icon :global(svg) {
          width: 20px;
          height: 20px;
        }

        .banner-texts h4 {
          font-size: 14px;
          font-weight: 700;
          color: #ffffff;
          margin: 0 0 2px;
        }

        .banner-texts p {
          font-size: 12px;
          color: #94a3b8;
          margin: 0;
        }

        .banner-texts strong {
          color: #16c96f;
        }

        .audit-cards-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 14px;
        }

        .audit-card-item {
          background: #03080e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          padding: 16px;
          display: flex;
          align-items: flex-start;
          gap: 14px;
        }

        .audit-card-item.pass {
          border-left: 3px solid #16c96f;
        }

        .audit-card-item.fail {
          border-left: 3px solid #64748b;
        }

        .audit-status-icon {
          margin-top: 2px;
        }

        .audit-card-item.pass .audit-status-icon { color: #16c96f; }
        .audit-card-item.fail .audit-status-icon { color: #64748b; }

        .audit-status-icon :global(svg) {
          width: 18px;
          height: 18px;
        }

        .audit-info {
          display: flex;
          flex-direction: column;
          gap: 2px;
        }

        .audit-category {
          font-size: 10px;
          font-weight: 700;
          color: #38bdf8;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .audit-info strong {
          font-size: 13px;
          color: #f1f5f9;
        }

        .audit-info p {
          font-size: 11px;
          color: #94a3b8;
          margin: 2px 0 0;
          line-height: 1.4;
        }

        /* Pestaña 3: Social */
        .tab-pane-social {
          display: flex;
          justify-content: center;
          padding: 10px 0;
        }

        .social-preview-container {
          width: 100%;
          max-width: 520px;
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .social-header-row {
          font-size: 11px;
          font-weight: 700;
          color: #64748b;
          letter-spacing: 0.5px;
        }

        .social-card-simulation {
          background: #03080e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 10px;
          overflow: hidden;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        }

        .social-img-box {
          width: 100%;
          height: 240px;
          overflow: hidden;
        }

        .social-img-box img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .social-img-placeholder {
          width: 100%;
          height: 180px;
          background: #071522;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          gap: 8px;
          color: #64748b;
          font-size: 12px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.06);
        }

        .social-img-placeholder :global(svg) {
          width: 32px;
          height: 32px;
          color: #38bdf8;
        }

        .social-card-body {
          padding: 14px 16px;
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .social-domain {
          font-size: 11px;
          color: #94a3b8;
          text-transform: uppercase;
        }

        .social-card-body h5 {
          font-size: 15px;
          font-weight: 700;
          color: #ffffff;
          margin: 0;
          line-height: 1.3;
        }

        .social-card-body p {
          font-size: 12px;
          color: #94a3b8;
          margin: 0;
          line-height: 1.4;
        }

        /* Right Sidebar */
        .gutenberg-right-sidebar {
          width: 320px;
          background: #040c14;
          border-left: 1px solid rgba(255, 255, 255, 0.08);
          display: flex;
          flex-direction: column;
          overflow-y: auto;
          z-index: 40;
        }

        .sidebar-tab-switcher {
          display: flex;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .tab-btn {
          flex: 1;
          height: 44px;
          background: transparent;
          border: none;
          color: #94a3b8;
          font-size: 12px;
          font-weight: 700;
          cursor: pointer;
          position: relative;
        }

        .tab-btn.active {
          color: #ffffff;
        }

        .tab-btn.active:after {
          content: "";
          position: absolute;
          bottom: 0;
          left: 0;
          right: 0;
          height: 2px;
          background: #38bdf8;
        }

        .sidebar-scrollable-content {
          padding: 16px;
          display: flex;
          flex-direction: column;
          gap: 18px;
        }

        /* Featured Image */
        .featured-image-section {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .section-label-header {
          font-size: 10px;
          font-weight: 700;
          color: #64748b;
          letter-spacing: 0.5px;
        }

        .featured-image-preview-container {
          position: relative;
          height: 140px;
          border-radius: 8px;
          overflow: hidden;
          border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .featured-img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .image-overlay-actions {
          position: absolute;
          inset: 0;
          background: rgba(0, 0, 0, 0.6);
          opacity: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          transition: opacity 0.15s;
        }

        .featured-image-preview-container:hover .image-overlay-actions {
          opacity: 1;
        }

        .btn-replace-img {
          height: 28px;
          padding: 0 10px;
          border-radius: 4px;
          background: #0284c7;
          border: none;
          color: #ffffff;
          font-size: 11px;
          font-weight: 600;
          cursor: pointer;
        }

        .btn-remove-img {
          width: 28px;
          height: 28px;
          border-radius: 4px;
          background: rgba(239, 68, 68, 0.8);
          border: none;
          color: #ffffff;
          display: grid;
          place-items: center;
          cursor: pointer;
        }

        .btn-remove-img :global(svg) {
          width: 14px;
          height: 14px;
        }

        .featured-image-dropzone {
          height: 120px;
          border: 1.5px dashed rgba(255, 255, 255, 0.15);
          border-radius: 8px;
          display: grid;
          place-items: center;
          cursor: pointer;
          background: #07131e;
          transition: all 0.15s;
        }

        .featured-image-dropzone:hover {
          border-color: #38bdf8;
          background: rgba(56, 189, 248, 0.04);
        }

        .dropzone-inner {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
          text-align: center;
        }

        .dropzone-inner :global(svg) {
          width: 22px;
          height: 22px;
          color: #38bdf8;
        }

        .dropzone-inner strong {
          font-size: 11px;
          color: #f1f5f9;
        }

        .dropzone-inner small {
          font-size: 10px;
          color: #64748b;
        }

        /* Page Meta List */
        .page-meta-list-group {
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.06);
          border-radius: 8px;
          padding: 8px 12px;
          display: flex;
          flex-direction: column;
        }

        .meta-list-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 8px 0;
          border-bottom: 1px solid rgba(255, 255, 255, 0.04);
          font-size: 12px;
        }

        .meta-list-row:last-child {
          border-bottom: none;
        }

        .meta-row-name {
          color: #94a3b8;
          font-weight: 600;
        }

        .meta-row-link {
          background: none;
          border: none;
          color: #38bdf8;
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
          padding: 0;
          max-width: 150px;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        .techlab-meta-select {
          height: 26px;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 4px;
          color: #ffffff;
          font-size: 11px;
          outline: none;
        }

        .techlab-meta-select-inline {
          height: 26px;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 4px;
          color: #ffffff;
          font-size: 11px;
          outline: none;
          max-width: 140px;
        }

        /* Block Tab */
        .sb-block-tab-content {
          padding: 16px;
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .block-type-badge {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 10px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 6px;
        }

        .block-type-badge :global(svg) {
          width: 16px;
          height: 16px;
          color: #38bdf8;
        }

        .block-type-badge div {
          display: flex;
          flex-direction: column;
        }

        .block-type-badge strong {
          font-size: 12px;
          color: #ffffff;
        }

        .block-type-badge small {
          font-size: 10px;
          color: #64748b;
        }

        .block-control-group {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .field-hint-label {
          font-size: 11px;
          color: #94a3b8;
          font-weight: 600;
        }

        .font-size-chips, .align-buttons-row {
          display: flex;
          gap: 6px;
        }

        .font-size-chips button, .align-buttons-row button {
          flex: 1;
          height: 32px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 4px;
          color: #cbd5e1;
          font-size: 11px;
          font-weight: 600;
          display: grid;
          place-items: center;
          cursor: pointer;
        }

        .font-size-chips button.active, .align-buttons-row button:hover {
          border-color: #38bdf8;
          color: #38bdf8;
          background: rgba(56, 189, 248, 0.08);
        }

        .align-buttons-row button :global(svg) {
          width: 14px;
          height: 14px;
        }

        /* Modal Generics */
        .techlab-modal-backdrop {
          position: fixed;
          inset: 0;
          z-index: 2000;
          background: rgba(0, 0, 0, 0.75);
          backdrop-filter: blur(4px);
          display: grid;
          place-items: center;
          padding: 16px;
        }

        .techlab-modal-card {
          width: 100%;
          max-width: 440px;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 12px;
          padding: 20px;
          box-shadow: 0 20px 50px rgba(0, 0, 0, 0.8);
          display: flex;
          flex-direction: column;
          gap: 14px;
        }

        .modal-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .modal-top h3 {
          font-size: 15px;
          font-weight: 700;
          color: #ffffff;
          margin: 0;
        }

        .modal-top button {
          background: none;
          border: none;
          color: #64748b;
          cursor: pointer;
        }

        .modal-body-content {
          display: flex;
          flex-direction: column;
          gap: 6px;
          font-size: 12px;
          color: #cbd5e1;
        }

        .modal-actions-bar {
          display: flex;
          align-items: center;
          justify-content: flex-end;
          gap: 8px;
          margin-top: 4px;
        }

        .btn-modal-ghost {
          height: 34px;
          padding: 0 14px;
          border-radius: 6px;
          background: transparent;
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: #cbd5e1;
          font-size: 12px;
          cursor: pointer;
        }

        .btn-modal-green {
          height: 34px;
          padding: 0 16px;
          border-radius: 6px;
          background: linear-gradient(110deg, #12b85f, #18d878);
          border: 1px solid rgba(67, 255, 147, 0.4);
          color: #030b12;
          font-size: 12px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          text-decoration: none;
          cursor: pointer;
        }

        .publish-success-card {
          text-align: center;
          align-items: center;
        }

        .success-icon-badge {
          width: 52px;
          height: 52px;
          border-radius: 50%;
          background: rgba(22, 201, 111, 0.15);
          border: 1px solid #16c96f;
          color: #16c96f;
          display: grid;
          place-items: center;
        }

        .success-icon-badge :global(svg) {
          width: 24px;
          height: 24px;
        }

        .published-url-copy-box {
          width: 100%;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 6px;
          padding: 8px 10px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 8px;
        }

        .url-text {
          font-size: 11px;
          color: #38bdf8;
          font-family: monospace;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        .btn-copy-url {
          height: 28px;
          padding: 0 10px;
          border-radius: 4px;
          background: #0284c7;
          border: none;
          color: #ffffff;
          font-size: 11px;
          font-weight: 600;
          display: inline-flex;
          align-items: center;
          gap: 4px;
          cursor: pointer;
          flex-shrink: 0;
        }

        .btn-copy-url :global(svg) {
          width: 12px;
          height: 12px;
        }

        /* =================================================================
            BARRA DE HERRAMIENTAS FLOTANTE GUTENBERG Y PALETA DE COLORES
            ================================================================= */
        .gutenberg-floating-block-toolbar {
          position: fixed;
          z-index: 120;
          display: flex;
          align-items: center;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.16);
          border-radius: 8px;
          box-shadow: 0 12px 36px rgba(0, 0, 0, 0.8), 0 0 20px rgba(56, 189, 248, 0.12);
          padding: 4px 6px;
          gap: 2px;
          animation: floatInTb 0.15s ease;
        }

        @keyframes floatInTb {
          from { opacity: 0; transform: translateY(4px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .toolbar-btn-group {
          display: flex;
          align-items: center;
          gap: 2px;
          position: relative;
        }

        .tb-btn {
          height: 32px;
          padding: 0 8px;
          background: transparent;
          border: none;
          border-radius: 5px;
          color: #cbd5e1;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 4px;
          cursor: pointer;
          font-size: 12px;
          font-weight: 700;
          transition: all 0.12s ease;
        }

        .tb-btn:hover,
        .tb-btn.active {
          background: rgba(56, 189, 248, 0.12);
          color: #38bdf8;
        }

        .tb-btn :global(svg) {
          width: 15px;
          height: 15px;
        }

        .tb-chevron-icon {
          width: 10px !important;
          height: 10px !important;
          opacity: 0.6;
          margin-left: 2px;
        }

        .tb-movers-duo {
          display: flex;
          flex-direction: column;
          gap: 1px;
          margin-left: 2px;
        }

        .tb-icon-mini-btn {
          width: 16px;
          height: 14px;
          background: transparent;
          border: none;
          border-radius: 3px;
          color: #64748b;
          display: grid;
          place-items: center;
          cursor: pointer;
          padding: 0;
        }

        .tb-icon-mini-btn:hover {
          background: rgba(255, 255, 255, 0.1);
          color: #ffffff;
        }

        .tb-icon-mini-btn :global(svg) {
          width: 10px;
          height: 10px;
        }

        .tb-divider {
          width: 1px;
          height: 20px;
          background: rgba(255, 255, 255, 0.1);
          margin: 0 4px;
        }

        .tb-color-indicator {
          width: 10px;
          height: 10px;
          border-radius: 50%;
          border: 1px solid rgba(255, 255, 255, 0.4);
          display: inline-block;
          margin-left: 2px;
        }

        /* Popovers Comunes */
        .gutenberg-tb-popover {
          position: absolute;
          top: 38px;
          left: 0;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.15);
          border-radius: 8px;
          box-shadow: 0 12px 36px rgba(0, 0, 0, 0.8), 0 0 20px rgba(0, 0, 0, 0.5);
          z-index: 150;
          animation: popoverFade 0.12s ease;
        }

        @keyframes popoverFade {
          from { opacity: 0; transform: translateY(-4px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .popover-header-title {
          display: block;
          padding: 8px 12px 4px;
          font-size: 10px;
          font-weight: 700;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .popover-item {
          width: 100%;
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 8px 14px;
          background: transparent;
          border: none;
          color: #cbd5e1;
          font-size: 12px;
          font-weight: 600;
          text-align: left;
          cursor: pointer;
          transition: background 0.1s;
        }

        .popover-item:hover {
          background: rgba(56, 189, 248, 0.12);
          color: #38bdf8;
        }

        .popover-item :global(svg) {
          width: 14px;
          height: 14px;
          color: #94a3b8;
        }

        .popover-item:hover :global(svg) {
          color: #38bdf8;
        }

        .popover-item.danger {
          color: #ef4444;
        }

        .popover-item.danger:hover {
          background: rgba(239, 68, 68, 0.12);
          color: #f87171;
        }

        .popover-item.danger :global(svg) {
          color: #ef4444;
        }

        .popover-divider {
          display: block;
          height: 1px;
          background: rgba(255, 255, 255, 0.08);
          margin: 4px 0;
        }

        .block-types-popover {
          width: 200px;
          padding: 4px 0;
        }

        .align-popover {
          width: 180px;
          padding: 4px 0;
        }

        .more-menu-popover {
          width: 200px;
          right: 0;
          left: auto;
          padding: 4px 0;
        }

        /* Link Input Popover */
        .link-input-popover {
          width: 280px;
          padding: 8px;
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .tb-url-input {
          flex: 1;
          height: 32px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 5px;
          padding: 0 10px;
          color: #ffffff;
          font-size: 12px;
          outline: none;
        }

        .tb-url-input:focus {
          border-color: #38bdf8;
        }

        .tb-url-submit-btn {
          height: 32px;
          padding: 0 12px;
          background: #0284c7;
          border: none;
          border-radius: 5px;
          color: #ffffff;
          font-size: 11px;
          font-weight: 700;
          cursor: pointer;
        }

        .tb-url-submit-btn:hover {
          background: #38bdf8;
          color: #030a10;
        }

        /* Color Picker Popover */
        .color-picker-popover {
          width: 260px;
          padding: 12px;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .color-tabs-switcher {
          display: flex;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 6px;
          padding: 2px;
        }

        .color-tab-btn {
          flex: 1;
          height: 28px;
          background: transparent;
          border: none;
          border-radius: 4px;
          color: #94a3b8;
          font-size: 11px;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.15s;
        }

        .color-tab-btn.active {
          background: #0284c7;
          color: #ffffff;
        }

        .color-palette-section {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .color-palette-title {
          font-size: 10px;
          color: #94a3b8;
          font-weight: 600;
        }

        .colors-grid-dots {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 8px;
        }

        .color-circle-dot {
          width: 100%;
          height: 28px;
          border-radius: 6px;
          border: 1px solid rgba(255, 255, 255, 0.15);
          cursor: pointer;
          transition: transform 0.15s, border-color 0.15s;
        }

        .color-circle-dot:hover {
          transform: scale(1.08);
          border-color: #ffffff;
        }

        .color-circle-dot.transparent-dot {
          background-image: repeating-linear-gradient(45deg, #333 0, #333 4px, #222 0, #222 8px);
        }

        .custom-color-picker-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding-top: 6px;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
        }

        .custom-color-picker-row label {
          font-size: 11px;
          color: #cbd5e1;
        }

        .native-color-picker {
          width: 28px;
          height: 28px;
          border: none;
          background: transparent;
          cursor: pointer;
          border-radius: 4px;
        }

        .reset-color-btn {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          background: transparent;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 4px;
          padding: 4px 8px;
          color: #94a3b8;
          font-size: 10px;
          cursor: pointer;
        }

        .reset-color-btn:hover {
          background: rgba(255, 255, 255, 0.06);
          color: #ffffff;
        }

        .reset-color-btn :global(svg) {
          width: 10px;
          height: 10px;
        }

        /* =================================================================
           PAGES GUTENBERG LIGHT MODE (theme-light & :global(.theme-light))
           ================================================================= */
        .techlab-gutenberg-root.theme-light,
        :global(.theme-light) .techlab-gutenberg-root {
          background: #f8fafc !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .gutenberg-top-bar,
        :global(.theme-light) .gutenberg-top-bar {
          background: #ffffff !important;
          border-bottom: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .back-btn-square,
        .techlab-gutenberg-root.theme-light .block-inserter-toggle-btn,
        .techlab-gutenberg-root.theme-light .history-btns-group button,
        .techlab-gutenberg-root.theme-light .sidebar-toggle-btn,
        :global(.theme-light) .back-btn-square,
        :global(.theme-light) .block-inserter-toggle-btn,
        :global(.theme-light) .history-btns-group button,
        :global(.theme-light) .sidebar-toggle-btn {
          background: #f8fafc !important;
          border: 1px solid #cbd5e1 !important;
          color: #334155 !important;
        }

        .techlab-gutenberg-root.theme-light .back-btn-square:hover,
        .techlab-gutenberg-root.theme-light .block-inserter-toggle-btn:hover,
        .techlab-gutenberg-root.theme-light .sidebar-toggle-btn:hover,
        :global(.theme-light) .back-btn-square:hover,
        :global(.theme-light) .block-inserter-toggle-btn:hover,
        :global(.theme-light) .sidebar-toggle-btn:hover {
          background: #f1f5f9 !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .document-type-badge,
        :global(.theme-light) .document-type-badge {
          background: #f8fafc !important;
          border: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .doc-live-title,
        :global(.theme-light) .doc-live-title {
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .draft-save-btn,
        :global(.theme-light) .draft-save-btn {
          background: #f8fafc !important;
          border: 1px solid #cbd5e1 !important;
          color: #334155 !important;
        }

        .techlab-gutenberg-root.theme-light .draft-save-btn:hover,
        :global(.theme-light) .draft-save-btn:hover {
          background: #f1f5f9 !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .draft-save-btn.saving,
        :global(.theme-light) .draft-save-btn.saving {
          background: #f0f9ff !important;
          border-color: #7dd3fc !important;
          color: #0284c7 !important;
        }

        .techlab-gutenberg-root.theme-light .draft-save-btn.saved,
        :global(.theme-light) .draft-save-btn.saved {
          background: #f0fdf4 !important;
          border-color: #86efac !important;
          color: #16a34a !important;
        }

        .techlab-gutenberg-root.theme-light .gutenberg-canvas-area,
        :global(.theme-light) .gutenberg-canvas-area,
        .techlab-gutenberg-root.theme-light .gutenberg-canvas-wrapper,
        :global(.theme-light) .gutenberg-canvas-wrapper {
          background: #f8fafc !important;
        }

        .techlab-gutenberg-root.theme-light .gutenberg-document-sheet,
        :global(.theme-light) .gutenberg-document-sheet {
          background: #ffffff !important;
          border: 1px solid #e2e8f0 !important;
          box-shadow: 0 4px 25px rgba(0, 0, 0, 0.05) !important;
        }

        .techlab-gutenberg-root.theme-light .title-input-wrapper,
        :global(.theme-light) .title-input-wrapper {
          border: none !important;
          outline: none !important;
        }

        .techlab-gutenberg-root.theme-light .gutenberg-main-title,
        :global(.theme-light) .gutenberg-main-title {
          color: #0f172a !important;
          border: none !important;
          border-bottom: none !important;
          outline: none !important;
          box-shadow: none !important;
          background: transparent !important;
        }

        .techlab-gutenberg-root.theme-light .gutenberg-main-title:focus,
        .techlab-gutenberg-root.theme-light .gutenberg-main-title:hover,
        :global(.theme-light) .gutenberg-main-title:focus,
        :global(.theme-light) .gutenberg-main-title:hover {
          border: none !important;
          border-bottom: none !important;
          outline: none !important;
          box-shadow: none !important;
        }

        .techlab-gutenberg-root.theme-light .gutenberg-main-title::placeholder,
        :global(.theme-light) .gutenberg-main-title::placeholder {
          color: #94a3b8 !important;
        }

        .techlab-gutenberg-root.theme-light .gutenberg-editable-content,
        :global(.theme-light) .gutenberg-editable-content {
          color: #1e293b !important;
          border: none !important;
        }

        .techlab-gutenberg-root.theme-light .gutenberg-editable-content.is-drag-over,
        :global(.theme-light) .gutenberg-editable-content.is-drag-over {
          background: #f0fdf4 !important;
          outline-color: #16a34a !important;
        }

        .techlab-gutenberg-root.theme-light .inline-plus-btn-right,
        :global(.theme-light) .inline-plus-btn-right {
          background: #ffffff !important;
          border: 1px solid #cbd5e1 !important;
          color: #0284c7 !important;
        }

        .techlab-gutenberg-root.theme-light .inline-plus-btn-right:hover,
        :global(.theme-light) .inline-plus-btn-right:hover {
          background: #0284c7 !important;
          color: #ffffff !important;
        }

        .techlab-gutenberg-root.theme-light .inline-blocks-popover-right,
        :global(.theme-light) .inline-blocks-popover-right {
          background: #ffffff !important;
          border: 1px solid #e2e8f0 !important;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1) !important;
        }

        .techlab-gutenberg-root.theme-light .popover-search-box input,
        :global(.theme-light) .popover-search-box input {
          background: #f8fafc !important;
          border: 1px solid #cbd5e1 !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .grid-item,
        :global(.theme-light) .grid-item {
          background: #f8fafc !important;
          border: 1px solid #e2e8f0 !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .gutenberg-sidebar-aside,
        .techlab-gutenberg-root.theme-light .gutenberg-right-sidebar,
        :global(.theme-light) .gutenberg-sidebar-aside,
        :global(.theme-light) .gutenberg-right-sidebar {
          background: #ffffff !important;
          border-left: 1px solid #e2e8f0 !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .sidebar-tab-switcher,
        :global(.theme-light) .sidebar-tab-switcher {
          background: #f8fafc !important;
          border-bottom: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .tab-btn,
        :global(.theme-light) .tab-btn {
          color: #64748b !important;
        }

        .techlab-gutenberg-root.theme-light .tab-btn.active,
        :global(.theme-light) .tab-btn.active {
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .tab-btn.active:after,
        :global(.theme-light) .tab-btn.active:after {
          background: #16c96f !important;
        }

        .techlab-gutenberg-root.theme-light .section-label-header,
        :global(.theme-light) .section-label-header {
          color: #475569 !important;
        }

        .techlab-gutenberg-root.theme-light .featured-image-dropzone,
        :global(.theme-light) .featured-image-dropzone {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
        }
        .techlab-gutenberg-root.theme-light .dropzone-inner strong,
        :global(.theme-light) .dropzone-inner strong {
          color: #0f172a !important;
        }
        .techlab-gutenberg-root.theme-light .dropzone-inner small,
        :global(.theme-light) .dropzone-inner small {
          color: #64748b !important;
        }

        .techlab-gutenberg-root.theme-light .meta-list-row,
        :global(.theme-light) .meta-list-row {
          border-bottom: 1px solid #f1f5f9 !important;
        }
        .techlab-gutenberg-root.theme-light .meta-row-name,
        :global(.theme-light) .meta-row-name {
          color: #475569 !important;
        }
        .techlab-gutenberg-root.theme-light .meta-row-link,
        :global(.theme-light) .meta-row-link {
          color: #0284c7 !important;
        }

        .techlab-gutenberg-root.theme-light .techlab-meta-select,
        .techlab-gutenberg-root.theme-light .techlab-meta-select-inline,
        :global(.theme-light) .techlab-meta-select,
        :global(.theme-light) .techlab-meta-select-inline {
          background: #f8fafc !important;
          border: 1px solid #cbd5e1 !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .sidebar-block-info-header,
        :global(.theme-light) .sidebar-block-info-header {
          background: #f8fafc !important;
          color: #0f172a !important;
        }
        .techlab-gutenberg-root.theme-light .field-hint-label,
        :global(.theme-light) .field-hint-label {
          color: #475569 !important;
        }
        .techlab-gutenberg-root.theme-light .font-size-chips button,
        .techlab-gutenberg-root.theme-light .align-buttons-row button,
        :global(.theme-light) .font-size-chips button,
        :global(.theme-light) .align-buttons-row button {
          background: #f8fafc !important;
          border: 1px solid #cbd5e1 !important;
          color: #334155 !important;
        }
        .techlab-gutenberg-root.theme-light .font-size-chips button.active,
        :global(.theme-light) .font-size-chips button.active {
          background: #0284c7 !important;
          border-color: #0284c7 !important;
          color: #ffffff !important;
        }

        /* ELEMENTOR CARD LIGHT MODE */
        .techlab-gutenberg-root.theme-light .elementor-active-canvas-card,
        :global(.theme-light) .elementor-active-canvas-card {
          background: #ffffff !important;
          border: 1px solid rgba(214, 51, 132, 0.25) !important;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05), 0 0 15px rgba(214, 51, 132, 0.05) !important;
        }
        .techlab-gutenberg-root.theme-light .elementor-card-title,
        :global(.theme-light) .elementor-card-title {
          color: #0f172a !important;
        }
        .techlab-gutenberg-root.theme-light .elementor-card-desc,
        :global(.theme-light) .elementor-card-desc {
          color: #475569 !important;
        }
        .techlab-gutenberg-root.theme-light .btn-revert-gutenberg,
        :global(.theme-light) .btn-revert-gutenberg {
          background: #f8fafc !important;
          border: 1px solid #cbd5e1 !important;
          color: #334155 !important;
        }
        .techlab-gutenberg-root.theme-light .btn-revert-gutenberg:hover,
        :global(.theme-light) .btn-revert-gutenberg:hover {
          background: #f1f5f9 !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .gutenberg-sidebar-header,
        :global(.theme-light) .gutenberg-sidebar-header {
          background: #f8fafc !important;
          border-bottom: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .sidebar-tab-button,
        :global(.theme-light) .sidebar-tab-button {
          color: #64748b !important;
        }

        .techlab-gutenberg-root.theme-light .sidebar-tab-button.active,
        :global(.theme-light) .sidebar-tab-button.active {
          color: #0d9651 !important;
          border-bottom: 2px solid #16c96f !important;
        }

        .techlab-gutenberg-root.theme-light .accordion-section-header,
        :global(.theme-light) .accordion-section-header {
          background: #ffffff !important;
          border-bottom: 1px solid #e2e8f0 !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .accordion-section-header:hover,
        :global(.theme-light) .accordion-section-header:hover {
          background: #f8fafc !important;
        }

        .techlab-gutenberg-root.theme-light .accordion-section-body,
        :global(.theme-light) .accordion-section-body {
          background: #ffffff !important;
        }

        .techlab-gutenberg-root.theme-light input[type="text"],
        .techlab-gutenberg-root.theme-light input[type="url"],
        .techlab-gutenberg-root.theme-light select,
        .techlab-gutenberg-root.theme-light textarea,
        :global(.theme-light) .techlab-gutenberg-root input[type="text"],
        :global(.theme-light) .techlab-gutenberg-root input[type="url"],
        :global(.theme-light) .techlab-gutenberg-root select,
        :global(.theme-light) .techlab-gutenberg-root textarea {
          background: #f8fafc !important;
          border: 1px solid #cbd5e1 !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .gutenberg-blocks-drawer,
        :global(.theme-light) .gutenberg-blocks-drawer {
          background: #ffffff !important;
          border-right: 1px solid #e2e8f0 !important;
          box-shadow: 10px 0 30px rgba(0, 0, 0, 0.05) !important;
        }

        .techlab-gutenberg-root.theme-light .drawer-header-bar,
        :global(.theme-light) .drawer-header-bar {
          background: #f8fafc !important;
          border-bottom: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .drawer-search-input,
        :global(.theme-light) .drawer-search-input {
          background: #f8fafc !important;
          border: 1px solid #cbd5e1 !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .block-library-card,
        :global(.theme-light) .block-library-card {
          background: #f8fafc !important;
          border: 1px solid #e2e8f0 !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .block-library-card:hover,
        :global(.theme-light) .block-library-card:hover {
          background: #f1f5f9 !important;
          border-color: #16c96f !important;
        }

        /* SEO Suite */
        .techlab-gutenberg-root.theme-light .techlab-pro-seo-suite,
        :global(.theme-light) .techlab-pro-seo-suite {
          background: #ffffff !important;
          border: 1px solid #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        .techlab-gutenberg-root.theme-light .seo-suite-top-bar,
        :global(.theme-light) .seo-suite-top-bar {
          background: #f8fafc !important;
          border-bottom: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .suite-icon-badge,
        :global(.theme-light) .suite-icon-badge {
          background: #ffffff !important;
          border: 1px solid #cbd5e1 !important;
        }

        .techlab-gutenberg-root.theme-light .suite-title-area h3,
        :global(.theme-light) .suite-title-area h3 {
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .suite-title-area p,
        :global(.theme-light) .suite-title-area p {
          color: #64748b !important;
        }

        .techlab-gutenberg-root.theme-light .suite-score-badge-card,
        :global(.theme-light) .suite-score-badge-card {
          background: #ffffff !important;
          border: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .seo-suite-tabs-nav,
        :global(.theme-light) .seo-suite-tabs-nav {
          background: #f8fafc !important;
          border-bottom: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .seo-nav-tab,
        :global(.theme-light) .seo-nav-tab {
          color: #64748b !important;
        }

        .techlab-gutenberg-root.theme-light .seo-nav-tab.active,
        :global(.theme-light) .seo-nav-tab.active {
          color: #0d9651 !important;
          background: #ffffff !important;
          border-bottom: 2px solid #16c96f !important;
        }

        .techlab-gutenberg-root.theme-light .google-serp-master-card,
        :global(.theme-light) .google-serp-master-card {
          background: #ffffff !important;
          border: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .google-snippet-frame,
        :global(.theme-light) .google-snippet-frame {
          background: #f8fafc !important;
          border: 1px solid #e2e8f0 !important;
        }

        .techlab-gutenberg-root.theme-light .brand-name,
        :global(.theme-light) .brand-name {
          color: #1e293b !important;
        }

        .techlab-gutenberg-root.theme-light .url-path,
        :global(.theme-light) .url-path {
          color: #475569 !important;
        }

        .techlab-gutenberg-root.theme-light .snippet-heading,
        :global(.theme-light) .snippet-heading {
          color: #1a0dab !important;
        }

        .techlab-gutenberg-root.theme-light .snippet-text,
        :global(.theme-light) .snippet-text {
          color: #4d5156 !important;
        }

        .techlab-gutenberg-root.theme-light .field-meta-info label,
        :global(.theme-light) .field-meta-info label {
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .field-meta-info p,
        :global(.theme-light) .field-meta-info p {
          color: #64748b !important;
        }

        .techlab-gutenberg-root.theme-light .wide-seo-input,
        .techlab-gutenberg-root.theme-light .wide-seo-textarea,
        :global(.theme-light) .wide-seo-input,
        :global(.theme-light) .wide-seo-textarea {
          background: #ffffff !important;
          border: 1px solid #cbd5e1 !important;
          color: #0f172a !important;
        }

        .techlab-gutenberg-root.theme-light .gutenberg-floating-block-toolbar,
        :global(.theme-light) .gutenberg-floating-block-toolbar {
          background: #ffffff !important;
          border: 1px solid #e2e8f0 !important;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1) !important;
        }

        .techlab-gutenberg-root.theme-light .tb-btn,
        :global(.theme-light) .tb-btn {
          color: #334155 !important;
        }

        .techlab-gutenberg-root.theme-light .gutenberg-tb-popover,
        :global(.theme-light) .gutenberg-tb-popover {
          background: #ffffff !important;
          border: 1px solid #e2e8f0 !important;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12) !important;
        }

        .techlab-gutenberg-root.theme-light .popover-item,
        :global(.theme-light) .popover-item {
          color: #334155 !important;
        }

        .techlab-gutenberg-root.theme-light .editor-footer-status-bar,
        :global(.theme-light) .editor-footer-status-bar {
          background: #ffffff !important;
          border-top: 1px solid #e2e8f0 !important;
          color: #64748b !important;
        }

        /* =================================================================
           ELEMENTOR BANNER & ACCIONES EN EDITOR ESTÁNDAR
           ================================================================= */
        .topbar-elementor-btn {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          background: #d63384;
          color: #ffffff !important;
          font-size: 12px;
          font-weight: 700;
          padding: 6px 13px;
          border-radius: 6px;
          text-decoration: none;
          transition: all 0.2s ease;
          box-shadow: 0 2px 8px rgba(214, 51, 132, 0.35);
        }
        .topbar-elementor-btn:hover {
          background: #e83e8c;
          transform: translateY(-1px);
          box-shadow: 0 4px 12px rgba(214, 51, 132, 0.5);
        }
        .elementor-pill-small {
          width: 17px;
          height: 17px;
          background: #ffffff;
          color: #d63384;
          font-weight: 900;
          font-size: 11px;
          border-radius: 3px;
          display: grid;
          place-items: center;
        }

        .elementor-active-canvas-card {
          margin: 24px 0 32px;
          padding: 48px 32px;
          background: #040e1a;
          border: 1px solid rgba(214, 51, 132, 0.3);
          border-radius: 12px;
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          box-shadow: 0 10px 40px rgba(0, 0, 0, 0.4), 0 0 20px rgba(214, 51, 132, 0.08);
        }
        .elementor-card-badge-row {
          display: flex;
          align-items: center;
          gap: 10px;
          margin-bottom: 16px;
        }
        .elementor-card-logo {
          width: 44px;
          height: 44px;
          background: #d63384;
          color: #ffffff;
          font-size: 24px;
          font-weight: 900;
          border-radius: 10px;
          display: grid;
          place-items: center;
          box-shadow: 0 4px 16px rgba(214, 51, 132, 0.5);
        }
        .elementor-card-tag {
          background: rgba(214, 51, 132, 0.15);
          color: #f472b6;
          border: 1px solid rgba(214, 51, 132, 0.35);
          font-size: 11px;
          font-weight: 700;
          padding: 4px 10px;
          border-radius: 20px;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        .elementor-card-title {
          font-size: 22px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 10px;
        }
        .elementor-card-desc {
          font-size: 14px;
          color: #94a3b8;
          max-width: 520px;
          line-height: 1.6;
          margin: 0 0 26px;
        }
        .elementor-card-btn-row {
          display: flex;
          align-items: center;
          gap: 14px;
          flex-wrap: wrap;
          justify-content: center;
        }
        .btn-launch-elementor-editor {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: #d63384;
          color: #ffffff !important;
          font-size: 14px;
          font-weight: 800;
          padding: 12px 26px;
          border-radius: 8px;
          text-decoration: none;
          transition: all 0.2s ease;
          box-shadow: 0 4px 16px rgba(214, 51, 132, 0.4);
        }
        .btn-launch-elementor-editor:hover {
          background: #e83e8c;
          transform: translateY(-2px);
          box-shadow: 0 6px 22px rgba(214, 51, 132, 0.6);
        }
        .btn-revert-gutenberg {
          background: transparent;
          border: 1px solid #334155;
          color: #94a3b8;
          font-size: 13px;
          font-weight: 600;
          padding: 11px 20px;
          border-radius: 8px;
          cursor: pointer;
          transition: all 0.15s ease;
        }
        .btn-revert-gutenberg:hover {
          background: rgba(255, 255, 255, 0.05);
          border-color: #64748b;
          color: #f1f5f9;
        }

        /* =================================================================
           PANEL DE PUBLICACIÓN LATERAL ESTILO WORDPRESS
           ================================================================= */
        .wp-publish-sidebar-panel {
          display: flex;
          flex-direction: column;
          height: 100%;
          min-height: 100%;
          background: #ffffff;
          color: #1e1e1e;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
        }
        :global(.theme-dark) .wp-publish-sidebar-panel,
        .techlab-gutenberg-root:not(.theme-light) .wp-publish-sidebar-panel {
          background: #1e1e1e;
          color: #f0f0f1;
        }

        .wp-pub-top-bar {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 12px 16px;
          border-bottom: 1px solid #e0e0e0;
          gap: 10px;
        }
        :global(.theme-dark) .wp-pub-top-bar,
        .techlab-gutenberg-root:not(.theme-light) .wp-pub-top-bar {
          border-bottom-color: #2c3338;
        }
        .wp-pub-top-bar.align-right {
          justify-content: flex-end;
        }

        .wp-btn-cancel-pub {
          padding: 6px 14px;
          background: #ffffff;
          border: 1.5px solid #2271b1;
          border-radius: 4px;
          color: #2271b1;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.15s ease;
        }
        .wp-btn-cancel-pub:hover:not(:disabled) {
          background: #f0f6fc;
        }
        .wp-btn-cancel-pub:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }
        :global(.theme-dark) .wp-btn-cancel-pub,
        .techlab-gutenberg-root:not(.theme-light) .wp-btn-cancel-pub {
          background: transparent;
          color: #3858e9;
          border-color: #3858e9;
        }

        .wp-btn-do-publish {
          padding: 6px 18px;
          background: #3858e9;
          border: 1.5px solid #3858e9;
          border-radius: 4px;
          color: #ffffff;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.15s ease;
        }
        .wp-btn-do-publish:hover:not(:disabled) {
          background: #2140d3;
        }
        .wp-btn-do-publish.is-busy {
          background: #3858e9;
          opacity: 0.85;
          cursor: wait;
        }

        .wp-btn-close-x {
          width: 32px;
          height: 32px;
          display: grid;
          place-items: center;
          background: transparent;
          border: none;
          color: #757575;
          cursor: pointer;
          border-radius: 4px;
        }
        .wp-btn-close-x:hover {
          background: rgba(0, 0, 0, 0.05);
          color: #1e1e1e;
        }
        :global(.theme-dark) .wp-btn-close-x:hover,
        .techlab-gutenberg-root:not(.theme-light) .wp-btn-close-x:hover {
          background: rgba(255, 255, 255, 0.1);
          color: #ffffff;
        }

        .wp-pub-body-content {
          flex: 1;
          padding: 20px 16px;
          overflow-y: auto;
          display: flex;
          flex-direction: column;
        }
        .wp-pub-body-content.is-loading-state {
          align-items: center;
          justify-content: center;
          min-height: 250px;
        }

        .wp-pub-spinner-ring {
          width: 38px;
          height: 38px;
          border: 3px solid rgba(56, 88, 233, 0.2);
          border-top-color: #3858e9;
          border-radius: 50%;
          animation: wpSpin 0.8s linear infinite;
        }
        @keyframes wpSpin {
          to { transform: rotate(360deg); }
        }

        .wp-pub-main-title {
          font-size: 15px;
          font-weight: 700;
          margin: 0 0 6px;
          color: inherit;
        }
        .wp-pub-sub-desc {
          font-size: 13px;
          color: #757575;
          margin: 0 0 20px;
          line-height: 1.4;
        }
        :global(.theme-dark) .wp-pub-sub-desc,
        .techlab-gutenberg-root:not(.theme-light) .wp-pub-sub-desc {
          color: #a7aaad;
        }

        .wp-pub-site-badge {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 10px 12px;
          background: #f0f0f1;
          border-radius: 6px;
          margin-bottom: 20px;
        }
        :global(.theme-dark) .wp-pub-site-badge,
        .techlab-gutenberg-root:not(.theme-light) .wp-pub-site-badge {
          background: #2c3338;
        }
        .wp-pub-site-icon {
          width: 36px;
          height: 36px;
          border-radius: 50%;
          background: #1e1e1e;
          color: #ffffff;
          display: grid;
          place-items: center;
        }
        :global(.theme-dark) .wp-pub-site-icon,
        .techlab-gutenberg-root:not(.theme-light) .wp-pub-site-icon {
          background: #ffffff;
          color: #1e1e1e;
        }
        .wp-pub-site-info {
          display: flex;
          flex-direction: column;
        }
        .wp-pub-site-info strong {
          font-size: 14px;
          font-weight: 600;
          color: inherit;
        }
        .wp-pub-site-info span {
          font-size: 12px;
          color: #757575;
        }
        :global(.theme-dark) .wp-pub-site-info span,
        .techlab-gutenberg-root:not(.theme-light) .wp-pub-site-info span {
          color: #a7aaad;
        }

        .wp-pub-checks-list {
          display: flex;
          flex-direction: column;
          border-top: 1px solid #e0e0e0;
        }
        :global(.theme-dark) .wp-pub-checks-list,
        .techlab-gutenberg-root:not(.theme-light) .wp-pub-checks-list {
          border-top-color: #2c3338;
        }
        .wp-pub-check-item {
          padding: 12px 0;
          border-bottom: 1px solid #e0e0e0;
        }
        :global(.theme-dark) .wp-pub-check-item,
        .techlab-gutenberg-root:not(.theme-light) .wp-pub-check-item {
          border-bottom-color: #2c3338;
        }
        .wp-pub-check-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
          font-size: 13px;
        }
        .wp-check-label {
          font-weight: 600;
          color: inherit;
        }
        .wp-check-val {
          color: #2271b1;
          font-weight: 500;
          cursor: pointer;
        }
        :global(.theme-dark) .wp-check-val,
        .techlab-gutenberg-root:not(.theme-light) .wp-check-val {
          color: #3858e9;
        }

        /* Post-Publish Notice */
        .wp-published-notice-card {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 10px 12px;
          border: 1px solid #2271b1;
          border-radius: 4px;
          margin-bottom: 24px;
          background: rgba(34, 113, 177, 0.06);
        }
        :global(.theme-dark) .wp-published-notice-card,
        .techlab-gutenberg-root:not(.theme-light) .wp-published-notice-card {
          border-color: #3858e9;
          background: rgba(56, 88, 233, 0.12);
        }
        .wp-published-link-pill {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          color: #2271b1;
          font-weight: 700;
          font-size: 13px;
          text-decoration: underline;
        }
        :global(.theme-dark) .wp-published-link-pill,
        .techlab-gutenberg-root:not(.theme-light) .wp-published-link-pill {
          color: #72aee6;
        }
        .wp-notice-caption {
          font-size: 13px;
          color: #757575;
        }
        :global(.theme-dark) .wp-notice-caption,
        .techlab-gutenberg-root:not(.theme-light) .wp-notice-caption {
          color: #c3c4c7;
        }

        .wp-whats-next-title {
          font-size: 14px;
          font-weight: 700;
          margin: 0 0 14px;
          color: inherit;
        }

        .wp-address-box-wrap {
          margin-bottom: 20px;
        }
        .wp-address-heading-label {
          font-size: 11px;
          font-weight: 700;
          color: #757575;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          margin-bottom: 6px;
          display: block;
        }
        :global(.theme-dark) .wp-address-heading-label,
        .techlab-gutenberg-root:not(.theme-light) .wp-address-heading-label {
          color: #a7aaad;
        }
        .wp-address-copy-row {
          display: flex;
          gap: 8px;
        }
        .wp-address-readonly-input {
          flex: 1;
          height: 36px;
          background: #f0f0f1;
          border: 1px solid #8c8f94;
          border-radius: 3px;
          padding: 0 10px;
          font-size: 12px;
          color: #1e1e1e;
        }
        :global(.theme-dark) .wp-address-readonly-input,
        .techlab-gutenberg-root:not(.theme-light) .wp-address-readonly-input {
          background: #2c3338;
          border-color: #50575e;
          color: #f0f0f1;
        }
        .wp-btn-copy-link {
          height: 36px;
          padding: 0 16px;
          background: #ffffff;
          border: 1.5px solid #2271b1;
          border-radius: 3px;
          color: #2271b1;
          font-size: 12px;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.15s ease;
        }
        .wp-btn-copy-link:hover {
          background: #f0f6fc;
        }
        :global(.theme-dark) .wp-btn-copy-link,
        .techlab-gutenberg-root:not(.theme-light) .wp-btn-copy-link {
          background: transparent;
          color: #72aee6;
          border-color: #3858e9;
        }

        .wp-published-buttons-stack {
          display: flex;
          flex-direction: column;
          gap: 10px;
          margin-top: 6px;
        }
        .wp-btn-view-live-page {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          height: 40px;
          background: #3858e9;
          color: #ffffff !important;
          font-size: 13px;
          font-weight: 700;
          border-radius: 4px;
          text-decoration: none;
          transition: background 0.15s ease;
        }
        .wp-btn-view-live-page:hover {
          background: #2140d3;
        }
        .wp-btn-add-new-page {
          display: flex;
          align-items: center;
          justify-content: center;
          height: 40px;
          background: #ffffff;
          border: 1.5px solid #2271b1;
          color: #2271b1 !important;
          font-size: 13px;
          font-weight: 700;
          border-radius: 4px;
          text-decoration: none;
          transition: all 0.15s ease;
        }
        .wp-btn-add-new-page:hover {
          background: #f0f6fc;
        }
        :global(.theme-dark) .wp-btn-add-new-page,
        .techlab-gutenberg-root:not(.theme-light) .wp-btn-add-new-page {
          background: transparent;
          color: #72aee6 !important;
          border-color: #3858e9;
        }

        .wp-pub-bottom-footer {
          margin-top: auto;
          padding: 16px;
          border-top: 1px solid #e0e0e0;
        }
        :global(.theme-dark) .wp-pub-bottom-footer,
        .techlab-gutenberg-root:not(.theme-light) .wp-pub-bottom-footer {
          border-top-color: #2c3338;
        }
        .wp-pub-checkbox-label {
          display: flex;
          align-items: flex-start;
          gap: 8px;
          font-size: 12px;
          color: #757575;
          cursor: pointer;
          line-height: 1.4;
        }
        :global(.theme-dark) .wp-pub-checkbox-label,
        .techlab-gutenberg-root:not(.theme-light) .wp-pub-checkbox-label {
          color: #a7aaad;
        }
        .wp-pub-checkbox-label input {
          margin-top: 2px;
          cursor: pointer;
          accent-color: #3858e9;
        }

        @media (max-width: 860px) {
          .form-field-row {
            grid-template-columns: 1fr;
            gap: 10px;
          }
          .audit-cards-grid {
            grid-template-columns: 1fr;
          }
        }
      `}</style>
    </div>
  );
}

export default function NuevoPaginaPage() {
  return (
    <Suspense
      fallback={
        <div
          style={{
            minHeight: "100vh",
            display: "grid",
            placeItems: "center",
            background: "#030a10",
            color: "#16c96f",
            fontSize: "14px",
            fontWeight: 600,
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <Loader2 className="animate-spin" style={{ width: 20, height: 20 }} />
            <span>Cargando Editor de Páginas...</span>
          </div>
        </div>
      }
    >
      <NuevoPaginaPageContent />
    </Suspense>
  );
}
