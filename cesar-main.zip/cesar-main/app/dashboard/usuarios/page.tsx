"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import {
  Users,
  UserPlus,
  Search,
  Filter,
  Shield,
  ShieldCheck,
  ShieldAlert,
  User,
  Mail,
  KeyRound,
  Edit2,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  X,
  UploadCloud,
  Eye,
  EyeOff,
  Copy,
  Check,
  FileText,
  Calendar,
  Lock,
  RefreshCw,
  Loader2,
  Sparkles,
  Camera,
  Image as ImageIcon,
} from "lucide-react";

// Preset de Avatares CyberTech para selección rápida
const PRESET_AVATARS = [
  "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80",
];

interface UserItem {
  id: string;
  name: string;
  lastName?: string | null;
  email: string;
  avatar?: string | null;
  role: "ADMIN" | "MODERADOR" | "USUARIO";
  createdAt: string;
  updatedAt: string;
  _count?: {
    posts: number;
    pages: number;
  };
}

export default function UsersManagementPage() {
  const [users, setUsers] = useState<UserItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [roleFilter, setRoleFilter] = useState<string>("ALL");

  // Notificaciones Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<"success" | "error">("success");

  // Modal de Crear / Editar Usuario
  const [showUserModal, setShowUserModal] = useState<boolean>(false);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Campos del Formulario
  const [formName, setFormName] = useState<string>("");
  const [formLastName, setFormLastName] = useState<string>("");
  const [formEmail, setFormEmail] = useState<string>("");
  const [formPassword, setFormPassword] = useState<string>("");
  const [formRole, setFormRole] = useState<"ADMIN" | "MODERADOR" | "USUARIO">("USUARIO");
  const [formAvatar, setFormAvatar] = useState<string>("");
  const [showPasswordText, setShowPasswordText] = useState<boolean>(false);

  // Subida de Foto / Avatar
  const [isUploadingAvatar, setIsUploadingAvatar] = useState<boolean>(false);
  const avatarInputRef = useRef<HTMLInputElement>(null);

  // Modal de Eliminación
  const [showDeleteModal, setShowDeleteModal] = useState<boolean>(false);
  const [userToDelete, setUserToDelete] = useState<UserItem | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // Estado para copiar correos
  const [copiedEmailId, setCopiedEmailId] = useState<string | null>(null);

  const showToast = (msg: string, type: "success" | "error" = "success") => {
    setToastMessage(msg);
    setToastType(type);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Cargar usuarios desde la API
  const loadUsers = useCallback(async () => {
    setIsLoading(true);
    try {
      let url = "/api/users";
      const params = new URLSearchParams();
      if (searchQuery.trim()) params.append("q", searchQuery.trim());
      if (roleFilter !== "ALL") params.append("role", roleFilter);
      if (params.toString()) url += `?${params.toString()}`;

      const res = await fetch(url);
      const data = await res.json();
      if (data.success) {
        setUsers(data.users || []);
      } else {
        showToast(data.error || "Error al cargar usuarios.", "error");
      }
    } catch (e) {
      console.error(e);
      showToast("Error de conexión al cargar usuarios.", "error");
    } finally {
      setIsLoading(false);
    }
  }, [searchQuery, roleFilter]);

  useEffect(() => {
    loadUsers();
  }, [loadUsers]);

  // Abrir Modal para Crear
  const handleOpenCreateModal = () => {
    setIsEditing(false);
    setEditingUserId(null);
    setFormName("");
    setFormLastName("");
    setFormEmail("");
    setFormPassword("");
    setFormRole("USUARIO");
    setFormAvatar("");
    setShowPasswordText(false);
    setShowUserModal(true);
  };

  // Abrir Modal para Editar
  const handleOpenEditModal = (u: UserItem) => {
    setIsEditing(true);
    setEditingUserId(u.id);
    setFormName(u.name || "");
    setFormLastName(u.lastName || "");
    setFormEmail(u.email || "");
    setFormPassword(""); // Vacío a menos que se desee cambiar
    setFormRole(u.role);
    setFormAvatar(u.avatar || "");
    setShowPasswordText(false);
    setShowUserModal(true);
  };

  // Subir Foto de Perfil vía /api/upload
  const handleUploadAvatar = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingAvatar(true);
    try {
      const formData = new FormData();
      formData.append("file", file);

      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      if (data.url) {
        setFormAvatar(data.url);
        showToast("Foto de perfil cargada correctamente.", "success");
      } else {
        showToast(data.error || "Error al subir la imagen.", "error");
      }
    } catch (err) {
      console.error(err);
      showToast("Error al subir archivo de imagen.", "error");
    } finally {
      setIsUploadingAvatar(false);
      if (avatarInputRef.current) avatarInputRef.current.value = "";
    }
  };

  // Guardar / Actualizar Usuario
  const handleSubmitUser = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formName.trim()) {
      showToast("Por favor ingresa el nombre.", "error");
      return;
    }
    if (!formEmail.trim()) {
      showToast("Por favor ingresa el correo electrónico.", "error");
      return;
    }

    if (!isEditing && (!formPassword || formPassword.length < 6)) {
      showToast("La contraseña debe tener al menos 6 caracteres.", "error");
      return;
    }

    if (isEditing && formPassword && formPassword.length < 6) {
      showToast("La nueva contraseña debe tener al menos 6 caracteres.", "error");
      return;
    }

    setIsSubmitting(true);
    try {
      const payload: any = {
        name: formName.trim(),
        lastName: formLastName.trim() || null,
        email: formEmail.trim().toLowerCase(),
        role: formRole,
        avatar: formAvatar || null,
      };

      if (formPassword) {
        payload.password = formPassword;
      }

      let res;
      if (isEditing && editingUserId) {
        payload.id = editingUserId;
        res = await fetch("/api/users", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      } else {
        res = await fetch("/api/users", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      }

      const data = await res.json();
      if (data.success) {
        showToast(data.message || "Usuario guardado exitosamente.", "success");
        setShowUserModal(false);
        loadUsers();
      } else {
        showToast(data.error || "Ocurrió un error al procesar el usuario.", "error");
      }
    } catch (err) {
      console.error(err);
      showToast("Error de conexión con el servidor.", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Abrir Modal de Eliminación
  const handleOpenDeleteModal = (u: UserItem) => {
    setUserToDelete(u);
    setShowDeleteModal(true);
  };

  // Confirmar Eliminación
  const handleConfirmDelete = async () => {
    if (!userToDelete) return;
    setIsDeleting(true);
    try {
      const res = await fetch(`/api/users?id=${userToDelete.id}`, {
        method: "DELETE",
      });
      const data = await res.json();
      if (data.success) {
        showToast(data.message || "Usuario eliminado correctamente.", "success");
        setShowDeleteModal(false);
        setUserToDelete(null);
        loadUsers();
      } else {
        showToast(data.error || "No se pudo eliminar el usuario.", "error");
      }
    } catch (err) {
      console.error(err);
      showToast("Error al conectar con el servidor.", "error");
    } finally {
      setIsDeleting(false);
    }
  };

  // Copiar Correo al Portapapeles
  const handleCopyEmail = (email: string, id: string) => {
    navigator.clipboard.writeText(email);
    setCopiedEmailId(id);
    showToast("Correo copiado al portapapeles.", "success");
    setTimeout(() => setCopiedEmailId(null), 2500);
  };

  // Métricas rápidas
  const totalCount = users.length;
  const adminCount = users.filter((u) => u.role === "ADMIN").length;
  const modCount = users.filter((u) => u.role === "MODERADOR").length;
  const userCount = users.filter((u) => u.role === "USUARIO").length;

  return (
    <div className="techlab-users-dashboard">
      {/* Toast Notification */}
      {toastMessage && (
        <div className={`techlab-toast ${toastType}`}>
          {toastType === "success" ? <CheckCircle2 /> : <AlertTriangle />}
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Cabecera Superior */}
      <div className="users-header-bar">
        <div className="header-title-group">
          <div className="header-icon-badge">
            <Users />
          </div>
          <div>
            <h1>Gestión de Usuarios y Roles</h1>
            <p>Administra las cuentas de acceso, roles, correos, fotos y contraseñas de la plataforma</p>
          </div>
        </div>

        <button
          type="button"
          className="btn-create-user-neon"
          onClick={handleOpenCreateModal}
        >
          <UserPlus />
          <span>Agregar Nuevo Usuario</span>
        </button>
      </div>

      {/* KPI Cards / Métricas Rápidas */}
      <section className="users-kpi-grid">
        <div className="kpi-card total">
          <div className="kpi-icon-box">
            <Users />
          </div>
          <div className="kpi-info">
            <span className="kpi-num">{totalCount}</span>
            <span className="kpi-label">Total Usuarios</span>
          </div>
        </div>

        <div className="kpi-card admin">
          <div className="kpi-icon-box">
            <ShieldCheck />
          </div>
          <div className="kpi-info">
            <span className="kpi-num">{adminCount}</span>
            <span className="kpi-label">Administradores</span>
          </div>
        </div>

        <div className="kpi-card mod">
          <div className="kpi-icon-box">
            <ShieldAlert />
          </div>
          <div className="kpi-info">
            <span className="kpi-num">{modCount}</span>
            <span className="kpi-label">Moderadores</span>
          </div>
        </div>

        <div className="kpi-card standard">
          <div className="kpi-icon-box">
            <User />
          </div>
          <div className="kpi-info">
            <span className="kpi-num">{userCount}</span>
            <span className="kpi-label">Usuarios Estándar</span>
          </div>
        </div>
      </section>

      {/* Barra de Búsqueda y Filtros */}
      <div className="users-filter-bar">
        <div className="search-input-wrapper">
          <Search />
          <input
            type="text"
            placeholder="Buscar usuario por nombre, apellido o correo..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <button
              type="button"
              className="clear-search-btn"
              onClick={() => setSearchQuery("")}
            >
              <X />
            </button>
          )}
        </div>

        <div className="filter-controls-group">
          <div className="role-filter-select-wrapper">
            <Filter />
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="role-dropdown-select"
            >
              <option value="ALL">Todos los roles</option>
              <option value="ADMIN">Administradores</option>
              <option value="MODERADOR">Moderadores</option>
              <option value="USUARIO">Usuarios estándar</option>
            </select>
          </div>

          <button
            type="button"
            className="btn-refresh-data"
            onClick={loadUsers}
            title="Refrescar lista"
          >
            <RefreshCw className={isLoading ? "animate-spin" : ""} />
          </button>
        </div>
      </div>

      {/* Tabla de Usuarios */}
      <div className="users-table-master-card">
        {isLoading ? (
          <div className="loading-state-container">
            <Loader2 className="animate-spin" />
            <span>Cargando...</span>
          </div>
        ) : users.length === 0 ? (
          <div className="empty-users-container">
            <Users />
            <h3>No se encontraron usuarios</h3>
            <p>Intenta ajustar los criterios de búsqueda o agrega un nuevo usuario con el botón superior.</p>
            <button
              type="button"
              className="btn-create-empty"
              onClick={handleOpenCreateModal}
            >
              <UserPlus />
              <span>Crear primer usuario</span>
            </button>
          </div>
        ) : (
          <div className="table-responsive-wrapper">
            <table className="techlab-users-table">
              <thead>
                <tr>
                  <th>Usuario</th>
                  <th>Correo Electrónico</th>
                  <th>Rol</th>
                  <th>Publicaciones / Páginas</th>
                  <th>Fecha de Registro</th>
                  <th className="text-right">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => {
                  const initials =
                    (u.name ? u.name.charAt(0) : "U") +
                    (u.lastName ? u.lastName.charAt(0) : "");
                  const formattedDate = new Date(u.createdAt).toLocaleDateString("es-ES", {
                    day: "2-digit",
                    month: "short",
                    year: "numeric",
                  });

                  return (
                    <tr key={u.id}>
                      {/* Avatar y Nombre Completo */}
                      <td>
                        <div className="user-profile-cell">
                          <div className="user-avatar-circle">
                            {u.avatar ? (
                              <img src={u.avatar} alt={u.name} className="avatar-img" />
                            ) : (
                              <span className="avatar-initials">{initials.toUpperCase()}</span>
                            )}
                          </div>
                          <div className="user-name-col">
                            <span className="user-full-name">
                              {u.name} {u.lastName || ""}
                            </span>
                            <small className="user-id-sub">ID: {u.id.substring(0, 8)}...</small>
                          </div>
                        </div>
                      </td>

                      {/* Correo con botón copiar */}
                      <td>
                        <div className="user-email-cell">
                          <span className="email-text">{u.email}</span>
                          <button
                            type="button"
                            className="btn-copy-email"
                            onClick={() => handleCopyEmail(u.email, u.id)}
                            title="Copiar correo"
                          >
                            {copiedEmailId === u.id ? (
                              <Check className="copied-check" />
                            ) : (
                              <Copy />
                            )}
                          </button>
                        </div>
                      </td>

                      {/* Badge de Rol */}
                      <td>
                        <span className={`role-badge ${u.role.toLowerCase()}`}>
                          {u.role === "ADMIN" && <ShieldCheck />}
                          {u.role === "MODERADOR" && <ShieldAlert />}
                          {u.role === "USUARIO" && <User />}
                          <span>{u.role}</span>
                        </span>
                      </td>

                      {/* Contadores */}
                      <td>
                        <div className="author-counts-cell">
                          <span className="count-pill posts" title="Posts creados">
                            {u._count?.posts || 0} posts
                          </span>
                          <span className="count-pill pages" title="Páginas creadas">
                            {u._count?.pages || 0} páginas
                          </span>
                        </div>
                      </td>

                      {/* Fecha */}
                      <td>
                        <span className="date-text">
                          <Calendar className="date-icon" />
                          {formattedDate}
                        </span>
                      </td>

                      {/* Botones de Acción */}
                      <td className="text-right">
                        <div className="action-buttons-group">
                          <button
                            type="button"
                            className="btn-action-edit"
                            onClick={() => handleOpenEditModal(u)}
                            title="Editar usuario y credenciales"
                          >
                            <Edit2 />
                            <span>Editar</span>
                          </button>

                          <button
                            type="button"
                            className="btn-action-delete"
                            onClick={() => handleOpenDeleteModal(u)}
                            title="Eliminar usuario"
                          >
                            <Trash2 />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* =================================================================
          MODAL: CREAR O EDITAR USUARIO
          ================================================================= */}
      {showUserModal && (
        <div className="techlab-modal-backdrop" onClick={() => setShowUserModal(false)}>
          <div className="user-form-modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="modal-top-header">
              <div className="modal-title-row">
                <div className="modal-header-icon">
                  {isEditing ? <Edit2 /> : <UserPlus />}
                </div>
                <div>
                  <h3>{isEditing ? "Editar Usuario y Credenciales" : "Crear Nuevo Usuario"}</h3>
                  <p>Configura el perfil, asigna su rol de acceso y gestiona sus contraseñas</p>
                </div>
              </div>
              <button
                type="button"
                className="btn-close-modal"
                onClick={() => setShowUserModal(false)}
              >
                <X />
              </button>
            </div>

            <form onSubmit={handleSubmitUser} className="modal-form-body">
              {/* Sección Avatar / Foto de Perfil */}
              <div className="avatar-picker-section">
                <div className="avatar-preview-box">
                  {formAvatar ? (
                    <img src={formAvatar} alt="Avatar Preview" className="preview-img" />
                  ) : (
                    <div className="preview-placeholder">
                      <User />
                    </div>
                  )}
                  <button
                    type="button"
                    className="btn-change-avatar-floating"
                    onClick={() => avatarInputRef.current?.click()}
                    title="Subir foto de perfil"
                  >
                    <Camera />
                  </button>
                  <input
                    ref={avatarInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleUploadAvatar}
                    style={{ display: "none" }}
                  />
                </div>

                <div className="avatar-actions-info">
                  <span className="avatar-section-title">Foto de Perfil / Avatar</span>
                  <div className="avatar-buttons-row">
                    <button
                      type="button"
                      className="btn-upload-avatar"
                      onClick={() => avatarInputRef.current?.click()}
                      disabled={isUploadingAvatar}
                    >
                      {isUploadingAvatar ? (
                        <Loader2 className="animate-spin" />
                      ) : (
                        <UploadCloud />
                      )}
                      <span>{isUploadingAvatar ? "Subiendo..." : "Subir Foto"}</span>
                    </button>

                    {formAvatar && (
                      <button
                        type="button"
                        className="btn-remove-avatar"
                        onClick={() => setFormAvatar("")}
                      >
                        Quitar foto
                      </button>
                    )}
                  </div>

                  {/* Avatares rápidos preset */}
                  <div className="preset-avatars-row">
                    <small>O elige un avatar rápido:</small>
                    <div className="preset-dots">
                      {PRESET_AVATARS.map((url, idx) => (
                        <img
                          key={idx}
                          src={url}
                          alt="Preset Avatar"
                          className={`preset-thumb ${formAvatar === url ? "selected" : ""}`}
                          onClick={() => setFormAvatar(url)}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Cuadrícula de Campos Personales */}
              <div className="form-fields-grid">
                <div className="form-field-group">
                  <label>Nombre: *</label>
                  <div className="input-icon-box">
                    <User />
                    <input
                      type="text"
                      placeholder="ej. Cesar"
                      value={formName}
                      onChange={(e) => setFormName(e.target.value)}
                      required
                    />
                  </div>
                </div>

                <div className="form-field-group">
                  <label>Apellido:</label>
                  <div className="input-icon-box">
                    <User />
                    <input
                      type="text"
                      placeholder="ej. Rodriguez"
                      value={formLastName}
                      onChange={(e) => setFormLastName(e.target.value)}
                    />
                  </div>
                </div>

                <div className="form-field-group full-width">
                  <label>Correo Electrónico: *</label>
                  <div className="input-icon-box">
                    <Mail />
                    <input
                      type="email"
                      placeholder="correo@ejemplo.com"
                      value={formEmail}
                      onChange={(e) => setFormEmail(e.target.value)}
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Selector de Roles con Tarjetas Visuales */}
              <div className="roles-selector-section">
                <label className="section-label">Rol en la Plataforma: *</label>
                <div className="roles-cards-grid">
                  <label className={`role-select-card admin ${formRole === "ADMIN" ? "selected" : ""}`}>
                    <input
                      type="radio"
                      name="userRole"
                      value="ADMIN"
                      checked={formRole === "ADMIN"}
                      onChange={() => setFormRole("ADMIN")}
                    />
                    <div className="role-card-header">
                      <ShieldCheck />
                      <strong>ADMINISTRADOR</strong>
                    </div>
                    <p>Acceso total al sistema, posts, páginas, menús, usuarios y ajustes.</p>
                  </label>

                  <label className={`role-select-card moderador ${formRole === "MODERADOR" ? "selected" : ""}`}>
                    <input
                      type="radio"
                      name="userRole"
                      value="MODERADOR"
                      checked={formRole === "MODERADOR"}
                      onChange={() => setFormRole("MODERADOR")}
                    />
                    <div className="role-card-header">
                      <ShieldAlert />
                      <strong>MODERADOR</strong>
                    </div>
                    <p>Puede redactar, editar y moderar publicaciones y páginas.</p>
                  </label>

                  <label className={`role-select-card usuario ${formRole === "USUARIO" ? "selected" : ""}`}>
                    <input
                      type="radio"
                      name="userRole"
                      value="USUARIO"
                      checked={formRole === "USUARIO"}
                      onChange={() => setFormRole("USUARIO")}
                    />
                    <div className="role-card-header">
                      <User />
                      <strong>USUARIO</strong>
                    </div>
                    <p>Perfil de suscriptor con permisos de lectura y comentarios.</p>
                  </label>
                </div>
              </div>

              {/* Sección de Seguridad y Contraseña */}
              <div className="security-password-section">
                <div className="security-section-title">
                  <KeyRound />
                  <span>Seguridad y Contraseña</span>
                </div>

                <div className="form-field-group">
                  <label>
                    {isEditing
                      ? "Cambiar Contraseña (dejar en blanco para mantener la actual):"
                      : "Contraseña de Acceso: *"}
                  </label>
                  <div className="input-icon-box">
                    <Lock />
                    <input
                      type={showPasswordText ? "text" : "password"}
                      placeholder={
                        isEditing ? "•••••••• (Ingresa nueva clave solo si deseas cambiarla)" : "Mínimo 6 caracteres"
                      }
                      value={formPassword}
                      onChange={(e) => setFormPassword(e.target.value)}
                      required={!isEditing}
                    />
                    <button
                      type="button"
                      className="btn-toggle-eye"
                      onClick={() => setShowPasswordText(!showPasswordText)}
                      title="Ver / Ocultar contraseña"
                    >
                      {showPasswordText ? <EyeOff /> : <Eye />}
                    </button>
                  </div>
                </div>
              </div>

              {/* Footer de Acciones del Modal */}
              <div className="modal-bottom-actions">
                <button
                  type="button"
                  className="btn-cancel-modal"
                  onClick={() => setShowUserModal(false)}
                  disabled={isSubmitting}
                >
                  Cancelar
                </button>

                <button
                  type="submit"
                  className="btn-submit-user-neon"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? <Loader2 className="animate-spin" /> : <Check />}
                  <span>{isSubmitting ? "Guardando en BD..." : isEditing ? "Actualizar Usuario" : "Crear Usuario"}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =================================================================
          MODAL: CONFIRMACIÓN DE ELIMINACIÓN DE USUARIO
          ================================================================= */}
      {showDeleteModal && userToDelete && (
        <div className="techlab-modal-backdrop" onClick={() => setShowDeleteModal(false)}>
          <div className="delete-modal-card-animated" onClick={(e) => e.stopPropagation()}>
            <div className="delete-icon-animated-badge">
              <Trash2 />
            </div>
            <h3>¿Seguro que quieres eliminar este usuario?</h3>
            <p>
              Esta acción es irreversible y eliminará la cuenta de{" "}
              <strong>
                {userToDelete.name} ({userToDelete.email})
              </strong>{" "}
              de la base de datos MySQL.
            </p>

            <div className="delete-modal-buttons">
              <button
                type="button"
                className="btn-cancel-delete"
                onClick={() => setShowDeleteModal(false)}
                disabled={isDeleting}
              >
                Cancelar
              </button>
              <button
                type="button"
                className="btn-confirm-delete"
                onClick={handleConfirmDelete}
                disabled={isDeleting}
              >
                {isDeleting ? "Eliminando..." : "Sí, eliminar usuario"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ESTILOS TECHLAB CYBER DARK PRO */}
      <style jsx>{`
        .techlab-users-dashboard {
          padding: 0 0 40px;
          color: inherit;
        }

        /* Toast */
        .techlab-toast {
          position: fixed;
          top: 70px;
          right: 24px;
          z-index: 1000;
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 12px 18px;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 600;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.6);
          animation: slideIn 0.25s ease;
        }

        .techlab-toast.success {
          background: #062316;
          border: 1px solid #16c96f;
          color: #a7f3d0;
        }

        .techlab-toast.error {
          background: #270d0d;
          border: 1px solid #ef4444;
          color: #fca5a5;
        }

        @keyframes slideIn {
          from { opacity: 0; transform: translateY(-16px); }
          to { opacity: 1; transform: translateY(0); }
        }

        /* Header */
        .users-header-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 24px;
        }

        .header-title-group {
          display: flex;
          align-items: center;
          gap: 14px;
        }

        .header-icon-badge {
          width: 48px;
          height: 48px;
          border-radius: 12px;
          background: rgba(22, 201, 111, 0.12);
          border: 1px solid rgba(22, 201, 111, 0.4);
          color: #16c96f;
          display: grid;
          place-items: center;
          box-shadow: 0 0 20px rgba(22, 201, 111, 0.2);
        }

        .header-icon-badge :global(svg) {
          width: 24px;
          height: 24px;
        }

        .header-title-group h1 {
          font-size: 22px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 4px;
          letter-spacing: -0.4px;
        }

        .header-title-group p {
          font-size: 13px;
          color: #94a3b8;
          margin: 0;
        }

        .btn-create-user-neon {
          height: 42px;
          padding: 0 20px;
          border-radius: 8px;
          background: linear-gradient(110deg, #12b85f, #18d878);
          border: 1px solid rgba(67, 255, 147, 0.4);
          color: #030b12;
          font-size: 13px;
          font-weight: 800;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          box-shadow: 0 0 20px rgba(22, 201, 111, 0.3);
          transition: all 0.15s ease;
        }

        .btn-create-user-neon:hover {
          transform: translateY(-2px);
          box-shadow: 0 0 26px rgba(22, 201, 111, 0.5);
        }

        .btn-create-user-neon :global(svg) {
          width: 16px;
          height: 16px;
        }

        /* KPI Grid */
        .users-kpi-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 16px;
          margin-bottom: 24px;
        }

        .kpi-card {
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          padding: 16px;
          display: flex;
          align-items: center;
          gap: 14px;
          transition: transform 0.15s, border-color 0.15s;
        }

        .kpi-card:hover {
          transform: translateY(-2px);
          border-color: rgba(255, 255, 255, 0.2);
        }

        .kpi-icon-box {
          width: 42px;
          height: 42px;
          border-radius: 8px;
          display: grid;
          place-items: center;
        }

        .kpi-icon-box :global(svg) {
          width: 20px;
          height: 20px;
        }

        .kpi-card.total .kpi-icon-box { background: rgba(56, 189, 248, 0.12); color: #38bdf8; }
        .kpi-card.admin .kpi-icon-box { background: rgba(22, 201, 111, 0.12); color: #16c96f; }
        .kpi-card.mod .kpi-icon-box { background: rgba(245, 158, 11, 0.12); color: #f59e0b; }
        .kpi-card.standard .kpi-icon-box { background: rgba(148, 163, 184, 0.12); color: #94a3b8; }

        .kpi-info {
          display: flex;
          flex-direction: column;
        }

        .kpi-num {
          font-size: 22px;
          font-weight: 800;
          color: #ffffff;
          line-height: 1.1;
        }

        .kpi-label {
          font-size: 11px;
          color: #94a3b8;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        /* Barra de Filtro */
        .users-filter-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          padding: 12px 18px;
          margin-bottom: 20px;
        }

        .search-input-wrapper {
          flex: 1;
          position: relative;
          display: flex;
          align-items: center;
        }

        .search-input-wrapper :global(svg) {
          position: absolute;
          left: 12px;
          width: 15px;
          height: 15px;
          color: #64748b;
        }

        .search-input-wrapper input {
          width: 100%;
          height: 38px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 0 36px;
          color: #ffffff;
          font-size: 13px;
          outline: none;
        }

        .search-input-wrapper input:focus {
          border-color: #38bdf8;
        }

        .clear-search-btn {
          position: absolute;
          right: 10px;
          background: none;
          border: none;
          color: #64748b;
          cursor: pointer;
        }

        .clear-search-btn :global(svg) {
          position: static;
          width: 14px;
          height: 14px;
        }

        .filter-controls-group {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .role-filter-select-wrapper {
          position: relative;
          display: flex;
          align-items: center;
        }

        .role-filter-select-wrapper :global(svg) {
          position: absolute;
          left: 10px;
          width: 13px;
          height: 13px;
          color: #64748b;
        }

        .role-dropdown-select {
          height: 38px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 0 14px 0 30px;
          color: #cbd5e1;
          font-size: 12px;
          font-weight: 600;
          outline: none;
          cursor: pointer;
        }

        .btn-refresh-data {
          width: 38px;
          height: 38px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          color: #94a3b8;
          display: grid;
          place-items: center;
          cursor: pointer;
        }

        .btn-refresh-data:hover {
          color: #38bdf8;
          border-color: #38bdf8;
        }

        .btn-refresh-data :global(svg) {
          width: 15px;
          height: 15px;
        }

        /* Tabla Master Card */
        .users-table-master-card {
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 12px;
          overflow: hidden;
        }

        .table-responsive-wrapper {
          overflow-x: auto;
        }

        .techlab-users-table {
          width: 100%;
          border-collapse: collapse;
          text-align: left;
        }

        .techlab-users-table th {
          background: #07131e;
          padding: 14px 18px;
          font-size: 11px;
          font-weight: 700;
          color: #94a3b8;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .techlab-users-table td {
          padding: 14px 18px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.05);
          font-size: 13px;
          vertical-align: middle;
        }

        .techlab-users-table tr:hover td {
          background: rgba(56, 189, 248, 0.02);
        }

        .text-right {
          text-align: right;
        }

        /* Celda de Usuario */
        .user-profile-cell {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .user-avatar-circle {
          width: 38px;
          height: 38px;
          border-radius: 50%;
          background: linear-gradient(135deg, #12b85f, #24a8ff);
          display: grid;
          place-items: center;
          overflow: hidden;
          flex-shrink: 0;
          border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .avatar-img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .avatar-initials {
          font-size: 12px;
          font-weight: 800;
          color: #ffffff;
        }

        .user-name-col {
          display: flex;
          flex-direction: column;
        }

        .user-full-name {
          font-size: 13px;
          font-weight: 700;
          color: #ffffff;
        }

        .user-id-sub {
          font-size: 10px;
          color: #64748b;
          font-family: monospace;
        }

        /* Celda Correo */
        .user-email-cell {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .email-text {
          color: #cbd5e1;
          font-size: 12px;
        }

        .btn-copy-email {
          background: none;
          border: none;
          color: #64748b;
          cursor: pointer;
          display: grid;
          place-items: center;
          padding: 2px;
        }

        .btn-copy-email:hover {
          color: #38bdf8;
        }

        .btn-copy-email :global(svg) {
          width: 13px;
          height: 13px;
        }

        .copied-check {
          color: #16c96f !important;
        }

        /* Badges de Rol */
        .role-badge {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          padding: 3px 10px;
          border-radius: 20px;
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.3px;
        }

        .role-badge :global(svg) {
          width: 12px;
          height: 12px;
        }

        .role-badge.admin {
          background: rgba(22, 201, 111, 0.15);
          color: #16c96f;
          border: 1px solid rgba(22, 201, 111, 0.3);
        }

        .role-badge.moderador {
          background: rgba(56, 189, 248, 0.15);
          color: #38bdf8;
          border: 1px solid rgba(56, 189, 248, 0.3);
        }

        .role-badge.usuario {
          background: rgba(148, 163, 184, 0.1);
          color: #94a3b8;
          border: 1px solid rgba(148, 163, 184, 0.2);
        }

        /* Contadores */
        .author-counts-cell {
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .count-pill {
          font-size: 11px;
          font-weight: 600;
          padding: 2px 8px;
          border-radius: 4px;
          background: rgba(255, 255, 255, 0.05);
          color: #cbd5e1;
        }

        /* Fecha */
        .date-text {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 12px;
          color: #94a3b8;
        }

        .date-icon {
          width: 13px;
          height: 13px;
          color: #64748b;
        }

        /* Acciones */
        .action-buttons-group {
          display: inline-flex;
          align-items: center;
          gap: 6px;
        }

        .btn-action-edit {
          height: 30px;
          padding: 0 10px;
          background: rgba(56, 189, 248, 0.08);
          border: 1px solid rgba(56, 189, 248, 0.3);
          border-radius: 5px;
          color: #38bdf8;
          font-size: 11px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          gap: 5px;
          cursor: pointer;
          transition: all 0.12s;
        }

        .btn-action-edit:hover {
          background: #38bdf8;
          color: #03080e;
        }

        .btn-action-edit :global(svg) {
          width: 12px;
          height: 12px;
        }

        .btn-action-delete {
          width: 30px;
          height: 30px;
          background: transparent;
          border: 1px solid rgba(239, 68, 68, 0.25);
          border-radius: 5px;
          color: #ef4444;
          display: grid;
          place-items: center;
          cursor: pointer;
          transition: all 0.12s;
        }

        .btn-action-delete:hover {
          background: rgba(239, 68, 68, 0.15);
          border-color: #ef4444;
        }

        .btn-action-delete :global(svg) {
          width: 13px;
          height: 13px;
        }

        /* Loading & Empty States */
        .loading-state-container,
        .empty-users-container {
          padding: 80px 20px;
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          gap: 12px;
          color: #64748b;
        }

        .empty-users-container :global(svg) {
          width: 42px;
          height: 42px;
          color: #38bdf8;
          opacity: 0.5;
        }

        .empty-users-container h3 {
          font-size: 17px;
          font-weight: 700;
          color: #cbd5e1;
          margin: 0;
        }

        .empty-users-container p {
          font-size: 13px;
          max-width: 400px;
          margin: 0;
        }

        .btn-create-empty {
          margin-top: 10px;
          height: 38px;
          padding: 0 18px;
          background: #16c96f;
          border: none;
          border-radius: 6px;
          color: #030b12;
          font-size: 12px;
          font-weight: 800;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
        }

        /* Modal Backdrop */
        .techlab-modal-backdrop {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.82);
          backdrop-filter: blur(5px);
          display: grid;
          place-items: center;
          z-index: 1000;
          padding: 20px;
          animation: fadeIn 0.15s ease;
        }

        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        /* Form Modal Card */
        .user-form-modal-card {
          width: 100%;
          max-width: 600px;
          max-height: 90vh;
          overflow-y: auto;
          background: #040c14;
          border: 1px solid rgba(56, 189, 248, 0.3);
          border-radius: 14px;
          box-shadow: 0 24px 70px rgba(0, 0, 0, 0.8), 0 0 30px rgba(56, 189, 248, 0.15);
          display: flex;
          flex-direction: column;
          animation: modalPop 0.2s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes modalPop {
          from { transform: scale(0.94); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }

        .modal-top-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 18px 24px;
          background: #07131e;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .modal-title-row {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .modal-header-icon {
          width: 40px;
          height: 40px;
          border-radius: 8px;
          background: rgba(56, 189, 248, 0.12);
          color: #38bdf8;
          display: grid;
          place-items: center;
        }

        .modal-header-icon :global(svg) {
          width: 20px;
          height: 20px;
        }

        .modal-title-row h3 {
          font-size: 16px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 2px;
        }

        .modal-title-row p {
          font-size: 12px;
          color: #94a3b8;
          margin: 0;
        }

        .btn-close-modal {
          background: none;
          border: none;
          color: #64748b;
          cursor: pointer;
        }

        .btn-close-modal:hover {
          color: #ffffff;
        }

        .modal-form-body {
          padding: 24px;
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        /* Avatar Picker */
        .avatar-picker-section {
          display: flex;
          align-items: center;
          gap: 20px;
          padding: 16px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.06);
          border-radius: 10px;
        }

        .avatar-preview-box {
          position: relative;
          width: 70px;
          height: 70px;
          border-radius: 50%;
          background: #03080e;
          border: 2px solid #38bdf8;
          overflow: hidden;
          flex-shrink: 0;
          display: grid;
          place-items: center;
        }

        .preview-img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .preview-placeholder {
          color: #64748b;
        }

        .preview-placeholder :global(svg) {
          width: 32px;
          height: 32px;
        }

        .btn-change-avatar-floating {
          position: absolute;
          bottom: 0;
          right: 0;
          width: 24px;
          height: 24px;
          border-radius: 50%;
          background: #38bdf8;
          border: none;
          color: #030a10;
          display: grid;
          place-items: center;
          cursor: pointer;
        }

        .btn-change-avatar-floating :global(svg) {
          width: 12px;
          height: 12px;
        }

        .avatar-actions-info {
          flex: 1;
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .avatar-section-title {
          font-size: 12px;
          font-weight: 700;
          color: #ffffff;
        }

        .avatar-buttons-row {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .btn-upload-avatar {
          height: 30px;
          padding: 0 12px;
          background: rgba(56, 189, 248, 0.12);
          border: 1px solid rgba(56, 189, 248, 0.3);
          border-radius: 5px;
          color: #38bdf8;
          font-size: 11px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
        }

        .btn-upload-avatar :global(svg) {
          width: 13px;
          height: 13px;
        }

        .btn-remove-avatar {
          background: none;
          border: none;
          color: #ef4444;
          font-size: 11px;
          cursor: pointer;
        }

        .preset-avatars-row {
          display: flex;
          flex-direction: column;
          gap: 4px;
          margin-top: 4px;
        }

        .preset-avatars-row small {
          font-size: 10px;
          color: #64748b;
        }

        .preset-dots {
          display: flex;
          gap: 6px;
        }

        .preset-thumb {
          width: 26px;
          height: 26px;
          border-radius: 50%;
          object-fit: cover;
          border: 1px solid rgba(255, 255, 255, 0.2);
          cursor: pointer;
          transition: transform 0.15s, border-color 0.15s;
        }

        .preset-thumb:hover,
        .preset-thumb.selected {
          transform: scale(1.15);
          border-color: #38bdf8;
        }

        /* Form Fields */
        .form-fields-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 14px;
        }

        .full-width {
          grid-column: span 2;
        }

        .form-field-group {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .form-field-group label {
          font-size: 11px;
          font-weight: 700;
          color: #cbd5e1;
        }

        .input-icon-box {
          position: relative;
          display: flex;
          align-items: center;
        }

        .input-icon-box :global(svg) {
          position: absolute;
          left: 12px;
          width: 15px;
          height: 15px;
          color: #64748b;
        }

        .input-icon-box input {
          width: 100%;
          height: 38px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 0 12px 0 36px;
          color: #ffffff;
          font-size: 13px;
          outline: none;
        }

        .input-icon-box input:focus {
          border-color: #38bdf8;
        }

        .btn-toggle-eye {
          position: absolute;
          right: 10px;
          background: none;
          border: none;
          color: #64748b;
          cursor: pointer;
        }

        .btn-toggle-eye :global(svg) {
          position: static;
          width: 15px;
          height: 15px;
        }

        /* Roles Selection */
        .roles-selector-section {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .section-label {
          font-size: 11px;
          font-weight: 700;
          color: #cbd5e1;
        }

        .roles-cards-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 10px;
        }

        .role-select-card {
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 8px;
          padding: 12px;
          display: flex;
          flex-direction: column;
          gap: 6px;
          cursor: pointer;
          position: relative;
          transition: all 0.15s;
        }

        .role-select-card input {
          display: none;
        }

        .role-select-card.selected {
          border-color: #16c96f;
          background: rgba(22, 201, 111, 0.06);
        }

        .role-select-card.selected.moderador {
          border-color: #38bdf8;
          background: rgba(56, 189, 248, 0.06);
        }

        .role-card-header {
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .role-card-header :global(svg) {
          width: 14px;
          height: 14px;
        }

        .role-select-card.admin .role-card-header { color: #16c96f; }
        .role-select-card.moderador .role-card-header { color: #38bdf8; }
        .role-select-card.usuario .role-card-header { color: #94a3b8; }

        .role-card-header strong {
          font-size: 11px;
          letter-spacing: 0.3px;
        }

        .role-select-card p {
          font-size: 10px;
          color: #94a3b8;
          margin: 0;
          line-height: 1.35;
        }

        /* Password Security Section */
        .security-password-section {
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.06);
          border-radius: 10px;
          padding: 16px;
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .security-section-title {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 12px;
          font-weight: 700;
          color: #f1f5f9;
        }

        .security-section-title :global(svg) {
          width: 14px;
          height: 14px;
          color: #38bdf8;
        }

        /* Modal Bottom Actions */
        .modal-bottom-actions {
          display: flex;
          align-items: center;
          justify-content: flex-end;
          gap: 10px;
          padding-top: 10px;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
        }

        .btn-cancel-modal {
          height: 38px;
          padding: 0 16px;
          background: transparent;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          color: #cbd5e1;
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
        }

        .btn-submit-user-neon {
          height: 40px;
          padding: 0 20px;
          background: linear-gradient(110deg, #12b85f, #18d878);
          border: 1px solid rgba(67, 255, 147, 0.4);
          border-radius: 6px;
          color: #030b12;
          font-size: 12px;
          font-weight: 800;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          box-shadow: 0 0 18px rgba(22, 201, 111, 0.3);
        }

        .btn-submit-user-neon:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }

        /* Modal Delete */
        .delete-modal-card-animated {
          width: 90%;
          max-width: 440px;
          background: #040c14;
          border: 1px solid rgba(239, 68, 68, 0.4);
          border-radius: 12px;
          padding: 24px;
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.8), 0 0 30px rgba(239, 68, 68, 0.2);
          animation: popIn 0.2s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes popIn {
          from { transform: scale(0.9); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }

        .delete-icon-animated-badge {
          width: 52px;
          height: 52px;
          border-radius: 50%;
          background: rgba(239, 68, 68, 0.15);
          border: 1px solid #ef4444;
          color: #ef4444;
          display: grid;
          place-items: center;
          margin-bottom: 14px;
        }

        .delete-icon-animated-badge :global(svg) {
          width: 24px;
          height: 24px;
        }

        .delete-modal-card-animated h3 {
          font-size: 17px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 8px;
        }

        .delete-modal-card-animated p {
          font-size: 13px;
          color: #94a3b8;
          line-height: 1.5;
          margin: 0 0 20px;
        }

        .delete-modal-card-animated p strong {
          color: #f1f5f9;
        }

        .delete-modal-buttons {
          width: 100%;
          display: flex;
          gap: 10px;
        }

        .btn-cancel-delete {
          flex: 1;
          height: 38px;
          background: transparent;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          color: #cbd5e1;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
        }

        .btn-confirm-delete {
          flex: 1;
          height: 38px;
          background: #ef4444;
          border: none;
          border-radius: 6px;
          color: #ffffff;
          font-size: 13px;
          font-weight: 700;
          cursor: pointer;
        }

        .btn-confirm-delete:hover {
          background: #dc2626;
        }

        @media (max-width: 960px) {
          .techlab-users-dashboard {
            padding: 16px;
          }
          .users-kpi-grid {
            grid-template-columns: repeat(2, 1fr);
          }
          .users-filter-bar {
            flex-direction: column;
          }
          .roles-cards-grid {
            grid-template-columns: 1fr;
          }
        }

        /* LIGHT MODE SCOPED OVERRIDES */
        :global(.theme-light) .techlab-users-dashboard {
          color: #0f172a !important;
        }

        :global(.theme-light) .users-header-bar {
          background: transparent !important;
          border: none !important;
        }

        :global(.theme-light) .header-title-group h1 {
          color: #0f172a !important;
        }

        :global(.theme-light) .header-title-group p {
          color: #64748b !important;
        }

        :global(.theme-light) .header-icon-badge {
          background: #ffffff !important;
          border-color: #cbd5e1 !important;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05) !important;
        }

        :global(.theme-light) .kpi-card {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .kpi-icon-box {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
        }

        :global(.theme-light) .kpi-info-text strong {
          color: #0f172a !important;
        }

        :global(.theme-light) .kpi-info-text span {
          color: #64748b !important;
        }

        :global(.theme-light) .users-filter-bar {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .search-input-wrapper input {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .filter-dropdown-select {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .btn-refresh-data {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #475569 !important;
        }

        :global(.theme-light) .btn-refresh-data:hover {
          background: #f1f5f9 !important;
          color: #0f172a !important;
        }

        /* USERS TABLE MASTER CARD */
        :global(.theme-light) .users-table-master-card {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .techlab-users-table th {
          background: #f8fafc !important;
          color: #475569 !important;
          border-bottom: 1px solid #e2e8f0 !important;
        }

        :global(.theme-light) .techlab-users-table td {
          border-bottom: 1px solid #f1f5f9 !important;
          color: #1e293b !important;
        }

        :global(.theme-light) .techlab-users-table tr:hover td {
          background: #f8fafc !important;
        }

        :global(.theme-light) .user-name-cell strong {
          color: #0f172a !important;
        }

        :global(.theme-light) .user-name-cell small {
          color: #64748b !important;
        }

        :global(.theme-light) .table-loading-box,
        :global(.theme-light) .table-empty-state {
          background: #ffffff !important;
          color: #64748b !important;
        }

        :global(.theme-light) .table-action-btn {
          background: #f8fafc !important;
          border-color: #e2e8f0 !important;
          color: #475569 !important;
        }

        :global(.theme-light) .table-action-btn:hover {
          background: #f1f5f9 !important;
          color: #0f172a !important;
          border-color: #cbd5e1 !important;
        }

        :global(.theme-light) .roles-cards-grid .role-card-item {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .role-card-item h4 {
          color: #0f172a !important;
        }

        :global(.theme-light) .role-card-item p {
          color: #64748b !important;
        }

        :global(.theme-light) .modal-card,
        :global(.theme-light) .delete-modal-card-animated {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15) !important;
        }

        :global(.theme-light) .modal-header h3,
        :global(.theme-light) .delete-modal-card-animated h3 {
          color: #0f172a !important;
        }

        :global(.theme-light) .modal-header p,
        :global(.theme-light) .delete-modal-card-animated p {
          color: #64748b !important;
        }

        :global(.theme-light) .form-group label {
          color: #1e293b !important;
        }

        :global(.theme-light) .form-group input,
        :global(.theme-light) .form-group select {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .btn-cancel,
        :global(.theme-light) .btn-cancel-delete {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #475569 !important;
        }
      `}</style>
    </div>
  );
}
