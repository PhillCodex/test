"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import {
  MessageSquare,
  CheckCircle2,
  Clock,
  ShieldAlert,
  Search,
  SlidersHorizontal,
  ExternalLink,
  Trash2,
  Check,
  X,
  Reply,
  Filter,
  User,
  Globe,
  Mail,
  AlertCircle,
  RefreshCw,
  Send,
  Sparkles,
} from "lucide-react";

interface CommentItem {
  id: string;
  authorName: string;
  authorEmail: string;
  authorUrl?: string | null;
  content: string;
  status: "APROBADO" | "PENDIENTE" | "RECHAZADO" | "SPAM";
  ipAddress?: string | null;
  userAgent?: string | null;
  createdAt: string;
  post: {
    id: string;
    title: string;
    slug: string;
  };
  replies?: CommentItem[];
}

interface Counts {
  total: number;
  approved: number;
  pending: number;
  rejected: number;
}

export default function CommentsDashboardPage() {
  const [comments, setComments] = useState<CommentItem[]>([]);
  const [counts, setCounts] = useState<Counts>({ total: 0, approved: 0, pending: 0, rejected: 0 });
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"ALL" | "PENDIENTE" | "APROBADO" | "RECHAZADO">("ALL");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [toast, setToast] = useState<{ message: string; type: "success" | "error" } | null>(null);

  // Reply Modal State
  const [replyModalOpen, setReplyModalOpen] = useState(false);
  const [targetComment, setTargetComment] = useState<CommentItem | null>(null);
  const [replyContent, setReplyContent] = useState("");
  const [submittingReply, setSubmittingReply] = useState(false);

  // New Manual Comment Modal State
  const [newModalOpen, setNewModalOpen] = useState(false);
  const [newAuthor, setNewAuthor] = useState("Cesar (Admin)");
  const [newEmail, setNewEmail] = useState("cesar@ingcesarco.com");
  const [newContent, setNewContent] = useState("");
  const [postsList, setPostsList] = useState<{ id: string; title: string; slug: string }[]>([]);
  const [selectedPostId, setSelectedPostId] = useState("");

  useEffect(() => {
    fetchComments();
    fetchPostsForModal();
  }, [activeTab]);

  const showToast = (message: string, type: "success" | "error" = "success") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  const fetchComments = async () => {
    try {
      setLoading(true);
      const url = activeTab === "ALL" ? `/api/comments` : `/api/comments?status=${activeTab}`;
      const res = await fetch(url);
      const data = await res.json();
      if (data.success) {
        setComments(data.comments || []);
        if (data.counts) {
          setCounts(data.counts);
        }
      }
    } catch (err) {
      console.error(err);
      showToast("Error al cargar comentarios.", "error");
    } finally {
      setLoading(false);
    }
  };

  const fetchPostsForModal = async () => {
    try {
      const res = await fetch("/api/posts");
      const data = await res.json();
      if (data.success && Array.isArray(data.posts) && data.posts.length > 0) {
        setPostsList(data.posts);
        setSelectedPostId(data.posts[0].id);
      }
    } catch (err) {
      // Ignore
    }
  };

  const handleUpdateStatus = async (id: string, newStatus: "APROBADO" | "PENDIENTE" | "RECHAZADO") => {
    try {
      const res = await fetch("/api/comments", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, status: newStatus }),
      });
      const data = await res.json();
      if (data.success) {
        setComments((prev) =>
          prev.map((c) => (c.id === id ? { ...c, status: newStatus } : c))
        );
        showToast(
          newStatus === "APROBADO"
            ? "Comentario aprobado y visible públicamente."
            : newStatus === "RECHAZADO"
            ? "Comentario rechazado."
            : "Comentario marcado como pendiente.",
          "success"
        );
        fetchComments();
      } else {
        showToast(data.error || "Error al actualizar estado.", "error");
      }
    } catch (err) {
      showToast("Error de conexión.", "error");
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("¿Estás seguro de que deseas eliminar permanentemente este comentario?")) return;
    try {
      const res = await fetch(`/api/comments?id=${id}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) {
        setComments((prev) => prev.filter((c) => c.id !== id));
        showToast("Comentario eliminado correctamente.", "success");
        fetchComments();
      } else {
        showToast(data.error || "Error al eliminar comentario.", "error");
      }
    } catch (err) {
      showToast("Error al eliminar.", "error");
    }
  };

  const handleBatchAction = async (action: "APROBAR" | "RECHAZAR" | "ELIMINAR") => {
    if (selectedIds.length === 0) return;
    if (action === "ELIMINAR" && !confirm(`¿Eliminar los ${selectedIds.length} comentarios seleccionados?`)) return;

    try {
      for (const id of selectedIds) {
        if (action === "ELIMINAR") {
          await fetch(`/api/comments?id=${id}`, { method: "DELETE" });
        } else {
          const status = action === "APROBAR" ? "APROBADO" : "RECHAZADO";
          await fetch("/api/comments", {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ id, status }),
          });
        }
      }
      setSelectedIds([]);
      showToast(`Acción en lote completada exitosamente (${selectedIds.length} elementos).`, "success");
      fetchComments();
    } catch (err) {
      showToast("Error en acción en lote.", "error");
    }
  };

  const handleOpenReplyModal = (comment: CommentItem) => {
    setTargetComment(comment);
    setReplyContent("");
    setReplyModalOpen(true);
  };

  const handleSubmitReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetComment || !replyContent.trim()) return;

    try {
      setSubmittingReply(true);
      const res = await fetch("/api/comments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          postId: targetComment.post.id,
          authorName: "TechLab Admin",
          authorEmail: "admin@techlab.com",
          content: replyContent.trim(),
          parentId: targetComment.id,
        }),
      });
      const data = await res.json();
      if (data.success) {
        // Auto-approve admin reply
        if (data.comment?.id) {
          await fetch("/api/comments", {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ id: data.comment.id, status: "APROBADO" }),
          });
        }
        showToast("Respuesta enviada y publicada exitosamente.", "success");
        setReplyModalOpen(false);
        fetchComments();
      } else {
        showToast(data.error || "Error al enviar respuesta.", "error");
      }
    } catch (err) {
      showToast("Error al enviar respuesta.", "error");
    } finally {
      setSubmittingReply(false);
    }
  };

  const handleCreateNewManual = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPostId || !newContent.trim()) {
      showToast("Completa la publicación y el comentario.", "error");
      return;
    }

    try {
      const res = await fetch("/api/comments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          postId: selectedPostId,
          authorName: newAuthor.trim(),
          authorEmail: newEmail.trim(),
          content: newContent.trim(),
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast("Comentario de prueba creado con éxito.", "success");
        setNewModalOpen(false);
        setNewContent("");
        fetchComments();
      } else {
        showToast(data.error || "Error al crear comentario.", "error");
      }
    } catch (err) {
      showToast("Error al crear comentario.", "error");
    }
  };

  const filteredComments = comments.filter((c) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      c.authorName.toLowerCase().includes(q) ||
      c.authorEmail.toLowerCase().includes(q) ||
      c.content.toLowerCase().includes(q) ||
      c.post?.title?.toLowerCase().includes(q)
    );
  });

  const toggleSelectAll = () => {
    if (selectedIds.length === filteredComments.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredComments.map((c) => c.id));
    }
  };

  const toggleSelectOne = (id: string) => {
    if (selectedIds.includes(id)) {
      setSelectedIds((prev) => prev.filter((x) => x !== id));
    } else {
      setSelectedIds((prev) => [...prev, id]);
    }
  };

  const formatDate = (dateStr: string) => {
    try {
      return new Date(dateStr).toLocaleDateString("es-ES", {
        day: "numeric",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch {
      return "Hace poco";
    }
  };

  return (
    <div className="comments-dashboard-container">
      {/* Toast Notification */}
      {toast && (
        <div className={`admin-toast-banner ${toast.type}`}>
          {toast.type === "success" ? <CheckCircle2 /> : <AlertCircle />}
          <span>{toast.message}</span>
        </div>
      )}

      {/* Header */}
      <div className="dashboard-heading">
        <div>
          <h1>Gestión y Moderación de Comentarios</h1>
          <p>Revisa, aprueba, responde y administra todos los comentarios de las publicaciones.</p>
        </div>
        <div className="header-actions">
          <button className="admin-btn ghost" onClick={fetchComments} title="Recargar">
            <RefreshCw className={loading ? "spin" : ""} /> Refrescar
          </button>
          <button className="admin-btn" onClick={() => setNewModalOpen(true)}>
            <MessageSquare /> + Nuevo Comentario
          </button>
        </div>
      </div>

      {/* 4 Métricas Principales */}
      <div className="stat-grid">
        <div className="stat-card">
          <div>
            <span>TOTAL DE COMENTARIOS</span>
            <strong>{counts.total}</strong>
            <small>Registrados en la base de datos</small>
          </div>
          <i>
            <MessageSquare />
          </i>
        </div>

        <div className="stat-card blue">
          <div>
            <span>APROBADOS Y PÚBLICOS</span>
            <strong>{counts.approved}</strong>
            <small>
              <b>{counts.total > 0 ? Math.round((counts.approved / counts.total) * 100) : 0}%</b> visibles en la web
            </small>
          </div>
          <i>
            <CheckCircle2 />
          </i>
        </div>

        <div className="stat-card" style={{ borderColor: counts.pending > 0 ? "rgba(245, 158, 11, 0.4)" : undefined }}>
          <div>
            <span style={{ color: "#f59e0b" }}>PENDIENTES POR MODERAR</span>
            <strong style={{ color: counts.pending > 0 ? "#f59e0b" : "#ffffff" }}>{counts.pending}</strong>
            <small>Esperando aprobación</small>
          </div>
          <i style={{ color: "#f59e0b", background: "rgba(245, 158, 11, 0.12)", borderColor: "rgba(245, 158, 11, 0.3)" }}>
            <Clock />
          </i>
        </div>

        <div className="stat-card" style={{ borderColor: "rgba(239, 68, 68, 0.2)" }}>
          <div>
            <span style={{ color: "#ef4444" }}>RECHAZADOS / SPAM</span>
            <strong style={{ color: "#ef4444" }}>{counts.rejected}</strong>
            <small>Descartados</small>
          </div>
          <i style={{ color: "#ef4444", background: "rgba(239, 68, 68, 0.12)", borderColor: "rgba(239, 68, 68, 0.3)" }}>
            <ShieldAlert />
          </i>
        </div>
      </div>

      {/* Panel Principal */}
      <section className="admin-card module-card">
        {/* Barra de Pestañas de Estado */}
        <div className="comments-tabs-bar">
          <div className="tabs-list">
            <button
              className={`tab-btn ${activeTab === "ALL" ? "active" : ""}`}
              onClick={() => setActiveTab("ALL")}
            >
              Todos <span className="badge">{counts.total}</span>
            </button>
            <button
              className={`tab-btn ${activeTab === "PENDIENTE" ? "active" : ""}`}
              onClick={() => setActiveTab("PENDIENTE")}
            >
              Pendientes{" "}
              {counts.pending > 0 && <span className="badge amber-badge">{counts.pending}</span>}
            </button>
            <button
              className={`tab-btn ${activeTab === "APROBADO" ? "active" : ""}`}
              onClick={() => setActiveTab("APROBADO")}
            >
              Aprobados <span className="badge green-badge">{counts.approved}</span>
            </button>
            <button
              className={`tab-btn ${activeTab === "RECHAZADO" ? "active" : ""}`}
              onClick={() => setActiveTab("RECHAZADO")}
            >
              Rechazados <span className="badge">{counts.rejected}</span>
            </button>
          </div>

          {/* Buscador */}
          <div className="comments-search-box">
            <Search />
            <input
              type="text"
              placeholder="Buscar por autor, correo, contenido o post..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        {/* Barra de Acciones por Lote (cuando hay checkboxes seleccionados) */}
        {selectedIds.length > 0 && (
          <div className="batch-actions-bar">
            <span>
              <b>{selectedIds.length}</b> comentarios seleccionados:
            </span>
            <div className="batch-btn-group">
              <button className="batch-btn approve" onClick={() => handleBatchAction("APROBAR")}>
                <Check /> Aprobar
              </button>
              <button className="batch-btn reject" onClick={() => handleBatchAction("RECHAZAR")}>
                <X /> Rechazar
              </button>
              <button className="batch-btn delete" onClick={() => handleBatchAction("ELIMINAR")}>
                <Trash2 /> Eliminar
              </button>
            </div>
          </div>
        )}

        {/* Tabla de Comentarios */}
        <div className="admin-table">
          <table>
            <thead>
              <tr>
                <th style={{ width: "40px" }}>
                  <input
                    type="checkbox"
                    checked={filteredComments.length > 0 && selectedIds.length === filteredComments.length}
                    onChange={toggleSelectAll}
                    aria-label="Seleccionar todos"
                  />
                </th>
                <th style={{ width: "220px" }}>Autor</th>
                <th>Comentario</th>
                <th style={{ width: "240px" }}>Publicación Vinculada</th>
                <th style={{ width: "130px" }}>Estado</th>
                <th style={{ width: "130px" }}>Fecha</th>
                <th style={{ width: "160px", textAlign: "right" }}>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={7} className="table-loading-cell">
                    <RefreshCw className="spin" /> Cargando comentarios...
                  </td>
                </tr>
              ) : filteredComments.length === 0 ? (
                <tr>
                  <td colSpan={7} className="table-empty-cell">
                    <MessageSquare />
                    <p>No se encontraron comentarios en esta sección.</p>
                  </td>
                </tr>
              ) : (
                filteredComments.map((comment) => {
                  const isApproved = comment.status === "APROBADO";
                  const isPending = comment.status === "PENDIENTE";
                  const isRejected = comment.status === "RECHAZADO";

                  return (
                    <tr key={comment.id} className={isPending ? "row-pending-highlight" : ""}>
                      <td>
                        <input
                          type="checkbox"
                          checked={selectedIds.includes(comment.id)}
                          onChange={() => toggleSelectOne(comment.id)}
                          aria-label={`Seleccionar comentario de ${comment.authorName}`}
                        />
                      </td>

                      {/* Columna Autor */}
                      <td>
                        <div className="author-cell-wrap">
                          <div className="author-mini-avatar">
                            <span>{comment.authorName.slice(0, 2).toUpperCase()}</span>
                          </div>
                          <div className="author-text-details">
                            <b>{comment.authorName}</b>
                            <small title={comment.authorEmail}>{comment.authorEmail}</small>
                            {comment.authorUrl && (
                              <a
                                href={comment.authorUrl.startsWith("http") ? comment.authorUrl : `https://${comment.authorUrl}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="author-web-link"
                              >
                                <Globe /> Web
                              </a>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Columna Comentario */}
                      <td>
                        <div className="comment-content-cell">
                          <p>{comment.content}</p>
                          {comment.ipAddress && (
                            <span className="ip-footprint">IP: {comment.ipAddress}</span>
                          )}
                        </div>
                      </td>

                      {/* Columna Publicación Vinculada */}
                      <td>
                        <div className="post-link-cell">
                          <b>{comment.post?.title || "Publicación"}</b>
                          {comment.post?.slug && (
                            <Link
                              href={`/posts/${comment.post.slug}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="view-post-ext-btn"
                              title="Abrir publicación en nueva pestaña"
                            >
                              <span>Ver Post</span>
                              <ExternalLink />
                            </Link>
                          )}
                        </div>
                      </td>

                      {/* Columna Estado */}
                      <td>
                        {isApproved && <span className="status">Aprobado</span>}
                        {isPending && <span className="status draft">Pendiente</span>}
                        {isRejected && <span className="status rejected">Rechazado</span>}
                      </td>

                      {/* Columna Fecha */}
                      <td>
                        <span className="date-cell">{formatDate(comment.createdAt)}</span>
                      </td>

                      {/* Columna Acciones */}
                      <td>
                        <div className="row-actions actions-right">
                          {/* Botón Aprobar */}
                          {!isApproved && (
                            <button
                              className="action-btn approve"
                              onClick={() => handleUpdateStatus(comment.id, "APROBADO")}
                              title="Aprobar y publicar"
                            >
                              <Check />
                            </button>
                          )}

                          {/* Botón Rechazar / Desaprobar */}
                          {isApproved && (
                            <button
                              className="action-btn reject"
                              onClick={() => handleUpdateStatus(comment.id, "RECHAZADO")}
                              title="Rechazar / Ocultar"
                            >
                              <X />
                            </button>
                          )}

                          {/* Botón Responder */}
                          <button
                            className="action-btn reply"
                            onClick={() => handleOpenReplyModal(comment)}
                            title="Responder como Administrador"
                          >
                            <Reply />
                          </button>

                          {/* Botón Eliminar */}
                          <button
                            className="action-btn delete"
                            onClick={() => handleDelete(comment.id)}
                            title="Eliminar permanentemente"
                          >
                            <Trash2 />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="table-footer">
          <span>Mostrando {filteredComments.length} de {counts.total} comentarios</span>
          <div className="table-page-nav">
            <button disabled>‹</button>
            <button className="current">1</button>
            <button disabled>›</button>
          </div>
        </div>
      </section>

      {/* =================================================================
          MODAL 1: RESPONDER COMENTARIO COMO ADMIN
          ================================================================= */}
      {replyModalOpen && targetComment && (
        <div className="admin-modal-overlay">
          <div className="admin-modal-card">
            <div className="modal-header">
              <div className="modal-header-title">
                <Reply />
                <h3>Responder Comentario</h3>
              </div>
              <button className="btn-close-modal" onClick={() => setReplyModalOpen(false)}>
                <X />
              </button>
            </div>

            <div className="modal-body">
              <div className="original-comment-quote">
                <strong>Comentario de {targetComment.authorName}:</strong>
                <p>"{targetComment.content}"</p>
                <small>En: {targetComment.post?.title}</small>
              </div>

              <form onSubmit={handleSubmitReply}>
                <label>
                  Tu Respuesta (aparecerá como TechLab Admin):
                  <textarea
                    rows={5}
                    placeholder="Escribe aquí tu respuesta oficial..."
                    value={replyContent}
                    onChange={(e) => setReplyContent(e.target.value)}
                    required
                  />
                </label>

                <div className="modal-footer-actions">
                  <button
                    type="button"
                    className="admin-btn ghost"
                    onClick={() => setReplyModalOpen(false)}
                    disabled={submittingReply}
                  >
                    Cancelar
                  </button>
                  <button type="submit" className="admin-btn" disabled={submittingReply}>
                    {submittingReply ? "Publicando..." : <><Send /> Publicar Respuesta</>}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* =================================================================
          MODAL 2: CREAR COMENTARIO MANUAL
          ================================================================= */}
      {newModalOpen && (
        <div className="admin-modal-overlay">
          <div className="admin-modal-card">
            <div className="modal-header">
              <div className="modal-header-title">
                <MessageSquare />
                <h3>Crear Comentario Manual</h3>
              </div>
              <button className="btn-close-modal" onClick={() => setNewModalOpen(false)}>
                <X />
              </button>
            </div>

            <div className="modal-body">
              <form onSubmit={handleCreateNewManual}>
                <div className="form-row-2">
                  <label>
                    Nombre del Autor:
                    <input
                      type="text"
                      value={newAuthor}
                      onChange={(e) => setNewAuthor(e.target.value)}
                      required
                    />
                  </label>

                  <label>
                    Correo Electrónico:
                    <input
                      type="email"
                      value={newEmail}
                      onChange={(e) => setNewEmail(e.target.value)}
                      required
                    />
                  </label>
                </div>

                <label>
                  Publicación de Destino:
                  <select
                    value={selectedPostId}
                    onChange={(e) => setSelectedPostId(e.target.value)}
                    required
                  >
                    {postsList.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.title}
                      </option>
                    ))}
                  </select>
                </label>

                <label>
                  Contenido del Comentario:
                  <textarea
                    rows={4}
                    placeholder="Escribe el comentario aquí..."
                    value={newContent}
                    onChange={(e) => setNewContent(e.target.value)}
                    required
                  />
                </label>

                <div className="modal-footer-actions">
                  <button
                    type="button"
                    className="admin-btn ghost"
                    onClick={() => setNewModalOpen(false)}
                  >
                    Cancelar
                  </button>
                  <button type="submit" className="admin-btn">
                    Crear y Guardar
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      <style jsx>{`
        .comments-dashboard-container {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        .header-actions {
          display: flex;
          gap: 12px;
        }

        .spin {
          animation: spinAnim 1s linear infinite;
        }

        @keyframes spinAnim {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }

        /* Toast Banner */
        .admin-toast-banner {
          position: fixed;
          top: 80px;
          right: 28px;
          z-index: 1000;
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 12px 20px;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 600;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.6);
          animation: slideInToast 0.2s ease;
        }

        .admin-toast-banner.success {
          background: #062b1a;
          border: 1px solid #16c96f;
          color: #a7f3d0;
        }

        .admin-toast-banner.error {
          background: #3b0d0d;
          border: 1px solid #ef4444;
          color: #fca5a5;
        }

        @keyframes slideInToast {
          from { transform: translateY(-10px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }

        /* Tabs Bar */
        .comments-tabs-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
          padding-bottom: 16px;
          margin-bottom: 16px;
          flex-wrap: wrap;
          gap: 14px;
        }

        .tabs-list {
          display: flex;
          gap: 8px;
        }

        .tab-btn {
          background: transparent;
          border: 1px solid rgba(255, 255, 255, 0.08);
          color: #94a3b8;
          padding: 8px 14px;
          border-radius: 8px;
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          transition: all 0.15s;
        }

        .tab-btn:hover {
          color: #ffffff;
          background: rgba(255, 255, 255, 0.04);
        }

        .tab-btn.active {
          background: rgba(22, 201, 111, 0.12);
          border-color: #16c96f;
          color: #16c96f;
          font-weight: 700;
        }

        .tab-btn .badge {
          font-size: 10px;
          background: rgba(255, 255, 255, 0.08);
          padding: 1px 6px;
          border-radius: 10px;
          color: #cbd5e1;
        }

        .tab-btn .badge.amber-badge {
          background: rgba(245, 158, 11, 0.2);
          color: #f59e0b;
        }

        .tab-btn .badge.green-badge {
          background: rgba(22, 201, 111, 0.2);
          color: #16c96f;
        }

        .comments-search-box {
          display: flex;
          align-items: center;
          gap: 8px;
          background: #050f18;
          border: 1px solid var(--admin-line);
          border-radius: 8px;
          padding: 0 12px;
          width: 340px;
          height: 38px;
        }

        .comments-search-box :global(svg) {
          width: 15px;
          height: 15px;
          color: #94a3b8;
        }

        .comments-search-box input {
          width: 100%;
          background: transparent;
          border: none;
          outline: none;
          color: #ffffff;
          font-size: 12px;
        }

        /* Batch Actions */
        .batch-actions-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: rgba(56, 189, 248, 0.08);
          border: 1px solid rgba(56, 189, 248, 0.25);
          padding: 10px 16px;
          border-radius: 8px;
          margin-bottom: 16px;
          font-size: 12px;
          color: #e2e8f0;
        }

        .batch-btn-group {
          display: flex;
          gap: 8px;
        }

        .batch-btn {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          padding: 6px 12px;
          border-radius: 6px;
          font-size: 11px;
          font-weight: 700;
          cursor: pointer;
          border: none;
          transition: transform 0.15s;
        }

        .batch-btn:hover {
          transform: translateY(-1px);
        }

        .batch-btn.approve {
          background: #16c96f;
          color: #030b12;
        }

        .batch-btn.reject {
          background: #f59e0b;
          color: #030b12;
        }

        .batch-btn.delete {
          background: #ef4444;
          color: #ffffff;
        }

        /* Table cells */
        .row-pending-highlight {
          background: rgba(245, 158, 11, 0.03);
        }

        .author-cell-wrap {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .author-mini-avatar {
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background: linear-gradient(135deg, #12b85f, #38bdf8);
          color: #030b12;
          font-size: 11px;
          font-weight: 800;
          display: grid;
          place-items: center;
          flex-shrink: 0;
        }

        .author-text-details {
          display: flex;
          flex-direction: column;
          min-width: 0;
        }

        .author-text-details b {
          font-size: 12px;
          color: #ffffff;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        .author-text-details small {
          color: #94a3b8;
          font-size: 10px;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        .author-web-link {
          display: inline-flex;
          align-items: center;
          gap: 3px;
          font-size: 9px;
          color: #38bdf8;
          text-decoration: none;
          margin-top: 2px;
        }

        .comment-content-cell p {
          font-size: 12px;
          line-height: 1.5;
          color: #e2e8f0;
          margin: 0 0 4px;
        }

        .ip-footprint {
          font-size: 10px;
          color: #64748b;
          font-family: monospace;
        }

        .post-link-cell b {
          font-size: 12px;
          color: #cbd5e1;
          display: block;
          margin-bottom: 4px;
          line-height: 1.3;
        }

        .view-post-ext-btn {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          font-size: 11px;
          font-weight: 700;
          color: #16c96f;
          text-decoration: none;
          padding: 2px 6px;
          background: rgba(22, 201, 111, 0.1);
          border: 1px solid rgba(22, 201, 111, 0.25);
          border-radius: 4px;
          transition: all 0.15s;
        }

        .view-post-ext-btn:hover {
          background: #16c96f;
          color: #030b12;
        }

        .status.rejected {
          color: #ef4444;
          background: rgba(239, 68, 68, 0.12);
        }

        .date-cell {
          font-size: 11px;
          color: #94a3b8;
        }

        .actions-right {
          justify-content: flex-end;
        }

        .action-btn {
          width: 28px;
          height: 28px;
          border-radius: 6px;
          display: grid;
          place-items: center;
          cursor: pointer;
          border: 1px solid transparent;
          transition: all 0.15s;
        }

        .action-btn.approve {
          background: rgba(22, 201, 111, 0.12);
          color: #16c96f;
          border-color: rgba(22, 201, 111, 0.3);
        }

        .action-btn.approve:hover {
          background: #16c96f;
          color: #030b12;
        }

        .action-btn.reject {
          background: rgba(245, 158, 11, 0.12);
          color: #f59e0b;
          border-color: rgba(245, 158, 11, 0.3);
        }

        .action-btn.reject:hover {
          background: #f59e0b;
          color: #030b12;
        }

        .action-btn.reply {
          background: rgba(56, 189, 248, 0.12);
          color: #38bdf8;
          border-color: rgba(56, 189, 248, 0.3);
        }

        .action-btn.reply:hover {
          background: #38bdf8;
          color: #030b12;
        }

        .action-btn.delete {
          background: rgba(239, 68, 68, 0.12);
          color: #ef4444;
          border-color: rgba(239, 68, 68, 0.3);
        }

        .action-btn.delete:hover {
          background: #ef4444;
          color: #ffffff;
        }

        .table-loading-cell,
        .table-empty-cell {
          text-align: center;
          padding: 48px !important;
          color: #94a3b8;
        }

        .table-empty-cell :global(svg) {
          width: 32px;
          height: 32px;
          margin-bottom: 8px;
          color: #64748b;
        }

        /* Modals */
        .admin-modal-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.75);
          backdrop-filter: blur(8px);
          z-index: 1000;
          display: grid;
          place-items: center;
          padding: 20px;
        }

        .admin-modal-card {
          width: 100%;
          max-width: 580px;
          background: #07131d;
          border: 1px solid rgba(22, 201, 111, 0.3);
          border-radius: 14px;
          box-shadow: 0 20px 50px rgba(0, 0, 0, 0.8), 0 0 30px rgba(22, 201, 111, 0.1);
          overflow: hidden;
          animation: modalSlide 0.2s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes modalSlide {
          from { transform: translateY(14px) scale(0.96); opacity: 0; }
          to { transform: translateY(0) scale(1); opacity: 1; }
        }

        .modal-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 16px 20px;
          background: #040c14;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .modal-header-title {
          display: flex;
          align-items: center;
          gap: 8px;
          color: #16c96f;
        }

        .modal-header-title h3 {
          font-size: 16px;
          font-weight: 700;
          color: #ffffff;
          margin: 0;
        }

        .btn-close-modal {
          background: none;
          border: none;
          color: #94a3b8;
          cursor: pointer;
          padding: 4px;
        }

        .btn-close-modal:hover {
          color: #ffffff;
        }

        .modal-body {
          padding: 20px;
        }

        .original-comment-quote {
          background: rgba(3, 11, 18, 0.8);
          border-left: 3px solid #38bdf8;
          border-radius: 0 6px 6px 0;
          padding: 12px 16px;
          margin-bottom: 16px;
        }

        .original-comment-quote strong {
          display: block;
          font-size: 12px;
          color: #38bdf8;
        }

        .original-comment-quote p {
          font-size: 13px;
          color: #cbd5e1;
          margin: 4px 0;
          font-style: italic;
        }

        .original-comment-quote small {
          font-size: 11px;
          color: #64748b;
        }

        .modal-body label {
          display: block;
          font-size: 12px;
          font-weight: 600;
          color: #cbd5df;
          margin-bottom: 14px;
        }

        .modal-body input,
        .modal-body select,
        .modal-body textarea {
          display: block;
          width: 100%;
          margin-top: 6px;
          padding: 10px 12px;
          background: #030a10;
          border: 1px solid var(--admin-line);
          border-radius: 7px;
          color: #ffffff;
          font-size: 13px;
          font-family: inherit;
          outline: none;
        }

        .modal-body input:focus,
        .modal-body select:focus,
        .modal-body textarea:focus {
          border-color: #16c96f;
        }

        .form-row-2 {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 12px;
        }

        .modal-footer-actions {
          display: flex;
          justify-content: flex-end;
          gap: 10px;
          margin-top: 18px;
        }
      `}</style>
    </div>
  );
}
