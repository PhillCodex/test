"use client";

import { useState, useEffect, useRef } from "react";
import {
  Settings,
  Save,
  Globe,
  Layout,
  UploadCloud,
  CheckCircle2,
  AlertTriangle,
  Loader2,
  Copy,
  ExternalLink,
  Shield,
  Sparkles,
  Search,
  Eye,
  Palette,
  Sliders,
  Image as ImageIcon,
  Check,
  RotateCcw,
  Sun,
  Moon,
  Shapes,
  Maximize2,
  CircuitBoard,
  Square,
  Circle,
  MessageCircle,
  Facebook,
  Twitter,
  Instagram,
  Linkedin,
  Youtube,
  Github,
  Mail,
  Phone,
  MapPin,
  Clock,
  Share2,
  PanelBottom,
  AtSign,
  Columns,
  Layers,
  BookOpen,
  FileText,
} from "lucide-react";

const FAVICON_PRESETS = [
  { name: "TechLab Cyan", url: "/favicon.ico", label: "Logo Original" },
  { name: "Verde Neón", url: "https://api.iconify.design/lucide:circuit-board.svg?color=%2316c96f", label: "Circuito Verde" },
  { name: "Azul Pro", url: "https://api.iconify.design/lucide:box.svg?color=%2338bdf8", label: "Caja 3D" },
  { name: "Púrpura Cloud", url: "https://api.iconify.design/lucide:cloud.svg?color=%23a855f7", label: "Nube Pro" },
];

const COLOR_PRESETS = [
  {
    name: "Cyber Emerald",
    label: "Verde Neón (Actual)",
    primary: "#16c96f",
    secondary: "#38bdf8",
    accent: "#12b85f",
  },
  {
    name: "Electric Cyan",
    label: "Cyan Eléctrico",
    primary: "#38bdf8",
    secondary: "#16c96f",
    accent: "#0ea5e9",
  },
  {
    name: "Neon Purple",
    label: "Púrpura Cyber",
    primary: "#a855f7",
    secondary: "#38bdf8",
    accent: "#9333ea",
  },
  {
    name: "Sunset Amber",
    label: "Ámbar & Fuego",
    primary: "#f59e0b",
    secondary: "#ef4444",
    accent: "#d97706",
  },
  {
    name: "Cyber Rose",
    label: "Rosa Neón",
    primary: "#ec4899",
    secondary: "#a855f7",
    accent: "#db2777",
  },
];

export default function AjustesPage() {
  const [activeTab, setActiveTab] = useState<"basico" | "personalizacion" | "footer" | "lectura">("basico");
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [isUploadingFavicon, setIsUploadingFavicon] = useState<boolean>(false);
  const [isUploadingLogo, setIsUploadingLogo] = useState<boolean>(false);
  const [isUploadingLogoDark, setIsUploadingLogoDark] = useState<boolean>(false);

  // 1. Campos Básicos
  const [siteTitle, setSiteTitle] = useState<string>("");
  const [siteDescription, setSiteDescription] = useState<string>("");
  const [faviconUrl, setFaviconUrl] = useState<string>("/favicon.ico");
  const [adminUrl, setAdminUrl] = useState<string>("/dashboard");
  const [publicUrl, setPublicUrl] = useState<string>("http://localhost:3000");

  // WhatsApp
  const [whatsappNumber, setWhatsappNumber] = useState<string>("+51 900 123 456");
  const [whatsappEnabled, setWhatsappEnabled] = useState<boolean>(true);
  const [whatsappMessage, setWhatsappMessage] = useState<string>("Hola! Deseo cotizar un proyecto tecnológico con TechLab.");

  // 2. Campos de Personalización
  const [logoUrl, setLogoUrl] = useState<string>("");
  const [logoDarkUrl, setLogoDarkUrl] = useState<string>("");
  const [slogan, setSlogan] = useState<string>("Tecnología que impulsa tu mundo.");
  const [primaryColor, setPrimaryColor] = useState<string>("#16c96f");
  const [secondaryColor, setSecondaryColor] = useState<string>("#38bdf8");
  const [accentColor, setAccentColor] = useState<string>("#12b85f");
  const [themeMode, setThemeMode] = useState<string>("dark");
  const [borderRadius, setBorderRadius] = useState<string>("rounded");

  // 3. Campos del Footer (Pie de Página)
  const [footerDescription, setFooterDescription] = useState<string>("Laboratorio de innovación tecnológica, desarrollo de software y servicios en la nube.");
  const [footerCopyright, setFooterCopyright] = useState<string>("© %year% %sitename%. Todos los derechos reservados.");
  const [footerBottomText, setFooterBottomText] = useState<string>("Términos y condiciones　|　Política de privacidad");
  const [footerEmail, setFooterEmail] = useState<string>("contacto@techlab.com");
  const [footerPhone, setFooterPhone] = useState<string>("+51 900 123 456");
  const [footerAddress, setFooterAddress] = useState<string>("Lima, Perú");
  const [footerSchedule, setFooterSchedule] = useState<string>("Lun - Vie: 9:00 AM - 6:00 PM");
  const [footerFacebook, setFooterFacebook] = useState<string>("https://facebook.com");
  const [footerTwitter, setFooterTwitter] = useState<string>("https://twitter.com");
  const [footerInstagram, setFooterInstagram] = useState<string>("https://instagram.com");
  const [footerLinkedin, setFooterLinkedin] = useState<string>("https://linkedin.com");
  const [footerYoutube, setFooterYoutube] = useState<string>("https://youtube.com");
  const [footerGithub, setFooterGithub] = useState<string>("https://github.com");
  const [footerShowSocial, setFooterShowSocial] = useState<boolean>(true);
  const [footerShowContact, setFooterShowContact] = useState<boolean>(true);
  const [footerNavTitle, setFooterNavTitle] = useState<string>("NAVEGACIÓN");
  const [footerServicesTitle, setFooterServicesTitle] = useState<string>("SERVICIOS");
  const [footerResourcesTitle, setFooterResourcesTitle] = useState<string>("RECURSOS");

  // 4. Campos de Ajustes de Lectura (Estilo WordPress)
  const [showOnFront, setShowOnFront] = useState<"posts" | "page">("posts");
  const [pageOnFront, setPageOnFront] = useState<string>("");
  const [pageForPosts, setPageForPosts] = useState<string>("");
  const [postsPerPage, setPostsPerPage] = useState<number>(10);
  const [pagesList, setPagesList] = useState<Array<{ id: string; title: string; slug: string; status: string; template: string }>>([]);

  // Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<"success" | "error">("success");

  const faviconInputRef = useRef<HTMLInputElement>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);
  const logoDarkInputRef = useRef<HTMLInputElement>(null);

  const showToast = (msg: string, type: "success" | "error" = "success") => {
    setToastMessage(msg);
    setToastType(type);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Cargar Ajustes desde la API
  useEffect(() => {
    const loadSettings = async () => {
      setIsLoading(true);
      try {
        const res = await fetch("/api/settings");
        const data = await res.json();
        if (data.success && data.settings) {
          const s = data.settings;
          const title = s.siteTitle || "";
          setSiteTitle(title);
          setSiteDescription(s.siteDescription || "");
          setFaviconUrl(s.faviconUrl || "/favicon.ico");
          setAdminUrl(s.adminUrl || "/dashboard");
          setPublicUrl(s.publicUrl || "http://localhost:3000");

          // WhatsApp
          setWhatsappNumber(s.whatsappNumber || "+51 900 123 456");
          setWhatsappEnabled(s.whatsappEnabled !== undefined ? s.whatsappEnabled : true);
          setWhatsappMessage(s.whatsappMessage || "");

          // Personalización
          setLogoUrl(s.logoUrl || "");
          setLogoDarkUrl(s.logoDarkUrl || "");
          setSlogan(s.slogan || "Tecnología que impulsa tu mundo.");
          setPrimaryColor(s.primaryColor || "#16c96f");
          setSecondaryColor(s.secondaryColor || "#38bdf8");
          setAccentColor(s.accentColor || "#12b85f");
          setThemeMode(s.themeMode || "dark");
          setBorderRadius(s.borderRadius || "rounded");

          // Footer
          if (s.footerDescription) setFooterDescription(s.footerDescription);
          if (s.footerCopyright) setFooterCopyright(s.footerCopyright);
          if (s.footerBottomText) setFooterBottomText(s.footerBottomText);
          if (s.footerEmail) setFooterEmail(s.footerEmail);
          if (s.footerPhone) setFooterPhone(s.footerPhone);
          if (s.footerAddress) setFooterAddress(s.footerAddress);
          if (s.footerSchedule) setFooterSchedule(s.footerSchedule);
          if (s.footerFacebook) setFooterFacebook(s.footerFacebook);
          if (s.footerTwitter) setFooterTwitter(s.footerTwitter);
          if (s.footerInstagram) setFooterInstagram(s.footerInstagram);
          if (s.footerLinkedin) setFooterLinkedin(s.footerLinkedin);
          if (s.footerYoutube) setFooterYoutube(s.footerYoutube);
          if (s.footerGithub) setFooterGithub(s.footerGithub);
          if (s.footerShowSocial !== undefined) setFooterShowSocial(s.footerShowSocial);
          if (s.footerNavTitle) setFooterNavTitle(s.footerNavTitle);
          if (s.footerServicesTitle) setFooterServicesTitle(s.footerServicesTitle);
          if (s.footerResourcesTitle) setFooterResourcesTitle(s.footerResourcesTitle);

          // Ajustes de Lectura
          if (s.showOnFront) setShowOnFront(s.showOnFront as "posts" | "page");
          if (s.pageOnFront) setPageOnFront(s.pageOnFront);
          if (s.pageForPosts) setPageForPosts(s.pageForPosts);
          if (s.postsPerPage) setPostsPerPage(Number(s.postsPerPage) || 10);

          if (typeof document !== "undefined" && title) {
            document.title = `Panel de Administración | ${title}`;
          }
        }

        // Cargar listado de páginas existentes para el selector de inicio y entradas
        try {
          const pagesRes = await fetch("/api/pages");
          const pagesData = await pagesRes.json();
          if (pagesData.pages && Array.isArray(pagesData.pages)) {
            setPagesList(pagesData.pages);
          }
        } catch (e) {
          console.warn("No se pudieron cargar las páginas:", e);
        }
      } catch (err) {
        console.error("Error al cargar ajustes:", err);
        showToast("Error al conectar con la base de datos.", "error");
      } finally {
        setIsLoading(false);
      }
    };

    loadSettings();
  }, []);

  // Subir Favicon
  const handleUploadFavicon = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingFavicon(true);
    try {
      const formData = new FormData();
      formData.append("file", file);

      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      if (data.url) {
        setFaviconUrl(data.url);
        showToast("Favicon subido correctamente.", "success");
      } else {
        showToast(data.error || "Error al subir favicon.", "error");
      }
    } catch (err) {
      console.error(err);
      showToast("Error de conexión al subir imagen.", "error");
    } finally {
      setIsUploadingFavicon(false);
      if (faviconInputRef.current) faviconInputRef.current.value = "";
    }
  };

  // Subir Logo Principal
  const handleUploadLogo = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingLogo(true);
    try {
      const formData = new FormData();
      formData.append("file", file);

      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      if (data.url) {
        setLogoUrl(data.url);
        showToast("Logotipo principal subido.", "success");
      } else {
        showToast(data.error || "Error al subir logo.", "error");
      }
    } catch (err) {
      console.error(err);
      showToast("Error al conectar con el servidor.", "error");
    } finally {
      setIsUploadingLogo(false);
      if (logoInputRef.current) logoInputRef.current.value = "";
    }
  };

  // Subir Logo Secundario
  const handleUploadLogoDark = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingLogoDark(true);
    try {
      const formData = new FormData();
      formData.append("file", file);

      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      if (data.url) {
        setLogoDarkUrl(data.url);
        showToast("Logotipo dark mode subido.", "success");
      } else {
        showToast(data.error || "Error al subir logo.", "error");
      }
    } catch (err) {
      console.error(err);
      showToast("Error al conectar con el servidor.", "error");
    } finally {
      setIsUploadingLogoDark(false);
      if (logoDarkInputRef.current) logoDarkInputRef.current.value = "";
    }
  };

  // Aplicar Preset de Color
  const applyColorPreset = (preset: (typeof COLOR_PRESETS)[0]) => {
    setPrimaryColor(preset.primary);
    setSecondaryColor(preset.secondary);
    setAccentColor(preset.accent);
    showToast(`Paleta "${preset.name}" seleccionada.`, "success");
  };

  // Guardar Ajustes en Base de Datos
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!siteTitle.trim()) {
      showToast("El título del sitio no puede estar vacío.", "error");
      return;
    }

    setIsSaving(true);
    try {
      const res = await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          siteTitle: siteTitle.trim(),
          siteDescription: siteDescription.trim(),
          faviconUrl: faviconUrl.trim(),
          adminUrl: adminUrl.trim(),
          publicUrl: publicUrl.trim(),
          whatsappNumber: whatsappNumber.trim(),
          whatsappEnabled,
          whatsappMessage: whatsappMessage.trim(),
          logoUrl: logoUrl.trim() || null,
          logoDarkUrl: logoDarkUrl.trim() || null,
          slogan: slogan.trim(),
          primaryColor,
          secondaryColor,
          accentColor,
          themeMode,
          borderRadius,
          footerDescription: footerDescription.trim(),
          footerCopyright: footerCopyright.trim(),
          footerBottomText: footerBottomText.trim(),
          footerEmail: footerEmail.trim(),
          footerPhone: footerPhone.trim(),
          footerAddress: footerAddress.trim(),
          footerSchedule: footerSchedule.trim(),
          footerFacebook: footerFacebook.trim(),
          footerTwitter: footerTwitter.trim(),
          footerInstagram: footerInstagram.trim(),
          footerLinkedin: footerLinkedin.trim(),
          footerYoutube: footerYoutube.trim(),
          footerGithub: footerGithub.trim(),
          footerShowSocial,
          footerShowContact,
          footerNavTitle: footerNavTitle.trim(),
          footerServicesTitle: footerServicesTitle.trim(),
          footerResourcesTitle: footerResourcesTitle.trim(),

          // Ajustes de Lectura
          showOnFront,
          pageOnFront: pageOnFront || null,
          pageForPosts: pageForPosts || null,
          postsPerPage: Number(postsPerPage) || 10,
        }),
      });

      const data = await res.json();
      if (data.success) {
        showToast("¡Ajustes guardados correctamente en MySQL!", "success");
        if (typeof document !== "undefined") {
          document.title = `Panel de Administración | ${siteTitle.trim()}`;
          let link: HTMLLinkElement | null = document.querySelector("link[rel~='icon']");
          if (!link) {
            link = document.createElement("link");
            link.rel = "icon";
            document.getElementsByTagName("head")[0].appendChild(link);
          }
          link.href = faviconUrl.trim();
        }
      } else {
        showToast(data.error || "Error al guardar ajustes.", "error");
      }
    } catch (err) {
      console.error(err);
      showToast("Error de conexión con el servidor.", "error");
    } finally {
      setIsSaving(false);
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    showToast(`${label} copiado al portapapeles.`, "success");
  };

  if (isLoading) {
    return (
      <div className="loading-fullscreen">
        <Loader2 className="animate-spin" />
        <span>Cargando...</span>
        <style jsx>{`
          .loading-fullscreen {
            min-height: 80vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 12px;
            color: #94a3b8;
          }
        `}</style>
      </div>
    );
  }

  return (
    <div className="techlab-settings-page">
      {/* Toast */}
      {toastMessage && (
        <div className={`techlab-toast ${toastType}`}>
          {toastType === "success" ? <CheckCircle2 /> : <AlertTriangle />}
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="settings-header-bar">
        <div className="header-title-group">
          <div className="header-icon-badge" style={{ color: primaryColor, borderColor: `${primaryColor}60` }}>
            <Settings />
          </div>
          <div>
            <h1>Ajustes Generales del Sitio</h1>
            <p>Personaliza la identidad, colores, logos, metadatos y configuración de tu plataforma</p>
          </div>
        </div>

        <button
          type="button"
          className="neon-add-btn"
          onClick={handleSaveSettings}
          disabled={isSaving}
          style={{
            background: `linear-gradient(110deg, ${accentColor}, ${primaryColor})`,
            boxShadow: `0 0 20px ${primaryColor}50`,
          }}
        >
          {isSaving ? <Loader2 className="animate-spin" /> : <Save />}
          <span>{isSaving ? "Guardando..." : "Guardar Cambios"}</span>
        </button>
      </div>

      {/* Tabs Switcher: Básico | Personalización */}
      <div className="settings-tabs-navbar">
        <button
          type="button"
          className={`tab-switch-btn ${activeTab === "basico" ? "active" : ""}`}
          onClick={() => setActiveTab("basico")}
        >
          <Sliders />
          <span>Básico</span>
        </button>

        <button
          type="button"
          className={`tab-switch-btn ${activeTab === "personalizacion" ? "active" : ""}`}
          onClick={() => setActiveTab("personalizacion")}
        >
          <Palette />
          <span>Personalización</span>
          <span className="tab-highlight-badge" style={{ backgroundColor: `${primaryColor}25`, color: primaryColor }}>
            Diseño & Logos
          </span>
        </button>

        <button
          type="button"
          className={`tab-switch-btn ${activeTab === "footer" ? "active" : ""}`}
          onClick={() => setActiveTab("footer")}
        >
          <PanelBottom />
          <span>Pie de Página (Footer)</span>
          <span className="tab-highlight-badge" style={{ backgroundColor: `${secondaryColor}25`, color: secondaryColor }}>
            Ancho Completo
          </span>
        </button>

        <button
          type="button"
          className={`tab-switch-btn ${activeTab === "lectura" ? "active" : ""}`}
          onClick={() => setActiveTab("lectura")}
        >
          <BookOpen />
          <span>Lectura</span>
          <span className="tab-highlight-badge" style={{ backgroundColor: `${accentColor}25`, color: accentColor }}>
            Página de Inicio
          </span>
        </button>
      </div>

      {/* Grid Principal */}
      <form onSubmit={handleSaveSettings} className={activeTab === "footer" || activeTab === "lectura" ? "settings-footer-form" : "settings-main-layout"}>
        {/* =================================================================
            PESTAÑA 1: BÁSICO
            ================================================================= */}
        {activeTab === "basico" && (
          <>
            {/* Columna Izquierda: Formulario Básico */}
            <div className="settings-left-col">
              {/* Card 1: Identidad del Sitio */}
              <section className="settings-card">
                <div className="settings-card-header">
                  <Globe />
                  <div>
                    <h2>Identidad & Metadatos del Sitio</h2>
                    <p>Define el nombre y la descripción que se mostrarán en la web y motores de búsqueda</p>
                  </div>
                </div>

                <div className="settings-card-body">
                  <div className="form-field-group">
                    <div className="field-label-row">
                      <label htmlFor="siteTitle">Título del Sitio:</label>
                      <span className="field-hint">{siteTitle.length}/70 caracteres</span>
                    </div>
                    <input
                      id="siteTitle"
                      type="text"
                      placeholder="ej. TechLab - Innovación y Desarrollo Web"
                      value={siteTitle}
                      onChange={(e) => setSiteTitle(e.target.value)}
                      className="settings-text-input"
                      required
                    />
                    <span className="field-description">
                      El título principal de tu sitio web que aparece en la pestaña del navegador y en los encabezados.
                    </span>
                  </div>

                  <div className="form-field-group">
                    <div className="field-label-row">
                      <label htmlFor="siteDescription">Descripción del Sitio:</label>
                      <span className="field-hint">{siteDescription.length}/160 caracteres</span>
                    </div>
                    <textarea
                      id="siteDescription"
                      rows={4}
                      placeholder="ej. Agencia especializada en desarrollo web de alto impacto, plataformas cloud y ciberseguridad..."
                      value={siteDescription}
                      onChange={(e) => setSiteDescription(e.target.value)}
                      className="settings-textarea-input"
                    />
                    <span className="field-description">
                      Breve resumen de tu sitio web utilizado como meta-descripción en Google y redes sociales.
                    </span>
                  </div>
                </div>
              </section>

              {/* Card 2: Icono del Sitio (Favicon) */}
              <section className="settings-card">
                <div className="settings-card-header">
                  <Sparkles />
                  <div>
                    <h2>Icono del Sitio (Favicon)</h2>
                    <p>El icono oficial que los usuarios verán en las pestañas y marcadores del navegador</p>
                  </div>
                </div>

                <div className="settings-card-body">
                  <div className="favicon-picker-container">
                    {/* Preview actual */}
                    <div className="favicon-current-display">
                      <div className="favicon-box">
                        <img src={faviconUrl} alt="Favicon actual" />
                      </div>
                      <div className="favicon-info">
                        <strong>Favicon Activo</strong>
                        <span>{faviconUrl}</span>
                      </div>
                    </div>

                    {/* Subir archivo */}
                    <div
                      className="favicon-upload-btn-wrap"
                      onClick={() => faviconInputRef.current?.click()}
                    >
                      {isUploadingFavicon ? (
                        <Loader2 className="animate-spin" />
                      ) : (
                        <UploadCloud />
                      )}
                      <span>{isUploadingFavicon ? "Subiendo..." : "Subir nuevo icono (.ico / .png / .svg)"}</span>
                      <input
                        ref={faviconInputRef}
                        type="file"
                        accept=".ico,.png,.svg,.jpg,.webp"
                        onChange={handleUploadFavicon}
                        style={{ display: "none" }}
                      />
                    </div>

                    {/* Presets rápidos */}
                    <div className="favicon-presets-wrap">
                      <span>O escoge un preset oficial:</span>
                      <div className="presets-grid">
                        {FAVICON_PRESETS.map((preset) => (
                          <button
                            key={preset.name}
                            type="button"
                            className={`preset-choice-btn ${faviconUrl === preset.url ? "selected" : ""}`}
                            onClick={() => setFaviconUrl(preset.url)}
                          >
                            <img src={preset.url} alt={preset.name} />
                            <span>{preset.label}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </section>

              {/* Card 3: Direcciones URLs */}
              <section className="settings-card">
                <div className="settings-card-header">
                  <Layout />
                  <div>
                    <h2>Direcciones URLs del Sistema</h2>
                    <p>Rutas de acceso para el portal público y el panel de administración</p>
                  </div>
                </div>

                <div className="settings-card-body">
                  <div className="form-field-group">
                    <label htmlFor="publicUrl">Dirección URL del Sitio Público:</label>
                    <div className="input-with-copy">
                      <input
                        id="publicUrl"
                        type="text"
                        placeholder="http://localhost:3000"
                        value={publicUrl}
                        onChange={(e) => setPublicUrl(e.target.value)}
                        className="settings-text-input"
                      />
                      <button
                        type="button"
                        className="btn-copy-input"
                        onClick={() => copyToClipboard(publicUrl, "URL Pública")}
                        title="Copiar URL pública"
                      >
                        <Copy />
                      </button>
                      <a
                        href={publicUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn-open-input"
                        title="Abrir web pública"
                      >
                        <ExternalLink />
                      </a>
                    </div>
                    <span className="field-description">
                      La dirección base donde está alojada la página principal para tus visitantes y clientes.
                    </span>
                  </div>

                  <div className="form-field-group">
                    <label htmlFor="adminUrl">Dirección URL del Panel de Administración:</label>
                    <div className="input-with-copy">
                      <input
                        id="adminUrl"
                        type="text"
                        placeholder="/dashboard"
                        value={adminUrl}
                        onChange={(e) => setAdminUrl(e.target.value)}
                        className="settings-text-input"
                      />
                      <button
                        type="button"
                        className="btn-copy-input"
                        onClick={() => copyToClipboard(publicUrl + adminUrl, "URL del Panel")}
                        title="Copiar URL del admin"
                      >
                        <Copy />
                      </button>
                    </div>
                    <span className="field-description">
                      Ruta relativa o absoluta para acceder al panel de control interno (`/dashboard`).
                    </span>
                  </div>
                </div>
              </section>

              {/* Card 4: Botón Flotante de WhatsApp */}
              <section className="settings-card">
                <div className="settings-card-header">
                  <div className="whatsapp-card-head-ico">
                    <MessageCircle />
                  </div>
                  <div>
                    <h2>Botón Flotante de WhatsApp</h2>
                    <p>Configura el botón de chat directo para que tus clientes te contacten por WhatsApp</p>
                  </div>
                </div>

                <div className="settings-card-body">
                  {/* Switch Activar/Desactivar */}
                  <div className="form-field-group">
                    <div className="field-label-row">
                      <label>Estado del Botón en la Web:</label>
                      <span className={`status-pill-badge ${whatsappEnabled ? "active" : "disabled"}`}>
                        {whatsappEnabled ? "Habilitado en la Web" : "Deshabilitado (Oculto)"}
                      </span>
                    </div>
                    <label className="settings-toggle-row">
                      <input
                        type="checkbox"
                        checked={whatsappEnabled}
                        onChange={(e) => setWhatsappEnabled(e.target.checked)}
                      />
                      <span className="toggle-slider" />
                      <span className="toggle-text">
                        {whatsappEnabled
                          ? "El botón verde de WhatsApp se mostrará flotando en la esquina inferior derecha de la web."
                          : "El botón de WhatsApp está desactivado y no aparecerá en el sitio público."}
                      </span>
                    </label>
                  </div>

                  {/* Número de WhatsApp */}
                  <div className="form-field-group">
                    <div className="field-label-row">
                      <label htmlFor="whatsappNumber">Número de WhatsApp (con código de país):</label>
                      <span className="field-hint">ej. +51 900 123 456</span>
                    </div>
                    <input
                      id="whatsappNumber"
                      type="text"
                      placeholder="+51 900 123 456"
                      value={whatsappNumber}
                      onChange={(e) => setWhatsappNumber(e.target.value)}
                      className="settings-text-input"
                    />
                    <span className="field-description">
                      Ingresa el número con el código internacional (ej. <b>+51</b> para Perú, <b>+52</b> para México, <b>+34</b> para España, <b>+1</b> para USA).
                    </span>
                  </div>

                  {/* Mensaje Predeterminado */}
                  <div className="form-field-group">
                    <label htmlFor="whatsappMessage">Mensaje inicial predeterminado (Opcional):</label>
                    <input
                      id="whatsappMessage"
                      type="text"
                      placeholder="ej. Hola TechLab! Deseo cotizar un proyecto web."
                      value={whatsappMessage}
                      onChange={(e) => setWhatsappMessage(e.target.value)}
                      className="settings-text-input"
                    />
                    <span className="field-description">
                      Texto que aparecerá escrito automáticamente en la app de WhatsApp del cliente al hacer clic.
                    </span>
                  </div>

                  {/* Acciones de WhatsApp: Guardar y Probar */}
                  <div className="whatsapp-actions-row">
                    <button
                      type="button"
                      onClick={handleSaveSettings}
                      disabled={isSaving}
                      className="btn-save-whatsapp-direct"
                      style={{
                        background: "#25d366",
                        color: "#030b12",
                        border: "none",
                        padding: "8px 16px",
                        borderRadius: "7px",
                        fontWeight: 700,
                        fontSize: "12px",
                        cursor: "pointer",
                        display: "inline-flex",
                        alignItems: "center",
                        gap: "6px",
                      }}
                    >
                      {isSaving ? <Loader2 className="animate-spin" style={{ width: 14, height: 14 }} /> : <Save style={{ width: 14, height: 14 }} />}
                      <span>{isSaving ? "Guardando..." : "Guardar WhatsApp"}</span>
                    </button>

                    {whatsappNumber && (
                      <a
                        href={`https://wa.me/${whatsappNumber.replace(/[^0-9]/g, "")}${whatsappMessage ? `?text=${encodeURIComponent(whatsappMessage)}` : ""}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn-test-whatsapp-link"
                      >
                        <ExternalLink /> Probar en WhatsApp Web
                      </a>
                    )}
                  </div>
                </div>
              </section>
            </div>

            {/* Columna Derecha: Live Previews Básicos */}
            <div className="settings-right-col">
              {/* Card: Live Browser Tab Mockup */}
              <div className="preview-card">
                <div className="preview-card-header">
                  <Eye />
                  <h3>Vista Previa: Pestaña del Navegador</h3>
                </div>
                <div className="preview-card-body">
                  <div className="mock-browser-window">
                    <div className="mock-browser-tab-bar">
                      <div className="mock-browser-tab active">
                        <img src={faviconUrl} alt="Favicon" className="mock-tab-icon" />
                        <span className="mock-tab-title">{siteTitle || "TechLab"}</span>
                        <span className="mock-tab-close">×</span>
                      </div>
                      <div className="mock-browser-newtab">+</div>
                    </div>

                    <div className="mock-browser-address-bar">
                      <Shield className="mock-secure-icon" style={{ color: primaryColor }} />
                      <span className="mock-url-text">
                        {publicUrl.replace(/^https?:\/\//, "")}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Card: Google SERP Preview */}
              <div className="preview-card">
                <div className="preview-card-header">
                  <Search />
                  <h3>Vista Previa: Resultado en Google</h3>
                </div>
                <div className="preview-card-body">
                  <div className="mock-google-snippet">
                    <div className="google-snippet-url-row">
                      <img src={faviconUrl} alt="Favicon" className="google-favicon" />
                      <div className="google-url-details">
                        <span className="google-site-name">TechLab</span>
                        <span className="google-display-url">{publicUrl}</span>
                      </div>
                    </div>
                    <h4 className="google-snippet-title">
                      {siteTitle || "TechLab - Innovación y Desarrollo Web"}
                    </h4>
                    <p className="google-snippet-desc">
                      {siteDescription || "Laboratorio de innovación tecnológica, desarrollo de software a medida, aplicaciones web y servicios en la nube de alta disponibilidad."}
                    </p>
                  </div>
                </div>
              </div>

              {/* Card: Live WhatsApp Button Mockup con Edición Directa */}
              <div className="preview-card">
                <div className="preview-card-header" style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <MessageCircle style={{ color: "#25d366" }} />
                    <h3>Vista Previa: Botón Flotante de WhatsApp</h3>
                  </div>
                </div>
                <div className="preview-card-body">
                  <div className="mock-whatsapp-preview-corner">
                    <div className="mock-corner-badge">
                      <span>Esquina inferior derecha</span>
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <small className={whatsappEnabled ? "text-green" : "text-red"}>
                          {whatsappEnabled ? "● Visible" : "○ Oculto"}
                        </small>
                        <button
                          type="button"
                          onClick={() => setWhatsappEnabled(!whatsappEnabled)}
                          className="btn-toggle-mini"
                          style={{
                            fontSize: "10px",
                            padding: "2px 8px",
                            borderRadius: "4px",
                            background: whatsappEnabled ? "rgba(239, 68, 68, 0.15)" : "rgba(37, 211, 102, 0.15)",
                            color: whatsappEnabled ? "#ef4444" : "#25d366",
                            border: "1px solid currentColor",
                            cursor: "pointer",
                          }}
                        >
                          {whatsappEnabled ? "Desactivar" : "Activar"}
                        </button>
                      </div>
                    </div>

                    {whatsappEnabled ? (
                      <div className="mock-whatsapp-btn-render">
                        <svg viewBox="0 0 32 32">
                          <path
                            fill="currentColor"
                            d="M16.02 3A12.8 12.8 0 0 0 5.1 22.49L3.4 29l6.66-1.75A12.99 12.99 0 1 0 16.02 3Zm0 23.61c-1.93 0-3.82-.52-5.47-1.5l-.39-.23-3.95 1.04 1.06-3.84-.25-.4a10.4 10.4 0 1 1 9 4.93Zm5.7-7.8c-.31-.16-1.85-.91-2.14-1.02-.28-.1-.49-.16-.7.16-.2.31-.8 1.02-.98 1.23-.18.21-.36.24-.67.08-.31-.16-1.32-.49-2.51-1.55a9.4 9.4 0 0 1-1.74-2.16c-.18-.31-.02-.48.14-.64.14-.14.31-.36.47-.55.15-.18.2-.31.31-.52.1-.21.05-.39-.03-.55-.08-.15-.7-1.68-.95-2.3-.25-.6-.51-.52-.7-.53h-.6c-.2 0-.54.08-.82.39-.28.31-1.08 1.05-1.08 2.57 0 1.51 1.11 2.98 1.26 3.18.16.21 2.18 3.32 5.27 4.66.74.32 1.31.51 1.76.65.74.23 1.41.2 1.94.12.59-.09 1.85-.76 2.11-1.49.26-.73.26-1.36.18-1.49-.07-.13-.28-.2-.59-.36Z"
                          />
                        </svg>
                      </div>
                    ) : (
                      <div className="mock-whatsapp-disabled-alert">
                        <span>Botón desactivado desde el panel</span>
                      </div>
                    )}

                    {/* Resumen informativo en la vista previa sin inputs redundantes */}
                    <div className="mock-whatsapp-info-display">
                      <div className="mock-whatsapp-info-row">
                        <span>Número destino:</span>
                        <b>{whatsappNumber || "No configurado"}</b>
                      </div>
                      {whatsappMessage && (
                        <div className="mock-whatsapp-msg-snippet" title={whatsappMessage}>
                          "{whatsappMessage}"
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Save Action Banner */}
              <div className="save-banner-card" style={{ borderColor: `${primaryColor}40` }}>
                <div className="save-banner-icon" style={{ background: `${primaryColor}20`, color: primaryColor }}>
                  <CheckCircle2 />
                </div>
                <div className="save-banner-content">
                  <h4>¿Todo listo?</h4>
                  <p>Guarda tus cambios para sincronizar la base de datos MySQL al instante.</p>
                </div>
                <button
                  type="submit"
                  className="neon-add-btn"
                  disabled={isSaving}
                  style={{
                    background: `linear-gradient(110deg, ${accentColor}, ${primaryColor})`,
                    boxShadow: `0 0 20px ${primaryColor}50`,
                  }}
                >
                  {isSaving ? <Loader2 className="animate-spin" /> : <Save />}
                  <span>{isSaving ? "Guardando..." : "Guardar Ajustes"}</span>
                </button>
              </div>
            </div>
          </>
        )}

        {/* =================================================================
            PESTAÑA 2: PERSONALIZACIÓN (LOGOS, COLORES, TEMAS)
            ================================================================= */}
        {activeTab === "personalizacion" && (
          <>
            {/* Columna Izquierda: Controles de Personalización */}
            <div className="settings-left-col">
              {/* Card 1: Logotipos de la Marca */}
              <section className="settings-card">
                <div className="settings-card-header">
                  <ImageIcon />
                  <div>
                    <h2>Logotipos de la Marca & Slogan</h2>
                    <p>Sube los logos oficiales para la barra de navegación, pie de página y correos</p>
                  </div>
                </div>

                <div className="settings-card-body">
                  {/* Grid de Logos */}
                  <div className="logos-upload-grid">
                    {/* Logo Principal */}
                    <div className="logo-upload-box">
                      <label>Logo Principal (Cabecera / Barra lateral):</label>
                      {logoUrl ? (
                        <div className="logo-preview-active">
                          <img src={logoUrl} alt="Logo Principal" />
                          <button
                            type="button"
                            className="btn-remove-logo"
                            onClick={() => setLogoUrl("")}
                          >
                            Eliminar Logo
                          </button>
                        </div>
                      ) : (
                        <div
                          className="logo-dropzone"
                          onClick={() => logoInputRef.current?.click()}
                        >
                          {isUploadingLogo ? <Loader2 className="animate-spin" /> : <UploadCloud />}
                          <span>{isUploadingLogo ? "Subiendo..." : "Subir Logo PNG / SVG"}</span>
                          <small>Fondo transparente recomendado</small>
                        </div>
                      )}
                      <input
                        ref={logoInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleUploadLogo}
                        style={{ display: "none" }}
                      />
                    </div>

                    {/* Logo Secundario (Claro / Miniatura) */}
                    <div className="logo-upload-box">
                      <label>Logo Secundario (Fondo Claro / Alternativo):</label>
                      {logoDarkUrl ? (
                        <div className="logo-preview-active light-bg">
                          <img src={logoDarkUrl} alt="Logo Secundario" />
                          <button
                            type="button"
                            className="btn-remove-logo"
                            onClick={() => setLogoDarkUrl("")}
                          >
                            Eliminar Logo
                          </button>
                        </div>
                      ) : (
                        <div
                          className="logo-dropzone"
                          onClick={() => logoDarkInputRef.current?.click()}
                        >
                          {isUploadingLogoDark ? <Loader2 className="animate-spin" /> : <UploadCloud />}
                          <span>{isUploadingLogoDark ? "Subiendo..." : "Subir Logo Secundario"}</span>
                          <small>Para fondos claros o versión reducida</small>
                        </div>
                      )}
                      <input
                        ref={logoDarkInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleUploadLogoDark}
                        style={{ display: "none" }}
                      />
                    </div>
                  </div>

                  {/* Slogan de Marca */}
                  <div className="form-field-group">
                    <label htmlFor="slogan">Slogan o Lema de la Marca:</label>
                    <input
                      id="slogan"
                      type="text"
                      placeholder="ej. Tecnología que impulsa tu mundo."
                      value={slogan}
                      onChange={(e) => setSlogan(e.target.value)}
                      className="settings-text-input"
                    />
                    <span className="field-description">
                      Aparece debajo del logotipo en la cabecera principal y en el pie de página.
                    </span>
                  </div>
                </div>
              </section>

              {/* Card 2: Paleta de Colores del Tema */}
              <section className="settings-card">
                <div className="settings-card-header">
                  <Palette />
                  <div>
                    <h2>Paleta de Colores del Tema (Neón & Acentos)</h2>
                    <p>Cambia el color verde neón característico o elige un tema predeterminado</p>
                  </div>
                </div>

                <div className="settings-card-body">
                  {/* Presets de Color */}
                  <div className="color-presets-section">
                    <label>Temas de Color Rápidos:</label>
                    <div className="color-presets-grid">
                      {COLOR_PRESETS.map((preset) => {
                        const isCurrent = primaryColor === preset.primary;
                        return (
                          <button
                            key={preset.name}
                            type="button"
                            className={`color-preset-card ${isCurrent ? "is-selected" : ""}`}
                            onClick={() => applyColorPreset(preset)}
                          >
                            <div className="preset-swatches-row">
                              <span className="swatch" style={{ backgroundColor: preset.primary }} />
                              <span className="swatch" style={{ backgroundColor: preset.secondary }} />
                              <span className="swatch" style={{ backgroundColor: preset.accent }} />
                            </div>
                            <div className="preset-card-info">
                              <strong>{preset.name}</strong>
                              <span>{preset.label}</span>
                            </div>
                            {isCurrent && <Check className="check-badge-icon" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Selectores Hexadecimales Personalizados */}
                  <div className="custom-color-pickers-row">
                    {/* Color Primario */}
                    <div className="color-picker-item">
                      <label>Color Primario (Neón):</label>
                      <div className="color-input-badge">
                        <input
                          type="color"
                          value={primaryColor}
                          onChange={(e) => setPrimaryColor(e.target.value)}
                          className="html-color-input"
                        />
                        <input
                          type="text"
                          value={primaryColor}
                          onChange={(e) => setPrimaryColor(e.target.value)}
                          className="hex-text-input"
                        />
                      </div>
                      <span className="picker-tip">Botones principales, brillo y badges</span>
                    </div>

                    {/* Color Secundario */}
                    <div className="color-picker-item">
                      <label>Color Secundario (Cyan / Info):</label>
                      <div className="color-input-badge">
                        <input
                          type="color"
                          value={secondaryColor}
                          onChange={(e) => setSecondaryColor(e.target.value)}
                          className="html-color-input"
                        />
                        <input
                          type="text"
                          value={secondaryColor}
                          onChange={(e) => setSecondaryColor(e.target.value)}
                          className="hex-text-input"
                        />
                      </div>
                      <span className="picker-tip">Enlaces, bordes interactivos y KPIs</span>
                    </div>

                    {/* Color de Acento */}
                    <div className="color-picker-item">
                      <label>Color de Acento (Hover):</label>
                      <div className="color-input-badge">
                        <input
                          type="color"
                          value={accentColor}
                          onChange={(e) => setAccentColor(e.target.value)}
                          className="html-color-input"
                        />
                        <input
                          type="text"
                          value={accentColor}
                          onChange={(e) => setAccentColor(e.target.value)}
                          className="hex-text-input"
                        />
                      </div>
                      <span className="picker-tip">Degradados y estados de pulsación</span>
                    </div>
                  </div>
                </div>
              </section>

              {/* Card 3: Estilo de Bordes & Tema de Interfaz */}
              <section className="settings-card">
                <div className="settings-card-header">
                  <Shapes />
                  <div>
                    <h2>Estilo Visual & Geometría</h2>
                    <p>Configura los bordes de los botones, tarjetas y el contraste general</p>
                  </div>
                </div>

                <div className="settings-card-body">
                  <div className="border-radius-choices-grid">
                    <button
                      type="button"
                      className={`geometry-choice-btn ${borderRadius === "rounded" ? "selected" : ""}`}
                      onClick={() => setBorderRadius("rounded")}
                    >
                      <div className="sample-shape rounded" style={{ borderColor: primaryColor }} />
                      <strong>Redondeado Moderno</strong>
                      <span>Estilo suave de 8px a 12px</span>
                    </button>

                    <button
                      type="button"
                      className={`geometry-choice-btn ${borderRadius === "sharp" ? "selected" : ""}`}
                      onClick={() => setBorderRadius("sharp")}
                    >
                      <div className="sample-shape sharp" style={{ borderColor: primaryColor }} />
                      <strong>Cyberpunk / Recto</strong>
                      <span>Bordes cortados de 2px a 4px</span>
                    </button>

                    <button
                      type="button"
                      className={`geometry-choice-btn ${borderRadius === "pill" ? "selected" : ""}`}
                      onClick={() => setBorderRadius("pill")}
                    >
                      <div className="sample-shape pill" style={{ borderColor: primaryColor }} />
                      <strong>Estilo Cápsula</strong>
                      <span>Bordes 100% redondeados</span>
                    </button>
                  </div>
                </div>
              </section>
            </div>

            {/* Columna Derecha: Live Interactive UI Previews */}
            <div className="settings-right-col">
              {/* Live UI Components Showcase */}
              <div className="preview-card">
                <div className="preview-card-header">
                  <Sparkles style={{ color: primaryColor }} />
                  <h3>Vista Previa: Componentes en Vivo</h3>
                </div>
                <div className="preview-card-body">
                  <div className="interactive-preview-container">
                    {/* Mock Header Brand */}
                    <div className="preview-mock-brand">
                      {logoUrl ? (
                        <img src={logoUrl} alt="Logo" className="mock-custom-logo-img" />
                      ) : (
                        <div className="mock-brand-logo-wrap">
                          <CircuitBoard style={{ color: primaryColor }} />
                          <div>
                            <strong>
                              {siteTitle ? siteTitle.split(" ")[0] : "Tech"}
                              <span style={{ color: primaryColor }}>
                                {siteTitle ? siteTitle.split(" ").slice(1).join(" ") || "Lab" : "Lab"}
                              </span>
                            </strong>
                            <small>{slogan}</small>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Botones Neón de Prueba */}
                    <div className="preview-element-row">
                      <label>Botón Principal Neón:</label>
                      <button
                        type="button"
                        className="mock-live-btn"
                        style={{
                          background: `linear-gradient(110deg, ${accentColor}, ${primaryColor})`,
                          boxShadow: `0 0 16px ${primaryColor}50`,
                          color: "#030b12",
                          borderRadius: borderRadius === "sharp" ? "4px" : borderRadius === "pill" ? "999px" : "8px",
                        }}
                      >
                        <Sparkles />
                        <span>Publicar Proyecto</span>
                      </button>
                    </div>

                    {/* Badge de Estado */}
                    <div className="preview-element-row">
                      <label>Insignia de Estado / Categoría:</label>
                      <div className="badges-sample-wrap">
                        <span
                          className="mock-sample-pill"
                          style={{
                            backgroundColor: `${primaryColor}20`,
                            borderColor: `${primaryColor}60`,
                            color: primaryColor,
                            borderRadius: borderRadius === "sharp" ? "3px" : borderRadius === "pill" ? "999px" : "20px",
                          }}
                        >
                          ● Activo en Web
                        </span>

                        <span
                          className="mock-sample-pill"
                          style={{
                            backgroundColor: `${secondaryColor}20`,
                            borderColor: `${secondaryColor}60`,
                            color: secondaryColor,
                            borderRadius: borderRadius === "sharp" ? "3px" : borderRadius === "pill" ? "999px" : "20px",
                          }}
                        >
                          ★ Nube & DevOps
                        </span>
                      </div>
                    </div>

                    {/* Tarjeta KPI */}
                    <div className="preview-element-row">
                      <label>Tarjeta KPI Dashboard:</label>
                      <div
                        className="mock-kpi-card-preview"
                        style={{
                          borderRadius: borderRadius === "sharp" ? "4px" : borderRadius === "pill" ? "16px" : "10px",
                        }}
                      >
                        <div
                          className="mock-kpi-icon"
                          style={{ backgroundColor: `${primaryColor}20`, color: primaryColor }}
                        >
                          <Globe />
                        </div>
                        <div className="mock-kpi-info">
                          <span className="num" style={{ color: primaryColor }}>12</span>
                          <span className="lbl">Proyectos Publicados</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Banner de Guardar Personalización */}
              <div className="save-banner-card" style={{ borderColor: `${primaryColor}50` }}>
                <div className="save-banner-icon" style={{ background: `${primaryColor}20`, color: primaryColor }}>
                  <Palette />
                </div>
                <div className="save-banner-content">
                  <h4>Guardar Personalización</h4>
                  <p>Aplica tu nueva paleta de colores y logotipos a toda la plataforma.</p>
                </div>
                <button
                  type="submit"
                  className="neon-add-btn"
                  disabled={isSaving}
                  style={{
                    background: `linear-gradient(110deg, ${accentColor}, ${primaryColor})`,
                    boxShadow: `0 0 20px ${primaryColor}50`,
                  }}
                >
                  {isSaving ? <Loader2 className="animate-spin" /> : <Save />}
                  <span>{isSaving ? "Guardando..." : "Aplicar Personalización"}</span>
                </button>
              </div>
            </div>
          </>
        )}

        {/* =================================================================
            PESTAÑA 3: FOOTER (PIE DE PÁGINA - FORMULARIO HORIZONTAL ANCHO)
            ================================================================= */}
        {activeTab === "footer" && (
          <div className="settings-footer-wide-container">
            {/* Card 1: Identidad y Textos Principales del Footer (Horizontal) */}
            <section className="settings-card footer-wide-card">
              <div className="settings-card-header">
                <div className="card-header-icon-box" style={{ color: primaryColor, backgroundColor: `${primaryColor}15` }}>
                  <PanelBottom />
                </div>
                <div>
                  <h2>Identidad & Textos del Pie de Página</h2>
                  <p>Configura el extracto institucional, el texto de copyright y los enlaces legales del footer</p>
                </div>
              </div>

              <div className="settings-card-body">
                <div className="footer-horizontal-row-2col">
                  {/* Columna 1: Descripción / Slogan */}
                  <div className="form-field-group">
                    <div className="field-label-row">
                      <label htmlFor="footerDescription">Descripción / Slogan del Footer:</label>
                      <span className="field-hint">{footerDescription.length}/200 caracteres</span>
                    </div>
                    <textarea
                      id="footerDescription"
                      rows={3}
                      placeholder="ej. Laboratorio de innovación tecnológica, desarrollo de software a medida y servicios en la nube."
                      value={footerDescription}
                      onChange={(e) => setFooterDescription(e.target.value)}
                      className="settings-textarea"
                    />
                    <span className="field-description">
                      Texto descriptivo que aparece debajo del logotipo en la primera columna del pie de página.
                    </span>
                  </div>

                  {/* Columna 2: Copyright y Enlaces Legales */}
                  <div className="footer-subfields-stack">
                    <div className="form-field-group">
                      <div className="field-label-row">
                        <label htmlFor="footerCopyright">Texto de Derechos Reservados (Copyright):</label>
                      </div>
                      <input
                        id="footerCopyright"
                        type="text"
                        placeholder="ej. © %year% %sitename%. Todos los derechos reservados."
                        value={footerCopyright}
                        onChange={(e) => setFooterCopyright(e.target.value)}
                        className="settings-text-input"
                      />
                      <span className="field-description">
                        Usa <code>%year%</code> para el año actual y <code>%sitename%</code> para el nombre del sitio.
                      </span>
                    </div>

                    <div className="form-field-group">
                      <div className="field-label-row">
                        <label htmlFor="footerBottomText">Texto Inferior de Políticas & Términos:</label>
                      </div>
                      <input
                        id="footerBottomText"
                        type="text"
                        placeholder="ej. Términos y condiciones　|　Política de privacidad"
                        value={footerBottomText}
                        onChange={(e) => setFooterBottomText(e.target.value)}
                        className="settings-text-input"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Card 2: Datos de Contacto (Grid Horizontal de 4 Columnas) */}
            <section className="settings-card footer-wide-card">
              <div className="settings-card-header flex-between">
                <div className="header-left-flex">
                  <div className="card-header-icon-box" style={{ color: secondaryColor, backgroundColor: `${secondaryColor}15` }}>
                    <Mail />
                  </div>
                  <div>
                    <h2>Datos de Contacto del Footer</h2>
                    <p>Información visible en la columna derecha de contacto del portal web</p>
                  </div>
                </div>

                <label className="toggle-switch-label">
                  <span className="toggle-text">Mostrar Bloque de Contacto</span>
                  <input
                    type="checkbox"
                    checked={footerShowContact}
                    onChange={(e) => setFooterShowContact(e.target.checked)}
                    className="toggle-checkbox"
                  />
                  <span className="toggle-slider" style={{ backgroundColor: footerShowContact ? primaryColor : "#334155" }} />
                </label>
              </div>

              {footerShowContact && (
                <div className="settings-card-body">
                  <div className="footer-horizontal-grid-4col">
                    <div className="form-field-group">
                      <label htmlFor="footerEmail"><Mail className="field-inline-icon" /> Correo de Contacto:</label>
                      <input
                        id="footerEmail"
                        type="email"
                        placeholder="contacto@techlab.com"
                        value={footerEmail}
                        onChange={(e) => setFooterEmail(e.target.value)}
                        className="settings-text-input"
                      />
                    </div>

                    <div className="form-field-group">
                      <label htmlFor="footerPhone"><Phone className="field-inline-icon" /> Teléfono / WhatsApp:</label>
                      <input
                        id="footerPhone"
                        type="text"
                        placeholder="+51 900 123 456"
                        value={footerPhone}
                        onChange={(e) => setFooterPhone(e.target.value)}
                        className="settings-text-input"
                      />
                    </div>

                    <div className="form-field-group">
                      <label htmlFor="footerAddress"><MapPin className="field-inline-icon" /> Dirección / Ubicación:</label>
                      <input
                        id="footerAddress"
                        type="text"
                        placeholder="Lima, Perú"
                        value={footerAddress}
                        onChange={(e) => setFooterAddress(e.target.value)}
                        className="settings-text-input"
                      />
                    </div>

                    <div className="form-field-group">
                      <label htmlFor="footerSchedule"><Clock className="field-inline-icon" /> Horario de Atención:</label>
                      <input
                        id="footerSchedule"
                        type="text"
                        placeholder="Lun - Vie: 9:00 AM - 6:00 PM"
                        value={footerSchedule}
                        onChange={(e) => setFooterSchedule(e.target.value)}
                        className="settings-text-input"
                      />
                    </div>
                  </div>
                </div>
              )}
            </section>

            {/* Card 3: Redes Sociales (Grid Horizontal de 6 Columnas) */}
            <section className="settings-card footer-wide-card">
              <div className="settings-card-header flex-between">
                <div className="header-left-flex">
                  <div className="card-header-icon-box" style={{ color: "#a855f7", backgroundColor: "rgba(168,85,247,0.15)" }}>
                    <Share2 />
                  </div>
                  <div>
                    <h2>Redes Sociales del Pie de Página</h2>
                    <p>Enlaces directos con iconos interactivos de tus canales oficiales</p>
                  </div>
                </div>

                <label className="toggle-switch-label">
                  <span className="toggle-text">Mostrar Iconos de Redes</span>
                  <input
                    type="checkbox"
                    checked={footerShowSocial}
                    onChange={(e) => setFooterShowSocial(e.target.checked)}
                    className="toggle-checkbox"
                  />
                  <span className="toggle-slider" style={{ backgroundColor: footerShowSocial ? primaryColor : "#334155" }} />
                </label>
              </div>

              {footerShowSocial && (
                <div className="settings-card-body">
                  <div className="footer-horizontal-grid-6col">
                    <div className="form-field-group">
                      <label htmlFor="footerFacebook"><Facebook className="field-inline-icon fb" /> Facebook:</label>
                      <input
                        id="footerFacebook"
                        type="url"
                        placeholder="https://facebook.com/..."
                        value={footerFacebook}
                        onChange={(e) => setFooterFacebook(e.target.value)}
                        className="settings-text-input"
                      />
                    </div>

                    <div className="form-field-group">
                      <label htmlFor="footerTwitter"><Twitter className="field-inline-icon tw" /> Twitter / X:</label>
                      <input
                        id="footerTwitter"
                        type="url"
                        placeholder="https://twitter.com/..."
                        value={footerTwitter}
                        onChange={(e) => setFooterTwitter(e.target.value)}
                        className="settings-text-input"
                      />
                    </div>

                    <div className="form-field-group">
                      <label htmlFor="footerInstagram"><Instagram className="field-inline-icon ig" /> Instagram:</label>
                      <input
                        id="footerInstagram"
                        type="url"
                        placeholder="https://instagram.com/..."
                        value={footerInstagram}
                        onChange={(e) => setFooterInstagram(e.target.value)}
                        className="settings-text-input"
                      />
                    </div>

                    <div className="form-field-group">
                      <label htmlFor="footerLinkedin"><Linkedin className="field-inline-icon in" /> LinkedIn:</label>
                      <input
                        id="footerLinkedin"
                        type="url"
                        placeholder="https://linkedin.com/in/..."
                        value={footerLinkedin}
                        onChange={(e) => setFooterLinkedin(e.target.value)}
                        className="settings-text-input"
                      />
                    </div>

                    <div className="form-field-group">
                      <label htmlFor="footerYoutube"><Youtube className="field-inline-icon yt" /> YouTube:</label>
                      <input
                        id="footerYoutube"
                        type="url"
                        placeholder="https://youtube.com/@..."
                        value={footerYoutube}
                        onChange={(e) => setFooterYoutube(e.target.value)}
                        className="settings-text-input"
                      />
                    </div>

                    <div className="form-field-group">
                      <label htmlFor="footerGithub"><Github className="field-inline-icon gh" /> GitHub:</label>
                      <input
                        id="footerGithub"
                        type="url"
                        placeholder="https://github.com/..."
                        value={footerGithub}
                        onChange={(e) => setFooterGithub(e.target.value)}
                        className="settings-text-input"
                      />
                    </div>
                  </div>
                </div>
              )}
            </section>

            {/* Card 4: Títulos de las Columnas de Navegación (Grid Horizontal de 3 Columnas) */}
            <section className="settings-card footer-wide-card">
              <div className="settings-card-header">
                <div className="card-header-icon-box" style={{ color: "#f59e0b", backgroundColor: "rgba(245,158,11,0.15)" }}>
                  <Columns />
                </div>
                <div>
                  <h2>Títulos de Columnas del Footer</h2>
                  <p>Personaliza los encabezados de las 3 columnas centrales de navegación rápida</p>
                </div>
              </div>

              <div className="settings-card-body">
                <div className="footer-horizontal-grid-3col">
                  <div className="form-field-group">
                    <label htmlFor="footerNavTitle">Título Columna 1:</label>
                    <input
                      id="footerNavTitle"
                      type="text"
                      placeholder="NAVEGACIÓN"
                      value={footerNavTitle}
                      onChange={(e) => setFooterNavTitle(e.target.value)}
                      className="settings-text-input"
                    />
                    <span className="field-description">Enlaces principales del portal web</span>
                  </div>

                  <div className="form-field-group">
                    <label htmlFor="footerServicesTitle">Título Columna 2:</label>
                    <input
                      id="footerServicesTitle"
                      type="text"
                      placeholder="SERVICIOS"
                      value={footerServicesTitle}
                      onChange={(e) => setFooterServicesTitle(e.target.value)}
                      className="settings-text-input"
                    />
                    <span className="field-description">Lista de servicios tecnológicos</span>
                  </div>

                  <div className="form-field-group">
                    <label htmlFor="footerResourcesTitle">Título Columna 3:</label>
                    <input
                      id="footerResourcesTitle"
                      type="text"
                      placeholder="RECURSOS"
                      value={footerResourcesTitle}
                      onChange={(e) => setFooterResourcesTitle(e.target.value)}
                      className="settings-text-input"
                    />
                    <span className="field-description">Artículos, guías y blog</span>
                  </div>
                </div>
              </div>
            </section>

            {/* Card 5: Vista Previa en Vivo del Footer (Full Width / Ancho Completo) */}
            <section className="settings-card footer-wide-card footer-preview-container-card">
              <div className="settings-card-header flex-between">
                <div className="header-left-flex">
                  <div className="card-header-icon-box" style={{ color: primaryColor, backgroundColor: `${primaryColor}15` }}>
                    <Eye />
                  </div>
                  <div>
                    <h2>Vista Previa en Vivo del Pie de Página</h2>
                    <p>Así es exactamente como se renderiza en la web pública con tu configuración actual</p>
                  </div>
                </div>
                <span className="live-preview-pill" style={{ borderColor: `${primaryColor}60`, color: primaryColor }}>
                  <span className="live-dot" style={{ backgroundColor: primaryColor }} />
                  Actualización en Vivo
                </span>
              </div>

              <div className="settings-card-body">
                {/* Mockup del Footer Público */}
                <div className="footer-live-mockup">
                  <div className="mockup-footer-grid">
                    {/* Brand */}
                    <div className="mockup-brand-col">
                      <div className="mockup-brand-header">
                        {logoUrl ? (
                          <img src={logoUrl} alt="Logo" style={{ maxHeight: "28px" }} />
                        ) : (
                          <div className="mockup-logo-text">
                            <CircuitBoard style={{ color: primaryColor }} />
                            <span>
                              <b>{siteTitle || "TechLab"}</b>
                            </span>
                          </div>
                        )}
                      </div>
                      <p className="mockup-brand-desc">{footerDescription || "Descripción del pie de página..."}</p>
                      {footerShowSocial && (
                        <div className="mockup-socials-row">
                          {footerFacebook && <span className="mock-social-circle"><Facebook /></span>}
                          {footerTwitter && <span className="mock-social-circle"><Twitter /></span>}
                          {footerInstagram && <span className="mock-social-circle"><Instagram /></span>}
                          {footerLinkedin && <span className="mock-social-circle"><Linkedin /></span>}
                          {footerYoutube && <span className="mock-social-circle"><Youtube /></span>}
                          {footerGithub && <span className="mock-social-circle"><Github /></span>}
                        </div>
                      )}
                    </div>

                    {/* Column 1 */}
                    <div className="mockup-links-col">
                      <h5>{footerNavTitle || "NAVEGACIÓN"}</h5>
                      <ul>
                        <li>Inicio</li>
                        <li>Servicios</li>
                        <li>Portafolio</li>
                        <li>Contacto</li>
                      </ul>
                    </div>

                    {/* Column 2 */}
                    <div className="mockup-links-col">
                      <h5>{footerServicesTitle || "SERVICIOS"}</h5>
                      <ul>
                        <li>Desarrollo Web</li>
                        <li>WordPress & CMS</li>
                        <li>Ciberseguridad</li>
                        <li>Cloud DevOps</li>
                      </ul>
                    </div>

                    {/* Column 3 */}
                    <div className="mockup-links-col">
                      <h5>{footerResourcesTitle || "RECURSOS"}</h5>
                      <ul>
                        <li>Blog & Artículos</li>
                        <li>Tutoriales</li>
                        <li>Guías Técnicas</li>
                        <li>Plantillas</li>
                      </ul>
                    </div>

                    {/* Column 4: Contact */}
                    {footerShowContact && (
                      <div className="mockup-links-col mockup-contact-col">
                        <h5>CONTACTO</h5>
                        <ul>
                          {footerEmail && <li><Mail /> {footerEmail}</li>}
                          {footerPhone && <li><Phone /> {footerPhone}</li>}
                          {footerAddress && <li><MapPin /> {footerAddress}</li>}
                          {footerSchedule && <li><Clock /> {footerSchedule}</li>}
                        </ul>
                      </div>
                    )}
                  </div>

                  {/* Copyright Bar */}
                  <div className="mockup-copyright-bar">
                    <span>
                      {footerCopyright
                        .replace("%year%", new Date().getFullYear().toString())
                        .replace("%sitename%", siteTitle || "TechLab")}
                    </span>
                    <span>{footerBottomText}</span>
                  </div>
                </div>
              </div>

              {/* Botón de Guardado en el Footer Tab */}
              <div className="footer-bottom-save-bar">
                <div className="save-info">
                  <strong>¿Listo para publicar tus cambios?</strong>
                  <span>Se actualizará en tiempo real el pie de página de todas las vistas del sitio web.</span>
                </div>
                <button
                  type="submit"
                  className="neon-add-btn"
                  disabled={isSaving}
                  style={{
                    background: `linear-gradient(110deg, ${accentColor}, ${primaryColor})`,
                    boxShadow: `0 0 20px ${primaryColor}50`,
                  }}
                >
                  {isSaving ? <Loader2 className="animate-spin" /> : <Save />}
                  <span>{isSaving ? "Guardando..." : "Guardar Ajustes del Footer"}</span>
                </button>
              </div>
            </section>
          </div>
        )}

        {/* =================================================================
            PESTAÑA 4: AJUSTES DE LECTURA (ESTILO WORDPRESS / ELEMENTOR)
            ================================================================= */}
        {activeTab === "lectura" && (
          <div className="settings-footer-layout">
            <section className="settings-card full-width-card">
              <div className="settings-card-header">
                <BookOpen style={{ color: primaryColor }} />
                <div>
                  <h2>Ajustes de Lectura</h2>
                  <p>Configura qué página o contenido verá el visitante al acceder a la página de inicio y el feed de entradas</p>
                </div>
              </div>

              <div className="settings-card-body">
                {/* Bloque 1: Tu página de inicio muestra (WordPress Style) */}
                <div className="reading-setting-section">
                  <div className="reading-setting-title-row">
                    <label className="reading-main-label">Tu página de inicio muestra</label>
                  </div>

                  <div className="reading-radio-group">
                    {/* Opción 1: Tus últimas entradas */}
                    <label className={`reading-radio-option ${showOnFront === "posts" ? "selected" : ""}`}>
                      <input
                        type="radio"
                        name="showOnFront"
                        value="posts"
                        checked={showOnFront === "posts"}
                        onChange={() => setShowOnFront("posts")}
                      />
                      <div className="radio-content">
                        <strong>Tus últimas entradas</strong>
                        <p>Diseño predeterminado con secciones completas: Hero principal, Servicios, Proyectos, Testimonios, Entradas del blog y Llamada a la acción (CTA).</p>
                      </div>
                    </label>

                    {/* Opción 2: Una página estática */}
                    <label className={`reading-radio-option ${showOnFront === "page" ? "selected" : ""}`}>
                      <input
                        type="radio"
                        name="showOnFront"
                        value="page"
                        checked={showOnFront === "page"}
                        onChange={() => setShowOnFront("page")}
                      />
                      <div className="radio-content">
                        <strong>Una página estática (seleccionar abajo)</strong>
                        <p>Carga una página personalizada diseñada con Elementor o con el editor Gutenberg.</p>
                      </div>
                    </label>

                    {/* Sub-selectores anidados (Página de inicio y Página de entradas) */}
                    <div className={`reading-sub-selectors ${showOnFront === "page" ? "is-active" : "is-disabled"}`}>
                      {/* Selector Página de Inicio */}
                      <div className="reading-select-row">
                        <label htmlFor="pageOnFront">Página de inicio:</label>
                        <select
                          id="pageOnFront"
                          value={pageOnFront}
                          onChange={(e) => setPageOnFront(e.target.value)}
                          disabled={showOnFront !== "page"}
                        >
                          <option value="">— Elegir —</option>
                          {pagesList.map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.title} {p.template === "elementor_canvas" ? "⚡ (Elementor Canvas)" : ""} {p.status !== "Publicado" ? `[${p.status}]` : ""}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Selector Página de Entradas */}
                      <div className="reading-select-row">
                        <label htmlFor="pageForPosts">Página de entradas:</label>
                        <select
                          id="pageForPosts"
                          value={pageForPosts}
                          onChange={(e) => setPageForPosts(e.target.value)}
                          disabled={showOnFront !== "page"}
                        >
                          <option value="">— Elegir —</option>
                          {pagesList.map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.title} {p.status !== "Publicado" ? `[${p.status}]` : ""}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Separador */}
                <div className="settings-divider" />

                {/* Bloque 2: Número de entradas por página */}
                <div className="reading-setting-section">
                  <div className="reading-setting-title-row">
                    <label className="reading-main-label">Número máximo de entradas a mostrar en el sitio</label>
                  </div>
                  <div className="reading-input-inline">
                    <input
                      type="number"
                      min={1}
                      max={50}
                      value={postsPerPage}
                      onChange={(e) => setPostsPerPage(Math.max(1, parseInt(e.target.value) || 1))}
                      className="reading-number-input"
                    />
                    <span className="reading-input-unit">entradas por página</span>
                  </div>
                </div>

                {/* Banner Informativo sobre Elementor y Header / Footer */}
                <div className="reading-info-callout">
                  <div className="callout-icon" style={{ color: primaryColor }}>
                    <Sparkles />
                  </div>
                  <div className="callout-text">
                    <strong>Integración con Elementor & Navegación</strong>
                    <p>
                      Al elegir una página estática como Página de Inicio, su contenido o lienzo de Elementor se integrará directamente en la raíz de tu dominio (<code>/</code>). 
                      <strong> No afecta ni al Header ni al Footer</strong>, garantizando que el menú principal, redes sociales y pie de página sigan disponibles para tus usuarios.
                    </p>
                  </div>
                </div>
              </div>

              {/* Botón de Guardado */}
              <div className="footer-bottom-save-bar">
                <div className="save-info">
                  <strong>¿Deseas guardar los ajustes de lectura?</strong>
                  <span>El cambio en la página de inicio se aplicará de inmediato para todos los visitantes.</span>
                </div>
                <button
                  type="submit"
                  className="neon-add-btn"
                  disabled={isSaving}
                  style={{
                    background: `linear-gradient(110deg, ${accentColor}, ${primaryColor})`,
                    boxShadow: `0 0 20px ${primaryColor}50`,
                  }}
                >
                  {isSaving ? <Loader2 className="animate-spin" /> : <Save />}
                  <span>{isSaving ? "Guardando..." : "Guardar Ajustes de Lectura"}</span>
                </button>
              </div>
            </section>
          </div>
        )}
      </form>

      {/* ESTILOS TECHLAB CYBER DARK PRO */}
      <style jsx>{`
        .techlab-settings-page {
          padding: 0 0 40px;
          color: inherit;
        }

        /* Toast */
        .techlab-toast {
          position: fixed;
          top: 70px;
          right: 24px;
          z-index: 1000;
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 12px 18px;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 600;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.6);
          animation: slideIn 0.25s ease;
        }

        .techlab-toast.success {
          background: #062316;
          border: 1px solid #16c96f;
          color: #a7f3d0;
        }

        .techlab-toast.error {
          background: #270d0d;
          border: 1px solid #ef4444;
          color: #fca5a5;
        }

        @keyframes slideIn {
          from { opacity: 0; transform: translateY(-16px); }
          to { opacity: 1; transform: translateY(0); }
        }

        /* Header */
        .settings-header-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 20px;
          gap: 16px;
        }

        .header-title-group {
          display: flex;
          align-items: center;
          gap: 14px;
        }

        .header-icon-badge {
          width: 48px;
          height: 48px;
          border-radius: 12px;
          background: rgba(56, 189, 248, 0.12);
          border: 1px solid rgba(56, 189, 248, 0.4);
          display: grid;
          place-items: center;
          box-shadow: 0 0 20px rgba(56, 189, 248, 0.2);
        }

        .header-icon-badge :global(svg) {
          width: 24px;
          height: 24px;
        }

        .header-title-group h1 {
          font-size: 22px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 4px;
          letter-spacing: -0.4px;
        }

        .header-title-group p {
          font-size: 13px;
          color: #94a3b8;
          margin: 0;
        }

        /* Tabs Switcher */
        .settings-tabs-navbar {
          display: flex;
          align-items: center;
          gap: 8px;
          margin-bottom: 24px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
          padding-bottom: 12px;
        }

        .tab-switch-btn {
          height: 40px;
          padding: 0 18px;
          border-radius: 8px;
          background: transparent;
          border: 1px solid transparent;
          color: #94a3b8;
          font-size: 13px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          transition: all 0.15s ease;
        }

        .tab-switch-btn:hover {
          color: #ffffff;
          background: rgba(255, 255, 255, 0.04);
        }

        .tab-switch-btn.active {
          color: #ffffff;
          background: #07131e;
          border-color: rgba(56, 189, 248, 0.35);
          box-shadow: 0 0 14px rgba(56, 189, 248, 0.15);
        }

        .tab-switch-btn :global(svg) {
          width: 16px;
          height: 16px;
        }

        .tab-highlight-badge {
          font-size: 10px;
          font-weight: 800;
          padding: 2px 7px;
          border-radius: 4px;
          text-transform: uppercase;
        }

        /* Layout */
        .settings-main-layout {
          display: grid;
          grid-template-columns: 1fr 380px;
          gap: 24px;
          align-items: start;
        }

        .settings-left-col,
        .settings-right-col {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        /* Cards */
        .settings-card,
        .preview-card {
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 12px;
          overflow: hidden;
        }

        .settings-card-header,
        .preview-card-header {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 16px 20px;
          background: #07131e;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .settings-card-header :global(svg),
        .preview-card-header :global(svg) {
          width: 20px;
          height: 20px;
          color: #38bdf8;
        }

        .settings-card-header h2,
        .preview-card-header h3 {
          font-size: 15px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 2px;
        }

        .settings-card-header p {
          font-size: 12px;
          color: #94a3b8;
          margin: 0;
        }

        .settings-card-body,
        .preview-card-body {
          padding: 20px;
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        /* Form Fields */
        .form-field-group {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .field-label-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .field-label-row label,
        .form-field-group label {
          font-size: 12px;
          font-weight: 700;
          color: #cbd5e1;
        }

        .field-hint {
          font-size: 11px;
          color: #64748b;
          font-family: monospace;
        }

        .settings-text-input,
        .settings-textarea-input {
          width: 100%;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 10px 14px;
          color: #ffffff;
          font-size: 13px;
          outline: none;
        }

        .settings-text-input:focus,
        .settings-textarea-input:focus {
          border-color: #38bdf8;
          box-shadow: 0 0 10px rgba(56, 189, 248, 0.2);
        }

        .field-description {
          font-size: 11px;
          color: #64748b;
          line-height: 1.4;
        }

        .input-with-copy {
          display: flex;
          gap: 6px;
        }

        .btn-copy-input,
        .btn-open-input {
          width: 40px;
          height: 40px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          color: #94a3b8;
          display: grid;
          place-items: center;
          cursor: pointer;
          text-decoration: none;
        }

        .btn-copy-input:hover,
        .btn-open-input:hover {
          color: #38bdf8;
          border-color: #38bdf8;
        }

        .btn-copy-input :global(svg),
        .btn-open-input :global(svg) {
          width: 15px;
          height: 15px;
        }

        /* Favicon Picker */
        .favicon-picker-container {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .favicon-current-display {
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 12px 16px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 8px;
        }

        .favicon-box {
          width: 44px;
          height: 44px;
          border-radius: 8px;
          background: #03070b;
          border: 1px solid rgba(255, 255, 255, 0.15);
          display: grid;
          place-items: center;
          padding: 6px;
        }

        .favicon-box img {
          max-width: 100%;
          max-height: 100%;
          object-fit: contain;
        }

        .favicon-info {
          display: flex;
          flex-direction: column;
        }

        .favicon-info strong {
          font-size: 13px;
          color: #ffffff;
        }

        .favicon-info span {
          font-size: 11px;
          color: #64748b;
          font-family: monospace;
          word-break: break-all;
        }

        .favicon-upload-btn-wrap {
          padding: 20px;
          background: #07131e;
          border: 1px dashed rgba(56, 189, 248, 0.4);
          border-radius: 8px;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          color: #38bdf8;
          font-size: 12px;
          font-weight: 600;
        }

        .favicon-upload-btn-wrap:hover {
          background: rgba(56, 189, 248, 0.05);
        }

        .favicon-upload-btn-wrap :global(svg) {
          width: 24px;
          height: 24px;
        }

        .favicon-presets-wrap span {
          display: block;
          font-size: 11px;
          font-weight: 700;
          color: #94a3b8;
          text-transform: uppercase;
          margin-bottom: 8px;
        }

        .presets-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 8px;
        }

        .preset-choice-btn {
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 8px 12px;
          display: flex;
          align-items: center;
          gap: 10px;
          color: #cbd5e1;
          font-size: 12px;
          cursor: pointer;
        }

        .preset-choice-btn:hover,
        .preset-choice-btn.selected {
          border-color: #38bdf8;
          background: rgba(56, 189, 248, 0.1);
          color: #38bdf8;
        }

        .preset-choice-btn img {
          width: 18px;
          height: 18px;
          object-fit: contain;
        }

        /* Logos Upload Section */
        .logos-upload-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 16px;
        }

        .logo-upload-box {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .logo-upload-box label {
          font-size: 12px;
          font-weight: 700;
          color: #cbd5e1;
        }

        .logo-dropzone {
          padding: 24px 16px;
          background: #07131e;
          border: 1px dashed rgba(255, 255, 255, 0.15);
          border-radius: 8px;
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          gap: 6px;
          cursor: pointer;
          color: #94a3b8;
          font-size: 12px;
          font-weight: 600;
        }

        .logo-dropzone:hover {
          border-color: #38bdf8;
          color: #38bdf8;
        }

        .logo-dropzone :global(svg) {
          width: 26px;
          height: 26px;
        }

        .logo-dropzone small {
          font-size: 10px;
          color: #64748b;
        }

        .logo-preview-active {
          padding: 16px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 10px;
        }

        .logo-preview-active.light-bg {
          background: #f8fafc;
        }

        .logo-preview-active img {
          max-height: 50px;
          max-width: 100%;
          object-fit: contain;
        }

        .btn-remove-logo {
          background: none;
          border: none;
          color: #ef4444;
          font-size: 11px;
          font-weight: 600;
          cursor: pointer;
        }

        /* Color Presets */
        .color-presets-section {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .color-presets-section label {
          font-size: 12px;
          font-weight: 700;
          color: #cbd5e1;
        }

        .color-presets-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 10px;
        }

        .color-preset-card {
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          padding: 12px;
          display: flex;
          flex-direction: column;
          gap: 8px;
          text-align: left;
          cursor: pointer;
          position: relative;
          transition: all 0.15s ease;
        }

        .color-preset-card:hover,
        .color-preset-card.is-selected {
          border-color: #38bdf8;
          background: rgba(56, 189, 248, 0.06);
        }

        .preset-swatches-row {
          display: flex;
          gap: 4px;
        }

        .swatch {
          width: 16px;
          height: 16px;
          border-radius: 50%;
        }

        .preset-card-info strong {
          display: block;
          font-size: 12px;
          color: #ffffff;
        }

        .preset-card-info span {
          font-size: 10px;
          color: #94a3b8;
        }

        .check-badge-icon {
          position: absolute;
          top: 10px;
          right: 10px;
          width: 14px;
          height: 14px;
          color: #16c96f;
        }

        /* Custom Color Pickers */
        .custom-color-pickers-row {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 12px;
          padding-top: 10px;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
        }

        .color-picker-item {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .color-picker-item label {
          font-size: 11px;
          font-weight: 700;
          color: #cbd5e1;
        }

        .color-input-badge {
          display: flex;
          align-items: center;
          gap: 6px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 4px 8px;
        }

        .html-color-input {
          width: 28px;
          height: 28px;
          border: none;
          background: transparent;
          cursor: pointer;
          padding: 0;
        }

        .hex-text-input {
          width: 100%;
          background: transparent;
          border: none;
          color: #ffffff;
          font-family: monospace;
          font-size: 12px;
          outline: none;
        }

        .picker-tip {
          font-size: 10px;
          color: #64748b;
        }

        /* Geometry choices */
        .border-radius-choices-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 12px;
        }

        .geometry-choice-btn {
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          padding: 16px 12px;
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          gap: 8px;
          cursor: pointer;
          color: #cbd5e1;
        }

        .geometry-choice-btn:hover,
        .geometry-choice-btn.selected {
          border-color: #38bdf8;
          color: #ffffff;
          background: rgba(56, 189, 248, 0.08);
        }

        .sample-shape {
          width: 48px;
          height: 32px;
          background: rgba(255, 255, 255, 0.05);
          border: 2px solid;
        }

        .sample-shape.rounded { border-radius: 8px; }
        .sample-shape.sharp { border-radius: 2px; }
        .sample-shape.pill { border-radius: 999px; }

        .geometry-choice-btn strong {
          font-size: 12px;
        }

        .geometry-choice-btn span {
          font-size: 10px;
          color: #94a3b8;
        }

        /* Interactive Showcase */
        .interactive-preview-container {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .preview-mock-brand {
          padding: 14px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 8px;
        }

        .mock-brand-logo-wrap {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .mock-brand-logo-wrap :global(svg) {
          width: 24px;
          height: 24px;
        }

        .mock-brand-logo-wrap strong {
          display: block;
          font-size: 14px;
          font-weight: 800;
          color: #ffffff;
        }

        .mock-brand-logo-wrap small {
          font-size: 10px;
          color: #94a3b8;
        }

        .mock-custom-logo-img {
          max-height: 36px;
          object-fit: contain;
        }

        .preview-element-row {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .preview-element-row label {
          font-size: 11px;
          font-weight: 700;
          color: #94a3b8;
          text-transform: uppercase;
        }

        .mock-live-btn {
          height: 38px;
          padding: 0 16px;
          border: none;
          font-size: 12px;
          font-weight: 800;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          cursor: pointer;
        }

        .mock-live-btn :global(svg) {
          width: 14px;
          height: 14px;
        }

        .badges-sample-wrap {
          display: flex;
          gap: 8px;
        }

        .mock-sample-pill {
          padding: 4px 12px;
          font-size: 11px;
          font-weight: 700;
          border: 1px solid;
          display: inline-flex;
          align-items: center;
          gap: 4px;
        }

        .mock-kpi-card-preview {
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          padding: 12px 14px;
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .mock-kpi-icon {
          width: 36px;
          height: 36px;
          border-radius: 6px;
          display: grid;
          place-items: center;
        }

        .mock-kpi-icon :global(svg) {
          width: 18px;
          height: 18px;
        }

        .mock-kpi-info {
          display: flex;
          flex-direction: column;
        }

        .mock-kpi-info .num {
          font-size: 18px;
          font-weight: 800;
        }

        .mock-kpi-info .lbl {
          font-size: 10px;
          color: #94a3b8;
          font-weight: 600;
          text-transform: uppercase;
        }

        /* Mock Browser Window */
        .mock-browser-window {
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          overflow: hidden;
        }

        .mock-browser-tab-bar {
          background: #03070b;
          padding: 8px 8px 0;
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .mock-browser-tab {
          background: #07131e;
          border-radius: 6px 6px 0 0;
          padding: 6px 10px;
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 11px;
          color: #ffffff;
          max-width: 200px;
        }

        .mock-tab-icon {
          width: 14px;
          height: 14px;
          object-fit: contain;
        }

        .mock-tab-title {
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          font-weight: 600;
        }

        .mock-tab-close {
          color: #64748b;
          font-size: 12px;
        }

        .mock-browser-newtab {
          color: #64748b;
          padding: 4px 8px;
          font-size: 14px;
        }

        .mock-browser-address-bar {
          background: #03070b;
          margin: 6px 8px 8px;
          border-radius: 4px;
          padding: 4px 10px;
          display: flex;
          align-items: center;
          gap: 6px;
          border: 1px solid rgba(255, 255, 255, 0.08);
        }

        .mock-secure-icon {
          width: 11px;
          height: 11px;
        }

        .mock-url-text {
          font-size: 10px;
          color: #94a3b8;
          font-family: monospace;
        }

        /* Mock Google Snippet */
        .mock-google-snippet {
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 8px;
          padding: 14px;
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .google-snippet-url-row {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .google-favicon {
          width: 16px;
          height: 16px;
          border-radius: 50%;
          background: #ffffff;
          padding: 1px;
        }

        .google-url-details {
          display: flex;
          flex-direction: column;
        }

        .google-site-name {
          font-size: 11px;
          font-weight: 700;
          color: #cbd5e1;
        }

        .google-display-url {
          font-size: 10px;
          color: #64748b;
        }

        .google-snippet-title {
          font-size: 14px;
          font-weight: 700;
          color: #60a5fa;
          margin: 0;
          line-height: 1.3;
        }

        .google-snippet-desc {
          font-size: 11px;
          color: #94a3b8;
          margin: 0;
          line-height: 1.4;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }

        /* Save Banner */
        .save-banner-card {
          background: linear-gradient(135deg, #07131e, #0c2033);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 12px;
          padding: 18px;
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .save-banner-icon {
          width: 36px;
          height: 36px;
          border-radius: 8px;
          display: grid;
          place-items: center;
        }

        .save-banner-icon :global(svg) {
          width: 20px;
          height: 20px;
        }

        .save-banner-content h4 {
          font-size: 14px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 4px;
        }

        .save-banner-content p {
          font-size: 12px;
          color: #94a3b8;
          margin: 0;
        }

        /* WhatsApp Setting Styles */
        .whatsapp-card-head-ico {
          width: 32px;
          height: 32px;
          border-radius: 8px;
          background: rgba(37, 211, 102, 0.15);
          color: #25d366;
          display: grid;
          place-items: center;
        }

        .status-pill-badge {
          font-size: 10px;
          font-weight: 700;
          padding: 3px 8px;
          border-radius: 12px;
          text-transform: uppercase;
        }

        .status-pill-badge.active {
          background: rgba(37, 211, 102, 0.15);
          color: #25d366;
          border: 1px solid rgba(37, 211, 102, 0.3);
        }

        .status-pill-badge.disabled {
          background: rgba(239, 68, 68, 0.15);
          color: #ef4444;
          border: 1px solid rgba(239, 68, 68, 0.3);
        }

        .settings-toggle-row {
          display: flex;
          align-items: center;
          gap: 12px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 8px;
          padding: 12px 16px;
          cursor: pointer;
          transition: border-color 0.2s;
        }

        .settings-toggle-row:hover {
          border-color: rgba(37, 211, 102, 0.4);
        }

        .settings-toggle-row input {
          position: absolute;
          opacity: 0;
          pointer-events: none;
        }

        .toggle-slider {
          position: relative;
          width: 44px;
          height: 24px;
          background: #1e293b;
          border-radius: 20px;
          transition: background 0.25s ease;
          flex-shrink: 0;
        }

        .toggle-slider:before {
          content: "";
          position: absolute;
          width: 18px;
          height: 18px;
          left: 3px;
          top: 3px;
          background: white;
          border-radius: 50%;
          transition: transform 0.25s ease;
        }

        .settings-toggle-row input:checked + .toggle-slider {
          background: #25d366;
        }

        .settings-toggle-row input:checked + .toggle-slider:before {
          transform: translateX(20px);
        }

        .toggle-text {
          font-size: 12px;
          color: #cbd5e1;
          line-height: 1.4;
        }

        .whatsapp-test-action-wrap {
          margin-top: 10px;
          padding-top: 12px;
          border-top: 1px dashed rgba(255, 255, 255, 0.08);
        }

        .btn-test-whatsapp-link {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: rgba(37, 211, 102, 0.12);
          border: 1px solid rgba(37, 211, 102, 0.35);
          color: #25d366;
          padding: 8px 14px;
          border-radius: 8px;
          font-size: 12px;
          font-weight: 600;
          text-decoration: none;
          transition: all 0.2s;
        }

        .btn-test-whatsapp-link:hover {
          background: #25d366;
          color: #030b12;
        }

        .btn-test-whatsapp-link :global(svg) {
          width: 14px;
          height: 14px;
        }

        /* Mock WhatsApp Preview Area */
        .mock-whatsapp-preview-corner {
          background: #030a10;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          padding: 16px;
          display: flex;
          flex-direction: column;
          gap: 14px;
          position: relative;
        }

        .mock-corner-badge {
          display: flex;
          align-items: center;
          justify-content: space-between;
          font-size: 11px;
          color: #64748b;
          border-bottom: 1px solid rgba(255, 255, 255, 0.06);
          padding-bottom: 8px;
        }

        .mock-corner-badge .text-green {
          color: #25d366;
          font-weight: 700;
        }

        .mock-corner-badge .text-red {
          color: #ef4444;
          font-weight: 700;
        }

        .mock-whatsapp-btn-render {
          align-self: flex-end;
          width: 48px;
          height: 48px;
          border-radius: 50%;
          background: #25d366;
          color: #ffffff;
          display: grid;
          place-items: center;
          box-shadow: 0 8px 24px rgba(37, 211, 102, 0.35);
          border: 2px solid rgba(255, 255, 255, 0.6);
        }

        .mock-whatsapp-btn-render svg {
          width: 26px;
          height: 26px;
        }

        .mock-whatsapp-disabled-alert {
          background: rgba(239, 68, 68, 0.08);
          border: 1px dashed rgba(239, 68, 68, 0.3);
          border-radius: 8px;
          padding: 14px;
          text-align: center;
          font-size: 12px;
          color: #ef4444;
        }

        .mock-whatsapp-info-display {
          display: flex;
          flex-direction: column;
          gap: 4px;
          font-size: 11px;
          color: #94a3b8;
          background: rgba(255, 255, 255, 0.02);
          border: 1px solid rgba(255, 255, 255, 0.06);
          border-radius: 6px;
          padding: 8px 10px;
          margin-top: 8px;
        }

        .mock-whatsapp-info-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .mock-whatsapp-info-row b {
          color: #25d366;
        }

        .mock-whatsapp-msg-snippet {
          color: #64748b;
          font-size: 10px;
          font-style: italic;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        /* LIGHT MODE SCOPED OVERRIDES */
        :global(.theme-light) .techlab-settings-page {
          color: #0f172a !important;
        }

        :global(.theme-light) .settings-header-bar {
          background: transparent !important;
          border: none !important;
        }

        :global(.theme-light) .header-title-group h1 {
          color: #0f172a !important;
        }

        :global(.theme-light) .header-title-group p {
          color: #64748b !important;
        }

        :global(.theme-light) .header-icon-badge {
          background: #ffffff !important;
          border-color: #cbd5e1 !important;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05) !important;
        }

        :global(.theme-light) .settings-tabs-navbar {
          border-bottom-color: #e2e8f0 !important;
        }

        :global(.theme-light) .tab-switch-btn {
          color: #64748b !important;
        }

        :global(.theme-light) .tab-switch-btn:hover {
          color: #0f172a !important;
          background: #f1f5f9 !important;
        }

        :global(.theme-light) .tab-switch-btn.active {
          color: #0d9651 !important;
          background: #ffffff !important;
          border-color: #16c96f !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.05) !important;
        }

        :global(.theme-light) .settings-card,
        :global(.theme-light) .preview-card {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .settings-card-header,
        :global(.theme-light) .preview-card-header {
          background: #f8fafc !important;
          border-bottom-color: #e2e8f0 !important;
        }

        :global(.theme-light) .settings-card-header h2,
        :global(.theme-light) .preview-card-header h3 {
          color: #0f172a !important;
        }

        :global(.theme-light) .settings-card-header p {
          color: #64748b !important;
        }

        :global(.theme-light) .field-label-row label,
        :global(.theme-light) .form-field-group label,
        :global(.theme-light) .color-presets-section label,
        :global(.theme-light) .color-picker-item label,
        :global(.theme-light) .logo-upload-box label {
          color: #1e293b !important;
        }

        :global(.theme-light) .field-hint {
          color: #64748b !important;
        }

        :global(.theme-light) .field-description,
        :global(.theme-light) .picker-tip {
          color: #64748b !important;
        }

        :global(.theme-light) .settings-text-input,
        :global(.theme-light) .settings-textarea-input {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .settings-text-input:focus,
        :global(.theme-light) .settings-textarea-input:focus {
          background: #ffffff !important;
          border-color: #16c96f !important;
          box-shadow: 0 0 0 2px rgba(22, 201, 111, 0.15) !important;
        }

        :global(.theme-light) .btn-copy-input,
        :global(.theme-light) .btn-open-input {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #475569 !important;
        }

        :global(.theme-light) .btn-copy-input:hover,
        :global(.theme-light) .btn-open-input:hover {
          background: #f1f5f9 !important;
          color: #0f172a !important;
          border-color: #94a3b8 !important;
        }

        :global(.theme-light) .favicon-current-display {
          background: #f8fafc !important;
          border-color: #e2e8f0 !important;
        }

        :global(.theme-light) .favicon-box {
          background: #ffffff !important;
          border-color: #cbd5e1 !important;
        }

        :global(.theme-light) .favicon-info strong {
          color: #0f172a !important;
        }

        :global(.theme-light) .favicon-info span {
          color: #64748b !important;
        }

        :global(.theme-light) .favicon-upload-btn-wrap,
        :global(.theme-light) .logo-dropzone {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0284c7 !important;
        }

        :global(.theme-light) .favicon-upload-btn-wrap:hover,
        :global(.theme-light) .logo-dropzone:hover {
          background: #f0f9ff !important;
          border-color: #0284c7 !important;
        }

        :global(.theme-light) .favicon-upload-btn-wrap span,
        :global(.theme-light) .logo-dropzone span {
          color: #1e293b !important;
        }

        :global(.theme-light) .logo-dropzone small {
          color: #64748b !important;
        }

        :global(.theme-light) .favicon-presets-wrap span {
          color: #64748b !important;
        }

        :global(.theme-light) .preset-choice-btn {
          background: #f8fafc !important;
          border-color: #e2e8f0 !important;
          color: #0f172a !important;
        }

        :global(.theme-light) .preset-choice-btn:hover {
          background: #f1f5f9 !important;
          border-color: #cbd5e1 !important;
        }

        :global(.theme-light) .preset-choice-btn.selected {
          background: rgba(22, 201, 111, 0.1) !important;
          border-color: #16c96f !important;
          color: #0d9651 !important;
        }

        :global(.theme-light) .color-preset-card {
          background: #f8fafc !important;
          border-color: #e2e8f0 !important;
        }

        :global(.theme-light) .color-preset-card:hover {
          border-color: #cbd5e1 !important;
        }

        :global(.theme-light) .color-preset-card.is-selected {
          background: #ffffff !important;
          border-color: #16c96f !important;
          box-shadow: 0 1px 4px rgba(22, 201, 111, 0.15) !important;
        }

        :global(.theme-light) .preset-card-info strong {
          color: #0f172a !important;
        }

        :global(.theme-light) .preset-card-info span {
          color: #64748b !important;
        }

        :global(.theme-light) .color-input-badge {
          background: #f8fafc !important;
          border-color: #cbd5e1 !important;
        }

        :global(.theme-light) .hex-text-input {
          color: #0f172a !important;
        }

        :global(.theme-light) .geometry-choice-btn {
          background: #f8fafc !important;
          border-color: #e2e8f0 !important;
        }

        :global(.theme-light) .geometry-choice-btn:hover {
          border-color: #cbd5e1 !important;
        }

        :global(.theme-light) .geometry-choice-btn.selected {
          background: #ffffff !important;
          border-color: #16c96f !important;
        }

        :global(.theme-light) .geometry-choice-btn strong {
          color: #0f172a !important;
        }

        :global(.theme-light) .geometry-choice-btn span {
          color: #64748b !important;
        }

        :global(.theme-light) .mock-browser-window {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .mock-browser-tab-bar {
          background: #f1f5f9 !important;
        }

        :global(.theme-light) .mock-browser-tab {
          background: #ffffff !important;
          color: #0f172a !important;
          border: 1px solid #e2e8f0 !important;
          border-bottom: none !important;
        }

        :global(.theme-light) .mock-browser-address-bar {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
        }

        :global(.theme-light) .mock-url-text {
          color: #475569 !important;
        }

        :global(.theme-light) .mock-google-snippet {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .google-site-name {
          color: #202124 !important;
        }

        :global(.theme-light) .google-display-url {
          color: #4d5156 !important;
        }

        :global(.theme-light) .google-snippet-title {
          color: #1a0dab !important;
        }

        :global(.theme-light) .google-snippet-desc {
          color: #4d5156 !important;
        }

        :global(.theme-light) .mock-whatsapp-preview-corner {
          background: #f8fafc !important;
          border-color: #e2e8f0 !important;
        }

        :global(.theme-light) .mock-corner-badge {
          border-bottom-color: #e2e8f0 !important;
          color: #64748b !important;
        }

        :global(.theme-light) .mock-whatsapp-info-display {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          color: #334155 !important;
        }

        :global(.theme-light) .mock-whatsapp-info-row b {
          color: #0d9651 !important;
        }

        :global(.theme-light) .interactive-preview-container {
          background: #f8fafc !important;
          border-color: #e2e8f0 !important;
        }

        :global(.theme-light) .mock-brand-logo-wrap strong {
          color: #0f172a !important;
        }

        :global(.theme-light) .mock-brand-logo-wrap small {
          color: #64748b !important;
        }

        :global(.theme-light) .mock-kpi-card-preview {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
        }

        :global(.theme-light) .save-banner-card {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04) !important;
        }

        :global(.theme-light) .save-banner-content h4 {
          color: #0f172a !important;
        }

        :global(.theme-light) .save-banner-content p {
          color: #64748b !important;
        }

        /* =========================================================================
           FOOTER TAB (HORIZONTAL WIDE LAYOUT)
           ========================================================================= */
        .settings-footer-form {
          width: 100%;
          display: block;
        }

        .settings-footer-wide-container {
          display: flex;
          flex-direction: column;
          gap: 20px;
          width: 100%;
        }

        .footer-wide-card {
          width: 100%;
        }

        .footer-horizontal-row-2col {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 20px;
          align-items: start;
        }

        .footer-subfields-stack {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .footer-horizontal-grid-4col {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 16px;
        }

        .footer-horizontal-grid-6col {
          display: grid;
          grid-template-columns: repeat(6, 1fr);
          gap: 12px;
        }

        .footer-horizontal-grid-3col {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 16px;
        }

        .field-inline-icon {
          width: 14px;
          height: 14px;
          display: inline-block;
          vertical-align: middle;
          margin-right: 4px;
        }

        .field-inline-icon.fb { color: #1877f2; }
        .field-inline-icon.tw { color: #1da1f2; }
        .field-inline-icon.ig { color: #e1306c; }
        .field-inline-icon.in { color: #0a66c2; }
        .field-inline-icon.yt { color: #ff0000; }
        .field-inline-icon.gh { color: #ffffff; }

        .flex-between {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .header-left-flex {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .card-header-icon-box {
          width: 38px;
          height: 38px;
          border-radius: 8px;
          display: grid;
          place-items: center;
          flex-shrink: 0;
        }

        .card-header-icon-box :global(svg) {
          width: 20px;
          height: 20px;
        }

        .toggle-switch-label {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          cursor: pointer;
          user-select: none;
        }

        .toggle-text {
          font-size: 12px;
          font-weight: 600;
          color: #94a3b8;
        }

        .toggle-checkbox {
          display: none;
        }

        .toggle-slider {
          position: relative;
          width: 40px;
          height: 22px;
          border-radius: 20px;
          transition: background-color 0.2s;
        }

        .toggle-slider::after {
          content: "";
          position: absolute;
          top: 3px;
          left: 3px;
          width: 16px;
          height: 16px;
          border-radius: 50%;
          background: #ffffff;
          transition: transform 0.2s;
        }

        .toggle-checkbox:checked + .toggle-slider::after {
          transform: translateX(18px);
        }

        /* Mockup del Footer en Vivo */
        .footer-preview-container-card {
          border-color: rgba(22, 201, 111, 0.2);
        }

        .live-preview-pill {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 11px;
          font-weight: 700;
          padding: 3px 10px;
          border: 1px solid;
          border-radius: 20px;
        }

        .live-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          animation: pulse 1.5s infinite;
        }

        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.3; }
        }

        .footer-live-mockup {
          background: #02080e;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          padding: 24px 28px 14px;
        }

        .mockup-footer-grid {
          display: grid;
          grid-template-columns: 2fr 1fr 1fr 1fr 1.5fr;
          gap: 20px;
          padding-bottom: 20px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .mockup-brand-col {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .mockup-logo-text {
          display: flex;
          align-items: center;
          gap: 8px;
          color: #ffffff;
          font-size: 16px;
        }

        .mockup-brand-desc {
          font-size: 11px;
          color: #94a3b8;
          line-height: 1.5;
          margin: 0;
        }

        .mockup-socials-row {
          display: flex;
          gap: 8px;
          margin-top: 4px;
        }

        .mock-social-circle {
          width: 26px;
          height: 26px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.06);
          border: 1px solid rgba(255, 255, 255, 0.1);
          display: grid;
          place-items: center;
          color: #94a3b8;
        }

        .mock-social-circle :global(svg) {
          width: 12px;
          height: 12px;
        }

        .mockup-links-col h5 {
          font-size: 11px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 10px;
          letter-spacing: 0.5px;
        }

        .mockup-links-col ul {
          list-style: none;
          padding: 0;
          margin: 0;
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .mockup-links-col li {
          font-size: 11px;
          color: #94a3b8;
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .mockup-links-col li :global(svg) {
          width: 12px;
          height: 12px;
          color: #64748b;
        }

        .mockup-copyright-bar {
          display: flex;
          justify-content: space-between;
          padding-top: 12px;
          font-size: 10.5px;
          color: #64748b;
        }

        .footer-bottom-save-bar {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-top: 20px;
          padding-top: 16px;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
          gap: 16px;
        }

        .save-info strong {
          display: block;
          font-size: 13px;
          color: #ffffff;
        }

        .save-info span {
          font-size: 11px;
          color: #94a3b8;
        }

        /* Light Mode Overrides for Footer Tab */
        :global(.theme-light) .footer-live-mockup {
          background: #ffffff !important;
          border-color: #e2e8f0 !important;
        }

        :global(.theme-light) .mockup-logo-text,
        :global(.theme-light) .mockup-links-col h5,
        :global(.theme-light) .save-info strong {
          color: #0f172a !important;
        }

        :global(.theme-light) .mockup-brand-desc,
        :global(.theme-light) .mockup-links-col li,
        :global(.theme-light) .mockup-copyright-bar,
        :global(.theme-light) .save-info span {
          color: #64748b !important;
        }

        :global(.theme-light) .mock-social-circle {
          background: #f1f5f9 !important;
          border-color: #e2e8f0 !important;
          color: #475569 !important;
        }

        @media (max-width: 1024px) {
          .footer-horizontal-row-2col,
          .footer-horizontal-grid-4col,
          .footer-horizontal-grid-6col,
          .footer-horizontal-grid-3col {
            grid-template-columns: 1fr;
          }

          .mockup-footer-grid {
            grid-template-columns: 1fr;
          }
        }
        /* =================================================================
           ESTILOS PESTAÑA LECTURA (WORDPRESS / ELEMENTOR PRO)
           ================================================================= */
        .reading-setting-section {
          padding: 16px 0;
        }

        .reading-setting-title-row {
          margin-bottom: 14px;
        }

        .reading-main-label {
          font-size: 14px;
          font-weight: 700;
          color: #ffffff;
          letter-spacing: 0.2px;
        }

        .reading-radio-group {
          display: flex;
          flex-direction: column;
          gap: 14px;
        }

        .reading-radio-option {
          display: flex;
          align-items: flex-start;
          gap: 12px;
          padding: 14px 18px;
          background: rgba(255, 255, 255, 0.02);
          border: 1px solid rgba(255, 255, 255, 0.07);
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .reading-radio-option:hover {
          background: rgba(56, 189, 248, 0.04);
          border-color: rgba(56, 189, 248, 0.25);
        }

        .reading-radio-option.selected {
          background: rgba(22, 201, 111, 0.05);
          border-color: rgba(22, 201, 111, 0.4);
        }

        .reading-radio-option input[type="radio"] {
          margin-top: 3px;
          accent-color: #16c96f;
          width: 17px;
          height: 17px;
          cursor: pointer;
          flex-shrink: 0;
        }

        .radio-content strong {
          display: block;
          font-size: 13.5px;
          color: #f1f5f9;
          margin-bottom: 4px;
        }

        .radio-content p {
          font-size: 12px;
          color: #94a3b8;
          line-height: 1.5;
          margin: 0;
        }

        .reading-sub-selectors {
          margin-left: 28px;
          padding: 16px 20px;
          background: #040c14;
          border-left: 3px solid #16c96f;
          border-radius: 0 10px 10px 0;
          display: flex;
          flex-direction: column;
          gap: 14px;
          transition: opacity 0.2s ease;
        }

        .reading-sub-selectors.is-disabled {
          opacity: 0.4;
          pointer-events: none;
          border-left-color: #334155;
        }

        .reading-select-row {
          display: flex;
          align-items: center;
          gap: 16px;
        }

        .reading-select-row label {
          min-width: 140px;
          font-size: 13px;
          font-weight: 600;
          color: #cbd5e1;
        }

        .reading-select-row select {
          flex: 1;
          max-width: 420px;
          height: 40px;
          background: #071522;
          border: 1px solid rgba(56, 189, 248, 0.25);
          border-radius: 8px;
          color: #ffffff;
          padding: 0 12px;
          font-size: 13px;
          cursor: pointer;
          transition: border-color 0.15s ease;
        }

        .reading-select-row select:focus {
          outline: none;
          border-color: #16c96f;
          box-shadow: 0 0 10px rgba(22, 201, 111, 0.2);
        }

        .reading-input-inline {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .reading-number-input {
          width: 90px;
          height: 40px;
          background: #071522;
          border: 1px solid rgba(56, 189, 248, 0.25);
          border-radius: 8px;
          color: #ffffff;
          padding: 0 12px;
          font-size: 14px;
          font-weight: 600;
          text-align: center;
        }

        .reading-input-unit {
          font-size: 13px;
          color: #94a3b8;
        }

        .reading-info-callout {
          display: flex;
          align-items: flex-start;
          gap: 14px;
          background: rgba(56, 189, 248, 0.06);
          border: 1px solid rgba(56, 189, 248, 0.25);
          border-radius: 12px;
          padding: 18px 22px;
          margin-top: 24px;
        }

        .callout-icon {
          width: 24px;
          height: 24px;
          flex-shrink: 0;
          margin-top: 2px;
        }

        .callout-text strong {
          display: block;
          font-size: 13.5px;
          color: #38bdf8;
          margin-bottom: 6px;
        }

        .callout-text p {
          font-size: 12.5px;
          color: #cbd5e1;
          line-height: 1.6;
          margin: 0;
        }

        .callout-text code {
          background: rgba(0, 0, 0, 0.4);
          padding: 2px 6px;
          border-radius: 4px;
          color: #16c96f;
          font-family: monospace;
        }

        /* Light Mode for Reading Tab */
        :global(.theme-light) .reading-radio-option {
          background: #f8fafc;
          border-color: #e2e8f0;
        }

        :global(.theme-light) .reading-radio-option.selected {
          background: #ecfdf5;
          border-color: #10b981;
        }

        :global(.theme-light) .radio-content strong,
        :global(.theme-light) .reading-main-label {
          color: #0f172a !important;
        }

        :global(.theme-light) .reading-sub-selectors {
          background: #f1f5f9;
        }

        :global(.theme-light) .reading-select-row select,
        :global(.theme-light) .reading-number-input {
          background: #ffffff;
          border-color: #cbd5e1;
          color: #0f172a;
        }

        :global(.theme-light) .reading-info-callout {
          background: #f0f9ff;
          border-color: #bae6fd;
        }

        :global(.theme-light) .callout-text p {
          color: #334155;
        }
      `}</style>
    </div>
  );
}
