import type { Metadata } from "next";
import DashboardShell from "@/components/dashboard/DashboardShell";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import "./dashboard.css";

export async function generateMetadata(): Promise<Metadata> {
  try {
    const settings = await prisma.siteSetting.findUnique({
      where: { id: "general" },
    });
    const siteTitle = settings?.siteTitle || "TechLab";
    const favicon = settings?.faviconUrl || "/favicon.ico";

    return {
      title: `Panel de Administración | ${siteTitle}`,
      robots: { index: false, follow: false },
      icons: {
        icon: favicon,
        shortcut: favicon,
        apple: favicon,
      },
    };
  } catch {
    return {
      title: "Panel de Administración | TechLab",
      robots: { index: false, follow: false },
    };
  }
}

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await getSession();
  let liveUser = session;

  if (session?.id) {
    try {
      const dbUser = await prisma.user.findUnique({
        where: { id: session.id },
        select: { id: true, email: true, name: true, lastName: true, role: true, avatar: true },
      });
      if (dbUser) {
        liveUser = {
          id: dbUser.id,
          email: dbUser.email,
          name: dbUser.name,
          role: dbUser.role,
          avatar: dbUser.avatar,
          image: dbUser.avatar,
        };
      }
    } catch (e) {
      console.error("Error al obtener usuario en vivo:", e);
    }
  }

  return <DashboardShell user={liveUser}>{children}</DashboardShell>;
}
