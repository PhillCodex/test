import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const settings = await prisma.siteSetting.findUnique({ where: { id: "general" } });
    const baseUrl = settings?.publicUrl || (new URL(req.url)).origin || "http://localhost:3000";

    const categories = await prisma.category.findMany({
      orderBy: { name: "asc" },
      select: {
        slug: true,
        createdAt: true,
        name: true,
      },
    });

    const now = new Date().toISOString();

    const catEntries = categories
      .map((c) => {
        const url = `${baseUrl}/categoria/${c.slug}`;
        const lastmod = c.createdAt ? new Date(c.createdAt).toISOString() : now;

        return `  <url>
    <loc>${url}</loc>
    <lastmod>${lastmod}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.6</priority>
  </url>`;
      })
      .join("\n");

    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="/sitemap.xsl"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${catEntries}
</urlset>`;

    return new NextResponse(xml, {
      headers: {
        "Content-Type": "application/xml; charset=utf-8",
        "Cache-Control": "public, s-maxage=3600, stale-while-revalidate=59",
      },
    });
  } catch (error) {
    console.error("Error al generar categoria.xml:", error);
    return new NextResponse("<error>Error al generar categoria.xml</error>", {
      status: 500,
      headers: { "Content-Type": "application/xml" },
    });
  }
}
