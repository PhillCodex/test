import type { Metadata } from "next";
import { Inter } from "next/font/google";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";
import AdminTopBar from "@/components/layout/AdminTopBar";
import VisitorTracker from "@/components/analytics/VisitorTracker";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export async function generateMetadata(): Promise<Metadata> {
  try {
    const settings = await prisma.siteSetting.findUnique({
      where: { id: "general" },
    });

    const baseTitle = settings?.siteTitle || "TechLab";
    const siteTitle = settings?.seoHomeTitle
      ? settings.seoHomeTitle.replace("%sitename%", baseTitle)
      : `${baseTitle} | Innovación y Desarrollo Web`;
    const siteDescription =
      settings?.seoHomeDescription ||
      settings?.siteDescription ||
      "Laboratorio de innovación tecnológica, desarrollo de software a medida, aplicaciones web y servicios en la nube de alta disponibilidad.";
    const faviconUrl = settings?.faviconUrl || "/favicon.ico";

    return {
      title: siteTitle,
      description: siteDescription,
      icons: {
        icon: faviconUrl,
        shortcut: faviconUrl,
        apple: faviconUrl,
      },
      openGraph: {
        title: siteTitle,
        description: siteDescription,
        type: "website",
        locale: "es_PE",
      },
      twitter: {
        card: "summary_large_image",
        title: siteTitle,
        description: siteDescription,
      },
    };
  } catch {
    return {
      title: "TechLab | Innovación y Desarrollo Web",
      description: "Laboratorio de innovación tecnológica, desarrollo de software a medida, aplicaciones web y servicios en la nube de alta disponibilidad.",
      icons: {
        icon: "/favicon.ico",
      },
    };
  }
}

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await getSession();
  let siteTitle = "TechLab";
  let pendingComments = 0;

  try {
    const [settings, commentsCount] = await Promise.all([
      prisma.siteSetting.findUnique({ where: { id: "general" }, select: { siteTitle: true } }),
      prisma.comment.count({ where: { status: "PENDIENTE" } }),
    ]);
    if (settings?.siteTitle) siteTitle = settings.siteTitle;
    pendingComments = commentsCount;
  } catch {}

  const isAdmin = session && session.role === "ADMIN";

  return (
    <html lang="es">
      <body className={inter.className}>
        {/* Barra superior de administración tipo WordPress para usuarios logueados con rol ADMIN */}
        {isAdmin && session && (
          <AdminTopBar
            user={session}
            siteTitle={siteTitle}
            pendingComments={pendingComments}
          />
        )}
        {/* Rastreador de visitas por IP en segundo plano */}
        <VisitorTracker />
        {children}
      </body>
    </html>
  );
}
