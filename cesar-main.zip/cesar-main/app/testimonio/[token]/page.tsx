"use client";

import { useState, useEffect, useRef } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  CircuitBoard,
  Star,
  User,
  Briefcase,
  UploadCloud,
  CheckCircle2,
  AlertTriangle,
  Send,
  Loader2,
  Camera,
  X,
  Sparkles,
  Quote,
} from "lucide-react";

const PRESET_AVATARS = [
  "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80",
];

const RATING_LABELS: Record<number, string> = {
  1: "Malo",
  2: "Regular",
  3: "Bueno",
  4: "Muy bueno",
  5: "¡Excelente!",
};

export default function ClientTestimonialFormPage() {
  const params = useParams();
  const token = params?.token as string;

  const [isLoading, setIsLoading] = useState(true);
  const [isCompleted, setIsCompleted] = useState(false);
  const [isExpired, setIsExpired] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Campos del formulario
  const [name, setName] = useState("");
  const [role, setRole] = useState("");
  const [company, setCompany] = useState("");
  const [content, setContent] = useState("");
  const [rating, setRating] = useState(5);
  const [hoverRating, setHoverRating] = useState<number | null>(null);
  const [avatar, setAvatar] = useState("");

  const [isUploading, setIsUploading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmittedSuccess, setIsSubmittedSuccess] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Verificar validez del token en MySQL
  useEffect(() => {
    if (!token) return;

    const checkToken = async () => {
      setIsLoading(true);
      try {
        const res = await fetch(`/api/testimonials/${token}`);
        const data = await res.json();

        if (data.notFound) {
          setErrorMessage("El enlace de testimonio no es válido o ha sido eliminado.");
        } else if (data.isExpired) {
          setIsExpired(true);
          setErrorMessage(data.error);
        } else if (data.isCompleted) {
          setIsCompleted(true);
        } else if (data.success && data.testimonial) {
          setName(data.testimonial.name || "");
          setRole(data.testimonial.role || "");
          setCompany(data.testimonial.company || "");
        } else {
          setErrorMessage(data.error || "No se pudo verificar el enlace.");
        }
      } catch (err) {
        console.error(err);
        setErrorMessage("Error de conexión al cargar el formulario.");
      } finally {
        setIsLoading(false);
      }
    };

    checkToken();
  }, [token]);

  // Subir Foto vía /api/upload
  const handleUploadPhoto = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const formData = new FormData();
      formData.append("file", file);

      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      if (data.url) {
        setAvatar(data.url);
      }
    } catch (err) {
      console.error("Error al subir foto:", err);
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  // Enviar testimonio
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim()) {
      alert("Por favor ingresa tu nombre.");
      return;
    }
    if (!content.trim()) {
      alert("Por favor escribe tu testimonio o reseña.");
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch(`/api/testimonials/${token}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name.trim(),
          role: role.trim() || null,
          company: company.trim() || null,
          avatar: avatar || null,
          content: content.trim(),
          rating,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setIsSubmittedSuccess(true);
      } else {
        alert(data.error || "Error al enviar el testimonio.");
      }
    } catch (err) {
      console.error(err);
      alert("Error de conexión con el servidor.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const activeStarCount = hoverRating !== null ? hoverRating : rating;

  return (
    <div className="client-testimonial-page">
      {/* Barra de cabecera */}
      <header className="client-header">
        <Link href="/" className="client-brand">
          <CircuitBoard />
          <span>
            <b>
              Tech<span>Lab</span>
            </b>
            <small>Tecnología que impulsa tu mundo</small>
          </span>
        </Link>
      </header>

      <main className="client-content-container">
        {isLoading ? (
          <div className="status-card-box">
            <Loader2 className="animate-spin" />
            <p>Cargando formulario...</p>
          </div>
        ) : errorMessage ? (
          <div className="status-card-box error">
            <div className="icon-badge error">
              <AlertTriangle />
            </div>
            <h2>Enlace no disponible</h2>
            <p>{errorMessage}</p>
            <Link href="/" className="btn-home-return">
              Volver al inicio
            </Link>
          </div>
        ) : isCompleted || isSubmittedSuccess ? (
          <div className="status-card-box success">
            <div className="icon-badge success">
              <CheckCircle2 />
            </div>
            <h2>¡Muchas gracias por tu testimonio!</h2>
            <p>
              Tu opinión ha sido recibida y registrada con éxito. Nos ayuda mucho a seguir mejorando y destacando nuestro
              trabajo.
            </p>

            <div className="testimonial-preview-card">
              <div className="preview-stars">
                {"★".repeat(rating)}
                {"☆".repeat(5 - rating)}
              </div>
              <p className="preview-quote">“{content || "Excelente trabajo profesional."}”</p>
              <div className="preview-author-row">
                <div className="author-avatar-mini">
                  {avatar ? (
                    <img src={avatar} alt={name} />
                  ) : (
                    <span>{name ? name.charAt(0).toUpperCase() : "C"}</span>
                  )}
                </div>
                <div>
                  <strong>{name || "Cliente"}</strong>
                  <small>{role || company || "Cliente TechLab"}</small>
                </div>
              </div>
            </div>

            <Link href="/" className="btn-home-return">
              Ir al Inicio (TechLab)
            </Link>
          </div>
        ) : (
          /* Formulario Interactivo del Cliente */
          <div className="testimonial-form-card">
            <div className="form-card-header">
              <div className="header-badge">
                <Sparkles />
                <span>Tu Opinión Importa</span>
              </div>
              <h1>Comparte tu Experiencia con Nosotros</h1>
              <p>
                Completa este breve formulario para contarnos qué te pareció el servicio y cómo te ayudamos con tu
                proyecto.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="testimonial-form-body">
              {/* Selector de Calificación en Estrellas */}
              <div className="form-group-block stars-block">
                <label>¿Cómo calificarías tu experiencia?</label>
                <div className="stars-interactive-row">
                  {[1, 2, 3, 4, 5].map((starNum) => (
                    <button
                      key={starNum}
                      type="button"
                      className={`star-btn ${starNum <= activeStarCount ? "filled" : ""}`}
                      onMouseEnter={() => setHoverRating(starNum)}
                      onMouseLeave={() => setHoverRating(null)}
                      onClick={() => setRating(starNum)}
                    >
                      <Star />
                    </button>
                  ))}
                  <span className="rating-tag-label">{RATING_LABELS[activeStarCount]}</span>
                </div>
              </div>

              {/* Foto de Perfil */}
              <div className="form-group-block avatar-block">
                <label>Foto de perfil o avatar (opcional):</label>
                <div className="avatar-uploader-row">
                  <div className="avatar-preview-circle">
                    {avatar ? (
                      <img src={avatar} alt="Avatar" />
                    ) : (
                      <span className="avatar-initial">{name ? name.charAt(0).toUpperCase() : <User />}</span>
                    )}
                  </div>

                  <div className="avatar-controls">
                    <button
                      type="button"
                      className="btn-upload-pic"
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isUploading}
                    >
                      {isUploading ? <Loader2 className="animate-spin" /> : <UploadCloud />}
                      <span>{isUploading ? "Subiendo..." : "Subir mi foto"}</span>
                    </button>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleUploadPhoto}
                      style={{ display: "none" }}
                    />

                    {avatar && (
                      <button
                        type="button"
                        className="btn-clear-photo"
                        onClick={() => setAvatar("")}
                      >
                        Quitar foto
                      </button>
                    )}

                    {/* Presets */}
                    <div className="avatar-presets-group">
                      <small>O elige un avatar:</small>
                      <div className="presets-list">
                        {PRESET_AVATARS.map((url, i) => (
                          <img
                            key={i}
                            src={url}
                            alt="Preset"
                            className={`preset-item ${avatar === url ? "active" : ""}`}
                            onClick={() => setAvatar(url)}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Nombre y Cargo */}
              <div className="form-row-2-cols">
                <div className="form-group-block">
                  <label>Tu Nombre Completo: *</label>
                  <div className="input-with-icon">
                    <User />
                    <input
                      type="text"
                      placeholder="ej. María López"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                    />
                  </div>
                </div>

                <div className="form-group-block">
                  <label>Tu Cargo, Profesión o Empresa:</label>
                  <div className="input-with-icon">
                    <Briefcase />
                    <input
                      type="text"
                      placeholder="ej. Emprendedora / CEO, Empresa"
                      value={role}
                      onChange={(e) => setRole(e.target.value)}
                    />
                  </div>
                </div>
              </div>

              {/* Testimonio / Reseña */}
              <div className="form-group-block">
                <label>Tu Testimonio / Reseña: *</label>
                <div className="textarea-wrapper">
                  <textarea
                    rows={4}
                    placeholder="Cuéntanos cómo fue tu experiencia, qué resultados obtuviste y por qué recomendarías nuestro trabajo..."
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    required
                  />
                </div>
              </div>

              {/* Botón de Enviar */}
              <button
                type="submit"
                className="btn-submit-testimonial-neon"
                disabled={isSubmitting}
              >
                {isSubmitting ? <Loader2 className="animate-spin" /> : <Send />}
                <span>{isSubmitting ? "Enviando testimonio..." : "Enviar Mi Testimonio"}</span>
              </button>
            </form>
          </div>
        )}
      </main>

      <style jsx>{`
        .client-testimonial-page {
          min-height: 100vh;
          background: #03070b;
          color: #f1f5f9;
          display: flex;
          flex-direction: column;
        }

        .client-header {
          height: 70px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
          background: rgba(3, 11, 18, 0.95);
          backdrop-filter: blur(15px);
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 0 24px;
        }

        .client-brand {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .client-brand :global(svg) {
          width: 28px;
          height: 28px;
          color: #24a8ff;
        }

        .client-brand b {
          font-size: 20px;
          color: #ffffff;
        }

        .client-brand b span {
          color: #16c96f;
        }

        .client-brand small {
          display: block;
          font-size: 9px;
          color: #94a3b8;
        }

        .client-content-container {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 40px 20px 80px;
        }

        /* Tarjeta de Formulario */
        .testimonial-form-card {
          width: 100%;
          max-width: 620px;
          background: #040c14;
          border: 1px solid rgba(56, 189, 248, 0.3);
          border-radius: 16px;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.8), 0 0 30px rgba(56, 189, 248, 0.15);
          overflow: hidden;
        }

        .form-card-header {
          padding: 28px 28px 20px;
          background: #07131e;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
          text-align: center;
        }

        .header-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 4px 12px;
          border-radius: 20px;
          background: rgba(22, 201, 111, 0.12);
          border: 1px solid rgba(22, 201, 111, 0.35);
          color: #16c96f;
          font-size: 11px;
          font-weight: 700;
          margin-bottom: 12px;
        }

        .header-badge :global(svg) {
          width: 13px;
          height: 13px;
        }

        .form-card-header h1 {
          font-size: 22px;
          font-weight: 800;
          color: #ffffff;
          margin: 0 0 8px;
        }

        .form-card-header p {
          font-size: 13px;
          color: #94a3b8;
          line-height: 1.5;
          margin: 0;
        }

        .testimonial-form-body {
          padding: 28px;
          display: flex;
          flex-direction: column;
          gap: 22px;
        }

        .form-group-block {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .form-group-block label {
          font-size: 12px;
          font-weight: 700;
          color: #cbd5e1;
        }

        /* Estrellas */
        .stars-block {
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.06);
          border-radius: 10px;
          padding: 16px;
          align-items: center;
          text-align: center;
        }

        .stars-interactive-row {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .star-btn {
          background: none;
          border: none;
          padding: 2px;
          cursor: pointer;
          color: #475569;
          transition: transform 0.15s, color 0.15s;
        }

        .star-btn:hover {
          transform: scale(1.25);
        }

        .star-btn :global(svg) {
          width: 30px;
          height: 30px;
        }

        .star-btn.filled {
          color: #fbbf24;
        }

        .star-btn.filled :global(svg) {
          fill: #fbbf24;
          filter: drop-shadow(0 0 8px rgba(251, 191, 36, 0.6));
        }

        .rating-tag-label {
          margin-left: 10px;
          font-size: 12px;
          font-weight: 800;
          color: #16c96f;
          padding: 3px 10px;
          border-radius: 6px;
          background: rgba(22, 201, 111, 0.12);
        }

        /* Avatar */
        .avatar-uploader-row {
          display: flex;
          align-items: center;
          gap: 16px;
          padding: 14px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.06);
          border-radius: 10px;
        }

        .avatar-preview-circle {
          width: 58px;
          height: 58px;
          border-radius: 50%;
          background: #03080e;
          border: 2px solid #38bdf8;
          overflow: hidden;
          display: grid;
          place-items: center;
          flex-shrink: 0;
        }

        .avatar-preview-circle img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .avatar-initial {
          font-size: 18px;
          font-weight: 800;
          color: #38bdf8;
        }

        .avatar-controls {
          flex: 1;
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .btn-upload-pic {
          height: 32px;
          padding: 0 14px;
          background: rgba(56, 189, 248, 0.12);
          border: 1px solid rgba(56, 189, 248, 0.3);
          border-radius: 6px;
          color: #38bdf8;
          font-size: 12px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
          width: fit-content;
        }

        .btn-upload-pic :global(svg) {
          width: 14px;
          height: 14px;
        }

        .btn-clear-photo {
          background: none;
          border: none;
          color: #ef4444;
          font-size: 11px;
          cursor: pointer;
          text-align: left;
          padding: 0;
        }

        .avatar-presets-group {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .avatar-presets-group small {
          font-size: 10px;
          color: #64748b;
        }

        .presets-list {
          display: flex;
          gap: 6px;
        }

        .preset-item {
          width: 24px;
          height: 24px;
          border-radius: 50%;
          object-fit: cover;
          border: 1px solid rgba(255, 255, 255, 0.2);
          cursor: pointer;
        }

        .preset-item:hover,
        .preset-item.active {
          border-color: #38bdf8;
          transform: scale(1.15);
        }

        /* 2 Columnas */
        .form-row-2-cols {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 14px;
        }

        .input-with-icon {
          position: relative;
          display: flex;
          align-items: center;
        }

        .input-with-icon :global(svg) {
          position: absolute;
          left: 12px;
          width: 15px;
          height: 15px;
          color: #64748b;
        }

        .input-with-icon input {
          width: 100%;
          height: 40px;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 0 12px 0 36px;
          color: #ffffff;
          font-size: 13px;
          outline: none;
        }

        .input-with-icon input:focus {
          border-color: #38bdf8;
        }

        .textarea-wrapper textarea {
          width: 100%;
          background: #07131e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          padding: 12px;
          color: #ffffff;
          font-size: 13px;
          font-family: inherit;
          line-height: 1.5;
          outline: none;
          resize: vertical;
        }

        .textarea-wrapper textarea:focus {
          border-color: #38bdf8;
        }

        .btn-submit-testimonial-neon {
          height: 44px;
          border-radius: 8px;
          background: linear-gradient(110deg, #12b85f, #18d878);
          border: 1px solid rgba(67, 255, 147, 0.4);
          color: #030b12;
          font-size: 14px;
          font-weight: 800;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          cursor: pointer;
          box-shadow: 0 0 20px rgba(22, 201, 111, 0.35);
          transition: transform 0.15s ease;
        }

        .btn-submit-testimonial-neon:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: 0 0 26px rgba(22, 201, 111, 0.5);
        }

        .btn-submit-testimonial-neon:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }

        /* Estados Finales (Success / Error) */
        .status-card-box {
          width: 100%;
          max-width: 540px;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 16px;
          padding: 36px 28px;
          text-align: center;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 14px;
        }

        .icon-badge {
          width: 56px;
          height: 56px;
          border-radius: 50%;
          display: grid;
          place-items: center;
        }

        .icon-badge.success {
          background: rgba(22, 201, 111, 0.15);
          border: 1px solid #16c96f;
          color: #16c96f;
        }

        .icon-badge.error {
          background: rgba(239, 68, 68, 0.15);
          border: 1px solid #ef4444;
          color: #ef4444;
        }

        .icon-badge :global(svg) {
          width: 28px;
          height: 28px;
        }

        .status-card-box h2 {
          font-size: 20px;
          font-weight: 800;
          color: #ffffff;
          margin: 0;
        }

        .status-card-box p {
          font-size: 13px;
          color: #94a3b8;
          line-height: 1.5;
          margin: 0;
        }

        .testimonial-preview-card {
          width: 100%;
          background: #07131e;
          border: 1px solid rgba(22, 201, 111, 0.3);
          border-radius: 10px;
          padding: 18px;
          margin: 10px 0;
          text-align: left;
        }

        .preview-stars {
          color: #16c96f;
          font-size: 13px;
          letter-spacing: 2px;
          margin-bottom: 8px;
        }

        .preview-quote {
          font-size: 13px;
          color: #f1f5f9;
          font-style: italic;
          margin-bottom: 14px;
        }

        .preview-author-row {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .author-avatar-mini {
          width: 34px;
          height: 34px;
          border-radius: 50%;
          background: #12b85f;
          display: grid;
          place-items: center;
          overflow: hidden;
          font-size: 12px;
          font-weight: 700;
          color: #ffffff;
        }

        .author-avatar-mini img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .btn-home-return {
          height: 38px;
          padding: 0 20px;
          background: rgba(56, 189, 248, 0.12);
          border: 1px solid rgba(56, 189, 248, 0.35);
          border-radius: 6px;
          color: #38bdf8;
          font-size: 12px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          justify-content: center;
        }

        @media (max-width: 640px) {
          .form-row-2-cols {
            grid-template-columns: 1fr;
          }
        }
      `}</style>
    </div>
  );
}
