import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

const INITIAL_PROJECT_CATEGORIES = [
  { name: "Desarrollo Web", slug: "desarrollo-web", color: "#16c96f", description: "Proyectos y sitios web a medida." },
  { name: "WordPress + WooCommerce", slug: "wordpress-woocommerce", color: "#38bdf8", description: "Tiendas y plataformas en WordPress." },
  { name: "Aplicación Web & SaaS", slug: "aplicacion-web-saas", color: "#f59e0b", description: "Sistemas interactivos y paneles administrativos." },
  { name: "Cloud & DevOps", slug: "cloud-devops", color: "#a855f7", description: "Infraestructura, servidores y automatizaciones." },
];

export async function GET() {
  try {
    const count = await prisma.projectCategory.count();
    if (count === 0) {
      for (const cat of INITIAL_PROJECT_CATEGORIES) {
        await prisma.projectCategory.upsert({
          where: { slug: cat.slug },
          update: {},
          create: cat,
        });
      }
    }

    const categories = await prisma.projectCategory.findMany({
      include: {
        _count: {
          select: { projects: true },
        },
      },
      orderBy: { name: "asc" },
    });

    return NextResponse.json({ success: true, categories });
  } catch (error: any) {
    console.error("Error en GET /api/projects/categories:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al obtener categorías de proyectos" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, slug, description, color } = body;

    if (!name || !name.trim()) {
      return NextResponse.json(
        { success: false, error: "El nombre de la categoría es obligatorio." },
        { status: 400 }
      );
    }

    const cleanSlug =
      slug && slug.trim()
        ? slug.trim().toLowerCase().replace(/[^a-z0-9-]+/g, "-")
        : name.trim().toLowerCase().replace(/[^a-z0-9-]+/g, "-");

    const category = await prisma.projectCategory.create({
      data: {
        name: name.trim(),
        slug: cleanSlug,
        description: description ? description.trim() : null,
        color: color || "#16c96f",
      },
    });

    return NextResponse.json({ success: true, category, message: "Categoría de proyecto creada exitosamente." });
  } catch (error: any) {
    console.error("Error en POST /api/projects/categories:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al crear la categoría de proyectos" },
      { status: 500 }
    );
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { id, name, slug, description, color } = body;

    if (!id) {
      return NextResponse.json({ success: false, error: "ID no proporcionado." }, { status: 400 });
    }

    const updateData: any = {};
    if (name) updateData.name = name.trim();
    if (slug) updateData.slug = slug.trim().toLowerCase().replace(/[^a-z0-9-]+/g, "-");
    if (description !== undefined) updateData.description = description ? description.trim() : null;
    if (color) updateData.color = color;

    const updated = await prisma.projectCategory.update({
      where: { id },
      data: updateData,
    });

    return NextResponse.json({ success: true, category: updated, message: "Categoría actualizada con éxito." });
  } catch (error: any) {
    console.error("Error en PUT /api/projects/categories:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al actualizar la categoría" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ success: false, error: "ID no proporcionado." }, { status: 400 });
    }

    await prisma.projectCategory.delete({
      where: { id },
    });

    return NextResponse.json({ success: true, message: "Categoría de proyecto eliminada correctamente." });
  } catch (error: any) {
    console.error("Error en DELETE /api/projects/categories:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al eliminar categoría" },
      { status: 500 }
    );
  }
}
