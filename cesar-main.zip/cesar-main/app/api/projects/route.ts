import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";

const INITIAL_PROJECTS = [
  {
    title: "Plataforma Educativa",
    slug: "plataforma-educativa",
    excerpt: "Plataforma de aprendizaje y cursos online con panel administrativo y suscripciones.",
    content: "Plataforma completa para venta y gestión de cursos en línea, exámenes automatizados y certificados digitales.",
    investment: "$3,500 USD",
    liveUrl: "https://ejemplo-educacion.com",
    clientName: "EducaTech Global",
    technologies: "Next.js, TypeScript, PostgreSQL, TailwindCSS",
    status: "PUBLICADO",
  },
  {
    title: "Tienda Online de Moda",
    slug: "tienda-online-de-moda",
    excerpt: "E-Commerce de alta conversión con pagos con tarjeta, Yape, Plin y envíos automáticos.",
    content: "Tienda virtual con catálogo dinámico, carrito persistente, pasarela de pagos integrada y gestión de inventario.",
    investment: "$2,200 USD",
    liveUrl: "https://ejemplo-tienda.com",
    clientName: "Importaciones CM",
    technologies: "WordPress, WooCommerce, Stripe, Redis",
    status: "PUBLICADO",
  },
  {
    title: "Portal Corporativo Empresarial",
    slug: "portal-corporativo-empresarial",
    excerpt: "Sitio web corporativo optimizado con alta velocidad de carga y posicionamiento orgánico.",
    content: "Diseño y desarrollo de identidad digital corporativa, integración con CRM y formularios interactivos.",
    investment: "$1,800 USD",
    liveUrl: "https://ejemplo-corporativo.com",
    clientName: "Inversiones del Norte",
    technologies: "React, Node.js, Express, AWS",
    status: "PUBLICADO",
  },
  {
    title: "Dashboard Analytics & BI",
    slug: "dashboard-analytics-bi",
    excerpt: "Panel de control en tiempo real con gráficos interactivos, métricas clave y reportes exportables.",
    content: "Sistema centralizado de métricas y KPIs para toma de decisiones ejecutivas en tiempo real.",
    investment: "$4,200 USD",
    liveUrl: "https://ejemplo-analytics.com",
    clientName: "DataMetrics SAS",
    technologies: "Next.js, Tailwind, Chart.js, BigQuery",
    status: "PUBLICADO",
  },
  {
    title: "Sistema de Reservas y Citas",
    slug: "sistema-de-reservas-y-citas",
    excerpt: "Aplicación web para agendamiento automatizado de citas con recordatorios por WhatsApp.",
    content: "Plataforma web con calendario interactivo, sincronización con Google Calendar y pagos anticipados.",
    investment: "$2,800 USD",
    liveUrl: "https://ejemplo-citas.com",
    clientName: "Clínica Dental Sonrisas",
    technologies: "React, Node.js, WhatsApp Cloud API",
    status: "PUBLICADO",
  },
];

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const q = searchParams.get("q");
    const category = searchParams.get("category");
    const status = searchParams.get("status");

    const where: any = {};
    if (status && status !== "ALL") {
      where.status = status;
    }

    if (category && category !== "ALL") {
      where.categoryId = category;
    }

    if (q && q.trim()) {
      where.OR = [
        { title: { contains: q.trim() } },
        { clientName: { contains: q.trim() } },
        { technologies: { contains: q.trim() } },
        { excerpt: { contains: q.trim() } },
        { content: { contains: q.trim() } },
      ];
    }

    let projects = await prisma.project.findMany({
      where,
      include: {
        category: true,
        author: {
          select: { id: true, name: true, lastName: true, avatar: true },
        },
      },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({ success: true, projects });
  } catch (error: any) {
    console.error("Error en GET /api/projects:", error);
    return NextResponse.json({
      success: true,
      projects: INITIAL_PROJECTS.map((p, idx) => ({
        id: `fallback-${idx}`,
        ...p,
        featuredImage: null,
        gallery: null,
        seoTitle: null,
        seoDescription: null,
        focusKeyword: null,
        seoScore: 85,
        views: 120,
        tags: "web, nextjs",
        categoryId: "default",
        authorId: "admin",
        createdAt: new Date(),
        updatedAt: new Date(),
        category: { id: "default", name: "Desarrollo Web", slug: "desarrollo-web", color: "#16c96f" },
        author: { id: "admin", name: "Cesar", lastName: null, avatar: null },
      })),
    });
  }
}

export async function POST(request: Request) {
  try {
    const session = await getSession();
    const body = await request.json();
    const {
      title,
      slug,
      excerpt,
      content,
      featuredImage,
      gallery,
      investment,
      liveUrl,
      clientName,
      technologies,
      categoryId,
      status,
    } = body;

    if (!title || !title.trim()) {
      return NextResponse.json({ success: false, error: "El título del proyecto es obligatorio." }, { status: 400 });
    }

    const cleanSlug =
      slug && slug.trim()
        ? slug.trim().toLowerCase().replace(/[^a-z0-9-]+/g, "-")
        : title.trim().toLowerCase().replace(/[^a-z0-9-]+/g, "-");

    const existing = await prisma.project.findUnique({
      where: { slug: cleanSlug },
    });

    const finalSlug = existing ? `${cleanSlug}-${Date.now()}` : cleanSlug;

    const newProject = await prisma.project.create({
      data: {
        title: title.trim(),
        slug: finalSlug,
        excerpt: excerpt ? excerpt.trim() : null,
        content: content ? content.trim() : null,
        featuredImage: featuredImage || null,
        gallery: gallery || null,
        investment: investment ? investment.trim() : null,
        liveUrl: liveUrl ? liveUrl.trim() : null,
        clientName: clientName ? clientName.trim() : null,
        technologies: technologies ? technologies.trim() : null,
        categoryId: categoryId || null,
        authorId: session?.id || null,
        status: status || "PUBLICADO",
      },
      include: {
        category: true,
      },
    });

    return NextResponse.json({
      success: true,
      project: newProject,
      message: "Proyecto creado exitosamente.",
    });
  } catch (error: any) {
    console.error("Error en POST /api/projects:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al crear el proyecto" },
      { status: 500 }
    );
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const {
      id,
      title,
      slug,
      excerpt,
      content,
      featuredImage,
      gallery,
      investment,
      liveUrl,
      clientName,
      technologies,
      categoryId,
      status,
    } = body;

    if (!id) {
      return NextResponse.json({ success: false, error: "ID no proporcionado." }, { status: 400 });
    }

    const updateData: any = {};
    if (title !== undefined) updateData.title = title.trim();
    if (slug !== undefined) {
      updateData.slug = slug.trim().toLowerCase().replace(/[^a-z0-9-]+/g, "-");
    }
    if (excerpt !== undefined) updateData.excerpt = excerpt ? excerpt.trim() : null;
    if (content !== undefined) updateData.content = content ? content.trim() : null;
    if (featuredImage !== undefined) updateData.featuredImage = featuredImage || null;
    if (gallery !== undefined) updateData.gallery = gallery || null;
    if (investment !== undefined) updateData.investment = investment ? investment.trim() : null;
    if (liveUrl !== undefined) updateData.liveUrl = liveUrl ? liveUrl.trim() : null;
    if (clientName !== undefined) updateData.clientName = clientName ? clientName.trim() : null;
    if (technologies !== undefined) updateData.technologies = technologies ? technologies.trim() : null;
    if (categoryId !== undefined) updateData.categoryId = categoryId || null;
    if (status !== undefined) updateData.status = status;

    const updated = await prisma.project.update({
      where: { id },
      data: updateData,
      include: { category: true },
    });

    return NextResponse.json({
      success: true,
      project: updated,
      message: "Proyecto actualizado correctamente.",
    });
  } catch (error: any) {
    console.error("Error en PUT /api/projects:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al actualizar proyecto" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ success: false, error: "ID no proporcionado." }, { status: 400 });
    }

    await prisma.project.delete({
      where: { id },
    });

    return NextResponse.json({ success: true, message: "Proyecto eliminado correctamente." });
  } catch (error: any) {
    console.error("Error en DELETE /api/projects:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al eliminar proyecto" },
      { status: 500 }
    );
  }
}
