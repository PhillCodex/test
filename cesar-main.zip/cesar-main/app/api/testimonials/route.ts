import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import crypto from "crypto";

// Testimonios iniciales por defecto basados en el Home
const INITIAL_TESTIMONIALS = [
  {
    name: "Carlos Méndez",
    role: "CEO, Importaciones CM",
    company: "Importaciones CM",
    content: "Excelente trabajo, muy profesional y cumplió con todo lo acordado.",
    rating: 5,
    status: "PUBLICADO",
    isCompleted: true,
  },
  {
    name: "María López",
    role: "Emprendedora",
    company: "Emprendedora",
    content: "Mi sitio web ahora es más rápido, seguro y fácil de administrar.",
    rating: 5,
    status: "PUBLICADO",
    isCompleted: true,
  },
  {
    name: "Javier Rojas",
    role: "Gerente de TI",
    company: "Gerente de TI",
    content: "Soporte inmediato y soluciones efectivas, 100% recomendado.",
    rating: 5,
    status: "PUBLICADO",
    isCompleted: true,
  },
  {
    name: "Ana Torres",
    role: "Diseñadora Gráfica",
    company: "Diseñadora Gráfica",
    content: "Gran conocimiento en WordPress y servidores, un experto.",
    rating: 5,
    status: "PUBLICADO",
    isCompleted: true,
  },
];

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");
    const q = searchParams.get("q");

    const where: any = {};
    if (status && status !== "ALL") {
      where.status = status;
    }

    if (q && q.trim()) {
      where.OR = [
        { name: { contains: q.trim() } },
        { role: { contains: q.trim() } },
        { company: { contains: q.trim() } },
        { content: { contains: q.trim() } },
      ];
    }

    let testimonials = await prisma.testimonial.findMany({
      where,
      orderBy: { createdAt: "desc" },
    });

    if (testimonials.length === 0 && !status && !q) {
      try {
        await prisma.testimonial.createMany({
          data: INITIAL_TESTIMONIALS,
        });
        testimonials = await prisma.testimonial.findMany({
          orderBy: { createdAt: "desc" },
        });
      } catch {
        // Fallback en memoria si la BD está ocupada
        testimonials = INITIAL_TESTIMONIALS.map((t, idx) => ({
          id: `default-${idx}`,
          ...t,
          avatar: null,
          isCompleted: true,
          token: null,
          expiresAt: null,
          clientEmail: null,
          clientNotes: null,
          createdAt: new Date(),
          updatedAt: new Date(),
        })) as any;
      }
    }

    return NextResponse.json({
      success: true,
      testimonials,
    });
  } catch (error: any) {
    console.error("Error en GET /api/testimonials:", error);
    return NextResponse.json({
      success: true,
      testimonials: INITIAL_TESTIMONIALS.map((t, idx) => ({
        id: `fallback-${idx}`,
        ...t,
        avatar: null,
        isCompleted: true,
        token: null,
        expiresAt: null,
        clientEmail: null,
        clientNotes: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      })),
    });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      name,
      role,
      company,
      avatar,
      content,
      rating,
      status,
      generateLink,
      clientEmail,
      clientNotes,
      expiryDays,
    } = body;

    // Caso 1: Generar enlace de invitación temporal para el cliente
    if (generateLink) {
      const token = crypto.randomBytes(16).toString("hex");
      let tokenExpiry = null;
      if (expiryDays && Number(expiryDays) > 0) {
        tokenExpiry = new Date();
        tokenExpiry.setDate(tokenExpiry.getDate() + Number(expiryDays));
      }

      const newInvitation = await prisma.testimonial.create({
        data: {
          name: name ? name.trim() : "Cliente Invitado",
          role: role ? role.trim() : null,
          company: company ? company.trim() : null,
          content: content ? content.trim() : "",
          rating: rating ? Number(rating) : 5,
          status: "PENDIENTE",
          token,
          tokenExpiry,
          isCompleted: false,
          clientEmail: clientEmail ? clientEmail.trim() : null,
          clientNotes: clientNotes ? clientNotes.trim() : null,
        },
      });

      return NextResponse.json({
        success: true,
        testimonial: newInvitation,
        token,
        message: "Enlace temporal para el cliente generado con éxito.",
      });
    }

    // Caso 2: Crear testimonio manual directo desde el Admin
    if (!name || !name.trim()) {
      return NextResponse.json(
        { success: false, error: "El nombre del cliente es obligatorio." },
        { status: 400 }
      );
    }

    if (!content || !content.trim()) {
      return NextResponse.json(
        { success: false, error: "El contenido de la reseña es obligatorio." },
        { status: 400 }
      );
    }

    const createdTestimonial = await prisma.testimonial.create({
      data: {
        name: name.trim(),
        role: role ? role.trim() : null,
        company: company ? company.trim() : null,
        avatar: avatar || null,
        content: content.trim(),
        rating: rating ? Number(rating) : 5,
        status: status || "PUBLICADO",
        isCompleted: true,
      },
    });

    return NextResponse.json({
      success: true,
      testimonial: createdTestimonial,
      message: "Testimonio creado exitosamente en la base de datos.",
    });
  } catch (error: any) {
    console.error("Error en POST /api/testimonials:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al crear el testimonio" },
      { status: 500 }
    );
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { id, name, role, company, avatar, content, rating, status } = body;

    if (!id) {
      return NextResponse.json(
        { success: false, error: "ID de testimonio no proporcionado." },
        { status: 400 }
      );
    }

    const updateData: any = {};
    if (name !== undefined) updateData.name = name.trim();
    if (role !== undefined) updateData.role = role ? role.trim() : null;
    if (company !== undefined) updateData.company = company ? company.trim() : null;
    if (avatar !== undefined) updateData.avatar = avatar || null;
    if (content !== undefined) updateData.content = content ? content.trim() : "";
    if (rating !== undefined) updateData.rating = Number(rating);
    if (status !== undefined) updateData.status = status;

    const updated = await prisma.testimonial.update({
      where: { id },
      data: updateData,
    });

    return NextResponse.json({
      success: true,
      testimonial: updated,
      message: "Testimonio actualizado correctamente.",
    });
  } catch (error: any) {
    console.error("Error en PUT /api/testimonials:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al actualizar testimonio" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        { success: false, error: "ID de testimonio no proporcionado." },
        { status: 400 }
      );
    }

    await prisma.testimonial.delete({
      where: { id },
    });

    return NextResponse.json({
      success: true,
      message: "Testimonio eliminado correctamente de la base de datos.",
    });
  } catch (error: any) {
    console.error("Error en DELETE /api/testimonials:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al eliminar testimonio" },
      { status: 500 }
    );
  }
}
