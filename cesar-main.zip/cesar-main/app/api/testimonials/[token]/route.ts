import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ token: string }> }
) {
  try {
    const { token } = await params;

    if (!token) {
      return NextResponse.json(
        { success: false, error: "Token inválido o no proporcionado" },
        { status: 400 }
      );
    }

    const testimonial = await prisma.testimonial.findUnique({
      where: { token },
    });

    if (!testimonial) {
      return NextResponse.json(
        { success: false, notFound: true, error: "El formulario de testimonio no existe o fue eliminado." },
        { status: 404 }
      );
    }

    if (testimonial.isCompleted) {
      return NextResponse.json({
        success: true,
        isCompleted: true,
        message: "Este formulario ya ha sido completado. ¡Muchas gracias por tu testimonio!",
        testimonial: {
          name: testimonial.name,
          role: testimonial.role,
          company: testimonial.company,
          rating: testimonial.rating,
        },
      });
    }

    if (testimonial.tokenExpiry && new Date(testimonial.tokenExpiry) < new Date()) {
      return NextResponse.json({
        success: false,
        isExpired: true,
        error: "Este enlace temporal de testimonio ha expirado. Comunícate con el administrador para solicitar un nuevo enlace.",
      });
    }

    return NextResponse.json({
      success: true,
      testimonial: {
        id: testimonial.id,
        name: testimonial.name === "Cliente Invitado" ? "" : testimonial.name,
        role: testimonial.role || "",
        company: testimonial.company || "",
        clientNotes: testimonial.clientNotes || "",
      },
    });
  } catch (error: any) {
    console.error("Error en GET /api/testimonials/[token]:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al verificar el enlace" },
      { status: 500 }
    );
  }
}

export async function POST(
  request: Request,
  { params }: { params: Promise<{ token: string }> }
) {
  try {
    const { token } = await params;
    const body = await request.json();
    const { name, role, company, avatar, content, rating } = body;

    if (!token) {
      return NextResponse.json(
        { success: false, error: "Token no proporcionado" },
        { status: 400 }
      );
    }

    const existing = await prisma.testimonial.findUnique({
      where: { token },
    });

    if (!existing) {
      return NextResponse.json(
        { success: false, error: "El formulario de testimonio no existe." },
        { status: 404 }
      );
    }

    if (existing.isCompleted) {
      return NextResponse.json(
        { success: false, error: "Este testimonio ya fue enviado previamente." },
        { status: 400 }
      );
    }

    if (existing.tokenExpiry && new Date(existing.tokenExpiry) < new Date()) {
      return NextResponse.json(
        { success: false, error: "El enlace temporal ha expirado." },
        { status: 400 }
      );
    }

    if (!name || !name.trim()) {
      return NextResponse.json(
        { success: false, error: "Por favor ingresa tu nombre completo." },
        { status: 400 }
      );
    }

    if (!content || !content.trim()) {
      return NextResponse.json(
        { success: false, error: "Por favor escribe tu reseña o testimonio." },
        { status: 400 }
      );
    }

    const updated = await prisma.testimonial.update({
      where: { token },
      data: {
        name: name.trim(),
        role: role ? role.trim() : null,
        company: company ? company.trim() : null,
        avatar: avatar || null,
        content: content.trim(),
        rating: rating ? Number(rating) : 5,
        status: "PUBLICADO", // Se publica automáticamente al ser enviado por el cliente
        isCompleted: true,
      },
    });

    return NextResponse.json({
      success: true,
      testimonial: updated,
      message: "¡Tu testimonio ha sido enviado exitosamente! Muchas gracias.",
    });
  } catch (error: any) {
    console.error("Error en POST /api/testimonials/[token]:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al enviar el testimonio" },
      { status: 500 }
    );
  }
}
