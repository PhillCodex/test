import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const settings = await prisma.siteSetting.findUnique({ where: { id: "general" } });
    const baseUrl = settings?.publicUrl || (new URL(req.url)).origin || "http://localhost:3000";

    const publishedStatuses = ["Publicado", "PUBLICADO", "published", "PUBLISHED", "Activo", "ACTIVO"];

    const [posts, pages, categories, projects, services] = await Promise.all([
      prisma.post.findMany({
        where: { status: { in: publishedStatuses } },
        orderBy: { updatedAt: "desc" },
        select: { id: true, title: true, slug: true, updatedAt: true },
      }),
      prisma.page.findMany({
        where: { status: { in: publishedStatuses } },
        orderBy: { updatedAt: "desc" },
        select: { id: true, title: true, slug: true, updatedAt: true },
      }),
      prisma.category.findMany({
        orderBy: { name: "asc" },
        select: { id: true, name: true, slug: true, createdAt: true },
      }),
      prisma.project.findMany({
        where: { status: { in: publishedStatuses } },
        orderBy: { updatedAt: "desc" },
        select: { id: true, title: true, slug: true, updatedAt: true },
      }),
      prisma.service.findMany({
        where: { status: { in: publishedStatuses } },
        orderBy: { updatedAt: "desc" },
        select: { id: true, title: true, slug: true, updatedAt: true },
      }),
    ]);

    const sitemaps = [
      {
        id: "index",
        file: "sitemap.xml",
        url: `${baseUrl}/sitemap.xml`,
        name: "Índice Principal de Sitemaps",
        type: "sitemapindex",
        count: 5,
        lastmod: new Date().toISOString(),
      },
      {
        id: "post",
        file: "post.xml",
        url: `${baseUrl}/post.xml`,
        name: "Entradas de Blog (Posts)",
        type: "urlset",
        count: posts.length,
        lastmod: posts[0]?.updatedAt?.toISOString() || new Date().toISOString(),
        items: posts.map((p) => ({
          loc: `${baseUrl}/posts/${p.slug}`,
          title: p.title,
          lastmod: p.updatedAt,
          changefreq: "weekly",
          priority: "0.8",
        })),
      },
      {
        id: "page",
        file: "page.xml",
        url: `${baseUrl}/page.xml`,
        name: "Páginas Estáticas",
        type: "urlset",
        count: pages.length + 1, // +1 for homepage
        lastmod: pages[0]?.updatedAt?.toISOString() || new Date().toISOString(),
        items: [
          {
            loc: `${baseUrl}`,
            title: "Página Principal (Home)",
            lastmod: new Date().toISOString(),
            changefreq: "daily",
            priority: "1.0",
          },
          ...pages.map((p) => ({
            loc: `${baseUrl}/${p.slug}`,
            title: p.title,
            lastmod: p.updatedAt,
            changefreq: "monthly",
            priority: "0.7",
          })),
        ],
      },
      {
        id: "categoria",
        file: "categoria.xml",
        url: `${baseUrl}/categoria.xml`,
        name: "Archivos de Categorías",
        type: "urlset",
        count: categories.length,
        lastmod: categories[0]?.createdAt?.toISOString() || new Date().toISOString(),
        items: categories.map((c) => ({
          loc: `${baseUrl}/categoria/${c.slug}`,
          title: c.name,
          lastmod: c.createdAt,
          changefreq: "weekly",
          priority: "0.6",
        })),
      },
      {
        id: "proyecto",
        file: "proyecto.xml",
        url: `${baseUrl}/proyecto.xml`,
        name: "Portafolio de Proyectos",
        type: "urlset",
        count: projects.length,
        lastmod: projects[0]?.updatedAt?.toISOString() || new Date().toISOString(),
        items: projects.map((p) => ({
          loc: `${baseUrl}/proyectos/${p.slug}`,
          title: p.title,
          lastmod: p.updatedAt,
          changefreq: "monthly",
          priority: "0.7",
        })),
      },
      {
        id: "servicio",
        file: "servicio.xml",
        url: `${baseUrl}/servicio.xml`,
        name: "Servicios y Soluciones",
        type: "urlset",
        count: services.length,
        lastmod: services[0]?.updatedAt?.toISOString() || new Date().toISOString(),
        items: services.map((s) => ({
          loc: `${baseUrl}/servicios/${s.slug}`,
          title: s.title,
          lastmod: s.updatedAt,
          changefreq: "monthly",
          priority: "0.8",
        })),
      },
    ];

    return NextResponse.json({ success: true, baseUrl, sitemaps });
  } catch (error) {
    console.error("Error en sitemap summary:", error);
    return NextResponse.json({ success: false, error: "Error al obtener resumen de sitemaps" }, { status: 500 });
  }
}
