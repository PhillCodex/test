import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import fs from "fs";
import path from "path";

export const dynamic = "force-dynamic";

export async function GET() {
  const cwd = process.cwd();
  const certPaths = [
    path.join(cwd, "certs", "global-bundle.pem"),
    path.join(cwd, "prisma", "certs", "global-bundle.pem"),
    path.resolve("certs", "global-bundle.pem"),
    path.resolve("prisma", "certs", "global-bundle.pem"),
  ];

  const certStatus = certPaths.map((p) => ({
    path: p,
    exists: fs.existsSync(p),
  }));

  const rawDbUrl = process.env.DATABASE_URL ? "CONFIGURED (length: " + process.env.DATABASE_URL.length + ")" : "MISSING";

  let dbStatus = "UNKNOWN";
  let userCount = -1;
  let errorMessage: string | null = null;
  let errorStack: string | null = null;

  try {
    userCount = await prisma.user.count();
    dbStatus = "CONNECTED_SUCCESS";
  } catch (err: any) {
    dbStatus = "CONNECTION_ERROR";
    errorMessage = err?.message || String(err);
    errorStack = err?.stack || null;
  }

  return NextResponse.json({
    status: dbStatus,
    userCount,
    rawDbUrl,
    certStatus,
    error: errorMessage,
    stack: errorStack,
    nodeEnv: process.env.NODE_ENV,
    cwd,
  });
}
