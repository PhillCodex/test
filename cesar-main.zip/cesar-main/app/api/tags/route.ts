import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    let tags = await prisma.tag.findMany({
      orderBy: { name: "asc" },
    });

    if (tags.length === 0) {
      const defaultTags = [
        { name: "WordPress", slug: "wordpress", description: "Publicaciones sobre el CMS WordPress, plugins y seguridad.", color: "cyan" },
        { name: "Seguridad", slug: "seguridad", description: "Buenas prácticas de ciberseguridad, firewalls y protección de datos.", color: "green" },
        { name: "Linux", slug: "linux", description: "Administración de servidores Linux, terminal y configuración de sistemas.", color: "purple" },
        { name: "Next.js", slug: "nextjs", description: "Desarrollo moderno frontend con React y Next.js.", color: "cyan" },
        { name: "DevOps", slug: "devops", description: "Automatización, pipelines CI/CD y despliegues en la nube.", color: "green" },
        { name: "Optimización", slug: "optimizacion", description: "Velocidad de carga, caché y optimización de bases de datos.", color: "orange" },
        { name: "SEO", slug: "seo", description: "Posicionamiento orgánico en motores de búsqueda como Google.", color: "purple" },
      ];

      for (const t of defaultTags) {
        await prisma.tag.upsert({
          where: { slug: t.slug },
          update: {},
          create: t,
        });
      }

      tags = await prisma.tag.findMany({
        orderBy: { name: "asc" },
      });
    }

    // Obtener todos los posts para calcular cuántas veces se usa cada tag
    const allPosts = await prisma.post.findMany({
      select: { tags: true },
    });

    const tagsWithCount = tags.map((tag) => {
      const count = allPosts.filter((p) => {
        if (!p.tags) return false;
        const normalizedPostTags = p.tags
          .toLowerCase()
          .split(",")
          .map((t) => t.replace(/#/g, "").trim());
        return normalizedPostTags.includes(tag.name.toLowerCase()) || normalizedPostTags.includes(tag.slug.toLowerCase());
      }).length;

      return {
        ...tag,
        postCount: count,
      };
    });

    return NextResponse.json({ tags: tagsWithCount });
  } catch (error) {
    console.error("Error en GET /api/tags:", error);
    return NextResponse.json({ error: "Error al obtener etiquetas de la base de datos." }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const { name, slug: customSlug, description = "", color = "cyan" } = await request.json();

    if (!name || typeof name !== "string") {
      return NextResponse.json({ error: "El nombre de la etiqueta es obligatorio." }, { status: 400 });
    }

    const cleanName = name.replace(/#/g, "").trim();

    const slug = (customSlug || cleanName)
      .toLowerCase()
      .trim()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "");

    const tag = await prisma.tag.upsert({
      where: { slug },
      update: {
        name: cleanName,
        description: description.trim(),
        color,
      },
      create: {
        name: cleanName,
        slug,
        description: description.trim(),
        color,
      },
    });

    return NextResponse.json({ success: true, tag });
  } catch (error) {
    console.error("Error en POST /api/tags:", error);
    return NextResponse.json({ error: "Error al guardar la etiqueta en base de datos." }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const { id, name, slug: customSlug, description = "", color = "cyan" } = await request.json();

    if (!id) {
      return NextResponse.json({ error: "El ID de la etiqueta es obligatorio." }, { status: 400 });
    }

    const cleanName = (name || "").replace(/#/g, "").trim();

    const slug = (customSlug || cleanName)
      .toLowerCase()
      .trim()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "");

    const tag = await prisma.tag.update({
      where: { id },
      data: {
        name: cleanName,
        slug,
        description: description.trim(),
        color,
      },
    });

    return NextResponse.json({ success: true, tag });
  } catch (error) {
    console.error("Error en PUT /api/tags:", error);
    return NextResponse.json({ error: "Error al actualizar la etiqueta." }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "El ID de la etiqueta es requerido." }, { status: 400 });
    }

    await prisma.tag.delete({
      where: { id },
    });

    return NextResponse.json({ success: true, message: "Etiqueta eliminada correctamente." });
  } catch (error) {
    console.error("Error en DELETE /api/tags:", error);
    return NextResponse.json({ error: "Error al eliminar la etiqueta de la base de datos." }, { status: 500 });
  }
}
