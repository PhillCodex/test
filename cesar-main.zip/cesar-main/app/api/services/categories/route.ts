import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

const INITIAL_SERVICE_CATEGORIES = [
  { name: "Desarrollo & Programación", slug: "desarrollo-programacion", color: "#16c96f", description: "Desarrollo de sitios web, APIs y software." },
  { name: "WordPress & CMS", slug: "wordpress-cms", color: "#38bdf8", description: "Implementación y personalización de gestores de contenido." },
  { name: "Ciberseguridad & Nube", slug: "ciberseguridad-nube", color: "#f59e0b", description: "Protección de datos, servidores y servicios en la nube." },
  { name: "Soporte & Consultoría", slug: "soporte-consultoria", color: "#a855f7", description: "Mantenimiento proactivo y asesoría técnica 24/7." },
];

export async function GET() {
  try {
    const count = await prisma.serviceCategory.count();
    if (count === 0) {
      for (const cat of INITIAL_SERVICE_CATEGORIES) {
        await prisma.serviceCategory.upsert({
          where: { slug: cat.slug },
          update: {},
          create: cat,
        });
      }
    }

    const categories = await prisma.serviceCategory.findMany({
      include: {
        _count: {
          select: { services: true },
        },
      },
      orderBy: { name: "asc" },
    });

    return NextResponse.json({ success: true, categories });
  } catch (error: any) {
    console.error("Error en GET /api/services/categories:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al obtener categorías de servicios" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, slug, description, color } = body;

    if (!name || !name.trim()) {
      return NextResponse.json(
        { success: false, error: "El nombre de la categoría es obligatorio." },
        { status: 400 }
      );
    }

    const cleanSlug =
      slug && slug.trim()
        ? slug.trim().toLowerCase().replace(/[^a-z0-9-]+/g, "-")
        : name.trim().toLowerCase().replace(/[^a-z0-9-]+/g, "-");

    const category = await prisma.serviceCategory.create({
      data: {
        name: name.trim(),
        slug: cleanSlug,
        description: description ? description.trim() : null,
        color: color || "#38bdf8",
      },
    });

    return NextResponse.json({ success: true, category, message: "Categoría de servicio creada exitosamente." });
  } catch (error: any) {
    console.error("Error en POST /api/services/categories:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al crear la categoría de servicios" },
      { status: 500 }
    );
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { id, name, slug, description, color } = body;

    if (!id) {
      return NextResponse.json({ success: false, error: "ID no proporcionado." }, { status: 400 });
    }

    const updateData: any = {};
    if (name) updateData.name = name.trim();
    if (slug) updateData.slug = slug.trim().toLowerCase().replace(/[^a-z0-9-]+/g, "-");
    if (description !== undefined) updateData.description = description ? description.trim() : null;
    if (color) updateData.color = color;

    const updated = await prisma.serviceCategory.update({
      where: { id },
      data: updateData,
    });

    return NextResponse.json({ success: true, category: updated, message: "Categoría actualizada correctamente." });
  } catch (error: any) {
    console.error("Error en PUT /api/services/categories:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al actualizar categoría" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ success: false, error: "ID no proporcionado." }, { status: 400 });
    }

    await prisma.serviceCategory.delete({
      where: { id },
    });

    return NextResponse.json({ success: true, message: "Categoría de servicio eliminada correctamente." });
  } catch (error: any) {
    console.error("Error en DELETE /api/services/categories:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al eliminar categoría" },
      { status: 500 }
    );
  }
}
