import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

const INITIAL_SERVICES = [
  {
    title: "Desarrollo Web",
    slug: "desarrollo-web",
    excerpt: "Sitios y aplicaciones rápidas, seguras y escalables con tecnologías modernas.",
    content: "Diseño y desarrollo frontend y backend a medida utilizando Next.js, React, Node.js y bases de datos relacionales de alto rendimiento.",
    price: "Desde $499 USD",
    priceLabel: "Por proyecto",
    icon: "CodeXml",
    status: "PUBLICADO",
  },
  {
    title: "WordPress Profesional",
    slug: "wordpress-profesional",
    excerpt: "Instalación, optimización y mantenimiento experto en entornos WordPress y WooCommerce.",
    content: "Implementación de temas a medida, configuración de plugins esenciales, pasarelas de pago y optimización extrema de Core Web Vitals.",
    price: "Desde $299 USD",
    priceLabel: "Por proyecto",
    icon: "Globe2",
    status: "PUBLICADO",
  },
  {
    title: "Ciberseguridad",
    slug: "ciberseguridad",
    excerpt: "Protegemos tus sistemas, servidores, bases de datos y usuarios ante cualquier amenaza.",
    content: "Auditoría de seguridad, certificados SSL, firewalls avanzados, protección contra ataques DDoS y blindaje de vulnerabilidades.",
    price: "Desde $199 USD",
    priceLabel: "Por auditoría",
    icon: "ShieldCheck",
    status: "PUBLICADO",
  },
  {
    title: "Cloud & DevOps",
    slug: "cloud-devops",
    excerpt: "Infraestructura en la nube, automatización, despliegue continuo y CI/CD.",
    content: "Configuración de servidores en AWS, Google Cloud, DigitalOcean, Docker, Kubernetes y automatización de despliegues.",
    price: "Desde $350 USD",
    priceLabel: "/mes",
    icon: "CloudCog",
    status: "PUBLICADO",
  },
  {
    title: "Soporte Técnico",
    slug: "soporte-tecnico",
    excerpt: "Atención rápida y soluciones efectivas 24/7 para que tu plataforma nunca se detenga.",
    content: "Resolución de incidencias críticas en tiempo récord, monitoreo constante de uptime y copias de seguridad automáticas.",
    price: "Desde $99 USD",
    priceLabel: "/mes",
    icon: "Headphones",
    status: "PUBLICADO",
  },
  {
    title: "Consultoría IT",
    slug: "consultoria-it",
    excerpt: "Estrategias tecnológicas que reducen costos y hacen crecer tu negocio digital.",
    content: "Asesoramiento integral sobre arquitectura de software, selección de proveedores cloud, optimización de flujos y escalabilidad.",
    price: "Desde $80 USD",
    priceLabel: "/hora",
    icon: "Lightbulb",
    status: "PUBLICADO",
  },
];

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const q = searchParams.get("q");
    const category = searchParams.get("category");
    const status = searchParams.get("status");

    const where: any = {};
    if (status && status !== "ALL") {
      where.status = status;
    }

    if (category && category !== "ALL") {
      where.categoryId = category;
    }

    if (q && q.trim()) {
      where.OR = [
        { title: { contains: q.trim() } },
        { excerpt: { contains: q.trim() } },
        { content: { contains: q.trim() } },
      ];
    }

    let services = await prisma.service.findMany({
      where,
      include: {
        category: true,
      },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({ success: true, services });
  } catch (error: any) {
    console.error("Error en GET /api/services:", error);
    return NextResponse.json({
      success: true,
      services: INITIAL_SERVICES.map((s, idx) => ({
        id: `fallback-${idx}`,
        ...s,
        featuredImage: null,
        seoTitle: null,
        seoDescription: null,
        focusKeyword: null,
        seoScore: 90,
        views: 150,
        categoryId: "default",
        authorId: "admin",
        createdAt: new Date(),
        updatedAt: new Date(),
        category: { id: "default", name: "Desarrollo & Programación", slug: "desarrollo-programacion", color: "#16c96f" },
      })),
    });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      title,
      slug,
      excerpt,
      content,
      featuredImage,
      icon,
      price,
      priceLabel,
      features,
      categoryId,
      status,
    } = body;

    if (!title || !title.trim()) {
      return NextResponse.json({ success: false, error: "El título del servicio es obligatorio." }, { status: 400 });
    }

    const cleanSlug =
      slug && slug.trim()
        ? slug.trim().toLowerCase().replace(/[^a-z0-9-]+/g, "-")
        : title.trim().toLowerCase().replace(/[^a-z0-9-]+/g, "-");

    const existing = await prisma.service.findUnique({
      where: { slug: cleanSlug },
    });

    const finalSlug = existing ? `${cleanSlug}-${Date.now()}` : cleanSlug;

    const newService = await prisma.service.create({
      data: {
        title: title.trim(),
        slug: finalSlug,
        excerpt: excerpt ? excerpt.trim() : null,
        content: content ? content.trim() : null,
        featuredImage: featuredImage || null,
        icon: icon || "Box",
        price: price ? price.trim() : null,
        priceLabel: priceLabel ? priceLabel.trim() : null,
        features: features || null,
        categoryId: categoryId || null,
        status: status || "PUBLICADO",
      },
      include: {
        category: true,
      },
    });

    return NextResponse.json({
      success: true,
      service: newService,
      message: "Servicio creado exitosamente.",
    });
  } catch (error: any) {
    console.error("Error en POST /api/services:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al crear el servicio" },
      { status: 500 }
    );
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const {
      id,
      title,
      slug,
      excerpt,
      content,
      featuredImage,
      icon,
      price,
      priceLabel,
      features,
      categoryId,
      status,
    } = body;

    if (!id) {
      return NextResponse.json({ success: false, error: "ID no proporcionado." }, { status: 400 });
    }

    const updateData: any = {};
    if (title !== undefined) updateData.title = title.trim();
    if (slug !== undefined) {
      updateData.slug = slug.trim().toLowerCase().replace(/[^a-z0-9-]+/g, "-");
    }
    if (excerpt !== undefined) updateData.excerpt = excerpt ? excerpt.trim() : null;
    if (content !== undefined) updateData.content = content ? content.trim() : null;
    if (featuredImage !== undefined) updateData.featuredImage = featuredImage || null;
    if (icon !== undefined) updateData.icon = icon;
    if (price !== undefined) updateData.price = price ? price.trim() : null;
    if (priceLabel !== undefined) updateData.priceLabel = priceLabel ? priceLabel.trim() : null;
    if (features !== undefined) updateData.features = features || null;
    if (categoryId !== undefined) updateData.categoryId = categoryId || null;
    if (status !== undefined) updateData.status = status;

    const updated = await prisma.service.update({
      where: { id },
      data: updateData,
      include: { category: true },
    });

    return NextResponse.json({
      success: true,
      service: updated,
      message: "Servicio actualizado correctamente.",
    });
  } catch (error: any) {
    console.error("Error en PUT /api/services:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al actualizar servicio" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ success: false, error: "ID no proporcionado." }, { status: 400 });
    }

    await prisma.service.delete({
      where: { id },
    });

    return NextResponse.json({ success: true, message: "Servicio eliminado correctamente." });
  } catch (error: any) {
    console.error("Error en DELETE /api/services:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al eliminar servicio" },
      { status: 500 }
    );
  }
}
