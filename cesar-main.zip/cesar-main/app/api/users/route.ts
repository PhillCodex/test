import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import bcrypt from "bcryptjs";
import { Role } from "@prisma/client";
import { getSession } from "@/lib/auth";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const q = searchParams.get("q");
    const roleFilter = searchParams.get("role");

    const where: any = {};

    if (q && q.trim()) {
      where.OR = [
        { name: { contains: q.trim() } },
        { lastName: { contains: q.trim() } },
        { email: { contains: q.trim() } },
      ];
    }

    if (roleFilter && roleFilter !== "ALL") {
      where.role = roleFilter as Role;
    }

    const users = await prisma.user.findMany({
      where,
      select: {
        id: true,
        name: true,
        lastName: true,
        email: true,
        avatar: true,
        role: true,
        createdAt: true,
        updatedAt: true,
        _count: {
          select: {
            posts: true,
            pages: true,
          },
        },
      },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({
      success: true,
      users,
    });
  } catch (error: any) {
    console.error("Error en GET /api/users:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al obtener usuarios" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await getSession();
    if (!session || session.role !== Role.ADMIN) {
      return NextResponse.json(
        { success: false, error: "No tienes permisos de Administrador para crear usuarios." },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { name, lastName, email, password, role, avatar } = body;

    if (!name || !name.trim()) {
      return NextResponse.json(
        { success: false, error: "El nombre es obligatorio." },
        { status: 400 }
      );
    }

    if (!email || !email.trim()) {
      return NextResponse.json(
        { success: false, error: "El correo electrónico es obligatorio." },
        { status: 400 }
      );
    }

    const cleanEmail = email.trim().toLowerCase();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(cleanEmail)) {
      return NextResponse.json(
        { success: false, error: "El formato de correo no es válido." },
        { status: 400 }
      );
    }

    if (!password || password.length < 6) {
      return NextResponse.json(
        { success: false, error: "La contraseña debe tener al menos 6 caracteres." },
        { status: 400 }
      );
    }

    // Verificar si el correo ya existe
    const existingUser = await prisma.user.findUnique({
      where: { email: cleanEmail },
    });

    if (existingUser) {
      return NextResponse.json(
        { success: false, error: "Ya existe un usuario registrado con este correo electrónico." },
        { status: 400 }
      );
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = await prisma.user.create({
      data: {
        name: name.trim(),
        lastName: lastName ? lastName.trim() : null,
        email: cleanEmail,
        password: hashedPassword,
        role: (role as Role) || Role.USUARIO,
        avatar: avatar || null,
      },
      select: {
        id: true,
        name: true,
        lastName: true,
        email: true,
        avatar: true,
        role: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    return NextResponse.json({
      success: true,
      user: newUser,
      message: "Usuario creado exitosamente en la base de datos.",
    });
  } catch (error: any) {
    console.error("Error en POST /api/users:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al crear usuario" },
      { status: 500 }
    );
  }
}

export async function PUT(request: Request) {
  try {
    const session = await getSession();
    if (!session || session.role !== Role.ADMIN) {
      return NextResponse.json(
        { success: false, error: "No tienes permisos de Administrador para editar usuarios." },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { id, name, lastName, email, password, role, avatar } = body;

    if (!id) {
      return NextResponse.json(
        { success: false, error: "ID de usuario no proporcionado." },
        { status: 400 }
      );
    }

    if (!name || !name.trim()) {
      return NextResponse.json(
        { success: false, error: "El nombre es obligatorio." },
        { status: 400 }
      );
    }

    if (!email || !email.trim()) {
      return NextResponse.json(
        { success: false, error: "El correo electrónico es obligatorio." },
        { status: 400 }
      );
    }

    const cleanEmail = email.trim().toLowerCase();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(cleanEmail)) {
      return NextResponse.json(
        { success: false, error: "El formato de correo no es válido." },
        { status: 400 }
      );
    }

    // Verificar si el correo está en uso por otro usuario distinto
    const conflictingUser = await prisma.user.findFirst({
      where: {
        email: cleanEmail,
        id: { not: id },
      },
    });

    if (conflictingUser) {
      return NextResponse.json(
        { success: false, error: "Este correo electrónico ya pertenece a otro usuario." },
        { status: 400 }
      );
    }

    const updateData: any = {
      name: name.trim(),
      lastName: lastName ? lastName.trim() : null,
      email: cleanEmail,
      role: (role as Role) || Role.USUARIO,
      avatar: avatar || null,
    };

    // Si se envió una nueva contraseña, actualizarla con hash bcrypt
    if (password && password.trim().length >= 6) {
      updateData.password = await bcrypt.hash(password.trim(), 10);
    }

    const updatedUser = await prisma.user.update({
      where: { id },
      data: updateData,
      select: {
        id: true,
        name: true,
        lastName: true,
        email: true,
        avatar: true,
        role: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    return NextResponse.json({
      success: true,
      user: updatedUser,
      message: "Datos de usuario actualizados correctamente.",
    });
  } catch (error: any) {
    console.error("Error en PUT /api/users:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al actualizar usuario" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: Request) {
  try {
    const session = await getSession();
    if (!session || session.role !== Role.ADMIN) {
      return NextResponse.json(
        { success: false, error: "No tienes permisos de Administrador para eliminar usuarios." },
        { status: 403 }
      );
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        { success: false, error: "ID de usuario no proporcionado." },
        { status: 400 }
      );
    }

    // Proteger contra auto-eliminación del usuario en sesión
    if (session.id === id) {
      return NextResponse.json(
        { success: false, error: "No puedes eliminar tu propia cuenta en sesión activa." },
        { status: 400 }
      );
    }

    // Verificar si es el último Administrador
    const userToDelete = await prisma.user.findUnique({
      where: { id },
    });

    if (!userToDelete) {
      return NextResponse.json(
        { success: false, error: "El usuario no existe." },
        { status: 404 }
      );
    }

    if (userToDelete.role === Role.ADMIN) {
      const adminCount = await prisma.user.count({
        where: { role: Role.ADMIN },
      });
      if (adminCount <= 1) {
        return NextResponse.json(
          { success: false, error: "No puedes eliminar al único Administrador del sistema." },
          { status: 400 }
        );
      }
    }

    await prisma.user.delete({
      where: { id },
    });

    return NextResponse.json({
      success: true,
      message: "Usuario eliminado correctamente de la base de datos.",
    });
  } catch (error: any) {
    console.error("Error en DELETE /api/users:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al eliminar usuario" },
      { status: 500 }
    );
  }
}
