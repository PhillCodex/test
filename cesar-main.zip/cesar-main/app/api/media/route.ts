import { NextRequest, NextResponse } from "next/server";
import { writeFile, unlink, mkdir } from "fs/promises";
import path from "path";
import crypto from "crypto";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const search = searchParams.get("search")?.toLowerCase().trim() || "";
    const type = searchParams.get("type") || "all";
    const dateFilter = searchParams.get("date") || "all";

    // Obtener todos los medios de la base de datos
    let mediaList: Array<{
      id: string;
      filename: string;
      originalName: string;
      url: string;
      mimeType: string;
      size: number;
      dimensions: string | null;
      altText: string | null;
      title: string | null;
      caption: string | null;
      description: string | null;
      uploadedBy: string | null;
      createdAt: Date | string;
      updatedAt: Date | string;
    }> = [];

    try {
      mediaList = await prisma.$queryRawUnsafe<any[]>(
        `SELECT * FROM media ORDER BY createdAt DESC`
      );
    } catch (dbErr: any) {
      console.error("Error consultando tabla media:", dbErr.message);
    }

    // Extraer meses/fechas únicas disponibles para el selector
    const dateMap = new Set<string>();
    mediaList.forEach((m) => {
      const d = new Date(m.createdAt);
      const monthNames = [
        "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
        "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
      ];
      const year = d.getFullYear();
      const monthIndex = d.getMonth();
      const key = `${year}-${String(monthIndex + 1).padStart(2, "0")}`;
      dateMap.add(JSON.stringify({ value: key, label: `${monthNames[monthIndex]} ${year}` }));
    });

    const availableDates = Array.from(dateMap).map((d) => JSON.parse(d));

    // Filtrar en memoria por búsqueda, tipo y fecha
    let filtered = mediaList;

    if (search) {
      filtered = filtered.filter(
        (m) =>
          m.filename.toLowerCase().includes(search) ||
          m.originalName.toLowerCase().includes(search) ||
          (m.title && m.title.toLowerCase().includes(search)) ||
          (m.altText && m.altText.toLowerCase().includes(search)) ||
          (m.caption && m.caption.toLowerCase().includes(search)) ||
          (m.description && m.description.toLowerCase().includes(search))
      );
    }

    if (type !== "all") {
      if (type === "image") {
        filtered = filtered.filter((m) => m.mimeType.startsWith("image/"));
      } else if (type === "audio") {
        filtered = filtered.filter((m) => m.mimeType.startsWith("audio/"));
      } else if (type === "video") {
        filtered = filtered.filter((m) => m.mimeType.startsWith("video/"));
      } else if (type === "document") {
        filtered = filtered.filter(
          (m) =>
            m.mimeType.includes("pdf") ||
            m.mimeType.includes("document") ||
            m.mimeType.includes("word") ||
            m.mimeType.includes("text") ||
            m.mimeType.includes("sheet") ||
            m.mimeType.includes("zip")
        );
      }
    }

    if (dateFilter !== "all") {
      filtered = filtered.filter((m) => {
        const d = new Date(m.createdAt);
        const y = d.getFullYear();
        const mo = String(d.getMonth() + 1).padStart(2, "0");
        return `${y}-${mo}` === dateFilter;
      });
    }

    return NextResponse.json({
      success: true,
      media: filtered,
      totalCount: filtered.length,
      availableDates,
    });
  } catch (error: any) {
    console.error("Error en GET /api/media:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getSession();
    const uploadedBy = session?.name || "Admin";

    const data = await req.formData();
    const files = data.getAll("files") as File[];
    const singleFile = data.get("file") as File | null;

    const attachedToTitle = (data.get("attachedToTitle") as string) || null;
    const attachedToUrl = (data.get("attachedToUrl") as string) || null;
    const attachedToType = (data.get("attachedToType") as string) || null;
    const attachedToId = (data.get("attachedToId") as string) || null;

    const filesToUpload: File[] = [];
    if (files && files.length > 0) {
      files.forEach((f) => {
        if (f && f.name) filesToUpload.push(f);
      });
    } else if (singleFile && singleFile.name) {
      filesToUpload.push(singleFile);
    }

    if (filesToUpload.length === 0) {
      return NextResponse.json({ error: "No se proporcionaron archivos para subir." }, { status: 400 });
    }

    const createdRecords = [];

    for (const file of filesToUpload) {
      const bytes = await file.arrayBuffer();
      const buffer = Buffer.from(bytes);
      const size = buffer.length;
      const mimeType = file.type || "application/octet-stream";

      // Sanitizar nombre de archivo
      const rawOriginalName = file.name;
      const ext = path.extname(rawOriginalName) || ".jpg";
      const baseName = path.basename(rawOriginalName, ext).replace(/[^a-zA-Z0-9_-]/g, "-");
      const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1e4)}`;
      const filename = `${baseName}-${uniqueSuffix}${ext}`;

      const base64Str = buffer.toString("base64");
      const dataUrl = `data:${mimeType};base64,${base64Str}`;

      // 1. Intentar escribir a disco local
      let savedToDisk = false;
      try {
        const uploadDir = path.join(process.cwd(), "public", "uploads");
        await mkdir(uploadDir, { recursive: true });
        const filePath = path.join(uploadDir, filename);
        await writeFile(filePath, buffer);
        savedToDisk = true;
      } catch {
        // Ignorar en serverless/Vercel
      }

      // 2. Intentar escribir en /tmp si no se pudo en public
      if (!savedToDisk) {
        try {
          const tmpDir = path.join("/tmp", "uploads");
          await mkdir(tmpDir, { recursive: true });
          await writeFile(path.join(tmpDir, filename), buffer);
        } catch {
          // Fallback a BD
        }
      }

      const publicUrl = `/uploads/${filename}`;
      const title = baseName.replace(/[-_]/g, " ");

      // Estimación de dimensiones si es imagen (o dimensiones por defecto)
      let dimensions: string | null = null;
      if (mimeType.startsWith("image/")) {
        dimensions = "1200 por 800 píxeles";
      }

      const id = crypto.randomUUID();

      await prisma.$executeRawUnsafe(
        `INSERT INTO media (id, filename, originalName, url, mimeType, size, dimensions, altText, title, caption, description, uploadedBy, attachedToTitle, attachedToUrl, attachedToType, attachedToId, fileData, createdAt, updatedAt)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(3), NOW(3))`,
        id,
        filename,
        rawOriginalName,
        publicUrl,
        mimeType,
        size,
        dimensions,
        title,
        title,
        "",
        "",
        uploadedBy,
        attachedToTitle,
        attachedToUrl,
        attachedToType,
        attachedToId,
        dataUrl
      );

      createdRecords.push({
        id,
        filename,
        originalName: rawOriginalName,
        url: publicUrl,
        dataUrl: dataUrl,
        mimeType,
        size,
        dimensions,
        altText: title,
        title,
        caption: "",
        description: "",
        uploadedBy,
        attachedToTitle,
        attachedToUrl,
        attachedToType,
        attachedToId,
        createdAt: new Date().toISOString(),
      });
    }

    return NextResponse.json({
      success: true,
      message: `${createdRecords.length} archivo(s) subido(s) con éxito.`,
      media: createdRecords,
    });
  } catch (error: any) {
    console.error("Error en POST /api/media:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const ids: string[] = Array.isArray(body.ids) ? body.ids : body.id ? [body.id] : [];

    if (ids.length === 0) {
      return NextResponse.json({ error: "No se proporcionaron IDs para eliminar." }, { status: 400 });
    }

    const uploadDir = path.join(process.cwd(), "public", "uploads");

    for (const id of ids) {
      const records = await prisma.$queryRawUnsafe<any[]>(
        `SELECT filename FROM media WHERE id = ?`,
        id
      );

      if (records && records.length > 0) {
        const filename = records[0].filename;
        const filePath = path.join(uploadDir, filename);
        await unlink(filePath).catch(() => {});
      }

      await prisma.$executeRawUnsafe(`DELETE FROM media WHERE id = ?`, id);
    }

    return NextResponse.json({
      success: true,
      message: `${ids.length} elemento(s) eliminado(s) permanentemente.`,
    });
  } catch (error: any) {
    console.error("Error en DELETE /api/media:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
