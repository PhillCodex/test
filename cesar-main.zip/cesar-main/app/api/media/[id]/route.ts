import { NextRequest, NextResponse } from "next/server";
import { unlink } from "fs/promises";
import path from "path";
import { prisma } from "@/lib/prisma";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const records = await prisma.$queryRawUnsafe<any[]>(
      `SELECT * FROM media WHERE id = ? LIMIT 1`,
      id
    );

    if (!records || records.length === 0) {
      return NextResponse.json({ error: "Archivo de medios no encontrado." }, { status: 404 });
    }

    return NextResponse.json({ success: true, media: records[0] });
  } catch (error: any) {
    console.error("Error en GET /api/media/[id]:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const { altText, title, caption, description } = body;

    await prisma.$executeRawUnsafe(
      `UPDATE media
       SET altText = ?, title = ?, caption = ?, description = ?, updatedAt = NOW(3)
       WHERE id = ?`,
      altText || "",
      title || "",
      caption || "",
      description || "",
      id
    );

    const updated = await prisma.$queryRawUnsafe<any[]>(
      `SELECT * FROM media WHERE id = ? LIMIT 1`,
      id
    );

    return NextResponse.json({
      success: true,
      message: "Detalles del adjunto actualizados correctamente.",
      media: updated[0],
    });
  } catch (error: any) {
    console.error("Error en PUT /api/media/[id]:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const records = await prisma.$queryRawUnsafe<any[]>(
      `SELECT filename FROM media WHERE id = ? LIMIT 1`,
      id
    );

    if (records && records.length > 0) {
      const filename = records[0].filename;
      const filePath = path.join(process.cwd(), "public", "uploads", filename);
      await unlink(filePath).catch(() => {});
    }

    await prisma.$executeRawUnsafe(`DELETE FROM media WHERE id = ?`, id);

    return NextResponse.json({
      success: true,
      message: "Archivo de medios eliminado permanentemente.",
    });
  } catch (error: any) {
    console.error("Error en DELETE /api/media/[id]:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
