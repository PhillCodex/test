import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const days = parseInt(searchParams.get("days") || "30", 10);

    const now = new Date();
    const startDate = new Date();
    startDate.setDate(now.getDate() - (days - 1));
    startDate.setHours(0, 0, 0, 0);

    // 1. Conteo de entidades reales en la base de datos
    const [
      postsTotal,
      postsPublished,
      postsDraft,
      categoriesCount,
      pagesCount,
      commentsCount,
      commentsPending,
      usersCount,
      projectsCount,
      servicesCount,
      recentPosts,
      siteSettings,
    ] = await Promise.all([
      prisma.post.count(),
      prisma.post.count({ where: { status: "Publicado" } }),
      prisma.post.count({ where: { status: "Borrador" } }),
      prisma.category.count(),
      prisma.page.count(),
      prisma.comment.count(),
      prisma.comment.count({ where: { status: "PENDIENTE" } }),
      prisma.user.count(),
      prisma.project.count(),
      prisma.service.count(),
      prisma.post.findMany({
        take: 5,
        orderBy: { createdAt: "desc" },
        include: { category: true, author: true },
      }),
      prisma.siteSetting.findUnique({ where: { id: "general" } }),
    ]);

    // 2. Obtener visitas reales de la tabla site_visits agrupadas por día
    let visitsData: Array<{ date: string; fullDate: string; visits: number; uniqueIps: number }> = [];

    try {
      const rawVisits = await prisma.$queryRawUnsafe<Array<{ createdAt: Date | string; ipAddress: string | null }>>(
        `SELECT createdAt, ipAddress FROM site_visits WHERE createdAt >= ? ORDER BY createdAt ASC`,
        startDate
      );

      // Mapear días del periodo para asegurar una serie continua
      const dayMap = new Map<string, { visits: number; ips: Set<string> }>();

      for (let i = 0; i < days; i++) {
        const d = new Date(startDate);
        d.setDate(d.getDate() + i);
        const dayKey = d.toISOString().split("T")[0]; // YYYY-MM-DD
        dayMap.set(dayKey, { visits: 0, ips: new Set() });
      }

      // Agrupar visitas reales
      rawVisits.forEach((v) => {
        const dateObj = typeof v.createdAt === "string" ? new Date(v.createdAt) : v.createdAt;
        const dayKey = dateObj.toISOString().split("T")[0];
        if (dayMap.has(dayKey)) {
          const item = dayMap.get(dayKey)!;
          item.visits += 1;
          if (v.ipAddress) item.ips.add(v.ipAddress);
        }
      });

      // Formatear datos para el gráfico de Recharts
      const monthNames = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];
      visitsData = Array.from(dayMap.entries()).map(([dayKey, val]) => {
        const d = new Date(dayKey + "T12:00:00Z");
        const formattedLabel = `${d.getUTCDate()} ${monthNames[d.getUTCMonth()]}`;

        return {
          date: formattedLabel,
          fullDate: dayKey,
          visits: val.visits,
          uniqueIps: val.ips.size,
        };
      });
    } catch (e) {
      console.error("Error al consultar visitas en analytics:", e);
    }

    const totalPeriodVisits = visitsData.reduce((acc, curr) => acc + curr.visits, 0);

    return NextResponse.json({
      success: true,
      stats: {
        postsTotal,
        postsPublished,
        postsDraft,
        categoriesCount,
        pagesCount,
        commentsCount,
        commentsPending,
        usersCount,
        projectsCount,
        servicesCount,
        totalPeriodVisits,
      },
      chartData: visitsData,
      recentPosts: recentPosts.map((p) => ({
        id: p.id,
        title: p.title,
        slug: p.slug,
        category: p.category?.name || "General",
        featuredImage: p.featuredImage || "/images/hero-techlab.png",
        createdAt: p.createdAt,
        views: p.views || 0,
        status: p.status,
      })),
      siteTitle: siteSettings?.siteTitle || "TechLab",
    });
  } catch (error: any) {
    console.error("Error en API analytics:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
