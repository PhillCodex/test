import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");
    const postId = searchParams.get("postId");
    const postSlug = searchParams.get("postSlug");
    const q = searchParams.get("q");

    const where: any = {};

    if (status && status !== "ALL") {
      where.status = status;
    }

    if (postId) {
      where.postId = postId;
    } else if (postSlug) {
      const post = await prisma.post.findUnique({
        where: { slug: postSlug },
        select: { id: true },
      });
      if (post) {
        where.postId = post.id;
      }
    }

    if (q) {
      where.OR = [
        { content: { contains: q } },
        { authorName: { contains: q } },
        { authorEmail: { contains: q } },
        { post: { title: { contains: q } } },
      ];
    }

    const comments = await prisma.comment.findMany({
      where,
      include: {
        post: {
          select: {
            id: true,
            title: true,
            slug: true,
          },
        },
        replies: {
          include: {
            post: {
              select: {
                id: true,
                title: true,
                slug: true,
              },
            },
          },
          orderBy: { createdAt: "asc" },
        },
      },
      orderBy: { createdAt: "desc" },
    });

    // Counts for dashboard tabs
    const [totalCount, approvedCount, pendingCount, rejectedCount] = await Promise.all([
      prisma.comment.count(),
      prisma.comment.count({ where: { status: "APROBADO" } }),
      prisma.comment.count({ where: { status: "PENDIENTE" } }),
      prisma.comment.count({ where: { status: "RECHAZADO" } }),
    ]);

    return NextResponse.json({
      success: true,
      comments,
      counts: {
        total: totalCount,
        approved: approvedCount,
        pending: pendingCount,
        rejected: rejectedCount,
      },
    });
  } catch (err: any) {
    console.error("Error en GET /api/comments:", err);
    return NextResponse.json(
      { success: false, error: err.message || "Error al obtener comentarios" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { postId, postSlug, authorName, authorEmail, authorUrl, content, parentId } = body;

    if (!content || !content.trim()) {
      return NextResponse.json(
        { success: false, error: "El contenido del comentario es obligatorio." },
        { status: 400 }
      );
    }

    if (!authorName || !authorName.trim()) {
      return NextResponse.json(
        { success: false, error: "El nombre es obligatorio." },
        { status: 400 }
      );
    }

    if (!authorEmail || !authorEmail.trim() || !authorEmail.includes("@")) {
      return NextResponse.json(
        { success: false, error: "Por favor ingresa un correo electrónico válido." },
        { status: 400 }
      );
    }

    let targetPostId = postId;
    if (!targetPostId && postSlug) {
      const post = await prisma.post.findUnique({
        where: { slug: postSlug },
        select: { id: true },
      });
      if (post) targetPostId = post.id;
    }

    if (!targetPostId) {
      return NextResponse.json(
        { success: false, error: "No se encontró la publicación vinculada." },
        { status: 400 }
      );
    }

    const ip = request.headers.get("x-forwarded-for") || request.headers.get("x-real-ip") || "127.0.0.1";
    const userAgent = request.headers.get("user-agent") || "";

    const newComment = await prisma.comment.create({
      data: {
        postId: targetPostId,
        authorName: authorName.trim(),
        authorEmail: authorEmail.trim().toLowerCase(),
        authorUrl: authorUrl ? authorUrl.trim() : null,
        content: content.trim(),
        parentId: parentId || null,
        status: "PENDIENTE", // Pendiente de moderación
        ipAddress: ip,
        userAgent: userAgent,
      },
      include: {
        post: {
          select: {
            id: true,
            title: true,
            slug: true,
          },
        },
      },
    });

    return NextResponse.json({
      success: true,
      comment: newComment,
      message: "¡Gracias por tu comentario! Ha sido enviado y está pendiente de moderación.",
    });
  } catch (err: any) {
    console.error("Error en POST /api/comments:", err);
    return NextResponse.json(
      { success: false, error: err.message || "Error al crear comentario." },
      { status: 500 }
    );
  }
}

export async function PATCH(request: Request) {
  try {
    const body = await request.json();
    const { id, status, content } = body;

    if (!id) {
      return NextResponse.json(
        { success: false, error: "Se requiere el ID del comentario." },
        { status: 400 }
      );
    }

    const updated = await prisma.comment.update({
      where: { id },
      data: {
        status: status !== undefined ? status : undefined,
        content: content !== undefined ? content : undefined,
      },
      include: {
        post: {
          select: {
            id: true,
            title: true,
            slug: true,
          },
        },
      },
    });

    return NextResponse.json({
      success: true,
      comment: updated,
      message: "Comentario actualizado correctamente.",
    });
  } catch (err: any) {
    console.error("Error en PATCH /api/comments:", err);
    return NextResponse.json(
      { success: false, error: err.message || "Error al actualizar comentario." },
      { status: 500 }
    );
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        { success: false, error: "Se requiere el ID del comentario." },
        { status: 400 }
      );
    }

    await prisma.comment.delete({
      where: { id },
    });

    return NextResponse.json({
      success: true,
      message: "Comentario eliminado correctamente.",
    });
  } catch (err: any) {
    console.error("Error en DELETE /api/comments:", err);
    return NextResponse.json(
      { success: false, error: err.message || "Error al eliminar comentario." },
      { status: 500 }
    );
  }
}
