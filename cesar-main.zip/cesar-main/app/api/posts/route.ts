import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");
    const slug = searchParams.get("slug");

    // Buscar un post específico por ID
    if (id) {
      const post = await prisma.post.findUnique({
        where: { id },
        include: {
          category: true,
          author: {
            select: { name: true, email: true, avatar: true },
          },
        },
      });

      if (!post) {
        return NextResponse.json({ error: "Post no encontrado." }, { status: 404 });
      }

      return NextResponse.json({ success: true, post });
    }

    // Buscar un post específico por Slug
    if (slug) {
      const post = await prisma.post.findUnique({
        where: { slug },
        include: {
          category: true,
          author: {
            select: { name: true, email: true, avatar: true },
          },
        },
      });

      if (!post) {
        return NextResponse.json({ error: "Post no encontrado." }, { status: 404 });
      }

      return NextResponse.json({ success: true, post });
    }

    // Listar todos los posts
    const posts = await prisma.post.findMany({
      include: {
        category: true,
        author: {
          select: { name: true, email: true },
        },
      },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({ posts });
  } catch (error) {
    console.error("Error en GET /api/posts:", error);
    return NextResponse.json({ error: "Error al obtener posts de la base de datos." }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      id,
      title,
      slug: customSlug,
      excerpt,
      content,
      featuredImage,
      seoTitle,
      seoDescription,
      focusKeyword,
      seoScore = 0,
      status = "Publicado",
      tags,
      categoryId,
    } = body;

    if (!title || !content) {
      return NextResponse.json(
        { error: "El título y el contenido del post son obligatorios." },
        { status: 400 }
      );
    }

    // Generar o limpiar slug amigable para SEO
    const cleanSlug = (customSlug || title)
      .toLowerCase()
      .trim()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "");

    const session = await getSession();
    let authorId = session?.id;

    if (!authorId) {
      const defaultAdmin = await prisma.user.findFirst({
        where: { role: "ADMIN" },
      });
      authorId = defaultAdmin?.id;
    }

    if (!authorId) {
      return NextResponse.json(
        { error: "No se encontró un usuario administrador para asociar el post." },
        { status: 401 }
      );
    }

    let post;
    if (id) {
      // Actualizar post existente por ID
      post = await prisma.post.update({
        where: { id },
        data: {
          title,
          slug: cleanSlug,
          excerpt,
          content,
          featuredImage,
          seoTitle: seoTitle || title,
          seoDescription: seoDescription || excerpt,
          focusKeyword,
          seoScore: Number(seoScore) || 0,
          status,
          tags: Array.isArray(tags) ? tags.join(",") : tags || "",
          categoryId: categoryId || null,
        },
        include: {
          category: true,
        },
      });
    } else {
      // Crear o actualizar por Slug
      post = await prisma.post.upsert({
        where: { slug: cleanSlug },
        update: {
          title,
          excerpt,
          content,
          featuredImage,
          seoTitle: seoTitle || title,
          seoDescription: seoDescription || excerpt,
          focusKeyword,
          seoScore: Number(seoScore) || 0,
          status,
          tags: Array.isArray(tags) ? tags.join(",") : tags || "",
          categoryId: categoryId || null,
        },
        create: {
          title,
          slug: cleanSlug,
          excerpt,
          content,
          featuredImage,
          seoTitle: seoTitle || title,
          seoDescription: seoDescription || excerpt,
          focusKeyword,
          seoScore: Number(seoScore) || 0,
          status,
          tags: Array.isArray(tags) ? tags.join(",") : tags || "",
          categoryId: categoryId || null,
          authorId,
        },
        include: {
          category: true,
        },
      });
    }

    const origin = request.nextUrl.origin;
    const publicSlugUrl = `${origin}/posts/${post.slug}`;

    return NextResponse.json({
      success: true,
      post,
      url: `/posts/${post.slug}`,
      fullUrl: publicSlugUrl,
      message:
        status === "Publicado"
          ? "¡Post guardado y publicado exitosamente en MySQL!"
          : "Borrador guardado correctamente.",
    });
  } catch (error) {
    console.error("Error en POST /api/posts:", error);
    return NextResponse.json({ error: "Error al guardar la publicación en base de datos." }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "ID de post no proporcionado." }, { status: 400 });
    }

    await prisma.post.delete({
      where: { id },
    });

    return NextResponse.json({ success: true, message: "Post eliminado correctamente." });
  } catch (error) {
    console.error("Error en DELETE /api/posts:", error);
    return NextResponse.json({ error: "Error al eliminar post de base de datos." }, { status: 500 });
  }
}
