import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");
    const slug = searchParams.get("slug");

    if (id) {
      const page = await prisma.page.findUnique({
        where: { id },
        include: {
          parent: { select: { id: true, title: true, slug: true } },
          children: { select: { id: true, title: true, slug: true } },
          author: { select: { name: true, email: true } },
        },
      });

      if (!page) {
        return NextResponse.json({ error: "Página no encontrada." }, { status: 404 });
      }

      return NextResponse.json({ success: true, page });
    }

    if (slug) {
      const page = await prisma.page.findUnique({
        where: { slug },
        include: {
          parent: { select: { id: true, title: true, slug: true } },
          children: { select: { id: true, title: true, slug: true } },
          author: { select: { name: true, email: true } },
        },
      });

      if (!page) {
        return NextResponse.json({ error: "Página no encontrada." }, { status: 404 });
      }

      return NextResponse.json({ success: true, page });
    }

    const pages = await prisma.page.findMany({
      include: {
        parent: {
          select: { id: true, title: true, slug: true },
        },
        children: {
          select: { id: true, title: true, slug: true },
        },
        author: {
          select: { name: true, email: true },
        },
      },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({ pages });
  } catch (error) {
    console.error("Error en GET /api/pages:", error);
    return NextResponse.json({ error: "Error al obtener páginas de la base de datos." }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      id,
      title,
      slug: customSlug,
      content,
      featuredImage,
      seoTitle,
      seoDescription,
      focusKeyword,
      seoScore = 0,
      status = "Publicado",
      template = "default",
      parentId = null,
    } = body;

    if (!title || !content) {
      return NextResponse.json(
        { error: "El título y el contenido de la página son obligatorios." },
        { status: 400 }
      );
    }

    // Generar o limpiar slug amigable para SEO
    const cleanSlug = (customSlug || title)
      .toLowerCase()
      .trim()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "");

    const session = await getSession();
    let authorId = session?.id;

    if (!authorId) {
      const defaultAdmin = await prisma.user.findFirst({
        where: { role: "ADMIN" },
      });
      authorId = defaultAdmin?.id;
    }

    if (!authorId) {
      return NextResponse.json(
        { error: "No se encontró un usuario administrador para asociar la página." },
        { status: 401 }
      );
    }

    let page;
    if (id) {
      page = await prisma.page.update({
        where: { id },
        data: {
          title,
          slug: cleanSlug,
          content,
          featuredImage,
          seoTitle: seoTitle || title,
          seoDescription: seoDescription || "",
          focusKeyword,
          seoScore: Number(seoScore) || 0,
          status,
          template,
          parentId: parentId || null,
        },
        include: { parent: true },
      });
    } else {
      page = await prisma.page.upsert({
        where: { slug: cleanSlug },
        update: {
          title,
          content,
          featuredImage,
          seoTitle: seoTitle || title,
          seoDescription: seoDescription || "",
          focusKeyword,
          seoScore: Number(seoScore) || 0,
          status,
          template,
          parentId: parentId || null,
        },
        create: {
          title,
          slug: cleanSlug,
          content,
          featuredImage,
          seoTitle: seoTitle || title,
          seoDescription: seoDescription || "",
          focusKeyword,
          seoScore: Number(seoScore) || 0,
          status,
          template,
          parentId: parentId || null,
          authorId,
        },
        include: {
          parent: true,
        },
      });
    }

    const origin = request.nextUrl.origin;
    const publicSlugUrl = `${origin}/paginas/${page.slug}`;

    return NextResponse.json({
      success: true,
      page,
      url: `/paginas/${page.slug}`,
      fullUrl: publicSlugUrl,
      message:
        status === "Publicado"
          ? "¡Página guardada exitosamente en MySQL!"
          : "Borrador de página guardado correctamente.",
    });
  } catch (error) {
    console.error("Error en POST /api/pages:", error);
    return NextResponse.json({ error: "Error al guardar la página en la base de datos." }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "ID de página no proporcionado." }, { status: 400 });
    }

    // Desvincular subpáginas antes de eliminar
    await prisma.page.updateMany({
      where: { parentId: id },
      data: { parentId: null },
    });

    await prisma.page.delete({
      where: { id },
    });

    return NextResponse.json({ success: true, message: "Página eliminada correctamente." });
  } catch (error) {
    console.error("Error en DELETE /api/pages:", error);
    return NextResponse.json({ error: "Error al eliminar página de base de datos." }, { status: 500 });
  }
}
