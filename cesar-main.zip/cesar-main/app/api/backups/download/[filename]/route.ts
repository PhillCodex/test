import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";

const BACKUPS_DIR = path.join(process.cwd(), "backups");

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ filename: string }> }
) {
  try {
    const { filename } = await params;
    if (!filename) {
      return NextResponse.json(
        { error: "Nombre de archivo no proporcionado" },
        { status: 400 }
      );
    }

    const safeFilename = path.basename(filename);
    const filePath = path.join(BACKUPS_DIR, safeFilename);

    if (!fs.existsSync(filePath)) {
      return NextResponse.json(
        { error: "Archivo de copia de seguridad no encontrado" },
        { status: 404 }
      );
    }

    const fileBuffer = fs.readFileSync(filePath);
    const stats = fs.statSync(filePath);

    let contentType = "application/json";
    if (safeFilename.endsWith(".sql")) contentType = "application/sql";
    if (safeFilename.endsWith(".zip")) contentType = "application/zip";

    return new NextResponse(fileBuffer, {
      status: 200,
      headers: {
        "Content-Type": contentType,
        "Content-Disposition": `attachment; filename="${safeFilename}"`,
        "Content-Length": stats.size.toString(),
      },
    });
  } catch (error: any) {
    console.error("Error al descargar backup:", error);
    return NextResponse.json(
      { error: "Error al procesar la descarga del backup" },
      { status: 500 }
    );
  }
}
