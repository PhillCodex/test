import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import fs from "fs";
import path from "path";

// Directorio de almacenamiento de backups
const BACKUPS_DIR = path.join(process.cwd(), "backups");
const CONFIG_FILE = path.join(BACKUPS_DIR, "backup-config.json");
const UPLOADS_DIR = path.join(process.cwd(), "public", "uploads");

// Asegurar que el directorio de backups existe
function ensureBackupsDir() {
  if (!fs.existsSync(BACKUPS_DIR)) {
    fs.mkdirSync(BACKUPS_DIR, { recursive: true });
  }
}

// Configuración predeterminada de backups automáticos
interface BackupConfig {
  autoBackupEnabled: boolean;
  frequency: "hourly" | "daily" | "weekly" | "monthly";
  executionTime: string;
  executionDay: string;
  executionDayOfMonth: number;
  includeDatabase: boolean;
  includeMedia: boolean;
  includeConfig: boolean;
  retentionLimit: number;
  storageLocation: "local" | "gdrive" | "s3" | "email";
  notificationEmail: string;
  notifyOnSuccess: boolean;
  notifyOnError: boolean;
  lastRun?: string;
  nextRun?: string;
}

const DEFAULT_CONFIG: BackupConfig = {
  autoBackupEnabled: true,
  frequency: "daily",
  executionTime: "03:00",
  executionDay: "sunday",
  executionDayOfMonth: 1,
  includeDatabase: true,
  includeMedia: true,
  includeConfig: true,
  retentionLimit: 10,
  storageLocation: "local",
  notificationEmail: "admin@techlab.com",
  notifyOnSuccess: true,
  notifyOnError: true,
};

function getBackupConfig(): BackupConfig {
  ensureBackupsDir();
  if (fs.existsSync(CONFIG_FILE)) {
    try {
      const data = fs.readFileSync(CONFIG_FILE, "utf-8");
      return { ...DEFAULT_CONFIG, ...JSON.parse(data) };
    } catch {
      return DEFAULT_CONFIG;
    }
  }
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(DEFAULT_CONFIG, null, 2), "utf-8");
  return DEFAULT_CONFIG;
}

function saveBackupConfig(config: Partial<BackupConfig>): BackupConfig {
  ensureBackupsDir();
  const current = getBackupConfig();
  const updated = { ...current, ...config };
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(updated, null, 2), "utf-8");
  return updated;
}

function formatBytes(bytes: number): string {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
}

// =========================================================================
// GET: Listar copias de seguridad, configuración y métricas
// =========================================================================
export async function GET() {
  try {
    ensureBackupsDir();
    const config = getBackupConfig();

    const files = fs.readdirSync(BACKUPS_DIR);
    const backupFiles = files.filter(
      (f) =>
        f.endsWith(".json") && f !== "backup-config.json" ||
        f.endsWith(".sql") ||
        f.endsWith(".zip")
    );

    let totalSizeBytes = 0;
    const backupsList = backupFiles.map((filename) => {
      const filePath = path.join(BACKUPS_DIR, filename);
      const stats = fs.statSync(filePath);
      totalSizeBytes += stats.size;

      let type: "full" | "database" | "media" = "database";
      let tablesCount = 0;
      let note = "";
      let creator = "Manual (Admin)";

      if (filename.includes("_full_") || filename.endsWith("_full.json")) {
        type = "full";
      } else if (filename.includes("_media_") || filename.endsWith("_media.json")) {
        type = "media";
      } else if (filename.includes("_db_") || filename.endsWith("_db.json") || filename.endsWith(".sql")) {
        type = "database";
      }

      if (filename.includes("auto_")) {
        creator = "Automático (Cron)";
      }

      // Intentar leer metadatos de archivos JSON
      if (filename.endsWith(".json")) {
        try {
          const content = JSON.parse(fs.readFileSync(filePath, "utf-8"));
          if (content.meta) {
            type = content.meta.type || type;
            tablesCount = content.meta.tablesCount || 0;
            note = content.meta.note || "";
            creator = content.meta.creator || creator;
          }
        } catch {
          // Si no es un JSON estructurado, usar valores inferidos
        }
      }

      return {
        id: filename,
        filename,
        type,
        size: stats.size,
        formattedSize: formatBytes(stats.size),
        createdAt: stats.mtime.toISOString(),
        tablesCount,
        note,
        creator,
        status: "completed",
      };
    });

    // Ordenar de más reciente a más antiguo
    backupsList.sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );

    // Contar tablas e items en la BD
    let dbStatus = "connected";
    let dbEntitiesTotal = 0;
    try {
      const [postsCount, pagesCount, usersCount, commentsCount] = await Promise.all([
        prisma.post.count(),
        prisma.page.count(),
        prisma.user.count(),
        prisma.comment.count(),
      ]);
      dbEntitiesTotal = postsCount + pagesCount + usersCount + commentsCount;
    } catch {
      dbStatus = "error";
    }

    // Comprobar carpeta de uploads
    let uploadsCount = 0;
    let uploadsSizeBytes = 0;
    if (fs.existsSync(UPLOADS_DIR)) {
      try {
        const uploadFiles = fs.readdirSync(UPLOADS_DIR);
        uploadsCount = uploadFiles.length;
        uploadFiles.forEach((file) => {
          try {
            const st = fs.statSync(path.join(UPLOADS_DIR, file));
            uploadsSizeBytes += st.size;
          } catch {}
        });
      } catch {}
    }

    return NextResponse.json({
      success: true,
      backups: backupsList,
      config,
      stats: {
        totalBackups: backupsList.length,
        totalSizeBytes,
        formattedTotalSize: formatBytes(totalSizeBytes),
        lastBackupDate: backupsList.length > 0 ? backupsList[0].createdAt : null,
        dbStatus,
        dbEntitiesTotal,
        uploadsCount,
        formattedUploadsSize: formatBytes(uploadsSizeBytes),
      },
    });
  } catch (error: any) {
    console.error("Error al obtener backups:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al leer backups" },
      { status: 500 }
    );
  }
}

// =========================================================================
// POST: Crear backup, Restaurar, Guardar configuración o Subir archivo
// =========================================================================
export async function POST(req: NextRequest) {
  try {
    ensureBackupsDir();
    const body = await req.json().catch(() => ({}));
    const { action = "create" } = body;

    // -----------------------------------------------------------------------
    // ACCIÓN 1: GUARDAR CONFIGURACIÓN AUTOMÁTICA
    // -----------------------------------------------------------------------
    if (action === "save_config") {
      const updatedConfig = saveBackupConfig(body.config || {});
      return NextResponse.json({
        success: true,
        config: updatedConfig,
        message: "Configuración de copias de seguridad guardada correctamente.",
      });
    }

    // -----------------------------------------------------------------------
    // ACCIÓN 2: CREAR COPIA DE SEGURIDAD MANUAL (O AUTOMÁTICA)
    // -----------------------------------------------------------------------
    if (action === "create") {
      const backupType: "full" | "database" | "media" = body.type || "full";
      const note: string = body.note || "";
      const isAuto: boolean = !!body.isAuto;
      const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
      const prefix = isAuto ? "auto" : "manual";
      const filename = `backup_${prefix}_${timestamp}_${backupType}.json`;
      const filePath = path.join(BACKUPS_DIR, filename);

      let databaseData: Record<string, any> = {};
      let mediaFiles: Array<{ name: string; size: number; base64?: string }> = [];
      let tablesCount = 0;

      // 1. Extraer datos de MySQL si aplica
      if (backupType === "full" || backupType === "database") {
        const [
          users,
          categories,
          tags,
          posts,
          pages,
          menus,
          menuItems,
          testimonials,
          projects,
          projectCategories,
          services,
          serviceCategories,
          serviceTags,
          siteSettings,
          comments,
        ] = await Promise.all([
          prisma.user.findMany(),
          prisma.category.findMany(),
          prisma.tag.findMany(),
          prisma.post.findMany(),
          prisma.page.findMany(),
          prisma.menu.findMany({ include: { items: true } }),
          prisma.menuItem.findMany(),
          prisma.testimonial.findMany(),
          prisma.project.findMany(),
          prisma.projectCategory.findMany(),
          prisma.service.findMany(),
          prisma.serviceCategory.findMany(),
          prisma.serviceTag.findMany(),
          prisma.siteSetting.findMany(),
          prisma.comment.findMany(),
        ]);

        databaseData = {
          users,
          categories,
          tags,
          posts,
          pages,
          menus,
          menuItems,
          testimonials,
          projects,
          projectCategories,
          services,
          serviceCategories,
          serviceTags,
          siteSettings,
          comments,
        };

        tablesCount = Object.keys(databaseData).length;
      }

      // 2. Extraer archivos de uploads si aplica
      if ((backupType === "full" || backupType === "media") && fs.existsSync(UPLOADS_DIR)) {
        try {
          const files = fs.readdirSync(UPLOADS_DIR);
          for (const file of files) {
            const p = path.join(UPLOADS_DIR, file);
            try {
              const st = fs.statSync(p);
              if (st.isFile()) {
                // Para archivos menores de 5MB incluimos base64 para restauración íntegra
                let base64 = undefined;
                if (st.size <= 5 * 1024 * 1024) {
                  base64 = fs.readFileSync(p).toString("base64");
                }
                mediaFiles.push({
                  name: file,
                  size: st.size,
                  base64,
                });
              }
            } catch {}
          }
        } catch (e) {
          console.error("Error al leer archivos de uploads:", e);
        }
      }

      // Estructura del paquete de backup
      const backupPackage = {
        meta: {
          version: "1.5.0",
          schemaVersion: "2.0",
          type: backupType,
          createdAt: new Date().toISOString(),
          creator: isAuto ? "Automático (Cron)" : "Manual (Admin)",
          note,
          tablesCount,
          mediaFilesCount: mediaFiles.length,
          generator: "TechLab CMS - Codeyfix",
        },
        database: databaseData,
        media: mediaFiles,
      };

      fs.writeFileSync(filePath, JSON.stringify(backupPackage, null, 2), "utf-8");

      const stats = fs.statSync(filePath);

      // Aplicar límite de retención
      const config = getBackupConfig();
      if (config.retentionLimit && config.retentionLimit > 0) {
        const allFiles = fs.readdirSync(BACKUPS_DIR).filter((f) => f.startsWith("backup_") && f.endsWith(".json"));
        if (allFiles.length > config.retentionLimit) {
          allFiles.sort((a, b) => {
            const sa = fs.statSync(path.join(BACKUPS_DIR, a));
            const sb = fs.statSync(path.join(BACKUPS_DIR, b));
            return sa.mtime.getTime() - sb.mtime.getTime();
          });
          const toDelete = allFiles.slice(0, allFiles.length - config.retentionLimit);
          for (const fileToDelete of toDelete) {
            try {
              fs.unlinkSync(path.join(BACKUPS_DIR, fileToDelete));
            } catch {}
          }
        }
      }

      return NextResponse.json({
        success: true,
        message: "¡Copia de seguridad creada exitosamente!",
        backup: {
          id: filename,
          filename,
          type: backupType,
          size: stats.size,
          formattedSize: formatBytes(stats.size),
          createdAt: stats.mtime.toISOString(),
          tablesCount,
          note,
          creator: isAuto ? "Automático (Cron)" : "Manual (Admin)",
        },
      });
    }

    // -----------------------------------------------------------------------
    // ACCIÓN 3: RESTAURAR COPIA DE SEGURIDAD
    // -----------------------------------------------------------------------
    if (action === "restore") {
      const { filename } = body;
      if (!filename) {
        return NextResponse.json({ success: false, error: "Nombre de archivo requerido." }, { status: 400 });
      }

      const filePath = path.join(BACKUPS_DIR, filename);
      if (!fs.existsSync(filePath)) {
        return NextResponse.json({ success: false, error: "El archivo de copia de seguridad no existe." }, { status: 404 });
      }

      const fileContent = fs.readFileSync(filePath, "utf-8");
      let backupData: any = {};

      try {
        backupData = JSON.parse(fileContent);
      } catch {
        return NextResponse.json({ success: false, error: "Formato de archivo inválido. Solo se admiten archivos de backup válidos." }, { status: 400 });
      }

      let restoredTables = 0;
      let restoredFiles = 0;

      // 1. Restaurar Base de Datos MySQL
      if (backupData.database && typeof backupData.database === "object") {
        const db = backupData.database;

        // Categorías
        if (Array.isArray(db.categories)) {
          for (const cat of db.categories) {
            await prisma.category.upsert({
              where: { id: cat.id },
              update: { name: cat.name, slug: cat.slug, color: cat.color, parentId: cat.parentId },
              create: { id: cat.id, name: cat.name, slug: cat.slug, color: cat.color, parentId: cat.parentId },
            }).catch(() => {});
          }
          restoredTables++;
        }

        // Tags
        if (Array.isArray(db.tags)) {
          for (const tag of db.tags) {
            await prisma.tag.upsert({
              where: { id: tag.id },
              update: { name: tag.name, slug: tag.slug, description: tag.description, color: tag.color },
              create: { id: tag.id, name: tag.name, slug: tag.slug, description: tag.description, color: tag.color },
            }).catch(() => {});
          }
          restoredTables++;
        }

        // Posts
        if (Array.isArray(db.posts)) {
          for (const p of db.posts) {
            await prisma.post.upsert({
              where: { id: p.id },
              update: {
                title: p.title,
                slug: p.slug,
                excerpt: p.excerpt,
                content: p.content,
                featuredImage: p.featuredImage,
                seoTitle: p.seoTitle,
                seoDescription: p.seoDescription,
                focusKeyword: p.focusKeyword,
                seoScore: p.seoScore,
                status: p.status,
                views: p.views || 0,
                tags: p.tags,
                authorId: p.authorId,
                categoryId: p.categoryId,
              },
              create: {
                id: p.id,
                title: p.title,
                slug: p.slug,
                excerpt: p.excerpt,
                content: p.content,
                featuredImage: p.featuredImage,
                seoTitle: p.seoTitle,
                seoDescription: p.seoDescription,
                focusKeyword: p.focusKeyword,
                seoScore: p.seoScore,
                status: p.status,
                views: p.views || 0,
                tags: p.tags,
                authorId: p.authorId,
                categoryId: p.categoryId,
              },
            }).catch(() => {});
          }
          restoredTables++;
        }

        // Páginas
        if (Array.isArray(db.pages)) {
          for (const pg of db.pages) {
            await prisma.page.upsert({
              where: { id: pg.id },
              update: {
                title: pg.title,
                slug: pg.slug,
                content: pg.content,
                featuredImage: pg.featuredImage,
                seoTitle: pg.seoTitle,
                seoDescription: pg.seoDescription,
                focusKeyword: pg.focusKeyword,
                seoScore: pg.seoScore,
                status: pg.status,
                template: pg.template || "default",
                parentId: pg.parentId,
                authorId: pg.authorId,
                views: pg.views || 0,
              },
              create: {
                id: pg.id,
                title: pg.title,
                slug: pg.slug,
                content: pg.content,
                featuredImage: pg.featuredImage,
                seoTitle: pg.seoTitle,
                seoDescription: pg.seoDescription,
                focusKeyword: pg.focusKeyword,
                seoScore: pg.seoScore,
                status: pg.status,
                template: pg.template || "default",
                parentId: pg.parentId,
                authorId: pg.authorId,
                views: pg.views || 0,
              },
            }).catch(() => {});
          }
          restoredTables++;
        }

        // SiteSettings
        if (Array.isArray(db.siteSettings)) {
          for (const st of db.siteSettings) {
            await prisma.siteSetting.upsert({
              where: { id: st.id || "general" },
              update: { ...st, id: st.id || "general" },
              create: { ...st, id: st.id || "general" },
            }).catch(() => {});
          }
          restoredTables++;
        }

        // Testimonios
        if (Array.isArray(db.testimonials)) {
          for (const tm of db.testimonials) {
            await prisma.testimonial.upsert({
              where: { id: tm.id },
              update: {
                name: tm.name,
                role: tm.role,
                company: tm.company,
                avatar: tm.avatar,
                content: tm.content,
                rating: tm.rating,
                status: tm.status,
              },
              create: {
                id: tm.id,
                name: tm.name,
                role: tm.role,
                company: tm.company,
                avatar: tm.avatar,
                content: tm.content,
                rating: tm.rating,
                status: tm.status,
              },
            }).catch(() => {});
          }
          restoredTables++;
        }

        // Proyectos
        if (Array.isArray(db.projects)) {
          for (const pr of db.projects) {
            await prisma.project.upsert({
              where: { id: pr.id },
              update: {
                title: pr.title,
                slug: pr.slug,
                excerpt: pr.excerpt,
                content: pr.content,
                featuredImage: pr.featuredImage,
                gallery: pr.gallery,
                investment: pr.investment,
                liveUrl: pr.liveUrl,
                clientName: pr.clientName,
                technologies: pr.technologies,
                status: pr.status,
                views: pr.views || 0,
              },
              create: {
                id: pr.id,
                title: pr.title,
                slug: pr.slug,
                excerpt: pr.excerpt,
                content: pr.content,
                featuredImage: pr.featuredImage,
                gallery: pr.gallery,
                investment: pr.investment,
                liveUrl: pr.liveUrl,
                clientName: pr.clientName,
                technologies: pr.technologies,
                status: pr.status,
                views: pr.views || 0,
              },
            }).catch(() => {});
          }
          restoredTables++;
        }

        // Servicios
        if (Array.isArray(db.services)) {
          for (const s of db.services) {
            await prisma.service.upsert({
              where: { id: s.id },
              update: {
                title: s.title,
                slug: s.slug,
                excerpt: s.excerpt,
                content: s.content,
                featuredImage: s.featuredImage,
                icon: s.icon,
                price: s.price,
                priceLabel: s.priceLabel,
                features: s.features,
                status: s.status,
              },
              create: {
                id: s.id,
                title: s.title,
                slug: s.slug,
                excerpt: s.excerpt,
                content: s.content,
                featuredImage: s.featuredImage,
                icon: s.icon,
                price: s.price,
                priceLabel: s.priceLabel,
                features: s.features,
                status: s.status,
              },
            }).catch(() => {});
          }
          restoredTables++;
        }
      }

      // 2. Restaurar Archivos Multimedia
      if (Array.isArray(backupData.media)) {
        if (!fs.existsSync(UPLOADS_DIR)) {
          fs.mkdirSync(UPLOADS_DIR, { recursive: true });
        }
        for (const item of backupData.media) {
          if (item.name && item.base64) {
            try {
              const buffer = Buffer.from(item.base64, "base64");
              fs.writeFileSync(path.join(UPLOADS_DIR, item.name), buffer);
              restoredFiles++;
            } catch {}
          }
        }
      }

      return NextResponse.json({
        success: true,
        message: `¡Restauración completada con éxito! Se restauraron las tablas de la base de datos y ${restoredFiles} archivos multimedia.`,
        restoredTables,
        restoredFiles,
      });
    }

    // -----------------------------------------------------------------------
    // ACCIÓN 4: SUBIR ARCHIVO DE COPIA DE SEGURIDAD
    // -----------------------------------------------------------------------
    if (action === "upload") {
      const { filename, contentBase64 } = body;
      if (!filename || !contentBase64) {
        return NextResponse.json({ success: false, error: "Archivo y contenido requeridos." }, { status: 400 });
      }

      const safeFilename = `uploaded_${Date.now()}_${filename.replace(/[^a-zA-Z0-9_.-]/g, "_")}`;
      const filePath = path.join(BACKUPS_DIR, safeFilename);

      const buffer = Buffer.from(contentBase64, "base64");
      fs.writeFileSync(filePath, buffer);

      const stats = fs.statSync(filePath);

      return NextResponse.json({
        success: true,
        message: "¡Copia de seguridad externa subida con éxito al servidor!",
        backup: {
          id: safeFilename,
          filename: safeFilename,
          type: "full",
          size: stats.size,
          formattedSize: formatBytes(stats.size),
          createdAt: stats.mtime.toISOString(),
          tablesCount: 0,
          creator: "Subido por Admin",
        },
      });
    }

    return NextResponse.json({ success: false, error: "Acción no reconocida." }, { status: 400 });
  } catch (error: any) {
    console.error("Error en POST /api/backups:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al procesar solicitud de backup" },
      { status: 500 }
    );
  }
}

// =========================================================================
// DELETE: Eliminar un archivo de copia de seguridad
// =========================================================================
export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const filename = searchParams.get("filename");

    if (!filename) {
      return NextResponse.json({ success: false, error: "Nombre de archivo requerido." }, { status: 400 });
    }

    const safeFilename = path.basename(filename);
    const filePath = path.join(BACKUPS_DIR, safeFilename);

    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      return NextResponse.json({
        success: true,
        message: `Copia de seguridad "${safeFilename}" eliminada exitosamente.`,
      });
    } else {
      return NextResponse.json({ success: false, error: "El archivo no existe." }, { status: 404 });
    }
  } catch (error: any) {
    console.error("Error al eliminar backup:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al eliminar archivo de backup" },
      { status: 500 }
    );
  }
}
