import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const categories = await prisma.category.findMany({
      include: {
        parent: {
          select: { id: true, name: true, slug: true },
        },
        children: {
          select: { id: true, name: true, slug: true },
        },
        _count: {
          select: { posts: true },
        },
      },
      orderBy: [{ parentId: "asc" }, { name: "asc" }],
    });

    return NextResponse.json({ categories });
  } catch (error) {
    console.error("Error en GET /api/categories:", error);
    return NextResponse.json({ error: "Error al obtener categorías de la base de datos." }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const { name, slug: customSlug, color = "green", parentId = null } = await request.json();

    if (!name || typeof name !== "string") {
      return NextResponse.json({ error: "El nombre de la categoría es obligatorio." }, { status: 400 });
    }

    const slug = (customSlug || name)
      .toLowerCase()
      .trim()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "");

    const category = await prisma.category.upsert({
      where: { slug },
      update: {
        name: name.trim(),
        color,
        parentId: parentId || null,
      },
      create: {
        name: name.trim(),
        slug,
        color,
        parentId: parentId || null,
      },
      include: {
        parent: true,
        _count: { select: { posts: true } },
      },
    });

    return NextResponse.json({ success: true, category });
  } catch (error) {
    console.error("Error en POST /api/categories:", error);
    return NextResponse.json({ error: "Error al guardar la categoría en base de datos." }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const { id, name, slug: customSlug, color = "green", parentId = null } = await request.json();

    if (!id) {
      return NextResponse.json({ error: "El ID de la categoría es obligatorio." }, { status: 400 });
    }

    const slug = (customSlug || name)
      .toLowerCase()
      .trim()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "");

    const category = await prisma.category.update({
      where: { id },
      data: {
        name: name.trim(),
        slug,
        color,
        parentId: parentId || null,
      },
      include: {
        parent: true,
        _count: { select: { posts: true } },
      },
    });

    return NextResponse.json({ success: true, category });
  } catch (error) {
    console.error("Error en PUT /api/categories:", error);
    return NextResponse.json({ error: "Error al actualizar la categoría." }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "El ID de la categoría es requerido." }, { status: 400 });
    }

    // Desvincular posts y categorías hijas antes de eliminar
    await prisma.category.updateMany({
      where: { parentId: id },
      data: { parentId: null },
    });

    await prisma.post.updateMany({
      where: { categoryId: id },
      data: { categoryId: null },
    });

    await prisma.category.delete({
      where: { id },
    });

    return NextResponse.json({ success: true, message: "Categoría eliminada correctamente." });
  } catch (error) {
    console.error("Error en DELETE /api/categories:", error);
    return NextResponse.json({ error: "Error al eliminar categoría de la base de datos." }, { status: 500 });
  }
}
