import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    let settings = await prisma.siteSetting.findUnique({
      where: { id: "general" },
    });

    if (!settings) {
      settings = await prisma.siteSetting.create({
        data: {
          id: "general",
          siteTitle: "TechLab",
          siteDescription: "Laboratorio de innovación tecnológica, desarrollo de software a medida, aplicaciones web y servicios en la nube de alta disponibilidad.",
          faviconUrl: "/favicon.ico",
          adminUrl: "/dashboard",
          publicUrl: "http://localhost:3000",
          logoUrl: null,
          logoDarkUrl: null,
          slogan: "Tecnología que impulsa tu mundo.",
          primaryColor: "#16c96f",
          secondaryColor: "#38bdf8",
          accentColor: "#12b85f",
          themeMode: "dark",
          borderRadius: "rounded",
          customCss: null,

          // Defaults WhatsApp
          whatsappNumber: "+51 900 123 456",
          whatsappEnabled: true,
          whatsappMessage: "Hola! Deseo cotizar un proyecto tecnológico con TechLab.",

          // Defaults SEO
          seoTitleSeparator: "-",
          seoHomeTitle: "%sitename% - Innovación y Desarrollo Web",
          seoHomeDescription: "Laboratorio de innovación tecnológica, desarrollo de software a medida, aplicaciones web y servicios en la nube de alta disponibilidad.",
          seoOgDefaultImage: null,
          seoOgTitle: null,
          seoOgDescription: null,
          seoTwitterCard: "summary_large_image",
          seoTwitterHandle: "@techlab",
          seoFacebookAppId: null,
          seoGoogleVerify: null,
          seoBingVerify: null,
          seoRobotsTxt: "User-agent: *\nAllow: /\nDisallow: /dashboard/\nDisallow: /api/\n\nSitemap: http://localhost:3000/sitemap.xml",
          seoSitemapEnabled: true,
          seoAnalyticsId: null,
          seoGtmId: null,
          seoCustomHead: null,
          seoCustomBody: null,

          // Defaults Footer
          footerDescription: "Laboratorio de innovación tecnológica, desarrollo de software y servicios en la nube.",
          footerCopyright: "© 2026 TechLab. Todos los derechos reservados.",
          footerBottomText: "Términos y condiciones　|　Política de privacidad",
          footerEmail: "contacto@techlab.com",
          footerPhone: "+51 900 123 456",
          footerAddress: "Lima, Perú",
          footerSchedule: "Lun - Vie: 9:00 AM - 6:00 PM",
          footerFacebook: "https://facebook.com",
          footerTwitter: "https://twitter.com",
          footerInstagram: "https://instagram.com",
          footerLinkedin: "https://linkedin.com",
          footerYoutube: "https://youtube.com",
          footerGithub: "https://github.com",
          footerShowSocial: true,
          footerShowContact: true,
          footerNavTitle: "NAVEGACIÓN",
          footerServicesTitle: "SERVICIOS",
          footerResourcesTitle: "RECURSOS",

          // Defaults Ajustes de Lectura
          showOnFront: "posts",
          pageOnFront: null,
          pageForPosts: null,
          postsPerPage: 10,
        },
      });
    }

    return NextResponse.json({ success: true, settings });
  } catch (error) {
    console.error("Error al obtener ajustes del sitio:", error);
    return NextResponse.json(
      { success: false, error: "Error al obtener la configuración del sitio." },
      { status: 500 }
    );
  }
}

export async function PUT(req: Request) {
  try {
    const body = await req.json();
    const {
      siteTitle,
      siteDescription,
      faviconUrl,
      adminUrl,
      publicUrl,
      logoUrl,
      logoDarkUrl,
      slogan,
      primaryColor,
      secondaryColor,
      accentColor,
      themeMode,
      borderRadius,
      customCss,

      // WhatsApp
      whatsappNumber,
      whatsappEnabled,
      whatsappMessage,

      // Campos SEO
      seoTitleSeparator,
      seoHomeTitle,
      seoHomeDescription,
      seoOgDefaultImage,
      seoOgTitle,
      seoOgDescription,
      seoTwitterCard,
      seoTwitterHandle,
      seoFacebookAppId,
      seoGoogleVerify,
      seoBingVerify,
      seoRobotsTxt,
      seoSitemapEnabled,
      seoAnalyticsId,
      seoGtmId,
      seoCustomHead,
      seoCustomBody,

      // Footer
      footerDescription,
      footerCopyright,
      footerBottomText,
      footerEmail,
      footerPhone,
      footerAddress,
      footerSchedule,
      footerFacebook,
      footerTwitter,
      footerInstagram,
      footerLinkedin,
      footerYoutube,
      footerGithub,
      footerShowSocial,
      footerShowContact,
      footerNavTitle,
      footerServicesTitle,
      footerResourcesTitle,

      // Ajustes de Lectura
      showOnFront,
      pageOnFront,
      pageForPosts,
      postsPerPage,
    } = body;

    const updated = await prisma.siteSetting.upsert({
      where: { id: "general" },
      update: {
        siteTitle: siteTitle !== undefined ? siteTitle : undefined,
        siteDescription: siteDescription !== undefined ? siteDescription : undefined,
        faviconUrl: faviconUrl !== undefined ? faviconUrl : undefined,
        adminUrl: adminUrl !== undefined ? adminUrl : undefined,
        publicUrl: publicUrl !== undefined ? publicUrl : undefined,
        logoUrl: logoUrl !== undefined ? logoUrl : undefined,
        logoDarkUrl: logoDarkUrl !== undefined ? logoDarkUrl : undefined,
        slogan: slogan !== undefined ? slogan : undefined,
        primaryColor: primaryColor !== undefined ? primaryColor : undefined,
        secondaryColor: secondaryColor !== undefined ? secondaryColor : undefined,
        accentColor: accentColor !== undefined ? accentColor : undefined,
        themeMode: themeMode !== undefined ? themeMode : undefined,
        borderRadius: borderRadius !== undefined ? borderRadius : undefined,
        customCss: customCss !== undefined ? customCss : undefined,

        // WhatsApp
        whatsappNumber: whatsappNumber !== undefined ? whatsappNumber : undefined,
        whatsappEnabled: whatsappEnabled !== undefined ? whatsappEnabled : undefined,
        whatsappMessage: whatsappMessage !== undefined ? whatsappMessage : undefined,

        // SEO Updates
        seoTitleSeparator: seoTitleSeparator !== undefined ? seoTitleSeparator : undefined,
        seoHomeTitle: seoHomeTitle !== undefined ? seoHomeTitle : undefined,
        seoHomeDescription: seoHomeDescription !== undefined ? seoHomeDescription : undefined,
        seoOgDefaultImage: seoOgDefaultImage !== undefined ? seoOgDefaultImage : undefined,
        seoOgTitle: seoOgTitle !== undefined ? seoOgTitle : undefined,
        seoOgDescription: seoOgDescription !== undefined ? seoOgDescription : undefined,
        seoTwitterCard: seoTwitterCard !== undefined ? seoTwitterCard : undefined,
        seoTwitterHandle: seoTwitterHandle !== undefined ? seoTwitterHandle : undefined,
        seoFacebookAppId: seoFacebookAppId !== undefined ? seoFacebookAppId : undefined,
        seoGoogleVerify: seoGoogleVerify !== undefined ? seoGoogleVerify : undefined,
        seoBingVerify: seoBingVerify !== undefined ? seoBingVerify : undefined,
        seoRobotsTxt: seoRobotsTxt !== undefined ? seoRobotsTxt : undefined,
        seoSitemapEnabled: seoSitemapEnabled !== undefined ? seoSitemapEnabled : undefined,
        seoAnalyticsId: seoAnalyticsId !== undefined ? seoAnalyticsId : undefined,
        seoGtmId: seoGtmId !== undefined ? seoGtmId : undefined,
        seoCustomHead: seoCustomHead !== undefined ? seoCustomHead : undefined,
        seoCustomBody: seoCustomBody !== undefined ? seoCustomBody : undefined,

        // Footer Updates
        footerDescription: footerDescription !== undefined ? footerDescription : undefined,
        footerCopyright: footerCopyright !== undefined ? footerCopyright : undefined,
        footerBottomText: footerBottomText !== undefined ? footerBottomText : undefined,
        footerEmail: footerEmail !== undefined ? footerEmail : undefined,
        footerPhone: footerPhone !== undefined ? footerPhone : undefined,
        footerAddress: footerAddress !== undefined ? footerAddress : undefined,
        footerSchedule: footerSchedule !== undefined ? footerSchedule : undefined,
        footerFacebook: footerFacebook !== undefined ? footerFacebook : undefined,
        footerTwitter: footerTwitter !== undefined ? footerTwitter : undefined,
        footerInstagram: footerInstagram !== undefined ? footerInstagram : undefined,
        footerLinkedin: footerLinkedin !== undefined ? footerLinkedin : undefined,
        footerYoutube: footerYoutube !== undefined ? footerYoutube : undefined,
        footerGithub: footerGithub !== undefined ? footerGithub : undefined,
        footerShowSocial: footerShowSocial !== undefined ? footerShowSocial : undefined,
        footerShowContact: footerShowContact !== undefined ? footerShowContact : undefined,
        footerNavTitle: footerNavTitle !== undefined ? footerNavTitle : undefined,
        footerServicesTitle: footerServicesTitle !== undefined ? footerServicesTitle : undefined,
        footerResourcesTitle: footerResourcesTitle !== undefined ? footerResourcesTitle : undefined,

        // Ajustes de Lectura
        showOnFront: showOnFront !== undefined ? showOnFront : undefined,
        pageOnFront: pageOnFront !== undefined ? pageOnFront : undefined,
        pageForPosts: pageForPosts !== undefined ? pageForPosts : undefined,
        postsPerPage: postsPerPage !== undefined ? Number(postsPerPage) : undefined,
      },
      create: {
        id: "general",
        siteTitle: siteTitle || "TechLab",
        siteDescription: siteDescription || "Laboratorio de innovación tecnológica, desarrollo de software a medida, aplicaciones web y servicios en la nube de alta disponibilidad.",
        faviconUrl: faviconUrl || "/favicon.ico",
        adminUrl: adminUrl || "/dashboard",
        publicUrl: publicUrl || "http://localhost:3000",
        logoUrl: logoUrl || null,
        logoDarkUrl: logoDarkUrl || null,
        slogan: slogan || "Tecnología que impulsa tu mundo.",
        primaryColor: primaryColor || "#16c96f",
        secondaryColor: secondaryColor || "#38bdf8",
        accentColor: accentColor || "#12b85f",
        themeMode: themeMode || "dark",
        borderRadius: borderRadius || "rounded",
        customCss: customCss || null,

        // WhatsApp Defaults on create
        whatsappNumber: whatsappNumber || "+51 900 123 456",
        whatsappEnabled: whatsappEnabled !== undefined ? whatsappEnabled : true,
        whatsappMessage: whatsappMessage || "Hola! Deseo cotizar un proyecto tecnológico con TechLab.",

        // SEO Defaults on Create
        seoTitleSeparator: seoTitleSeparator || "-",
        seoHomeTitle: seoHomeTitle || "%sitename% - Innovación y Desarrollo Web",
        seoHomeDescription: seoHomeDescription || null,
        seoOgDefaultImage: seoOgDefaultImage || null,
        seoOgTitle: seoOgTitle || null,
        seoOgDescription: seoOgDescription || null,
        seoTwitterCard: seoTwitterCard || "summary_large_image",
        seoTwitterHandle: seoTwitterHandle || "@techlab",
        seoFacebookAppId: seoFacebookAppId || null,
        seoGoogleVerify: seoGoogleVerify || null,
        seoBingVerify: seoBingVerify || null,
        seoRobotsTxt: seoRobotsTxt || "User-agent: *\nAllow: /\nDisallow: /dashboard/\nDisallow: /api/",
        seoSitemapEnabled: seoSitemapEnabled !== undefined ? seoSitemapEnabled : true,
        seoAnalyticsId: seoAnalyticsId || null,
        seoGtmId: seoGtmId || null,
        seoCustomHead: seoCustomHead || null,
        seoCustomBody: seoCustomBody || null,

        // Footer Defaults on Create
        footerDescription: footerDescription || "Laboratorio de innovación tecnológica, desarrollo de software y servicios en la nube.",
        footerCopyright: footerCopyright || "© 2026 TechLab. Todos los derechos reservados.",
        footerBottomText: footerBottomText || "Términos y condiciones　|　Política de privacidad",
        footerEmail: footerEmail || "contacto@techlab.com",
        footerPhone: footerPhone || "+51 900 123 456",
        footerAddress: footerAddress || "Lima, Perú",
        footerSchedule: footerSchedule || "Lun - Vie: 9:00 AM - 6:00 PM",
        footerFacebook: footerFacebook || "https://facebook.com",
        footerTwitter: footerTwitter || "https://twitter.com",
        footerInstagram: footerInstagram || "https://instagram.com",
        footerLinkedin: footerLinkedin || "https://linkedin.com",
        footerYoutube: footerYoutube || "https://youtube.com",
        footerGithub: footerGithub || "https://github.com",
        footerShowSocial: footerShowSocial !== undefined ? footerShowSocial : true,
        footerShowContact: footerShowContact !== undefined ? footerShowContact : true,
        footerNavTitle: footerNavTitle || "NAVEGACIÓN",
        footerServicesTitle: footerServicesTitle || "SERVICIOS",
        footerResourcesTitle: footerResourcesTitle || "RECURSOS",

        // Ajustes de Lectura
        showOnFront: showOnFront || "posts",
        pageOnFront: pageOnFront || null,
        pageForPosts: pageForPosts || null,
        postsPerPage: postsPerPage ? Number(postsPerPage) : 10,
      },
    });

    return NextResponse.json({ success: true, settings: updated });
  } catch (error) {
    console.error("Error al actualizar ajustes del sitio:", error);
    return NextResponse.json(
      { success: false, error: "Error interno al guardar los cambios." },
      { status: 500 }
    );
  }
}
