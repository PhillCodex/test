import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// Elementos por defecto basados en el navbar de inicio
const DEFAULT_HEADER_ITEMS = [
  { label: "INICIO", url: "/#inicio", icon: "Home", order: 0 },
  { label: "SERVICIOS", url: "/#servicios", icon: "Briefcase", order: 1 },
  { label: "SOLUCIONES", url: "/#servicios", icon: "Layers", order: 2 },
  { label: "PORTAFOLIO", url: "/#portafolio", icon: "FolderGit2", order: 3 },
  { label: "RECURSOS", url: "/#recursos", icon: "Cpu", order: 4 },
  { label: "SOBRE MÍ", url: "/#sobre-mi", icon: "User", order: 5 },
  { label: "CONTACTO", url: "/#contacto", icon: "Mail", order: 6 },
];

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const slug = searchParams.get("slug");
    const location = searchParams.get("location");
    const menuId = searchParams.get("id");

    // Consulta de un menú específico o menú por ubicación
    let targetMenu = null;
    if (menuId) {
      targetMenu = await prisma.menu.findUnique({
        where: { id: menuId },
        include: {
          items: {
            orderBy: { order: "asc" },
            include: {
              children: {
                orderBy: { order: "asc" },
                include: { children: { orderBy: { order: "asc" } } },
              },
              page: true,
            },
          },
        },
      });
    } else if (slug) {
      targetMenu = await prisma.menu.findUnique({
        where: { slug },
        include: {
          items: {
            orderBy: { order: "asc" },
            include: {
              children: {
                orderBy: { order: "asc" },
                include: { children: { orderBy: { order: "asc" } } },
              },
              page: true,
            },
          },
        },
      });
    } else if (location) {
      targetMenu = await prisma.menu.findFirst({
        where: { location },
        include: {
          items: {
            orderBy: { order: "asc" },
            include: {
              children: {
                orderBy: { order: "asc" },
                include: { children: { orderBy: { order: "asc" } } },
              },
              page: true,
            },
          },
        },
      });
    }

    // Si no se encontró un target específico, tomar el primario
    if (!targetMenu) {
      targetMenu = await prisma.menu.findFirst({
        where: { isPrimary: true },
        include: {
          items: {
            orderBy: { order: "asc" },
            include: {
              children: {
                orderBy: { order: "asc" },
                include: { children: { orderBy: { order: "asc" } } },
              },
              page: true,
            },
          },
        },
      });
    }

    // Si no existe ningún menú en la BD, inicializar
    if (!targetMenu) {
      try {
        targetMenu = await prisma.menu.create({
          data: {
            name: "Menú Principal (Header)",
            slug: "menu-principal",
            location: "HEADER",
            isPrimary: true,
            items: {
              create: DEFAULT_HEADER_ITEMS.map((item) => ({
                label: item.label,
                url: item.url,
                icon: item.icon,
                order: item.order,
                target: "_self",
              })),
            },
          },
          include: {
            items: {
              orderBy: { order: "asc" },
              include: { children: { orderBy: { order: "asc" } }, page: true },
            },
          },
        });
      } catch {
        targetMenu = {
          id: "default-menu",
          name: "Menú Principal (Header)",
          slug: "menu-principal",
          location: "HEADER",
          isPrimary: true,
          items: DEFAULT_HEADER_ITEMS.map((i, idx) => ({ id: `it-${idx}`, ...i, target: "_self", children: [] })),
        } as any;
      }
    }

    // Listar todos los menús para el switcher del panel
    const menus = await prisma.menu.findMany({
      orderBy: { createdAt: "asc" },
      include: { _count: { select: { items: true } } },
    });

    const pages = await prisma.page.findMany({
      select: { id: true, title: true, slug: true, status: true },
      orderBy: { updatedAt: "desc" },
    });

    const categories = await prisma.category.findMany({
      select: { id: true, name: true, slug: true, color: true },
      orderBy: { name: "asc" },
    });

    return NextResponse.json({
      success: true,
      menu: targetMenu,
      menus,
      pages,
      categories,
    });
  } catch (error: any) {
    console.error("Error en GET /api/menus:", error);
    return NextResponse.json({
      success: true,
      menu: {
        id: "default-menu",
        name: "Menú Principal (Header)",
        slug: "menu-principal",
        location: "HEADER",
        isPrimary: true,
        items: DEFAULT_HEADER_ITEMS.map((i, idx) => ({ id: `it-${idx}`, ...i, target: "_self", children: [] })),
      },
      menus: [],
      pages: [],
      categories: [],
    });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { id, name, slug, location, isPrimary, items } = body;

    if (!name || !name.trim()) {
      return NextResponse.json(
        { success: false, error: "El nombre del menú es obligatorio" },
        { status: 400 }
      );
    }

    const cleanSlug =
      (slug && slug.trim()) ||
      name
        .toLowerCase()
        .trim()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "");

    // Si este menú se define como Primario, quitar el primario de los demás con la misma ubicación
    if (isPrimary) {
      await prisma.menu.updateMany({
        where: { location: location || "HEADER" },
        data: { isPrimary: false },
      });
    }

    let menuRecord;

    if (id) {
      // Actualizar menú existente
      menuRecord = await prisma.menu.update({
        where: { id },
        data: {
          name: name.trim(),
          slug: cleanSlug,
          location: location || "HEADER",
          isPrimary: Boolean(isPrimary),
        },
      });

      // Eliminar elementos antiguos para recrear la jerarquía limpia
      await prisma.menuItem.deleteMany({
        where: { menuId: id },
      });
    } else {
      // Crear nuevo menú
      menuRecord = await prisma.menu.create({
        data: {
          name: name.trim(),
          slug: cleanSlug,
          location: location || "HEADER",
          isPrimary: Boolean(isPrimary),
        },
      });
    }

    // Guardar los elementos con su jerarquía de Padre / Hijos
    if (items && Array.isArray(items) && items.length > 0) {
      // Primero crear los elementos de nivel superior (padres)
      const parentIdMap: Record<string, string> = {};

      for (let i = 0; i < items.length; i++) {
        const item = items[i];
        if (!item.isSubItem) {
          const createdParent = await prisma.menuItem.create({
            data: {
              menuId: menuRecord.id,
              label: item.label,
              url: item.url,
              icon: item.icon || null,
              target: item.target || "_self",
              order: i,
              pageId: item.pageId || null,
            },
          });
          if (item.tempId) {
            parentIdMap[item.tempId] = createdParent.id;
          }
        }
      }

      // Luego crear los sub-elementos (hijos) vinculados a sus padres
      for (let i = 0; i < items.length; i++) {
        const item = items[i];
        if (item.isSubItem) {
          const realParentId =
            item.parentTempId && parentIdMap[item.parentTempId]
              ? parentIdMap[item.parentTempId]
              : null;

          await prisma.menuItem.create({
            data: {
              menuId: menuRecord.id,
              label: item.label,
              url: item.url,
              icon: item.icon || null,
              target: item.target || "_self",
              order: i,
              parentId: realParentId,
              pageId: item.pageId || null,
            },
          });
        }
      }
    }

    // Devolver el menú completo actualizado
    const fullMenu = await prisma.menu.findUnique({
      where: { id: menuRecord.id },
      include: {
        items: {
          orderBy: { order: "asc" },
          include: {
            children: {
              orderBy: { order: "asc" },
              include: { children: { orderBy: { order: "asc" } } },
            },
            page: true,
          },
        },
      },
    });

    return NextResponse.json({
      success: true,
      menu: fullMenu,
      message: "Menú guardado correctamente en la base de datos",
    });
  } catch (error: any) {
    console.error("Error en POST /api/menus:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al guardar el menú" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        { success: false, error: "ID de menú no proporcionado" },
        { status: 400 }
      );
    }

    await prisma.menu.delete({
      where: { id },
    });

    return NextResponse.json({
      success: true,
      message: "Menú eliminado correctamente",
    });
  } catch (error: any) {
    console.error("Error en DELETE /api/menus:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Error al eliminar menú" },
      { status: 500 }
    );
  }
}
