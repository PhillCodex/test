import { NextRequest, NextResponse } from "next/server";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import crypto from "crypto";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    const uploadedBy = session?.name || "Admin";

    const data = await request.formData();
    const file: File | null = data.get("file") as unknown as File;

    const attachedToTitle = (data.get("attachedToTitle") as string) || null;
    const attachedToUrl = (data.get("attachedToUrl") as string) || null;
    const attachedToType = (data.get("attachedToType") as string) || null;
    const attachedToId = (data.get("attachedToId") as string) || null;

    if (!file) {
      return NextResponse.json({ error: "No se proporcionó ningún archivo." }, { status: 400 });
    }

    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);
    const size = buffer.length;
    const mimeType = file.type || "image/jpeg";

    // Sanitizar nombre de archivo y agregar timestamp único
    const originalName = file.name.replace(/[^a-zA-Z0-9.-]/g, "_");
    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
    const ext = path.extname(originalName) || ".jpg";
    const filename = `${path.basename(originalName, ext)}-${uniqueSuffix}${ext}`;

    // Base64 Data URL para respaldo universal (en Vercel y serverless)
    const base64Str = buffer.toString("base64");
    const dataUrl = `data:${mimeType};base64,${base64Str}`;

    // 1. Intentar guardar en disco local (public/uploads)
    let savedToDisk = false;
    try {
      const uploadDir = path.join(process.cwd(), "public", "uploads");
      await mkdir(uploadDir, { recursive: true });
      const filePath = path.join(uploadDir, filename);
      await writeFile(filePath, buffer);
      savedToDisk = true;
    } catch {
      // Ignorar fallo de escritura si el entorno es de solo lectura (como Vercel)
    }

    // 2. Intentar guardar en /tmp/uploads si no se pudo en public
    if (!savedToDisk) {
      try {
        const tmpDir = path.join("/tmp", "uploads");
        await mkdir(tmpDir, { recursive: true });
        await writeFile(path.join(tmpDir, filename), buffer);
      } catch {
        // Fallback a base de datos
      }
    }

    const publicUrl = `/uploads/${filename}`;
    const baseTitle = path.basename(originalName, ext).replace(/[-_]/g, " ");

    let dimensions: string | null = null;
    if (mimeType.startsWith("image/")) {
      dimensions = "1200 por 800 píxeles";
    }

    const mediaId = crypto.randomUUID();

    try {
      await prisma.$executeRawUnsafe(
        `INSERT INTO media (id, filename, originalName, url, mimeType, size, dimensions, altText, title, caption, description, uploadedBy, attachedToTitle, attachedToUrl, attachedToType, attachedToId, fileData, createdAt, updatedAt)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(3), NOW(3))`,
        mediaId,
        filename,
        file.name,
        publicUrl,
        mimeType,
        size,
        dimensions,
        baseTitle,
        baseTitle,
        "",
        "",
        uploadedBy,
        attachedToTitle,
        attachedToUrl,
        attachedToType,
        attachedToId,
        dataUrl
      );
    } catch (dbErr: any) {
      console.warn("No se pudo registrar medio en BD:", dbErr.message);
    }

    return NextResponse.json({
      success: true,
      url: publicUrl,
      dataUrl: dataUrl,
      name: filename,
      id: mediaId,
    });
  } catch (error) {
    console.error("Error en /api/upload:", error);
    return NextResponse.json(
      { error: "Error al procesar la subida del archivo." },
      { status: 500 }
    );
  }
}
