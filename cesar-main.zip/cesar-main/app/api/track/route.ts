import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import crypto from "crypto";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const path = typeof body.path === "string" ? body.path.slice(0, 255) : "/";
    const referer = typeof body.referer === "string" ? body.referer.slice(0, 500) : req.headers.get("referer") || null;

    // Obtener IP del visitante
    const forwardedFor = req.headers.get("x-forwarded-for");
    const realIp = req.headers.get("x-real-ip");
    let ip = "127.0.0.1";

    if (forwardedFor) {
      ip = forwardedFor.split(",")[0].trim();
    } else if (realIp) {
      ip = realIp.trim();
    }

    const userAgent = req.headers.get("user-agent") || null;

    // Ignorar llamadas a rutas de administración interna para las estadísticas del portal
    if (path.startsWith("/api") || path.startsWith("/_next") || path.startsWith("/dashboard")) {
      return NextResponse.json({ success: true, ignored: true });
    }

    // Registrar visita por IP en MySQL con query directo
    const id = crypto.randomUUID();
    await prisma.$executeRawUnsafe(
      `INSERT INTO site_visits (id, ipAddress, path, userAgent, referer, createdAt) VALUES (?, ?, ?, ?, ?, NOW())`,
      id,
      ip,
      path,
      userAgent ? userAgent.slice(0, 500) : null,
      referer
    );

    // Si es una publicación específica (/posts/[slug]), incrementar contador de visitas
    if (path.startsWith("/posts/")) {
      const slug = path.replace("/posts/", "").split("?")[0].split("/")[0];
      if (slug) {
        await prisma.post.updateMany({
          where: { slug },
          data: { views: { increment: 1 } },
        }).catch(() => {});
      }
    }

    return NextResponse.json({ success: true, ip, path });
  } catch (error: any) {
    console.error("Error al registrar visita:", error.message);
    return NextResponse.json({ success: true, ignored: true, warning: error.message }, { status: 200 });
  }
}

