import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import Hero from "@/components/home/Hero";
import Services from "@/components/home/Services";
import Projects from "@/components/home/Projects";
import Testimonials from "@/components/home/Testimonials";
import Articles from "@/components/home/Articles";
import CTA from "@/components/home/CTA";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function Home() {
  let settings = null;
  try {
    settings = await prisma.siteSetting.findUnique({
      where: { id: "general" },
    });
  } catch (e) {
    console.warn("Could not query settings during build, using defaults:", e);
  }

  const whatsappEnabled = settings?.whatsappEnabled !== false;
  const whatsappNumber = settings?.whatsappNumber || "51900123456";
  const cleanNumber = whatsappNumber.replace(/[^0-9]/g, "");
  const whatsappMessage = settings?.whatsappMessage || "";
  const whatsappLink = `https://wa.me/${cleanNumber}${whatsappMessage ? `?text=${encodeURIComponent(whatsappMessage)}` : ""}`;

  // Si en Ajustes de Lectura se seleccionó una página estática para el Inicio
  let customFrontPage = null;
  if (settings?.showOnFront === "page" && settings?.pageOnFront) {
    try {
      customFrontPage = await prisma.page.findFirst({
        where: {
          OR: [
            { id: settings.pageOnFront },
            { slug: settings.pageOnFront },
          ],
        },
      });
    } catch (e) {
      console.warn("Could not load custom front page:", e);
    }
  }

  return (
    <>
      <Header />
      {customFrontPage ? (
        <main className="custom-front-page-main">
          {customFrontPage.template === "elementor_canvas" ? (
            <div
              className="elementor-canvas-content"
              dangerouslySetInnerHTML={{ __html: customFrontPage.content }}
            />
          ) : (
            <div className="container" style={{ padding: "40px 0 80px", minHeight: "60vh" }}>
              <div
                className="page-rich-content"
                style={{ fontSize: "16px", lineHeight: 1.85, color: "#cbd5e1" }}
                dangerouslySetInnerHTML={{ __html: customFrontPage.content }}
              />
            </div>
          )}
        </main>
      ) : (
        <main>
          <Hero />
          <Services />
          <Projects />
          <Testimonials />
          <Articles />
          <CTA />
        </main>
      )}
      <Footer />

      {/* Botón Flotante de WhatsApp Dinámico */}
      {whatsappEnabled && cleanNumber && (
        <a
          className="whatsapp"
          href={whatsappLink}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Contactar por WhatsApp"
          title="Contactar por WhatsApp"
        >
          <svg viewBox="0 0 32 32" aria-hidden="true">
            <path
              fill="currentColor"
              d="M16.02 3A12.8 12.8 0 0 0 5.1 22.49L3.4 29l6.66-1.75A12.99 12.99 0 1 0 16.02 3Zm0 23.61c-1.93 0-3.82-.52-5.47-1.5l-.39-.23-3.95 1.04 1.06-3.84-.25-.4a10.4 10.4 0 1 1 9 4.93Zm5.7-7.8c-.31-.16-1.85-.91-2.14-1.02-.28-.1-.49-.16-.7.16-.2.31-.8 1.02-.98 1.23-.18.21-.36.24-.67.08-.31-.16-1.32-.49-2.51-1.55a9.4 9.4 0 0 1-1.74-2.16c-.18-.31-.02-.48.14-.64.14-.14.31-.36.47-.55.15-.18.2-.31.31-.52.1-.21.05-.39-.03-.55-.08-.15-.7-1.68-.95-2.3-.25-.6-.51-.52-.7-.53h-.6c-.2 0-.54.08-.82.39-.28.31-1.08 1.05-1.08 2.57 0 1.51 1.11 2.98 1.26 3.18.16.21 2.18 3.32 5.27 4.66.74.32 1.31.51 1.76.65.74.23 1.41.2 1.94.12.59-.09 1.85-.76 2.11-1.49.26-.73.26-1.36.18-1.49-.07-.13-.28-.2-.59-.36Z"
            />
          </svg>
        </a>
      )}
    </>
  );
}
