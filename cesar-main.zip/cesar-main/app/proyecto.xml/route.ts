import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const settings = await prisma.siteSetting.findUnique({ where: { id: "general" } });
    const baseUrl = settings?.publicUrl || (new URL(req.url)).origin || "http://localhost:3000";

    const projects = await prisma.project.findMany({
      where: {
        status: { in: ["Publicado", "PUBLICADO", "published", "PUBLISHED", "Activo", "ACTIVO"] },
      },
      orderBy: { updatedAt: "desc" },
      select: {
        slug: true,
        updatedAt: true,
        title: true,
      },
    });

    const now = new Date().toISOString();

    const projEntries = projects
      .map((p) => {
        const url = `${baseUrl}/proyectos/${p.slug}`;
        const lastmod = p.updatedAt ? new Date(p.updatedAt).toISOString() : now;

        return `  <url>
    <loc>${url}</loc>
    <lastmod>${lastmod}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>`;
      })
      .join("\n");

    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="/sitemap.xsl"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${projEntries}
</urlset>`;

    return new NextResponse(xml, {
      headers: {
        "Content-Type": "application/xml; charset=utf-8",
        "Cache-Control": "public, s-maxage=3600, stale-while-revalidate=59",
      },
    });
  } catch (error) {
    console.error("Error al generar proyecto.xml:", error);
    return new NextResponse("<error>Error al generar proyecto.xml</error>", {
      status: 500,
      headers: { "Content-Type": "application/xml" },
    });
  }
}
