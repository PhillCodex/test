import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const settings = await prisma.siteSetting.findUnique({ where: { id: "general" } });
    const baseUrl = settings?.publicUrl || (new URL(req.url)).origin || "http://localhost:3000";

    const [latestPost, latestPage, latestProject, latestService] = await Promise.all([
      prisma.post.findFirst({
        where: { status: "Publicado" },
        orderBy: { updatedAt: "desc" },
        select: { updatedAt: true },
      }),
      prisma.page.findFirst({
        where: { status: "Publicado" },
        orderBy: { updatedAt: "desc" },
        select: { updatedAt: true },
      }),
      prisma.project.findFirst({
        where: { status: "PUBLICADO" },
        orderBy: { updatedAt: "desc" },
        select: { updatedAt: true },
      }),
      prisma.service.findFirst({
        where: { status: "PUBLICADO" },
        orderBy: { updatedAt: "desc" },
        select: { updatedAt: true },
      }),
    ]);

    const now = new Date().toISOString();
    const postLastMod = latestPost?.updatedAt?.toISOString() || now;
    const pageLastMod = latestPage?.updatedAt?.toISOString() || now;
    const projectLastMod = latestProject?.updatedAt?.toISOString() || now;
    const serviceLastMod = latestService?.updatedAt?.toISOString() || now;

    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="/sitemap.xsl"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <sitemap>
    <loc>${baseUrl}/post.xml</loc>
    <lastmod>${postLastMod}</lastmod>
  </sitemap>
  <sitemap>
    <loc>${baseUrl}/page.xml</loc>
    <lastmod>${pageLastMod}</lastmod>
  </sitemap>
  <sitemap>
    <loc>${baseUrl}/categoria.xml</loc>
    <lastmod>${now}</lastmod>
  </sitemap>
  <sitemap>
    <loc>${baseUrl}/proyecto.xml</loc>
    <lastmod>${projectLastMod}</lastmod>
  </sitemap>
  <sitemap>
    <loc>${baseUrl}/servicio.xml</loc>
    <lastmod>${serviceLastMod}</lastmod>
  </sitemap>
</sitemapindex>`;

    return new NextResponse(xml, {
      headers: {
        "Content-Type": "application/xml; charset=utf-8",
        "Cache-Control": "public, s-maxage=3600, stale-while-revalidate=59",
      },
    });
  } catch (error) {
    console.error("Error al generar sitemap.xml:", error);
    return new NextResponse("<error>Error al generar el sitemap</error>", {
      status: 500,
      headers: { "Content-Type": "application/xml" },
    });
  }
}
