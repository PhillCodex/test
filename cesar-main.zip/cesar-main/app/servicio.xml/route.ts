import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const settings = await prisma.siteSetting.findUnique({ where: { id: "general" } });
    const baseUrl = settings?.publicUrl || (new URL(req.url)).origin || "http://localhost:3000";

    const services = await prisma.service.findMany({
      where: {
        status: { in: ["Publicado", "PUBLICADO", "published", "PUBLISHED", "Activo", "ACTIVO"] },
      },
      orderBy: { updatedAt: "desc" },
      select: {
        slug: true,
        updatedAt: true,
        title: true,
      },
    });

    const now = new Date().toISOString();

    const servEntries = services
      .map((s) => {
        const url = `${baseUrl}/servicios/${s.slug}`;
        const lastmod = s.updatedAt ? new Date(s.updatedAt).toISOString() : now;

        return `  <url>
    <loc>${url}</loc>
    <lastmod>${lastmod}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>`;
      })
      .join("\n");

    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="/sitemap.xsl"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${servEntries}
</urlset>`;

    return new NextResponse(xml, {
      headers: {
        "Content-Type": "application/xml; charset=utf-8",
        "Cache-Control": "public, s-maxage=3600, stale-while-revalidate=59",
      },
    });
  } catch (error) {
    console.error("Error al generar servicio.xml:", error);
    return new NextResponse("<error>Error al generar servicio.xml</error>", {
      status: 500,
      headers: { "Content-Type": "application/xml" },
    });
  }
}
