import { NextRequest, NextResponse } from "next/server";
import { readFile } from "fs/promises";
import path from "path";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  try {
    const resolvedParams = await params;
    const pathSegments = resolvedParams?.path || [];
    const filename = pathSegments[pathSegments.length - 1];

    if (!filename) {
      return new NextResponse("Not Found", { status: 404 });
    }

    // 1. Intentar leer del sistema de archivos local (public/uploads)
    try {
      const localPublicPath = path.join(process.cwd(), "public", "uploads", ...pathSegments);
      const fileBuffer = await readFile(localPublicPath);
      const mime = getMimeType(filename);
      return new NextResponse(fileBuffer, {
        status: 200,
        headers: {
          "Content-Type": mime,
          "Cache-Control": "public, max-age=31536000, immutable",
        },
      });
    } catch {
      // Continuar al siguiente método si no está en public
    }

    // 2. Intentar leer de /tmp/uploads (usado en entornos serverless/Vercel)
    try {
      const tmpPath = path.join("/tmp", "uploads", filename);
      const tmpBuffer = await readFile(tmpPath);
      const mime = getMimeType(filename);
      return new NextResponse(tmpBuffer, {
        status: 200,
        headers: {
          "Content-Type": mime,
          "Cache-Control": "public, max-age=31536000, immutable",
        },
      });
    } catch {
      // Continuar si no está en tmp
    }

    // 3. Buscar en la base de datos MySQL (tabla media con fileData LONGTEXT)
    try {
      const mediaRecords = await prisma.$queryRawUnsafe<any[]>(
        `SELECT mimeType, fileData, url FROM media WHERE filename = ? OR originalName = ? OR url LIKE ? LIMIT 1`,
        filename,
        filename,
        `%${filename}%`
      );

      if (mediaRecords && mediaRecords.length > 0) {
        const record = mediaRecords[0];
        if (record.fileData) {
          const base64Data = record.fileData.includes("base64,")
            ? record.fileData.split("base64,")[1]
            : record.fileData;
          const buffer = Buffer.from(base64Data, "base64");
          return new NextResponse(buffer, {
            status: 200,
            headers: {
              "Content-Type": record.mimeType || getMimeType(filename),
              "Cache-Control": "public, max-age=31536000, immutable",
            },
          });
        }
      }
    } catch (dbErr) {
      console.error("Error consultando medio en BD:", dbErr);
    }

    return new NextResponse("File Not Found", { status: 404 });
  } catch (error) {
    console.error("Error sirviendo archivo en /uploads:", error);
    return new NextResponse("Internal Server Error", { status: 500 });
  }
}

function getMimeType(filename: string): string {
  const ext = path.extname(filename).toLowerCase();
  switch (ext) {
    case ".jpg":
    case ".jpeg":
      return "image/jpeg";
    case ".png":
      return "image/png";
    case ".gif":
      return "image/gif";
    case ".webp":
      return "image/webp";
    case ".svg":
      return "image/svg+xml";
    case ".ico":
      return "image/x-icon";
    case ".mp4":
      return "video/mp4";
    case ".webm":
      return "video/webm";
    case ".pdf":
      return "application/pdf";
    default:
      return "application/octet-stream";
  }
}
