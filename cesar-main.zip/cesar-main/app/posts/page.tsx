import type { Metadata } from "next";
import Link from "next/link";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import Container from "@/components/ui/Container";
import SectionTitle from "@/components/ui/SectionTitle";
import { prisma } from "@/lib/prisma";
import { Calendar, Clock, ArrowRight, Folder } from "lucide-react";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Blog & Recursos | TechLab",
  description: "Artículos técnicos, guías y recursos de desarrollo web, tecnología y optimización.",
};

export default async function BlogIndexPage() {
  const posts = await prisma.post.findMany({
    where: { status: { in: ["Publicado", "PUBLICADO"] } },
    include: { category: true, author: { select: { name: true } } },
    orderBy: { createdAt: "desc" },
  });

  const categories = await prisma.category.findMany({
    orderBy: { name: "asc" },
  });

  return (
    <>
      <Header />
      <main className="blog-archive-main">
        <Container>
          {/* Header */}
          <div className="blog-archive-header">
            <span className="blog-eyebrow">BLOG & RECURSOS TÉCNICOS</span>
            <h1>Artículos, Guías & Ciberseguridad</h1>
            <p>
              Explora nuestras publicaciones especializadas en desarrollo web, DevOps, infraestructura cloud y optimización para empresas.
            </p>
          </div>

          {/* Categories Bar */}
          <div className="blog-categories-pills">
            <span className="cat-pill active">Todos ({posts.length})</span>
            {categories.map((c) => (
              <span key={c.id} className="cat-pill">
                {c.name}
              </span>
            ))}
          </div>

          {/* Articles Grid */}
          <div className="blog-posts-grid">
            {posts.map((p) => {
              const formattedDate = new Date(p.createdAt).toLocaleDateString("es-ES", {
                day: "numeric",
                month: "short",
                year: "numeric",
              });
              const readTime = `${Math.max(3, Math.ceil((p.content?.length || 500) / 400))} min`;

              return (
                <Link href={`/posts/${p.slug}`} key={p.id} className="blog-post-card-link">
                  <article className="blog-post-card">
                    {p.featuredImage && (
                      <div className="post-thumbnail-wrap">
                        <img src={p.featuredImage} alt={p.title} />
                      </div>
                    )}
                    <div className="post-card-body">
                      {p.category && <span className="post-cat-badge">{p.category.name}</span>}
                      <h2>{p.title}</h2>
                      {p.excerpt && <p className="post-excerpt-text">{p.excerpt}</p>}
                      <div className="post-meta-footer">
                        <span className="meta-sub">
                          <Calendar className="mini-ico" /> {formattedDate}
                        </span>
                        <span className="meta-sub">
                          <Clock className="mini-ico" /> {readTime}
                        </span>
                        <span className="read-more-text">
                          Leer artículo <ArrowRight className="mini-ico" />
                        </span>
                      </div>
                    </div>
                  </article>
                </Link>
              );
            })}
          </div>
        </Container>
      </main>
      <Footer />

      <style>{`
        .blog-archive-main {
          min-height: calc(100vh - 200px);
          padding: 40px 0 80px;
        }

        .blog-archive-header {
          text-align: center;
          max-width: 680px;
          margin: 0 auto 36px;
        }

        .blog-eyebrow {
          display: inline-block;
          font-size: 11px;
          font-weight: 800;
          color: #16c96f;
          letter-spacing: 0.8px;
          text-transform: uppercase;
          background: rgba(22, 201, 111, 0.1);
          border: 1px solid rgba(22, 201, 111, 0.3);
          padding: 4px 14px;
          border-radius: 20px;
          margin-bottom: 12px;
        }

        .blog-archive-header h1 {
          font-size: clamp(32px, 4.5vw, 48px);
          font-weight: 900;
          color: #ffffff;
          margin: 0 0 12px;
          letter-spacing: -1px;
        }

        .blog-archive-header p {
          font-size: 15px;
          line-height: 1.6;
          color: #94a3b8;
          margin: 0;
        }

        .blog-categories-pills {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          flex-wrap: wrap;
          margin-bottom: 40px;
        }

        .cat-pill {
          font-size: 12px;
          font-weight: 600;
          color: #cbd5e1;
          background: #040e17;
          border: 1px solid rgba(255, 255, 255, 0.08);
          padding: 6px 14px;
          border-radius: 20px;
          cursor: pointer;
          transition: all 0.15s;
        }

        .cat-pill:hover,
        .cat-pill.active {
          background: rgba(22, 201, 111, 0.15);
          border-color: #16c96f;
          color: #16c96f;
        }

        .blog-posts-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 24px;
        }

        .blog-post-card-link {
          text-decoration: none;
          color: inherit;
        }

        .blog-post-card {
          background: #040e17;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 12px;
          overflow: hidden;
          display: flex;
          flex-direction: column;
          height: 100%;
          transition: transform 0.2s, border-color 0.2s, box-shadow 0.2s;
        }

        .blog-post-card:hover {
          transform: translateY(-4px);
          border-color: #16c96f;
          box-shadow: 0 14px 30px rgba(0, 0, 0, 0.6);
        }

        .post-thumbnail-wrap {
          height: 180px;
          overflow: hidden;
        }

        .post-thumbnail-wrap img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          transition: transform 0.3s ease;
        }

        .blog-post-card:hover .post-thumbnail-wrap img {
          transform: scale(1.05);
        }

        .post-card-body {
          padding: 20px;
          display: flex;
          flex-direction: column;
          flex: 1;
        }

        .post-cat-badge {
          font-size: 10px;
          font-weight: 700;
          color: #16c96f;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          margin-bottom: 8px;
        }

        .post-card-body h2 {
          font-size: 16px;
          font-weight: 700;
          color: #ffffff;
          margin: 0 0 10px;
          line-height: 1.4;
        }

        .post-excerpt-text {
          font-size: 12px;
          line-height: 1.6;
          color: #94a3b8;
          margin: 0 0 16px;
          display: -webkit-box;
          -webkit-line-clamp: 3;
          -webkit-box-orient: vertical;
          overflow: hidden;
          flex: 1;
        }

        .post-meta-footer {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding-top: 14px;
          border-top: 1px solid rgba(255, 255, 255, 0.06);
          font-size: 11px;
          color: #64748b;
        }

        .meta-sub {
          display: inline-flex;
          align-items: center;
          gap: 4px;
        }

        .mini-ico {
          width: 12px;
          height: 12px;
        }

        .read-more-text {
          color: #38bdf8;
          font-weight: 600;
          display: inline-flex;
          align-items: center;
          gap: 4px;
        }

        @media (max-width: 900px) {
          .blog-posts-grid {
            grid-template-columns: repeat(2, 1fr);
          }
        }

        @media (max-width: 600px) {
          .blog-posts-grid {
            grid-template-columns: 1fr;
          }
        }
      `}</style>
    </>
  );
}
