import type { Metadata } from "next";
import Link from "next/link";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import Container from "@/components/ui/Container";
import PostComments from "@/components/blog/PostComments";
import { prisma } from "@/lib/prisma";
import {
  Calendar,
  Clock,
  ArrowRight,
  Folder,
  Tag as TagIcon,
  User,
  Share2,
  Bookmark,
  CheckCircle2,
  ChevronRight,
  ArrowLeft,
  Sparkles,
  ExternalLink,
  MessageSquare,
  Shield,
  Zap,
} from "lucide-react";

export const dynamic = "force-dynamic";

interface PostPageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: PostPageProps): Promise<Metadata> {
  const { slug } = await params;
  const post = await prisma.post.findUnique({
    where: { slug },
    include: { category: true },
  });

  if (!post) {
    return {
      title: "Artículo no encontrado | TechLab",
    };
  }

  const settings = await prisma.siteSetting.findUnique({ where: { id: "general" } });
  const siteTitle = settings?.siteTitle || "TechLab";
  const title = post.seoTitle || `${post.title} - ${siteTitle}`;
  const description = post.seoDescription || post.excerpt || "Artículo especializado en tecnología, software y ciberseguridad.";

  return {
    title,
    description,
    openGraph: {
      title,
      description,
      images: post.featuredImage ? [{ url: post.featuredImage }] : [],
    },
  };
}

export default async function PublicPostPage({ params }: PostPageProps) {
  const { slug } = await params;

  const post = await prisma.post.findUnique({
    where: { slug },
    include: { category: true, author: true },
  });

  if (!post) {
    return (
      <>
        <Header />
        <main className="post-not-found-wrap">
          <Container>
            <div className="not-found-card">
              <span className="error-code">404</span>
              <h1>Publicación no encontrada</h1>
              <p>El artículo que buscas no existe o ha sido movido a otra ubicación.</p>
              <Link href="/posts" className="btn-return-blog">
                <ArrowLeft /> Volver al Blog
              </Link>
            </div>
          </Container>
        </main>
        <Footer />
      </>
    );
  }

  // Increment views count safely
  try {
    await prisma.post.update({
      where: { id: post.id },
      data: { views: { increment: 1 } },
    });
  } catch (e) {
    // Ignore in read-only cases
  }

  // Fetch Sidebar Data
  const [categoriesWithCount, allTags, relatedPosts] = await Promise.all([
    prisma.category.findMany({
      include: {
        _count: {
          select: { posts: { where: { status: { in: ["Publicado", "PUBLICADO"] } } } },
        },
      },
      orderBy: { name: "asc" },
    }),
    prisma.tag.findMany({
      take: 12,
      orderBy: { name: "asc" },
    }),
    prisma.post.findMany({
      where: {
        id: { not: post.id },
        status: { in: ["Publicado", "PUBLICADO"] },
      },
      take: 3,
      orderBy: { createdAt: "desc" },
      include: { category: true },
    }),
  ]);

  const formattedDate = new Date(post.createdAt).toLocaleDateString("es-ES", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const readTime = `${Math.max(3, Math.ceil((post.content?.length || 500) / 400))} min de lectura`;

  // Parse post tags
  const postTagsList = post.tags
    ? post.tags
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean)
    : [];

  return (
    <>
      <Header />
      <main className="single-post-main">
        <Container>
          {/* Breadcrumbs Top Bar */}
          <nav className="post-breadcrumbs" aria-label="Ruta de navegación">
            <Link href="/">Inicio</Link>
            <ChevronRight className="crumb-sep" />
            <Link href="/posts">Blog & Recursos</Link>
            {post.category && (
              <>
                <ChevronRight className="crumb-sep" />
                <Link href={`/posts?cat=${post.category.slug}`}>{post.category.name}</Link>
              </>
            )}
            <ChevronRight className="crumb-sep" />
            <span className="current-crumb">{post.title}</span>
          </nav>

          {/* 2-Column Layout: Main Content (Left) + Sidebar (Right) */}
          <div className="post-layout-grid">
            {/* =========================================================
                COLUMNA PRINCIPAL IZQUIERDA (ARTÍCULO + CONTENIDO + COMENTARIOS)
                ========================================================= */}
            <div className="post-main-column">
              <article className="post-content-article">
                {/* Header del Post */}
                <header className="post-header-hero">
                  {post.category && (
                    <div className="post-category-badge-wrap">
                      <span className="post-cat-badge">{post.category.name}</span>
                    </div>
                  )}

                  {/* TÍTULO H1 PRINCIPAL */}
                  <h1 className="post-main-h1">{post.title}</h1>

                  {/* Fila de Metadatos */}
                  <div className="post-meta-details-bar">
                    <div className="author-meta-box">
                      <div className="author-avatar-badge">
                        {post.author?.avatar ? (
                          <img src={post.author.avatar} alt={post.author.name} />
                        ) : (
                          <User />
                        )}
                      </div>
                      <div className="author-names-group">
                        <strong className="author-name-text">{post.author?.name || "TechLab Team"}</strong>
                        <span className="author-role-sub">Autor especializado</span>
                      </div>
                    </div>

                    <div className="meta-stats-group">
                      <div className="meta-stat-item">
                        <Calendar className="stat-ico" />
                        <span>{formattedDate}</span>
                      </div>
                      <div className="meta-stat-item">
                        <Clock className="stat-ico" />
                        <span>{readTime}</span>
                      </div>
                    </div>
                  </div>
                </header>

                {/* Imagen Destacada Hero */}
                {post.featuredImage && (
                  <div className="post-featured-hero-image">
                    <img src={post.featuredImage} alt={post.title} />
                  </div>
                )}

                {/* Extracto o Resumen Lead */}
                {post.excerpt && (
                  <div className="post-lead-summary-card">
                    <div className="lead-accent-bar" />
                    <p>{post.excerpt}</p>
                  </div>
                )}

                {/* =========================================================
                    CUERPO DEL ARTÍCULO (HTML FORMATEADO DEL EDITOR)
                    ========================================================= */}
                <div
                  className="post-rich-html-content"
                  dangerouslySetInnerHTML={{ __html: post.content }}
                />

                {/* Footer del Post: Compartir y tags en móvil */}
                <div className="post-article-footer">
                  <div className="share-actions-group">
                    <span className="share-label">
                      <Share2 /> Compartir este artículo:
                    </span>
                    <div className="share-social-links">
                      <a
                        href={`https://wa.me/?text=${encodeURIComponent(`${post.title} https://techlab.com/posts/${post.slug}`)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="share-btn whatsapp"
                        title="Compartir en WhatsApp"
                      >
                        WhatsApp
                      </a>
                      <a
                        href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(post.title)}&url=${encodeURIComponent(`https://techlab.com/posts/${post.slug}`)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="share-btn twitter"
                        title="Compartir en X / Twitter"
                      >
                        X (Twitter)
                      </a>
                      <a
                        href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(`https://techlab.com/posts/${post.slug}`)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="share-btn linkedin"
                        title="Compartir en LinkedIn"
                      >
                        LinkedIn
                      </a>
                    </div>
                  </div>
                </div>
              </article>

              {/* SECCIÓN DE COMENTARIOS AJAX */}
              <PostComments postId={post.id} postSlug={post.slug} />
            </div>

            {/* =========================================================
                COLUMNA LATERAL DERECHA (SIDEBAR: CATEGORÍAS, ETIQUETAS, AUTOR)
                ========================================================= */}
            <aside className="post-sidebar-column">
              {/* Widget 1: Categorías */}
              <div className="sidebar-widget-card">
                <div className="widget-header">
                  <Folder className="widget-icon" />
                  <h3>Categorías</h3>
                </div>
                <div className="widget-body">
                  <ul className="categories-widget-list">
                    {categoriesWithCount.map((cat) => {
                      const isCurrent = post.category?.id === cat.id;
                      return (
                        <li key={cat.id}>
                          <Link
                            href={`/posts?cat=${cat.slug}`}
                            className={`category-item-link ${isCurrent ? "current-cat" : ""}`}
                          >
                            <span className="cat-bullet" />
                            <span className="cat-name">{cat.name}</span>
                            <span className="cat-count">{cat._count.posts}</span>
                          </Link>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              </div>

              {/* Widget 2: Etiquetas / Tags del Post & Globales */}
              <div className="sidebar-widget-card">
                <div className="widget-header">
                  <TagIcon className="widget-icon" />
                  <h3>Etiquetas</h3>
                </div>
                <div className="widget-body">
                  {postTagsList.length > 0 ? (
                    <div className="tags-cloud-wrap">
                      {postTagsList.map((tag, idx) => (
                        <Link key={idx} href={`/posts?tag=${encodeURIComponent(tag)}`} className="sidebar-tag-pill active-tag">
                          #{tag}
                        </Link>
                      ))}
                    </div>
                  ) : allTags.length > 0 ? (
                    <div className="tags-cloud-wrap">
                      {allTags.map((tag) => (
                        <Link key={tag.id} href={`/posts?tag=${tag.slug}`} className="sidebar-tag-pill">
                          #{tag.name}
                        </Link>
                      ))}
                    </div>
                  ) : (
                    <p className="empty-widget-text">No hay etiquetas disponibles.</p>
                  )}
                </div>
              </div>

              {/* Widget 3: Sobre el Autor */}
              <div className="sidebar-widget-card author-box">
                <div className="author-card-avatar-wrap">
                  {post.author?.avatar ? (
                    <img src={post.author.avatar} alt={post.author.name} />
                  ) : (
                    <div className="avatar-placeholder">{post.author?.name ? post.author.name.charAt(0).toUpperCase() : "C"}</div>
                  )}
                </div>
                <h4 className="author-card-name">{post.author?.name || "TechLab Team"}</h4>
                <span className="author-card-title">Equipo de Ingeniería & Contenido</span>
                <p className="author-card-bio">
                  Investigación técnica, desarrollo web full-stack, optimización cloud y ciberseguridad aplicada a negocios.
                </p>
              </div>

              {/* Widget 4: Banner CTA Rápido */}
              <div className="sidebar-widget-card cta-box">
                <div className="cta-neon-badge">
                  <Zap />
                  <span>TechLab Solutions</span>
                </div>
                <h4>¿Necesitas asesoría o desarrollo tecnológico?</h4>
                <p>Creamos y optimizamos sistemas a medida con alta disponibilidad y máxima seguridad.</p>
                <Link href="/#contacto" className="sidebar-cta-btn">
                  Cotizar Proyecto <ArrowRight />
                </Link>
              </div>
            </aside>
          </div>

          {/* Artículos Recomendados al Final */}
          {relatedPosts.length > 0 && (
            <section className="related-articles-bottom-section">
              <div className="related-header">
                <Sparkles className="related-sparkle-icon" />
                <h2>Artículos Relacionados</h2>
              </div>

              <div className="related-grid-layout">
                {relatedPosts.map((r) => (
                  <Link href={`/posts/${r.slug}`} key={r.id} className="related-post-card-item">
                    {r.featuredImage ? (
                      <div className="related-img-wrap">
                        <img src={r.featuredImage} alt={r.title} />
                      </div>
                    ) : (
                      <div className="related-img-placeholder">
                        <Shield />
                      </div>
                    )}
                    <div className="related-body-info">
                      {r.category && <span className="related-cat-label">{r.category.name}</span>}
                      <h4>{r.title}</h4>
                      <span className="read-more-link">
                        Leer publicación <ArrowRight />
                      </span>
                    </div>
                  </Link>
                ))}
              </div>
            </section>
          )}
        </Container>
      </main>
      <Footer />

      <style>{`
        .single-post-main {
          min-height: calc(100vh - 200px);
          padding: 24px 0 64px;
        }

        /* Breadcrumbs */
        .post-breadcrumbs {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 12px;
          color: #94a3b8;
          margin-bottom: 28px;
          flex-wrap: wrap;
        }

        .post-breadcrumbs a {
          color: #94a3b8;
          transition: color 0.15s;
          text-decoration: none;
        }

        .post-breadcrumbs a:hover {
          color: #16c96f;
        }

        .crumb-sep {
          width: 14px;
          height: 14px;
          color: #475569;
          flex-shrink: 0;
        }

        .current-crumb {
          color: #e2e8f0;
          font-weight: 600;
          max-width: 320px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        /* 2-Column Grid Layout */
        .post-layout-grid {
          display: grid;
          grid-template-columns: minmax(0, 1fr) 340px;
          gap: 32px;
          align-items: start;
        }

        /* Main Left Column */
        .post-main-column {
          min-width: 0;
        }

        .post-content-article {
          background: linear-gradient(155deg, rgba(8, 23, 34, 0.95), rgba(4, 16, 26, 0.95));
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 14px;
          padding: 36px 40px;
          box-shadow: 0 16px 40px rgba(0, 0, 0, 0.4);
        }

        .post-category-badge-wrap {
          margin-bottom: 14px;
        }

        .post-cat-badge {
          display: inline-block;
          font-size: 11px;
          font-weight: 800;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          color: #16c96f;
          background: rgba(22, 201, 111, 0.12);
          border: 1px solid rgba(22, 201, 111, 0.3);
          padding: 4px 12px;
          border-radius: 20px;
        }

        /* TÍTULO H1 */
        .post-main-h1 {
          font-size: clamp(28px, 3.2vw, 42px);
          font-weight: 800;
          line-height: 1.18;
          color: #ffffff;
          letter-spacing: -1px;
          margin: 0 0 20px;
        }

        .post-meta-details-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding-bottom: 24px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
          margin-bottom: 28px;
          flex-wrap: wrap;
          gap: 16px;
        }

        .author-meta-box {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .author-avatar-badge {
          width: 44px;
          height: 44px;
          border-radius: 50%;
          overflow: hidden;
          background: linear-gradient(135deg, #12b85f, #24a8ff);
          display: grid;
          place-items: center;
          color: #030b12;
          flex-shrink: 0;
          box-shadow: 0 0 12px rgba(22, 201, 111, 0.35);
        }

        .author-avatar-badge img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .author-avatar-badge svg {
          width: 22px;
          height: 22px;
        }

        .author-names-group {
          display: flex;
          flex-direction: column;
        }

        .author-name-text {
          font-size: 14px;
          font-weight: 700;
          color: #ffffff;
        }

        .author-role-sub {
          font-size: 11px;
          color: #94a3b8;
        }

        .meta-stats-group {
          display: flex;
          align-items: center;
          gap: 20px;
        }

        .meta-stat-item {
          display: flex;
          align-items: center;
          gap: 6px;
          color: #94a3b8;
          font-size: 12px;
        }

        .stat-ico {
          width: 15px;
          height: 15px;
          color: #16c96f;
        }

        /* Hero Image */
        .post-featured-hero-image {
          border-radius: 10px;
          overflow: hidden;
          margin-bottom: 28px;
          border: 1px solid rgba(255, 255, 255, 0.1);
          max-height: 460px;
        }

        .post-featured-hero-image img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          display: block;
        }

        /* Lead Summary Box */
        .post-lead-summary-card {
          position: relative;
          background: rgba(3, 11, 18, 0.7);
          border: 1px solid rgba(56, 189, 248, 0.2);
          border-radius: 8px;
          padding: 18px 24px;
          margin-bottom: 32px;
        }

        .lead-accent-bar {
          position: absolute;
          left: 0;
          top: 0;
          bottom: 0;
          width: 4px;
          background: linear-gradient(180deg, #16c96f, #38bdf8);
          border-radius: 4px 0 0 4px;
        }

        .post-lead-summary-card p {
          font-size: 15px;
          line-height: 1.6;
          color: #cbd5e1;
          margin: 0;
          font-style: italic;
        }

        /* =========================================================
            TYPOGRAPHY & RICH CONTENT STYLING (FROM EDITOR)
            ========================================================= */
        .post-rich-html-content {
          font-size: 15px;
          line-height: 1.8;
          color: #e2e8f0;
        }

        .post-rich-html-content p {
          margin: 0 0 20px;
        }

        .post-rich-html-content h1,
        .post-rich-html-content h2,
        .post-rich-html-content h3,
        .post-rich-html-content h4 {
          color: #ffffff;
          font-weight: 800;
          letter-spacing: -0.5px;
          margin: 36px 0 16px;
          line-height: 1.3;
        }

        .post-rich-html-content h2 {
          font-size: 24px;
          padding-bottom: 8px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .post-rich-html-content h3 {
          font-size: 20px;
        }

        .post-rich-html-content h4 {
          font-size: 17px;
        }

        .post-rich-html-content a {
          color: #16c96f;
          text-decoration: underline;
          text-underline-offset: 3px;
          transition: color 0.15s;
        }

        .post-rich-html-content a:hover {
          color: #38bdf8;
        }

        .post-rich-html-content strong {
          color: #ffffff;
          font-weight: 700;
        }

        .post-rich-html-content ul,
        .post-rich-html-content ol {
          margin: 0 0 24px;
          padding-left: 24px;
        }

        .post-rich-html-content li {
          margin-bottom: 8px;
          color: #cbd5e1;
        }

        .post-rich-html-content blockquote {
          margin: 28px 0;
          padding: 16px 24px;
          background: rgba(3, 11, 18, 0.75);
          border-left: 4px solid #16c96f;
          border-radius: 0 8px 8px 0;
          color: #cbd5e1;
          font-style: italic;
          font-size: 15px;
        }

        .post-rich-html-content pre {
          background: #03080e !important;
          border: 1px solid rgba(56, 189, 248, 0.25) !important;
          border-radius: 8px !important;
          padding: 18px 20px !important;
          overflow-x: auto !important;
          margin: 24px 0 !important;
          font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace !important;
          font-size: 13px !important;
          line-height: 1.5 !important;
          color: #a7f3d0 !important;
        }

        .post-rich-html-content code {
          background: rgba(255, 255, 255, 0.08);
          color: #38bdf8;
          padding: 2px 6px;
          border-radius: 4px;
          font-size: 13px;
          font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        }

        .post-rich-html-content pre code {
          background: none;
          padding: 0;
          color: inherit;
        }

        .post-rich-html-content img {
          max-width: 100%;
          height: auto;
          border-radius: 8px;
          margin: 24px 0;
          border: 1px solid rgba(255, 255, 255, 0.08);
        }

        .post-rich-html-content table {
          width: 100%;
          border-collapse: collapse;
          margin: 24px 0;
          font-size: 13px;
        }

        .post-rich-html-content th,
        .post-rich-html-content td {
          padding: 10px 14px;
          border: 1px solid rgba(255, 255, 255, 0.08);
          text-align: left;
        }

        .post-rich-html-content th {
          background: rgba(22, 201, 111, 0.1);
          color: #ffffff;
          font-weight: 700;
        }

        /* Post Article Footer */
        .post-article-footer {
          margin-top: 36px;
          padding-top: 24px;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
        }

        .share-actions-group {
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 14px;
        }

        .share-label {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          color: #94a3b8;
          font-size: 13px;
          font-weight: 600;
        }

        .share-label svg {
          width: 16px;
          height: 16px;
          color: #16c96f;
        }

        .share-social-links {
          display: flex;
          gap: 10px;
        }

        .share-btn {
          padding: 6px 14px;
          border-radius: 6px;
          font-size: 11px;
          font-weight: 700;
          text-decoration: none;
          transition: all 0.2s;
          border: 1px solid transparent;
        }

        .share-btn.whatsapp {
          background: rgba(37, 211, 102, 0.12);
          color: #25d366;
          border-color: rgba(37, 211, 102, 0.3);
        }

        .share-btn.whatsapp:hover {
          background: #25d366;
          color: #030b12;
        }

        .share-btn.twitter {
          background: rgba(56, 189, 248, 0.12);
          color: #38bdf8;
          border-color: rgba(56, 189, 248, 0.3);
        }

        .share-btn.twitter:hover {
          background: #38bdf8;
          color: #030b12;
        }

        .share-btn.linkedin {
          background: rgba(10, 102, 194, 0.15);
          color: #60a5fa;
          border-color: rgba(10, 102, 194, 0.3);
        }

        .share-btn.linkedin:hover {
          background: #0a66c2;
          color: #ffffff;
        }

        /* =========================================================
            COLUMNA LATERAL DERECHA (SIDEBAR WIDGETS)
            ========================================================= */
        .post-sidebar-column {
          display: flex;
          flex-direction: column;
          gap: 24px;
          position: sticky;
          top: 90px;
        }

        .sidebar-widget-card {
          background: linear-gradient(155deg, rgba(8, 23, 34, 0.95), rgba(4, 16, 26, 0.95));
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 12px;
          padding: 22px;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.35);
        }

        .widget-header {
          display: flex;
          align-items: center;
          gap: 8px;
          padding-bottom: 12px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
          margin-bottom: 16px;
        }

        .widget-header h3 {
          font-size: 15px;
          font-weight: 700;
          color: #ffffff;
          margin: 0;
        }

        .widget-icon {
          width: 17px;
          height: 17px;
          color: #16c96f;
        }

        /* Categorías List */
        .categories-widget-list {
          list-style: none;
          padding: 0;
          margin: 0;
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .category-item-link {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 8px 12px;
          border-radius: 6px;
          color: #cbd5e1;
          font-size: 12px;
          font-weight: 600;
          text-decoration: none;
          transition: all 0.15s;
          border: 1px solid transparent;
        }

        .category-item-link:hover,
        .category-item-link.current-cat {
          background: rgba(22, 201, 111, 0.1);
          color: #16c96f;
          border-color: rgba(22, 201, 111, 0.25);
        }

        .cat-bullet {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #16c96f;
          margin-right: 8px;
          flex-shrink: 0;
        }

        .cat-name {
          flex: 1;
        }

        .cat-count {
          font-size: 10px;
          background: rgba(255, 255, 255, 0.06);
          padding: 2px 6px;
          border-radius: 12px;
          color: #94a3b8;
        }

        /* Etiquetas / Tags */
        .tags-cloud-wrap {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
        }

        .sidebar-tag-pill {
          font-size: 11px;
          font-weight: 600;
          color: #38bdf8;
          background: rgba(56, 189, 248, 0.1);
          border: 1px solid rgba(56, 189, 248, 0.25);
          padding: 4px 10px;
          border-radius: 6px;
          text-decoration: none;
          transition: all 0.15s;
        }

        .sidebar-tag-pill:hover,
        .sidebar-tag-pill.active-tag {
          background: #38bdf8;
          color: #030b12;
          box-shadow: 0 0 12px rgba(56, 189, 248, 0.4);
        }

        .empty-widget-text {
          color: #64748b;
          font-size: 12px;
          margin: 0;
        }

        /* Author Box */
        .author-box {
          text-align: center;
          padding: 24px 20px;
        }

        .author-card-avatar-wrap {
          width: 64px;
          height: 64px;
          border-radius: 50%;
          overflow: hidden;
          margin: 0 auto 12px;
          border: 2px solid #16c96f;
          box-shadow: 0 0 16px rgba(22, 201, 111, 0.35);
        }

        .author-card-avatar-wrap img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .avatar-placeholder {
          width: 100%;
          height: 100%;
          background: linear-gradient(135deg, #12b85f, #38bdf8);
          color: #030b12;
          font-size: 24px;
          font-weight: 800;
          display: grid;
          place-items: center;
        }

        .author-card-name {
          font-size: 16px;
          font-weight: 700;
          color: #ffffff;
          margin: 0 0 2px;
        }

        .author-card-title {
          font-size: 11px;
          color: #16c96f;
          display: block;
          margin-bottom: 10px;
        }

        .author-card-bio {
          font-size: 12px;
          line-height: 1.5;
          color: #94a3b8;
          margin: 0;
        }

        /* CTA Box */
        .cta-box {
          background: radial-gradient(circle at 80% 20%, rgba(22, 201, 111, 0.15), transparent 60%),
            linear-gradient(155deg, #071926, #030d15);
          border: 1px solid rgba(22, 201, 111, 0.3);
        }

        .cta-neon-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 10px;
          font-weight: 800;
          color: #16c96f;
          background: rgba(22, 201, 111, 0.15);
          padding: 3px 8px;
          border-radius: 4px;
          margin-bottom: 12px;
          text-transform: uppercase;
        }

        .cta-neon-badge svg {
          width: 12px;
          height: 12px;
        }

        .cta-box h4 {
          font-size: 15px;
          font-weight: 700;
          color: #ffffff;
          margin: 0 0 8px;
          line-height: 1.35;
        }

        .cta-box p {
          font-size: 12px;
          color: #94a3b8;
          margin: 0 0 16px;
          line-height: 1.5;
        }

        .sidebar-cta-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          width: 100%;
          padding: 10px 16px;
          border-radius: 8px;
          background: linear-gradient(110deg, #12b85f, #18d878);
          color: #030b12;
          font-weight: 700;
          font-size: 12px;
          text-decoration: none;
          box-shadow: 0 0 16px rgba(22, 201, 111, 0.3);
          transition: all 0.2s;
        }

        .sidebar-cta-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 0 22px rgba(22, 201, 111, 0.5);
          background: #20df7b;
        }

        .sidebar-cta-btn svg {
          width: 14px;
          height: 14px;
        }

        /* =========================================================
            BOTTOM RELATED POSTS SECTION
            ========================================================= */
        .related-articles-bottom-section {
          margin-top: 56px;
          padding-top: 36px;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
        }

        .related-header {
          display: flex;
          align-items: center;
          gap: 8px;
          margin-bottom: 24px;
        }

        .related-header h2 {
          font-size: 22px;
          font-weight: 700;
          color: #ffffff;
          margin: 0;
        }

        .related-sparkle-icon {
          width: 20px;
          height: 20px;
          color: #16c96f;
        }

        .related-grid-layout {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 20px;
        }

        .related-post-card-item {
          background: linear-gradient(145deg, rgba(8, 23, 34, 0.9), rgba(4, 16, 26, 0.9));
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 12px;
          overflow: hidden;
          text-decoration: none;
          transition: all 0.2s;
          display: flex;
          flex-direction: column;
        }

        .related-post-card-item:hover {
          transform: translateY(-3px);
          border-color: rgba(22, 201, 111, 0.35);
          box-shadow: 0 12px 30px rgba(0, 0, 0, 0.4);
        }

        .related-img-wrap {
          height: 140px;
          overflow: hidden;
        }

        .related-img-wrap img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          transition: transform 0.3s;
        }

        .related-post-card-item:hover .related-img-wrap img {
          transform: scale(1.04);
        }

        .related-img-placeholder {
          height: 140px;
          background: linear-gradient(135deg, #071926, #030e18);
          display: grid;
          place-items: center;
          color: #38bdf8;
        }

        .related-img-placeholder svg {
          width: 36px;
          height: 36px;
          opacity: 0.6;
        }

        .related-body-info {
          padding: 16px;
          display: flex;
          flex-direction: column;
          flex: 1;
        }

        .related-cat-label {
          font-size: 10px;
          font-weight: 700;
          text-transform: uppercase;
          color: #16c96f;
          margin-bottom: 6px;
        }

        .related-body-info h4 {
          font-size: 14px;
          font-weight: 700;
          color: #ffffff;
          margin: 0 0 12px;
          line-height: 1.4;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }

        .read-more-link {
          margin-top: auto;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 11px;
          font-weight: 600;
          color: #38bdf8;
        }

        .read-more-link svg {
          width: 12px;
          height: 12px;
          transition: transform 0.15s;
        }

        .related-post-card-item:hover .read-more-link svg {
          transform: translateX(3px);
        }

        /* 404 wrap */
        .post-not-found-wrap {
          min-height: calc(100vh - 200px);
          padding: 80px 0;
          display: flex;
          align-items: center;
        }

        .not-found-card {
          max-width: 500px;
          margin: 0 auto;
          text-align: center;
          background: #081722;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 14px;
          padding: 40px;
        }

        .error-code {
          font-size: 64px;
          font-weight: 900;
          color: #16c96f;
          display: block;
          line-height: 1;
          margin-bottom: 12px;
        }

        .not-found-card h1 {
          font-size: 22px;
          color: #ffffff;
          margin: 0 0 8px;
        }

        .not-found-card p {
          color: #94a3b8;
          font-size: 14px;
          margin: 0 0 24px;
        }

        .btn-return-blog {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: #16c96f;
          color: #030b12;
          font-weight: 700;
          font-size: 13px;
          padding: 10px 20px;
          border-radius: 8px;
          text-decoration: none;
        }

        /* Responsiveness */
        @media (max-width: 960px) {
          .post-layout-grid {
            grid-template-columns: 1fr;
          }
          .post-sidebar-column {
            position: static;
            margin-top: 24px;
          }
          .related-grid-layout {
            grid-template-columns: repeat(2, 1fr);
          }
        }

        @media (max-width: 640px) {
          .post-content-article {
            padding: 24px 18px;
          }
          .related-grid-layout {
            grid-template-columns: 1fr;
          }
          .post-meta-details-bar {
            flex-direction: column;
            align-items: flex-start;
          }
        }
      `}</style>
    </>
  );
}
