"use client";

import Link from "next/link";
import { AlertCircle, Home, ArrowLeft } from "lucide-react";

export default function NotFound() {
  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "#030a10",
        padding: "24px",
        color: "#f1f5f9",
        fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
      }}
    >
      <div
        style={{
          background: "#081520",
          border: "1px solid rgba(22, 201, 111, 0.2)",
          borderRadius: "16px",
          padding: "48px 36px",
          maxWidth: "520px",
          width: "100%",
          textAlign: "center",
          boxShadow: "0 20px 50px rgba(0, 0, 0, 0.6), 0 0 30px rgba(22, 201, 111, 0.08)",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <div
          style={{
            width: "64px",
            height: "64px",
            borderRadius: "50%",
            background: "rgba(22, 201, 111, 0.12)",
            border: "1px solid rgba(22, 201, 111, 0.3)",
            color: "#16c96f",
            display: "grid",
            placeItems: "center",
            marginBottom: "20px",
          }}
        >
          <AlertCircle style={{ width: "32px", height: "32px" }} />
        </div>

        <span
          style={{
            fontSize: "12px",
            fontWeight: 800,
            letterSpacing: "2px",
            color: "#16c96f",
            background: "rgba(22, 201, 111, 0.1)",
            padding: "4px 12px",
            borderRadius: "20px",
            marginBottom: "12px",
            border: "1px solid rgba(22, 201, 111, 0.25)",
          }}
        >
          ERROR 404
        </span>

        <h1
          style={{
            fontSize: "26px",
            fontWeight: 800,
            marginBottom: "10px",
            color: "#ffffff",
          }}
        >
          Página no encontrada
        </h1>

        <p
          style={{
            fontSize: "14px",
            color: "#94a3b8",
            lineHeight: 1.6,
            marginBottom: "28px",
          }}
        >
          La página o recurso que buscas no existe, ha sido movida o la dirección ingresada no es correcta.
        </p>

        <div
          style={{
            display: "flex",
            gap: "12px",
            width: "100%",
            justifyContent: "center",
            flexWrap: "wrap",
          }}
        >
          <Link
            href="/"
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "8px",
              background: "#16c96f",
              color: "#030b12",
              fontWeight: 700,
              fontSize: "13px",
              padding: "10px 20px",
              borderRadius: "8px",
              textDecoration: "none",
              boxShadow: "0 0 15px rgba(22, 201, 111, 0.3)",
            }}
          >
            <Home style={{ width: "16px", height: "16px" }} /> Volver al Inicio
          </Link>

          <Link
            href="/dashboard"
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "8px",
              background: "rgba(255, 255, 255, 0.05)",
              border: "1px solid rgba(255, 255, 255, 0.15)",
              color: "#e2e8f0",
              fontWeight: 600,
              fontSize: "13px",
              padding: "10px 20px",
              borderRadius: "8px",
              textDecoration: "none",
            }}
          >
            <ArrowLeft style={{ width: "16px", height: "16px" }} /> Ir al Panel
          </Link>
        </div>
      </div>
    </div>
  );
}
