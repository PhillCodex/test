"use client";

import { useActionState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { CircuitBoard, Lock, Mail, ArrowRight, ShieldCheck, AlertCircle } from "lucide-react";
import { loginAction } from "@/lib/actions/auth";

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const callbackUrl = searchParams.get("callbackUrl") || "/dashboard";
  const urlError = searchParams.get("error");

  const [state, formAction, isPending] = useActionState(
    async (prevState: { error?: string } | null, formData: FormData) => {
      const res = await loginAction(prevState, formData);
      if (!res.error) {
        router.push(callbackUrl);
        router.refresh();
      }
      return res;
    },
    null
  );

  const displayError = state?.error || urlError;

  return (
    <div className="login-box">
      <div className="login-header">
        <Link href="/" className="login-brand">
          <CircuitBoard />
          <span>
            <b>Tech<span>Lab</span></b>
            <small>Panel de Administración</small>
          </span>
        </Link>
        <h2>Iniciar Sesión</h2>
        <p>Ingresa con tu cuenta de Administrador para acceder al panel de control.</p>
      </div>

      {displayError && (
        <div className="login-error-alert" role="alert">
          <AlertCircle />
          <span>{displayError}</span>
        </div>
      )}

      <form action={formAction} className="login-form">
        <div className="form-group">
          <label htmlFor="email">Correo Electrónico</label>
          <div className="input-wrapper">
            <Mail />
            <input
              id="email"
              name="email"
              type="email"
              required
              placeholder="ejemplo@empresa.com"
              autoComplete="email"
            />
          </div>
        </div>

        <div className="form-group">
          <label htmlFor="password">Contraseña</label>
          <div className="input-wrapper">
            <Lock />
            <input
              id="password"
              name="password"
              type="password"
              required
              placeholder="••••••••••••"
              autoComplete="current-password"
            />
          </div>
        </div>

        <div className="login-helper">
          <div className="secure-badge">
            <ShieldCheck />
            <span>Conexión cifrada y segura</span>
          </div>
        </div>

        <button type="submit" className="login-submit-btn" disabled={isPending}>
          {isPending ? (
            <span>Autenticando...</span>
          ) : (
            <>
              <span>Acceder al Panel</span>
              <ArrowRight />
            </>
          )}
        </button>
      </form>

      <div className="login-footer">
        <Link href="/" className="back-link">
          ← Volver al sitio principal
        </Link>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <div className="login-container">
      <Suspense fallback={<div style={{ color: "#94a3b8" }}>Cargando panel...</div>}>
        <LoginForm />
      </Suspense>

      <style jsx>{`
        .login-container {
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          background: radial-gradient(circle at 50% 20%, rgba(36, 168, 255, 0.08), transparent 45%),
            radial-gradient(circle at 80% 80%, rgba(22, 201, 111, 0.06), transparent 40%),
            #030b12;
          padding: 24px;
          color: #f5f7fa;
          font-family: inherit;
        }

        :global(.login-box) {
          width: 100%;
          max-width: 440px;
          background: linear-gradient(155deg, rgba(8, 23, 34, 0.95), rgba(4, 16, 26, 0.95));
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 16px;
          padding: 36px 32px;
          box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5), 0 0 30px rgba(22, 201, 111, 0.05);
          backdrop-filter: blur(16px);
        }

        :global(.login-header) {
          text-align: center;
          margin-bottom: 28px;
        }

        :global(.login-brand) {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          color: inherit;
          text-decoration: none;
          margin-bottom: 18px;
        }

        :global(.login-brand svg) {
          width: 32px;
          height: 32px;
          color: #24a8ff;
        }

        :global(.login-brand b) {
          font-size: 24px;
          letter-spacing: -0.5px;
        }

        :global(.login-brand b span) {
          color: #16c96f;
        }

        :global(.login-brand small) {
          display: block;
          font-size: 10px;
          color: #94a3b8;
          font-weight: 400;
          margin-top: 1px;
        }

        :global(.login-header h2) {
          font-size: 20px;
          font-weight: 700;
          margin: 0 0 8px;
          letter-spacing: -0.3px;
        }

        :global(.login-header p) {
          font-size: 12px;
          color: #94a3b8;
          margin: 0;
          line-height: 1.5;
        }

        :global(.login-error-alert) {
          display: flex;
          align-items: center;
          gap: 10px;
          background: rgba(239, 68, 68, 0.12);
          border: 1px solid rgba(239, 68, 68, 0.35);
          color: #fca5a5;
          padding: 12px 14px;
          border-radius: 8px;
          font-size: 12px;
          margin-bottom: 20px;
        }

        :global(.login-error-alert svg) {
          width: 18px;
          height: 18px;
          flex-shrink: 0;
          color: #ef4444;
        }

        :global(.login-form) {
          display: flex;
          flex-direction: column;
          gap: 18px;
        }

        :global(.form-group) {
          display: flex;
          flex-direction: column;
          gap: 7px;
        }

        :global(.form-group label) {
          font-size: 12px;
          font-weight: 600;
          color: #cbd5df;
        }

        :global(.input-wrapper) {
          position: relative;
          display: flex;
          align-items: center;
        }

        :global(.input-wrapper svg) {
          position: absolute;
          left: 14px;
          width: 17px;
          height: 17px;
          color: #64748b;
          pointer-events: none;
          transition: color 0.2s;
        }

        :global(.input-wrapper input) {
          width: 100%;
          height: 44px;
          padding: 0 14px 0 42px;
          background: #05111a;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          color: #ffffff;
          font-size: 13px;
          outline: none;
          transition: all 0.2s;
        }

        :global(.input-wrapper input:focus) {
          border-color: #16c96f;
          box-shadow: 0 0 0 3px rgba(22, 201, 111, 0.12);
        }

        :global(.input-wrapper input:focus + svg),
        :global(.input-wrapper:focus-within svg) {
          color: #16c96f;
        }

        :global(.login-helper) {
          display: flex;
          align-items: center;
          justify-content: space-between;
          font-size: 11px;
        }

        :global(.secure-badge) {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          color: #16c96f;
          font-size: 11px;
        }

        :global(.secure-badge svg) {
          width: 14px;
          height: 14px;
        }

        :global(.login-submit-btn) {
          height: 44px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          border-radius: 8px;
          background: linear-gradient(110deg, #12b85f, #18d878);
          color: white;
          font-size: 13px;
          font-weight: 650;
          border: 1px solid rgba(67, 255, 147, 0.3);
          box-shadow: 0 8px 24px rgba(22, 201, 111, 0.2);
          cursor: pointer;
          transition: all 0.2s;
          margin-top: 6px;
        }

        :global(.login-submit-btn:hover:not(:disabled)) {
          transform: translateY(-1px);
          box-shadow: 0 10px 28px rgba(22, 201, 111, 0.3);
          background: #20df7b;
        }

        :global(.login-submit-btn:disabled) {
          opacity: 0.65;
          cursor: not-allowed;
        }

        :global(.login-submit-btn svg) {
          width: 16px;
          height: 16px;
        }

        :global(.login-footer) {
          margin-top: 24px;
          text-align: center;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
          padding-top: 18px;
        }

        :global(.back-link) {
          font-size: 12px;
          color: #94a3b8;
          text-decoration: none;
          transition: color 0.2s;
        }

        :global(.back-link:hover) {
          color: #16c96f;
        }
      `}</style>
    </div>
  );
}
