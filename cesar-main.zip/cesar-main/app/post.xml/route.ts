import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const settings = await prisma.siteSetting.findUnique({ where: { id: "general" } });
    const baseUrl = settings?.publicUrl || (new URL(req.url)).origin || "http://localhost:3000";

    const posts = await prisma.post.findMany({
      where: {
        status: { in: ["Publicado", "PUBLICADO", "published", "PUBLISHED"] },
      },
      orderBy: { updatedAt: "desc" },
      select: {
        slug: true,
        updatedAt: true,
        featuredImage: true,
        title: true,
      },
    });

    const urlEntries = posts
      .map((p) => {
        const url = `${baseUrl}/posts/${p.slug}`;
        const lastmod = p.updatedAt ? new Date(p.updatedAt).toISOString() : new Date().toISOString();
        const imageTag = p.featuredImage
          ? `\n    <image:image>\n      <image:loc>${p.featuredImage.startsWith("http") ? p.featuredImage : baseUrl + p.featuredImage}</image:loc>\n      <image:title>${p.title.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")}</image:title>\n    </image:image>`
          : "";

        return `  <url>
    <loc>${url}</loc>
    <lastmod>${lastmod}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>${imageTag}
  </url>`;
      })
      .join("\n");

    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="/sitemap.xsl"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
${urlEntries}
</urlset>`;

    return new NextResponse(xml, {
      headers: {
        "Content-Type": "application/xml; charset=utf-8",
        "Cache-Control": "public, s-maxage=3600, stale-while-revalidate=59",
      },
    });
  } catch (error) {
    console.error("Error al generar post.xml:", error);
    return new NextResponse("<error>Error al generar post.xml</error>", {
      status: 500,
      headers: { "Content-Type": "application/xml" },
    });
  }
}
