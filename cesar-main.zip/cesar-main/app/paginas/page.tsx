import type { Metadata } from "next";
import Link from "next/link";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import Container from "@/components/ui/Container";
import { prisma } from "@/lib/prisma";
import {
  FileText,
  ChevronRight,
  Sparkles,
  Calendar,
  Eye,
  ArrowRight,
} from "lucide-react";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Páginas | TechLab",
  description: "Directorio de páginas e información oficial de TechLab.",
};

export default async function PublicPagesDirectory() {
  const pages = await prisma.page.findMany({
    where: { status: "Publicado" },
    orderBy: { createdAt: "desc" },
    include: { author: { select: { name: true } } },
  });

  return (
    <>
      <Header />
      <main className="pages-directory-main">
        <Container>
          {/* Header */}
          <div className="directory-hero">
            <div className="badge-chip">
              <Sparkles className="badge-ico" /> Directorio de Páginas
            </div>
            <h1>Páginas y Documentación</h1>
            <p>Explora todas las secciones, políticas e información relevante de nuestro sitio web.</p>
          </div>

          {/* Grid de Páginas */}
          <div className="pages-grid">
            {pages.map((p) => {
              const formattedDate = new Date(p.createdAt).toLocaleDateString("es-ES", {
                day: "numeric",
                month: "short",
                year: "numeric",
              });

              return (
                <Link key={p.id} href={"/paginas/" + p.slug} className="page-dir-card">
                  <div className="card-top">
                    <div className="page-icon-badge">
                      <FileText />
                    </div>
                    <span className="card-views">
                      <Eye className="ico" /> {p.views} vistas
                    </span>
                  </div>

                  <h3>{p.title}</h3>
                  <p className="card-desc">
                    {p.seoDescription || "Conoce todos los detalles sobre esta sección especializada de TechLab."}
                  </p>

                  <div className="card-footer">
                    <span className="card-date">
                      <Calendar className="ico" /> {formattedDate}
                    </span>
                    <span className="card-read-link">
                      Leer página <ArrowRight className="arr" />
                    </span>
                  </div>
                </Link>
              );
            })}
          </div>
        </Container>
      </main>
      <Footer />

      <style>{`
        .pages-directory-main {
          min-height: 85vh;
          background: #02070c;
          padding: 60px 0 100px;
          color: #f1f5f9;
        }

        .directory-hero {
          text-align: center;
          max-width: 650px;
          margin: 0 auto 50px;
        }

        .badge-chip {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          background: rgba(22, 201, 111, 0.12);
          border: 1px solid rgba(22, 201, 111, 0.3);
          color: #16c96f;
          font-size: 12px;
          font-weight: 700;
          padding: 4px 12px;
          border-radius: 20px;
          margin-bottom: 16px;
        }

        .badge-chip :global(.badge-ico) {
          width: 13px;
          height: 13px;
        }

        h1 {
          font-size: clamp(28px, 4vw, 40px);
          font-weight: 800;
          color: #ffffff;
          margin-bottom: 12px;
        }

        .directory-hero p {
          color: #94a3b8;
          font-size: 15px;
          line-height: 1.6;
        }

        .pages-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
          gap: 20px;
        }

        .page-dir-card {
          background: #06111d;
          border: 1px solid rgba(56, 189, 248, 0.15);
          border-radius: 12px;
          padding: 24px;
          text-decoration: none;
          display: flex;
          flex-direction: column;
          transition: transform 0.2s, border-color 0.2s, box-shadow 0.2s;
        }

        .page-dir-card:hover {
          transform: translateY(-4px);
          border-color: #38bdf8;
          box-shadow: 0 12px 30px rgba(0, 0, 0, 0.5), 0 0 20px rgba(56, 189, 248, 0.1);
        }

        .card-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 16px;
        }

        .page-icon-badge {
          width: 40px;
          height: 40px;
          border-radius: 8px;
          background: rgba(56, 189, 248, 0.12);
          border: 1px solid rgba(56, 189, 248, 0.3);
          color: #38bdf8;
          display: grid;
          place-items: center;
        }

        .page-icon-badge :global(svg) {
          width: 20px;
          height: 20px;
        }

        .card-views {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          font-size: 11px;
          color: #64748b;
        }

        .card-views :global(.ico) {
          width: 12px;
          height: 12px;
        }

        .page-dir-card h3 {
          font-size: 18px;
          font-weight: 700;
          color: #ffffff;
          margin-bottom: 8px;
          line-height: 1.35;
        }

        .card-desc {
          font-size: 13px;
          color: #94a3b8;
          line-height: 1.6;
          margin-bottom: 20px;
          flex-grow: 1;
        }

        .card-footer {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding-top: 14px;
          border-top: 1px solid rgba(255, 255, 255, 0.06);
          font-size: 12px;
        }

        .card-date {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          color: #64748b;
        }

        .card-date :global(.ico) {
          width: 12px;
          height: 12px;
        }

        .card-read-link {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          color: #16c96f;
          font-weight: 700;
        }

        .card-read-link :global(.arr) {
          width: 14px;
          height: 14px;
          transition: transform 0.15s;
        }

        .page-dir-card:hover .card-read-link :global(.arr) {
          transform: translateX(3px);
        }
      `}</style>
    </>
  );
}
