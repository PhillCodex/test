import type { Metadata } from "next";
import Link from "next/link";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import Container from "@/components/ui/Container";
import { prisma } from "@/lib/prisma";
import { renderElementorContent } from "@/lib/elementor-renderer";
import {
  ChevronRight,
  ArrowLeft,
  Calendar,
  Clock,
  User,
  Share2,
  Sparkles,
  FileText,
  AlertTriangle,
} from "lucide-react";

export const dynamic = "force-dynamic";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const decoded = decodeURIComponent(slug);
  const normalized = decoded
    .toLowerCase()
    .trim()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-+|-+$/g, "");

  const page = await prisma.page.findFirst({
    where: {
      OR: [{ slug }, { slug: decoded }, { slug: normalized }, { id: slug }],
    },
  });

  if (!page) {
    return {
      title: "Página no encontrada | TechLab",
    };
  }

  const settings = await prisma.siteSetting.findUnique({ where: { id: "general" } }).catch(() => null);
  const siteTitle = settings?.siteTitle || "TechLab";
  const title = page.seoTitle || (page.title + " - " + siteTitle);
  const description =
    page.seoDescription || "Página informativa especializada en tecnología, software y ciberseguridad.";

  return {
    title,
    description,
    openGraph: {
      title,
      description,
      images: page.featuredImage ? [{ url: page.featuredImage }] : [],
    },
  };
}

export default async function PublicSinglePage({ params }: PageProps) {
  const { slug } = await params;
  const decoded = decodeURIComponent(slug);
  const normalized = decoded
    .toLowerCase()
    .trim()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-+|-+$/g, "");

  const page = await prisma.page.findFirst({
    where: {
      OR: [{ slug }, { slug: decoded }, { slug: normalized }, { id: slug }],
    },
    include: {
      author: { select: { id: true, name: true, avatar: true } },
      parent: { select: { id: true, title: true, slug: true } },
      children: { select: { id: true, title: true, slug: true } },
    },
  });

  if (!page) {
    return (
      <>
        <Header />
        <main className="page-not-found-wrap">
          <Container>
            <div className="not-found-card">
              <span className="error-code">404</span>
              <h1>Página no encontrada</h1>
              <p>La página que buscas no existe o ha sido movida a otra ubicación.</p>
              <Link href="/" className="btn-return-home">
                <ArrowLeft /> Volver al Inicio
              </Link>
            </div>
          </Container>
        </main>
        <Footer />
        <style>{`
          .page-not-found-wrap {
            min-height: 70vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 80px 20px;
            background: #03070b;
          }
          .not-found-card {
            background: #07131e;
            border: 1px solid rgba(56, 189, 248, 0.2);
            border-radius: 16px;
            padding: 50px 30px;
            text-align: center;
            max-width: 500px;
            margin: 0 auto;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.6);
          }
          .error-code {
            font-size: 14px;
            font-weight: 800;
            color: #16c96f;
            background: rgba(22, 201, 111, 0.12);
            padding: 4px 12px;
            border-radius: 20px;
            display: inline-block;
            margin-bottom: 16px;
          }
          .not-found-card h1 {
            font-size: 28px;
            font-weight: 800;
            color: #ffffff;
            margin-bottom: 12px;
          }
          .not-found-card p {
            color: #94a3b8;
            font-size: 15px;
            margin-bottom: 24px;
          }
          .btn-return-home {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: linear-gradient(110deg, #12b85f, #18d878);
            color: #030b12;
            font-weight: 700;
            font-size: 14px;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
          }
        `}</style>
      </>
    );
  }

  // Incrementar vistas
  try {
    await prisma.page.update({
      where: { id: page.id },
      data: { views: { increment: 1 } },
    });
  } catch (e) {
    // Ignorar en solo lectura
  }

  const formattedDate = new Date(page.createdAt).toLocaleDateString("es-ES", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const readTime = Math.max(2, Math.ceil((page.content?.length || 400) / 450)) + " min de lectura";
  const renderedHtml = renderElementorContent(page.content);

  // Si la plantilla es Canvas Elementor
  if (page.template === "elementor_canvas") {
    return (
      <main className="elementor-canvas-wrapper">
        <div
          className="elementor-canvas-content"
          dangerouslySetInnerHTML={{ __html: renderedHtml }}
        />
        <style>{`
          .elementor-canvas-wrapper {
            min-height: 100vh;
            background: #03070b;
            color: #f1f5f9;
          }
          .elementor-rendered-root {
            width: 100%;
          }
        `}</style>
      </main>
    );
  }

  return (
    <>
      <Header />
      <main className="public-single-page-wrap">
        <Container>
          {/* Breadcrumbs */}
          <nav className="page-breadcrumbs" aria-label="Ruta de navegación">
            <Link href="/">Inicio</Link>
            <ChevronRight className="crumb-sep" />
            {page.parent ? (
              <>
                <Link href={"/paginas/" + page.parent.slug}>{page.parent.title}</Link>
                <ChevronRight className="crumb-sep" />
              </>
            ) : null}
            <span className="current-crumb">{page.title}</span>
          </nav>

          {/* Aviso si la página está en Borrador */}
          {page.status !== "Publicado" && (
            <div className="draft-notice-banner">
              <AlertTriangle className="draft-notice-ico" />
              <span>
                <strong>Modo Vista Previa:</strong> Esta página está guardada como <em>{page.status}</em>. Puedes publicarla desde el panel para hacerla pública.
              </span>
              <Link href={"/dashboard/paginas/nuevo?edit=" + page.id} className="draft-edit-link">
                Editar en Panel
              </Link>
            </div>
          )}

          {/* Page Card Wrapper */}
          <article className="public-page-card">
            {/* Header Hero */}
            <div className="page-hero-header">
              <div className="page-badge-row">
                <span className="page-category-badge">
                  <Sparkles className="badge-ico" /> Página Informativa
                </span>
                <span className="page-meta-stat">
                  <Clock className="stat-ico" /> {readTime}
                </span>
                <span className="page-meta-stat">
                  <Calendar className="stat-ico" /> {formattedDate}
                </span>
              </div>

              <h1 className="page-main-title">{page.title}</h1>

              {page.author && (
                <div className="page-author-row">
                  <div className="author-avatar-badge">
                    {page.author.avatar ? (
                      <img src={page.author.avatar} alt={page.author.name} />
                    ) : (
                      <User />
                    )}
                  </div>
                  <div className="author-info">
                    <strong>{page.author.name}</strong>
                    <span>Publicado por el equipo editorial</span>
                  </div>
                </div>
              )}
            </div>

            {/* Imagen Destacada si existe */}
            {page.featuredImage && (
              <div className="page-featured-media">
                <img src={page.featuredImage} alt={page.title} />
              </div>
            )}

            {/* Cuerpo del Contenido HTML */}
            <div
              className="page-rich-content"
              dangerouslySetInnerHTML={{ __html: renderedHtml }}
            />

            {/* Subpáginas / Páginas Hijas si existen */}
            {page.children && page.children.length > 0 && (
              <div className="page-subpages-section">
                <h3>Subpáginas y Secciones Relacionadas:</h3>
                <div className="subpages-grid">
                  {page.children.map((child) => (
                    <Link
                      key={child.id}
                      href={"/paginas/" + child.slug}
                      className="subpage-card-link"
                    >
                      <FileText className="subpage-ico" />
                      <span>{child.title}</span>
                      <ChevronRight className="subpage-arr" />
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {/* Footer de la Página */}
            <div className="page-card-footer">
              <div className="share-box">
                <span className="share-title">
                  <Share2 className="share-ico" /> Compartir:
                </span>
                <div className="share-buttons">
                  <a
                    href={"https://wa.me/?text=" + encodeURIComponent(page.title + " https://cesar-one.vercel.app/paginas/" + page.slug)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-share whatsapp"
                  >
                    WhatsApp
                  </a>
                  <a
                    href={"https://twitter.com/intent/tweet?text=" + encodeURIComponent(page.title) + "&url=" + encodeURIComponent("https://cesar-one.vercel.app/paginas/" + page.slug)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-share twitter"
                  >
                    X (Twitter)
                  </a>
                  <a
                    href={"https://www.linkedin.com/sharing/share-offsite/?url=" + encodeURIComponent("https://cesar-one.vercel.app/paginas/" + page.slug)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-share linkedin"
                  >
                    LinkedIn
                  </a>
                </div>
              </div>
            </div>
          </article>
        </Container>
      </main>
      <Footer />

      <style>{`
        .public-single-page-wrap {
          min-height: 85vh;
          background: #02070c;
          padding: 30px 0 80px;
          color: #f1f5f9;
        }

        /* Breadcrumbs */
        .page-breadcrumbs {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 13px;
          color: #64748b;
          margin-bottom: 24px;
          flex-wrap: wrap;
        }

        .page-breadcrumbs a {
          color: #94a3b8;
          text-decoration: none;
          transition: color 0.15s;
        }

        .page-breadcrumbs a:hover {
          color: #38bdf8;
        }

        .page-breadcrumbs .crumb-sep {
          width: 14px;
          height: 14px;
          opacity: 0.5;
        }

        .current-crumb {
          color: #cbd5e1;
          font-weight: 600;
        }

        /* Draft Notice Banner */
        .draft-notice-banner {
          background: rgba(245, 158, 11, 0.1);
          border: 1px solid rgba(245, 158, 11, 0.35);
          border-radius: 10px;
          padding: 12px 18px;
          margin-bottom: 24px;
          display: flex;
          align-items: center;
          gap: 12px;
          color: #fcd34d;
          font-size: 13px;
        }

        .draft-notice-ico {
          width: 18px;
          height: 18px;
          flex-shrink: 0;
          color: #f59e0b;
        }

        .draft-edit-link {
          margin-left: auto;
          background: #f59e0b;
          color: #03080e;
          font-weight: 700;
          font-size: 12px;
          padding: 4px 12px;
          border-radius: 6px;
          text-decoration: none;
          white-space: nowrap;
        }

        /* Card Principal */
        .public-page-card {
          background: #06111d;
          border: 1px solid rgba(56, 189, 248, 0.18);
          border-radius: 16px;
          padding: 48px clamp(20px, 5vw, 60px);
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.6), 0 0 30px rgba(56, 189, 248, 0.04);
          max-width: 980px;
          margin: 0 auto;
        }

        /* Hero Header */
        .page-hero-header {
          height: auto !important;
          position: static !important;
          background: transparent !important;
          border: none !important;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
          padding-bottom: 28px !important;
          margin-bottom: 36px !important;
          backdrop-filter: none !important;
          z-index: auto !important;
          display: block !important;
        }

        .page-badge-row {
          display: flex;
          align-items: center;
          gap: 16px;
          margin-bottom: 18px;
          flex-wrap: wrap;
        }

        .page-category-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          background: rgba(22, 201, 111, 0.12);
          border: 1px solid rgba(22, 201, 111, 0.3);
          color: #16c96f;
          font-size: 11px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          padding: 4px 10px;
          border-radius: 6px;
        }

        .page-category-badge .badge-ico {
          width: 12px;
          height: 12px;
        }

        .page-meta-stat {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 12px;
          color: #94a3b8;
        }

        .page-meta-stat .stat-ico {
          width: 13px;
          height: 13px;
          color: #38bdf8;
        }

        .page-main-title {
          font-size: clamp(28px, 4.5vw, 42px) !important;
          font-weight: 800 !important;
          line-height: 1.25 !important;
          color: #ffffff !important;
          margin: 0 0 24px 0 !important;
          letter-spacing: -0.5px !important;
          display: block !important;
        }

        .page-author-row {
          display: flex;
          align-items: center;
          gap: 12px;
          margin-top: 10px;
        }

        .author-avatar-badge {
          width: 38px;
          height: 38px;
          border-radius: 50%;
          background: #0f2336;
          border: 1px solid rgba(56, 189, 248, 0.3);
          display: grid;
          place-items: center;
          overflow: hidden;
          color: #38bdf8;
          flex-shrink: 0;
        }

        .author-avatar-badge img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .author-avatar-badge svg {
          width: 18px;
          height: 18px;
        }

        .author-info {
          display: flex;
          flex-direction: column;
        }

        .author-info strong {
          font-size: 13px;
          color: #f1f5f9;
        }

        .author-info span {
          font-size: 11px;
          color: #64748b;
        }

        /* Imagen Destacada */
        .page-featured-media {
          margin-bottom: 36px;
          border-radius: 12px;
          overflow: hidden;
          border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .page-featured-media img {
          width: 100%;
          max-height: 480px;
          object-fit: cover;
          display: block;
        }

        /* Contenido de Texto / Párrafos */
        .page-rich-content {
          font-size: 16px;
          line-height: 1.85;
          color: #cbd5e1;
          display: block;
          margin-top: 12px;
        }

        .page-rich-content p {
          margin: 0 0 20px 0;
          line-height: 1.85;
          color: #cbd5e1;
          font-size: 16px;
          display: block;
        }

        .page-rich-content h2 {
          font-size: 26px;
          font-weight: 800;
          color: #ffffff;
          margin: 40px 0 16px;
          border-left: 4px solid #16c96f;
          padding-left: 12px;
          display: block;
        }

        .page-rich-content h3 {
          font-size: 20px;
          font-weight: 700;
          color: #ffffff;
          margin: 32px 0 14px;
          display: block;
        }

        .page-rich-content h4 {
          font-size: 17px;
          font-weight: 600;
          color: #38bdf8;
          margin: 24px 0 10px;
          display: block;
        }

        .page-rich-content ul,
        .page-rich-content ol {
          margin: 16px 0 24px 24px;
          padding-left: 8px;
        }

        .page-rich-content li {
          margin-bottom: 8px;
          line-height: 1.7;
        }

        .page-rich-content blockquote {
          background: rgba(56, 189, 248, 0.04);
          border-left: 3px solid #38bdf8;
          padding: 16px 20px;
          border-radius: 0 8px 8px 0;
          margin: 24px 0;
          color: #94a3b8;
          font-style: italic;
        }

        .page-rich-content pre {
          background: #03080e;
          border: 1px solid rgba(255, 255, 255, 0.1);
          padding: 16px;
          border-radius: 8px;
          overflow-x: auto;
          margin: 24px 0;
          color: #38bdf8;
        }

        .page-rich-content img {
          max-width: 100%;
          border-radius: 8px;
          margin: 20px 0;
        }

        .page-rich-content a {
          color: #38bdf8;
          text-decoration: underline;
        }

        /* Subpáginas */
        .page-subpages-section {
          margin-top: 48px;
          padding-top: 28px;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
        }

        .page-subpages-section h3 {
          font-size: 16px;
          font-weight: 700;
          color: #cbd5e1;
          margin-bottom: 16px;
        }

        .subpages-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
          gap: 12px;
        }

        .subpage-card-link {
          display: flex;
          align-items: center;
          gap: 10px;
          background: #071522;
          border: 1px solid rgba(56, 189, 248, 0.2);
          border-radius: 8px;
          padding: 12px 16px;
          color: #f1f5f9;
          text-decoration: none;
          font-size: 13px;
          font-weight: 600;
          transition: border-color 0.15s, background-color 0.15s;
        }

        .subpage-card-link:hover {
          border-color: #38bdf8;
          background: rgba(56, 189, 248, 0.08);
          color: #38bdf8;
        }

        .subpage-card-link .subpage-ico {
          width: 16px;
          height: 16px;
          color: #16c96f;
        }

        .subpage-card-link .subpage-arr {
          width: 14px;
          height: 14px;
          margin-left: auto;
          color: #64748b;
        }

        /* Footer Card */
        .page-card-footer {
          margin-top: 48px;
          padding-top: 24px;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
        }

        .share-box {
          display: flex;
          align-items: center;
          gap: 16px;
          flex-wrap: wrap;
        }

        .share-title {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 13px;
          font-weight: 700;
          color: #94a3b8;
        }

        .share-title .share-ico {
          width: 14px;
          height: 14px;
        }

        .share-buttons {
          display: flex;
          align-items: center;
          gap: 8px;
          flex-wrap: wrap;
        }

        .btn-share {
          font-size: 12px;
          font-weight: 600;
          padding: 6px 12px;
          border-radius: 6px;
          text-decoration: none;
          display: inline-flex;
          align-items: center;
          transition: opacity 0.15s;
        }

        .btn-share:hover {
          opacity: 0.85;
        }

        .btn-share.whatsapp {
          background: #25d366;
          color: #030a10;
        }

        .btn-share.twitter {
          background: #1d9bf0;
          color: #ffffff;
        }

        .btn-share.linkedin {
          background: #0a66c2;
          color: #ffffff;
        }
      `}</style>
    </>
  );
}
