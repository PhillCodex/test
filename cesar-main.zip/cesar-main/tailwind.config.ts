import type { Config } from "tailwindcss";
export default {content:["./app/**/*.{ts,tsx}","./components/**/*.{ts,tsx}"],theme:{extend:{colors:{ink:"#030B12",panel:"#07131D",green:"#16C96F",cyan:"#24A8FF"}}},plugins:[]} satisfies Config;
