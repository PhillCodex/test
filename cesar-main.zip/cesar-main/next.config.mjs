/** @type {import('next').NextConfig} */
const nextConfig = {
  outputFileTracingIncludes: {
    '/*': ['./certs/**/*', './prisma/**/*'],
    '/**/*': ['./certs/**/*', './prisma/**/*'],
  },
};

export default nextConfig;
