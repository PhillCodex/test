import { NextResponse } from "next/server";
import type { NextRequest } from "next/request";
import { jwtVerify } from "jose";

const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || "techlab-super-secure-jwt-key-2026-auth-cesar"
);

const COOKIE_NAME = "techlab_session";

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const token = request.cookies.get(COOKIE_NAME)?.value;

  let sessionUser: { role?: string; email?: string } | null = null;

  if (token) {
    try {
      const { payload } = await jwtVerify(token, JWT_SECRET);
      sessionUser = payload as { role?: string; email?: string };
    } catch {
      sessionUser = null;
    }
  }

  // Rutas protegidas del Dashboard
  if (pathname.startsWith("/dashboard")) {
    if (!sessionUser) {
      const loginUrl = new URL("/login", request.url);
      loginUrl.searchParams.set("callbackUrl", pathname);
      return NextResponse.redirect(loginUrl);
    }

    if (sessionUser.role !== "ADMIN") {
      const loginUrl = new URL("/login", request.url);
      loginUrl.searchParams.set(
        "error",
        "Solo los usuarios con rol Administrador pueden acceder al panel."
      );
      return NextResponse.redirect(loginUrl);
    }

    return NextResponse.next();
  }

  // Si ya está autenticado como ADMIN e intenta entrar a /login, redirigir a /dashboard
  if (pathname === "/login" && sessionUser?.role === "ADMIN") {
    return NextResponse.redirect(new URL("/dashboard", request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/dashboard/:path*", "/login"],
};
