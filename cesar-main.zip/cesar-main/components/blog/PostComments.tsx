"use client";

import { useState, useEffect } from "react";
import { MessageSquare, Send, CheckCircle2, AlertCircle, User, Clock, CornerDownRight, Sparkles } from "lucide-react";

interface CommentItem {
  id: string;
  authorName: string;
  authorEmail: string;
  authorUrl?: string | null;
  content: string;
  status: string;
  createdAt: string;
  replies?: CommentItem[];
}

interface PostCommentsProps {
  postId: string;
  postSlug: string;
  initialComments?: CommentItem[];
}

export default function PostComments({ postId, postSlug, initialComments = [] }: PostCommentsProps) {
  const [comments, setComments] = useState<CommentItem[]>(initialComments);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Form State
  const [authorName, setAuthorName] = useState("");
  const [authorEmail, setAuthorEmail] = useState("");
  const [authorUrl, setAuthorUrl] = useState("");
  const [content, setContent] = useState("");
  const [replyToId, setReplyToId] = useState<string | null>(null);
  const [replyToName, setReplyToName] = useState<string | null>(null);

  // Feedback State
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    fetchComments();
  }, [postId]);

  const fetchComments = async () => {
    try {
      setLoading(true);
      const res = await fetch(`/api/comments?postId=${postId}&status=APROBADO`);
      const data = await res.json();
      if (data.success && Array.isArray(data.comments)) {
        setComments(data.comments);
      }
    } catch (err) {
      console.error("Error fetching comments:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!authorName.trim()) {
      setErrorMsg("Por favor escribe tu nombre.");
      return;
    }
    if (!authorEmail.trim() || !authorEmail.includes("@")) {
      setErrorMsg("Por favor ingresa un correo electrónico válido.");
      return;
    }
    if (!content.trim()) {
      setErrorMsg("Por favor escribe tu comentario.");
      return;
    }

    try {
      setSubmitting(true);
      const res = await fetch("/api/comments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          postId,
          postSlug,
          authorName: authorName.trim(),
          authorEmail: authorEmail.trim(),
          authorUrl: authorUrl.trim() || null,
          content: content.trim(),
          parentId: replyToId,
        }),
      });

      const data = await res.json();

      if (data.success) {
        setSuccessMsg(data.message || "¡Comentario enviado! Aparecerá una vez aprobado.");
        setContent("");
        setReplyToId(null);
        setReplyToName(null);
      } else {
        setErrorMsg(data.error || "Ocurrió un error al enviar tu comentario.");
      }
    } catch (err) {
      setErrorMsg("Error de conexión al servidor. Inténtalo de nuevo.");
    } finally {
      setSubmitting(false);
    }
  };

  const getInitials = (name: string) => {
    if (!name) return "U";
    return name.slice(0, 2).toUpperCase();
  };

  const formatDate = (dateStr: string) => {
    try {
      return new Date(dateStr).toLocaleDateString("es-ES", {
        day: "numeric",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch {
      return "Hace poco";
    }
  };

  return (
    <section className="post-comments-section" id="comentarios">
      <div className="comments-header">
        <div className="comments-title-wrap">
          <MessageSquare className="comments-icon-glow" />
          <h3>
            Comentarios <span>({comments.length})</span>
          </h3>
        </div>
        <p className="comments-subtitle">
          ¿Tienes alguna duda o aporte sobre esta publicación? Comparte tu opinión con la comunidad.
        </p>
      </div>

      {/* Lista de Comentarios Aprobados */}
      <div className="comments-list-container">
        {comments.length === 0 ? (
          <div className="no-comments-box">
            <Sparkles />
            <p>Sé el primero en dejar un comentario en esta publicación.</p>
          </div>
        ) : (
          <div className="comments-flow">
            {comments.map((c) => (
              <div key={c.id} className="comment-card">
                <div className="comment-avatar">
                  <span>{getInitials(c.authorName)}</span>
                </div>
                <div className="comment-body">
                  <div className="comment-meta-row">
                    <div className="author-info">
                      <strong className="author-name">{c.authorName}</strong>
                      {c.authorUrl && (
                        <a
                          href={c.authorUrl.startsWith("http") ? c.authorUrl : `https://${c.authorUrl}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="author-site-badge"
                        >
                          Sitio Web
                        </a>
                      )}
                    </div>
                    <span className="comment-date">
                      <Clock />
                      {formatDate(c.createdAt)}
                    </span>
                  </div>

                  <p className="comment-text-content">{c.content}</p>

                  <div className="comment-actions-row">
                    <button
                      type="button"
                      className="btn-reply-link"
                      onClick={() => {
                        setReplyToId(c.id);
                        setReplyToName(c.authorName);
                        document.getElementById("comment-form-target")?.scrollIntoView({ behavior: "smooth" });
                      }}
                    >
                      <CornerDownRight /> Responder
                    </button>
                  </div>

                  {/* Respuestas anidadas */}
                  {c.replies && c.replies.length > 0 && (
                    <div className="comment-replies-list">
                      {c.replies.map((reply) => (
                        <div key={reply.id} className="reply-card">
                          <div className="comment-avatar small">
                            <span>{getInitials(reply.authorName)}</span>
                          </div>
                          <div className="comment-body">
                            <div className="comment-meta-row">
                              <strong className="author-name">{reply.authorName}</strong>
                              <span className="comment-date">{formatDate(reply.createdAt)}</span>
                            </div>
                            <p className="comment-text-content">{reply.content}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Formulario AJAX de Comentarios */}
      <div className="comment-form-container" id="comment-form-target">
        <div className="form-heading">
          <h4>
            {replyToName ? (
              <>
                Respondiendo a <span className="replying-name">{replyToName}</span>
                <button
                  type="button"
                  className="btn-cancel-reply"
                  onClick={() => {
                    setReplyToId(null);
                    setReplyToName(null);
                  }}
                >
                  (Cancelar respuesta)
                </button>
              </>
            ) : (
              "Dejar un Comentario"
            )}
          </h4>
          <span className="form-disclaimer">Tu dirección de correo electrónico no será publicada. Los campos obligatorios están marcados con *</span>
        </div>

        {/* Alerta de Éxito */}
        {successMsg && (
          <div className="ajax-alert success">
            <CheckCircle2 />
            <div>
              <strong>¡Comentario Enviado!</strong>
              <p>{successMsg}</p>
            </div>
          </div>
        )}

        {/* Alerta de Error */}
        {errorMsg && (
          <div className="ajax-alert error">
            <AlertCircle />
            <div>
              <strong>No se pudo enviar</strong>
              <p>{errorMsg}</p>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="ajax-comment-form">
          <div className="form-grid-fields">
            <div className="field-group">
              <label htmlFor="c-name">
                Nombre <span className="req">*</span>
              </label>
              <input
                id="c-name"
                type="text"
                placeholder="ej. Juan Pérez"
                value={authorName}
                onChange={(e) => setAuthorName(e.target.value)}
                required
                disabled={submitting}
              />
            </div>

            <div className="field-group">
              <label htmlFor="c-email">
                Correo Electrónico <span className="req">*</span>
              </label>
              <input
                id="c-email"
                type="email"
                placeholder="ej. juan@ejemplo.com"
                value={authorEmail}
                onChange={(e) => setAuthorEmail(e.target.value)}
                required
                disabled={submitting}
              />
            </div>

            <div className="field-group full-width">
              <label htmlFor="c-url">
                Sitio Web / Red Social <small>(Opcional)</small>
              </label>
              <input
                id="c-url"
                type="url"
                placeholder="https://tusitio.com"
                value={authorUrl}
                onChange={(e) => setAuthorUrl(e.target.value)}
                disabled={submitting}
              />
            </div>

            <div className="field-group full-width">
              <label htmlFor="c-content">
                Comentario <span className="req">*</span>
              </label>
              <textarea
                id="c-content"
                rows={5}
                placeholder="Escribe aquí tu opinión, consulta o recomendación sobre este artículo..."
                value={content}
                onChange={(e) => setContent(e.target.value)}
                required
                disabled={submitting}
              />
            </div>
          </div>

          <div className="form-submit-row">
            <button type="submit" className="btn-submit-comment" disabled={submitting}>
              {submitting ? (
                <>
                  <span className="spinner-icon">⏳</span> Enviando comentario...
                </>
              ) : (
                <>
                  <Send /> Publicar Comentario
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      <style jsx>{`
        .post-comments-section {
          margin-top: 48px;
          padding-top: 36px;
          border-top: 1px solid rgba(255, 255, 255, 0.09);
        }

        .comments-header {
          margin-bottom: 28px;
        }

        .comments-title-wrap {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .comments-title-wrap h3 {
          font-size: 22px;
          font-weight: 700;
          color: #ffffff;
          margin: 0;
          letter-spacing: -0.5px;
        }

        .comments-title-wrap h3 span {
          color: #16c96f;
          font-size: 18px;
        }

        :global(.comments-icon-glow) {
          width: 22px;
          height: 22px;
          color: #16c96f;
          filter: drop-shadow(0 0 8px rgba(22, 201, 111, 0.5));
        }

        .comments-subtitle {
          color: #94a3b8;
          font-size: 13px;
          margin: 6px 0 0;
        }

        .no-comments-box {
          padding: 32px 20px;
          text-align: center;
          background: rgba(8, 23, 34, 0.5);
          border: 1px dashed rgba(255, 255, 255, 0.12);
          border-radius: 10px;
          color: #94a3b8;
          font-size: 13px;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
        }

        .no-comments-box :global(svg) {
          width: 24px;
          height: 24px;
          color: #16c96f;
        }

        .comments-flow {
          display: flex;
          flex-direction: column;
          gap: 18px;
          margin-bottom: 36px;
        }

        .comment-card {
          display: flex;
          gap: 16px;
          padding: 20px;
          background: linear-gradient(145deg, rgba(8, 23, 34, 0.8), rgba(4, 16, 26, 0.8));
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 12px;
        }

        .comment-avatar {
          width: 42px;
          height: 42px;
          border-radius: 50%;
          background: linear-gradient(135deg, #12b85f, #24a8ff);
          display: grid;
          place-items: center;
          font-weight: 800;
          font-size: 14px;
          color: #030b12;
          flex-shrink: 0;
          box-shadow: 0 0 12px rgba(22, 201, 111, 0.3);
        }

        .comment-avatar.small {
          width: 32px;
          height: 32px;
          font-size: 12px;
        }

        .comment-body {
          flex: 1;
        }

        .comment-meta-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 8px;
          flex-wrap: wrap;
          gap: 8px;
        }

        .author-info {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .author-name {
          font-size: 14px;
          font-weight: 700;
          color: #ffffff;
        }

        .author-site-badge {
          font-size: 10px;
          color: #38bdf8;
          background: rgba(56, 189, 248, 0.1);
          padding: 2px 6px;
          border-radius: 4px;
          border: 1px solid rgba(56, 189, 248, 0.25);
          text-decoration: none;
        }

        .comment-date {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          color: #64748b;
          font-size: 11px;
        }

        .comment-date :global(svg) {
          width: 12px;
          height: 12px;
        }

        .comment-text-content {
          font-size: 13px;
          line-height: 1.6;
          color: #cbd5e1;
          margin: 0 0 10px;
          white-space: pre-wrap;
        }

        .comment-actions-row {
          display: flex;
          gap: 12px;
        }

        .btn-reply-link {
          background: none;
          border: none;
          color: #16c96f;
          font-size: 11px;
          font-weight: 600;
          display: inline-flex;
          align-items: center;
          gap: 4px;
          cursor: pointer;
          padding: 0;
          transition: color 0.15s;
        }

        .btn-reply-link:hover {
          color: #2bf08a;
          text-decoration: underline;
        }

        .btn-reply-link :global(svg) {
          width: 12px;
          height: 12px;
        }

        .comment-replies-list {
          margin-top: 14px;
          padding-left: 16px;
          border-left: 2px solid rgba(22, 201, 111, 0.2);
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .reply-card {
          display: flex;
          gap: 12px;
          padding: 12px;
          background: rgba(3, 11, 18, 0.6);
          border-radius: 8px;
          border: 1px solid rgba(255, 255, 255, 0.05);
        }

        /* Formulario */
        .comment-form-container {
          background: linear-gradient(155deg, rgba(8, 23, 34, 0.9), rgba(4, 16, 26, 0.9));
          border: 1px solid rgba(22, 201, 111, 0.2);
          border-radius: 14px;
          padding: 28px;
          box-shadow: 0 12px 36px rgba(0, 0, 0, 0.4), 0 0 20px rgba(22, 201, 111, 0.05);
        }

        .form-heading h4 {
          font-size: 18px;
          font-weight: 700;
          color: #ffffff;
          margin: 0 0 4px;
        }

        .replying-name {
          color: #38bdf8;
        }

        .btn-cancel-reply {
          background: none;
          border: none;
          color: #ef4444;
          font-size: 11px;
          margin-left: 8px;
          cursor: pointer;
        }

        .form-disclaimer {
          display: block;
          color: #64748b;
          font-size: 11px;
          margin-bottom: 18px;
        }

        .ajax-alert {
          display: flex;
          align-items: flex-start;
          gap: 12px;
          padding: 14px 16px;
          border-radius: 8px;
          margin-bottom: 20px;
          font-size: 13px;
        }

        .ajax-alert.success {
          background: rgba(22, 201, 111, 0.12);
          border: 1px solid rgba(22, 201, 111, 0.35);
          color: #a7f3d0;
        }

        .ajax-alert.success :global(svg) {
          width: 20px;
          height: 20px;
          color: #16c96f;
          flex-shrink: 0;
        }

        .ajax-alert.error {
          background: rgba(239, 68, 68, 0.12);
          border: 1px solid rgba(239, 68, 68, 0.35);
          color: #fca5a5;
        }

        .ajax-alert.error :global(svg) {
          width: 20px;
          height: 20px;
          color: #ef4444;
          flex-shrink: 0;
        }

        .ajax-alert strong {
          display: block;
          font-weight: 700;
          margin-bottom: 2px;
        }

        .ajax-alert p {
          margin: 0;
          font-size: 12px;
          opacity: 0.9;
        }

        .form-grid-fields {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 16px;
        }

        .field-group {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .field-group.full-width {
          grid-column: 1 / -1;
        }

        .field-group label {
          font-size: 12px;
          font-weight: 600;
          color: #cbd5e1;
        }

        .field-group label .req {
          color: #16c96f;
        }

        .field-group label small {
          color: #64748b;
          font-weight: 400;
        }

        .field-group input,
        .field-group textarea {
          background: #030a10;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          padding: 10px 14px;
          color: #ffffff;
          font-size: 13px;
          font-family: inherit;
          outline: none;
          transition: border-color 0.2s, box-shadow 0.2s;
        }

        .field-group input:focus,
        .field-group textarea:focus {
          border-color: #16c96f;
          box-shadow: 0 0 0 2px rgba(22, 201, 111, 0.15);
        }

        .form-submit-row {
          margin-top: 20px;
          display: flex;
          justify-content: flex-end;
        }

        .btn-submit-comment {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: linear-gradient(110deg, #12b85f, #18d878);
          border: 1px solid rgba(67, 255, 147, 0.4);
          color: #030b12;
          font-weight: 700;
          font-size: 13px;
          padding: 12px 24px;
          border-radius: 8px;
          cursor: pointer;
          box-shadow: 0 0 16px rgba(22, 201, 111, 0.3);
          transition: all 0.2s;
        }

        .btn-submit-comment:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: 0 0 24px rgba(22, 201, 111, 0.5);
          background: #20df7b;
        }

        .btn-submit-comment:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }

        .btn-submit-comment :global(svg) {
          width: 15px;
          height: 15px;
        }

        @media (max-width: 640px) {
          .form-grid-fields {
            grid-template-columns: 1fr;
          }
          .comment-card {
            flex-direction: column;
          }
        }
      `}</style>
    </section>
  );
}
