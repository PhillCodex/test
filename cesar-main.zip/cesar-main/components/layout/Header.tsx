"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import {
  CircuitBoard,
  Menu as MenuIcon,
  Search,
  Sun,
  X,
  ChevronDown,
  Home,
  Briefcase,
  Layers,
  FolderGit2,
  Cpu,
  User,
  Mail,
  Globe,
  Code,
  Sparkles,
  Shield,
  Zap,
  Terminal,
  Layout,
  BookOpen,
  FileText,
  Phone,
  Compass,
  HelpCircle,
  Award,
  Flame,
  Rocket,
  Star,
  Boxes,
  Wrench,
  FolderKanban,
} from "lucide-react";

// Icon Map for dynamic icons in the navbar
const NAVBAR_ICONS: { [key: string]: any } = {
  Home,
  Briefcase,
  Layers,
  FolderGit2,
  Cpu,
  User,
  Mail,
  Globe,
  Code,
  Sparkles,
  Shield,
  Zap,
  Terminal,
  Layout,
  BookOpen,
  FileText,
  Phone,
  Compass,
  HelpCircle,
  Award,
  Flame,
  Rocket,
  Star,
  Boxes,
  Wrench,
  FolderKanban,
};

const DEFAULT_LINKS = [
  { id: "1", label: "Inicio", url: "/#inicio", icon: "Home" },
  { id: "2", label: "Servicios", url: "/#servicios", icon: "Briefcase" },
  {
    id: "3",
    label: "Soluciones",
    url: "/#servicios",
    icon: "Layers",
    children: [
      { id: "3-1", label: "Desarrollo Web", url: "/#servicios", icon: "Code" },
      { id: "3-2", label: "Cloud & DevOps", url: "/#servicios", icon: "Zap" },
      { id: "3-3", label: "Ciberseguridad", url: "/#servicios", icon: "Shield" },
    ],
  },
  { id: "4", label: "Portafolio", url: "/#portafolio", icon: "FolderKanban" },
  { id: "5", label: "Recursos", url: "/posts", icon: "BookOpen" },
  { id: "6", label: "Sobre mí", url: "/#sobre-mi", icon: "User" },
  { id: "7", label: "Contacto", url: "/#contacto", icon: "Mail" },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  const [menuLinks, setMenuLinks] = useState<any[]>(DEFAULT_LINKS);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [siteTitle, setSiteTitle] = useState<string>("TechLab");
  const [slogan, setSlogan] = useState<string>("Tecnología que impulsa tu mundo.");
  const [logoUrl, setLogoUrl] = useState<string>("");

  useEffect(() => {
    const fetchHeaderData = async () => {
      try {
        const [menuRes, settingsRes] = await Promise.all([
          fetch("/api/menus?location=HEADER"),
          fetch("/api/settings"),
        ]);

        const menuData = await menuRes.json();
        if (menuData.success && menuData.menu?.items && menuData.menu.items.length > 0) {
          const topLevelItems = menuData.menu.items.filter((item: any) => !item.parentId);
          setMenuLinks(topLevelItems);
        }

        const settingsData = await settingsRes.json();
        if (settingsData.success && settingsData.settings) {
          if (settingsData.settings.siteTitle) setSiteTitle(settingsData.settings.siteTitle);
          if (settingsData.settings.slogan) setSlogan(settingsData.settings.slogan);
          if (settingsData.settings.logoUrl) setLogoUrl(settingsData.settings.logoUrl);
        }
      } catch (err) {
        console.error("Error al cargar header:", err);
      }
    };

    fetchHeaderData();
  }, []);

  return (
    <header>
      <div className="nav container">
        {/* LOGO DINÁMICO DESDE AJUSTES */}
        <Link href="/" className="brand">
          {logoUrl ? (
            <img src={logoUrl} alt={siteTitle} className="brand-logo-img" />
          ) : (
            <>
              <CircuitBoard />
              <span>
                <b>
                  {(() => {
                    const title = siteTitle || "TechLab";
                    if (title.includes(" ")) {
                      const words = title.split(" ");
                      return (
                        <>
                          {words[0]} <span>{words.slice(1).join(" ")}</span>
                        </>
                      );
                    }
                    if (title.toLowerCase() === "techlab") {
                      return (
                        <>
                          Tech<span>Lab</span>
                        </>
                      );
                    }
                    return <span>{title}</span>;
                  })()}
                </b>
                <small>{slogan || "Tecnología que impulsa tu mundo."}</small>
              </span>
            </>
          )}
        </Link>

        {/* NAVEGACIÓN */}
        <nav className={open ? "open" : ""}>
          {menuLinks.map((item, idx) => {
            const hasChildren = item.children && item.children.length > 0;
            const IconComponent = item.icon ? NAVBAR_ICONS[item.icon] : null;

            if (hasChildren) {
              return (
                <div
                  key={item.id || idx}
                  className="nav-dropdown-wrapper"
                  onMouseEnter={() => setActiveDropdown(item.id || String(idx))}
                  onMouseLeave={() => setActiveDropdown(null)}
                >
                  <Link
                    href={item.url || "#"}
                    className="nav-link-item with-arrow"
                    onClick={() => setOpen(false)}
                    target={item.target || "_self"}
                  >
                    {IconComponent && <IconComponent className="nav-ico" />}
                    <span>{item.label}</span>
                    <ChevronDown className="dropdown-arrow" />
                  </Link>

                  <div className={`nav-dropdown-menu ${activeDropdown === (item.id || String(idx)) ? "is-active" : ""}`}>
                    {item.children.map((child: any, cIdx: number) => {
                      const ChildIcon = child.icon ? NAVBAR_ICONS[child.icon] : null;
                      return (
                        <Link
                          key={child.id || cIdx}
                          href={child.url}
                          className="dropdown-child-link"
                          onClick={() => {
                            setOpen(false);
                            setActiveDropdown(null);
                          }}
                          target={child.target || "_self"}
                        >
                          {ChildIcon && <ChildIcon className="child-ico" />}
                          <span>{child.label}</span>
                        </Link>
                      );
                    })}
                  </div>
                </div>
              );
            }

            return (
              <Link
                key={item.id || idx}
                onClick={() => setOpen(false)}
                href={item.url}
                className="nav-link-item"
                target={item.target || "_self"}
              >
                {IconComponent && <IconComponent className="nav-ico" />}
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>

        {/* ACCIONES */}
        <div className="nav-actions">
          <button aria-label="Buscar">
            <Search />
          </button>
          <button aria-label="Cambiar tema">
            <Sun />
          </button>
          <Link className="btn compact" href="/#contacto">
            Solicitar servicio
          </Link>
          <button
            className="menu"
            onClick={() => setOpen(!open)}
            aria-label="Abrir menú"
          >
            {open ? <X /> : <MenuIcon />}
          </button>
        </div>
      </div>

      <style jsx>{`
        .brand-logo-img {
          max-height: 38px;
          object-fit: contain;
        }

        :global(.nav-link-item) {
          display: inline-flex !important;
          align-items: center !important;
          gap: 6px !important;
          font-size: 11px !important;
          font-weight: 700 !important;
          text-transform: uppercase !important;
          color: #c6ced6 !important;
          text-decoration: none !important;
          white-space: nowrap !important;
          transition: color 0.2s ease !important;
        }

        :global(.nav-link-item:hover) {
          color: #16c96f !important;
        }

        :global(.nav-ico) {
          width: 14px !important;
          height: 14px !important;
          color: #16c96f !important;
          flex-shrink: 0 !important;
        }

        .dropdown-arrow {
          width: 11px;
          height: 11px;
          margin-left: 2px;
          opacity: 0.7;
          transition: transform 0.2s;
        }

        .nav-dropdown-wrapper {
          position: relative;
          display: inline-flex;
          align-items: center;
        }

        .nav-dropdown-wrapper:hover .dropdown-arrow {
          transform: rotate(180deg);
        }

        .nav-dropdown-menu {
          position: absolute;
          top: 100%;
          left: 0;
          min-width: 190px;
          background: #040c14;
          border: 1px solid rgba(255, 255, 255, 0.12);
          border-radius: 8px;
          padding: 6px 0;
          box-shadow: 0 12px 30px rgba(0, 0, 0, 0.8), 0 0 20px rgba(22, 201, 111, 0.1);
          opacity: 0;
          visibility: hidden;
          transform: translateY(6px);
          transition: all 0.15s ease;
          z-index: 100;
        }

        .nav-dropdown-wrapper:hover .nav-dropdown-menu,
        .nav-dropdown-menu.is-active {
          opacity: 1;
          visibility: visible;
          transform: translateY(0);
        }

        :global(.dropdown-child-link) {
          display: flex !important;
          align-items: center !important;
          gap: 8px !important;
          padding: 8px 16px !important;
          color: #cbd5e1 !important;
          font-size: 12px !important;
          font-weight: 600 !important;
          text-transform: none !important;
          text-decoration: none !important;
          transition: background 0.12s !important;
        }

        :global(.dropdown-child-link:hover) {
          background: rgba(22, 201, 111, 0.12) !important;
          color: #16c96f !important;
        }

        :global(.child-ico) {
          width: 14px !important;
          height: 14px !important;
          color: #16c96f !important;
          flex-shrink: 0 !important;
        }

        @media (max-width: 800px) {
          .nav-dropdown-menu {
            position: static;
            box-shadow: none;
            border: none;
            background: transparent;
            padding-left: 14px;
            opacity: 1;
            visibility: visible;
            transform: none;
          }
        }
      `}</style>
    </header>
  );
}
