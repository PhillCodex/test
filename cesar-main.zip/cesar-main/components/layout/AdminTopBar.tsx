"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  Paintbrush,
  MessageSquare,
  Plus,
  Home,
  LayoutDashboard,
  Settings,
  FilePenLine,
  Files,
  Users,
  FolderKanban,
  Box,
  LogOut,
  UserRound,
  ExternalLink,
  ChevronDown,
  Palette,
  Sparkles,
  Image as ImageIcon,
} from "lucide-react";
import { logoutAction } from "@/lib/actions/auth";
import type { SessionUser } from "@/lib/auth";

interface AdminTopBarProps {
  user: SessionUser;
  siteTitle?: string;
  pendingComments?: number;
}

export default function AdminTopBar({
  user,
  siteTitle = "TechLab",
  pendingComments = 0,
}: AdminTopBarProps) {
  const pathname = usePathname();
  const router = useRouter();

  const [siteDropdown, setSiteDropdown] = useState(false);
  const [addDropdown, setAddDropdown] = useState(false);
  const [userDropdown, setUserDropdown] = useState(false);

  const siteDropdownRef = useRef<HTMLDivElement>(null);
  const addDropdownRef = useRef<HTMLDivElement>(null);
  const userDropdownRef = useRef<HTMLDivElement>(null);

  // Cerrar dropdowns al hacer clic fuera
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (siteDropdownRef.current && !siteDropdownRef.current.contains(e.target as Node)) {
        setSiteDropdown(false);
      }
      if (addDropdownRef.current && !addDropdownRef.current.contains(e.target as Node)) {
        setAddDropdown(false);
      }
      if (userDropdownRef.current && !userDropdownRef.current.contains(e.target as Node)) {
        setUserDropdown(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Agregar clase al body para el offset superior
  useEffect(() => {
    document.body.classList.add("has-wp-admin-bar");
    return () => {
      document.body.classList.remove("has-wp-admin-bar");
    };
  }, []);

  // No renderizar si ya estamos dentro del dashboard
  if (pathname && pathname.startsWith("/dashboard")) {
    return null;
  }

  const handleLogout = async () => {
    await logoutAction();
    router.push("/login");
    router.refresh();
  };

  const displayName = user?.name || "Admin";
  const avatarUrl = user?.avatar || user?.image;

  // Determinar la acción de edición según la ruta actual
  const isPost = pathname.startsWith("/posts/") && pathname !== "/posts";
  const isPage = (pathname.startsWith("/paginas/") && pathname !== "/paginas") || pathname === "/" || pathname === "/servicios" || pathname === "/proyectos";
  const currentSlug = pathname.startsWith("/paginas/")
    ? pathname.replace("/paginas/", "").split("?")[0]
    : (pathname === "/" ? "home" : pathname.replace(/^\//, "").split("?")[0]);

  return (
    <div className="wp-admin-top-bar" id="wpadminbar">
      <div className="admin-bar-inner">
        {/* Lado Izquierdo: Nombre del sitio, Editar, Comentarios, + Añadir */}
        <div className="admin-bar-left">
          {/* Menú del Sitio */}
          <div
            ref={siteDropdownRef}
            className={`admin-bar-item has-dropdown ${siteDropdown ? "open" : ""}`}
            onMouseEnter={() => setSiteDropdown(true)}
            onMouseLeave={() => setSiteDropdown(false)}
          >
            <Link href="/dashboard" className="admin-bar-link site-name-link">
              <Home className="bar-icon" />
              <span>{siteTitle}</span>
            </Link>

            {siteDropdown && (
              <div className="admin-bar-submenu">
                <Link href="/dashboard">
                  <LayoutDashboard className="sub-icon" />
                  <span>Escritorio</span>
                </Link>
                <Link href="/dashboard/menus">
                  <span>Menús</span>
                </Link>
                <Link href="/dashboard/ajustes">
                  <Settings className="sub-icon" />
                  <span>Ajustes</span>
                </Link>
                <Link href="/dashboard/backups">
                  <span>Copias de Seguridad</span>
                </Link>
              </div>
            )}
          </div>

          {/* Botón de Edición Contextual */}
          {isPost ? (
            <div className="admin-bar-item">
              <Link href="/dashboard/posts" className="admin-bar-link">
                <FilePenLine className="bar-icon" />
                <span>Editar Entrada</span>
              </Link>
            </div>
          ) : isPage ? (
            <>
              <div className="admin-bar-item">
                <Link href={currentSlug && currentSlug !== "home" ? `/dashboard/paginas/nuevo?slug=${encodeURIComponent(currentSlug)}` : "/dashboard/paginas"} className="admin-bar-link">
                  <Files className="bar-icon" />
                  <span>Editar Página</span>
                </Link>
              </div>
              <div className="admin-bar-item">
                <Link
                  href={`/dashboard/elementor/editor?slug=${encodeURIComponent(currentSlug)}`}
                  className="admin-bar-link elementor-bar-link"
                  title="Editar esta página en pantalla completa con Elementor"
                >
                  <span className="elementor-logo-e">E</span>
                  <span>Editar con Elementor</span>
                </Link>
              </div>
            </>
          ) : (
            <div className="admin-bar-item">
              <Link href="/dashboard/ajustes" className="admin-bar-link">
                <Paintbrush className="bar-icon" />
                <span>Editar el sitio</span>
              </Link>
            </div>
          )}

          {/* Comentarios Pendientes */}
          <div className="admin-bar-item">
            <Link href="/dashboard/comentarios" className="admin-bar-link">
              <MessageSquare className="bar-icon" />
              <span className="comments-count-pill">{pendingComments}</span>
            </Link>
          </div>

          {/* Menú + Añadir */}
          <div
            ref={addDropdownRef}
            className={`admin-bar-item has-dropdown ${addDropdown ? "open" : ""}`}
            onMouseEnter={() => setAddDropdown(true)}
            onMouseLeave={() => setAddDropdown(false)}
          >
            <button
              type="button"
              className="admin-bar-link btn-link"
              onClick={() => setAddDropdown(!addDropdown)}
            >
              <Plus className="bar-icon" />
              <span>Añadir</span>
            </button>

            {addDropdown && (
              <div className="admin-bar-submenu">
                <Link href="/dashboard/posts/nuevo">
                  <FilePenLine className="sub-icon" />
                  <span>Entrada / Post</span>
                </Link>
                <Link href="/dashboard/medios">
                  <ImageIcon className="sub-icon" />
                  <span>Medio</span>
                </Link>
                <Link href="/dashboard/paginas/nuevo">
                  <Files className="sub-icon" />
                  <span>Página</span>
                </Link>
                <Link href="/dashboard/elementor/editor?new=1">
                  <span className="elementor-sub-e">E</span>
                  <span>Página con Elementor</span>
                </Link>
                <Link href="/dashboard/proyectos/nuevo">
                  <FolderKanban className="sub-icon" />
                  <span>Proyecto</span>
                </Link>
                <Link href="/dashboard/servicios/nuevo">
                  <Box className="sub-icon" />
                  <span>Servicio</span>
                </Link>
                <Link href="/dashboard/usuarios">
                  <Users className="sub-icon" />
                  <span>Usuario</span>
                </Link>
              </div>
            )}
          </div>
        </div>

        {/* Lado Derecho: Hola, Usuario y Avatar */}
        <div className="admin-bar-right">
          <div
            ref={userDropdownRef}
            className={`admin-bar-item has-dropdown user-item ${userDropdown ? "open" : ""}`}
            onMouseEnter={() => setUserDropdown(true)}
            onMouseLeave={() => setUserDropdown(false)}
          >
            <button
              type="button"
              className="admin-bar-link user-link-btn"
              onClick={() => setUserDropdown(!userDropdown)}
            >
              <span>Hola, {displayName}</span>
              <div className="bar-avatar-circle">
                {avatarUrl ? (
                  <img src={avatarUrl} alt={displayName} />
                ) : (
                  <span>{displayName.charAt(0).toUpperCase()}</span>
                )}
              </div>
            </button>

            {userDropdown && (
              <div className="admin-bar-submenu submenu-right">
                <div className="submenu-user-header">
                  <div className="bar-avatar-large">
                    {avatarUrl ? (
                      <img src={avatarUrl} alt={displayName} />
                    ) : (
                      <span>{displayName.charAt(0).toUpperCase()}</span>
                    )}
                  </div>
                  <div>
                    <strong>{displayName}</strong>
                    <small>{user.email}</small>
                  </div>
                </div>
                <div className="submenu-divider" />
                <Link href="/dashboard/usuarios">
                  <UserRound className="sub-icon" />
                  <span>Editar mi perfil</span>
                </Link>
                <button
                  type="button"
                  onClick={handleLogout}
                  className="submenu-logout-btn"
                >
                  <LogOut className="sub-icon" />
                  <span>Cerrar sesión</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <style jsx global>{`
        body.has-wp-admin-bar {
          padding-top: 32px !important;
        }

        .wp-admin-top-bar {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          height: 32px;
          background: #1d2327;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
          color: #f0f0f1;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
          font-size: 13px;
          z-index: 999999;
          box-sizing: border-box;
          user-select: none;
        }

        .admin-bar-inner {
          display: flex;
          justify-content: space-between;
          align-items: center;
          height: 100%;
          padding: 0 12px;
          max-width: 100%;
        }

        .admin-bar-left,
        .admin-bar-right {
          display: flex;
          align-items: center;
          height: 100%;
        }

        .admin-bar-item {
          position: relative;
          display: flex;
          align-items: center;
          height: 100%;
        }

        .admin-bar-link {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          height: 100%;
          padding: 0 10px;
          color: #f0f0f1;
          text-decoration: none;
          font-size: 13px;
          font-weight: 400;
          cursor: pointer;
          background: transparent;
          border: none;
          transition: background 0.15s, color 0.15s;
        }

        .admin-bar-link:hover,
        .admin-bar-item.open > .admin-bar-link {
          background: #2c3338;
          color: #72aee6;
        }

        .bar-icon {
          width: 15px;
          height: 15px;
          color: #a7aaad;
        }

        .admin-bar-link:hover .bar-icon,
        .admin-bar-item.open .bar-icon {
          color: #72aee6;
        }

        .site-name-link {
          font-weight: 600;
        }

        .elementor-bar-link {
          gap: 6px;
        }

        .elementor-bar-link:hover {
          background: #d63384 !important;
          color: #ffffff !important;
        }

        .elementor-logo-e {
          display: inline-grid;
          place-items: center;
          width: 16px;
          height: 16px;
          background: #d63384;
          color: #ffffff;
          font-size: 10px;
          font-weight: 900;
          border-radius: 3px;
          line-height: 1;
        }

        .elementor-sub-e {
          display: inline-grid;
          place-items: center;
          width: 14px;
          height: 14px;
          background: #d63384;
          color: #ffffff;
          font-size: 9px;
          font-weight: 900;
          border-radius: 2px;
          line-height: 1;
        }

        .comments-count-pill {
          background: #464b50;
          color: #ffffff;
          font-size: 10px;
          font-weight: 700;
          padding: 1px 6px;
          border-radius: 10px;
          margin-left: 2px;
        }

        .admin-bar-link:hover .comments-count-pill {
          background: #2271b1;
        }

        .user-link-btn {
          gap: 8px;
        }

        .bar-avatar-circle {
          width: 20px;
          height: 20px;
          border-radius: 50%;
          overflow: hidden;
          background: #464b50;
          display: grid;
          place-items: center;
          color: #ffffff;
          font-size: 10px;
          font-weight: 700;
        }

        .bar-avatar-circle img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        /* Submenús Desplegables */
        .admin-bar-submenu {
          position: absolute;
          top: 32px;
          left: 0;
          min-width: 180px;
          background: #2c3338;
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-top: none;
          box-shadow: 0 4px 16px rgba(0, 0, 0, 0.4);
          display: flex;
          flex-direction: column;
          z-index: 1000000;
        }

        .admin-bar-submenu.submenu-right {
          left: auto;
          right: 0;
          min-width: 220px;
        }

        .admin-bar-submenu a,
        .admin-bar-submenu button {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 8px 14px;
          color: #f0f0f1;
          text-decoration: none;
          font-size: 12px;
          background: transparent;
          border: none;
          text-align: left;
          width: 100%;
          cursor: pointer;
          transition: background 0.15s, color 0.15s;
        }

        .admin-bar-submenu a:hover,
        .admin-bar-submenu button:hover {
          background: #135e96;
          color: #ffffff;
        }

        .sub-icon {
          width: 14px;
          height: 14px;
          color: #a7aaad;
        }

        .admin-bar-submenu a:hover .sub-icon,
        .admin-bar-submenu button:hover .sub-icon {
          color: #ffffff;
        }

        .submenu-user-header {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 12px 14px;
          background: #1d2327;
        }

        .bar-avatar-large {
          width: 32px;
          height: 32px;
          border-radius: 50%;
          overflow: hidden;
          background: #464b50;
          display: grid;
          place-items: center;
          color: #ffffff;
          font-size: 12px;
          font-weight: 700;
          flex-shrink: 0;
        }

        .bar-avatar-large img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .submenu-user-header strong {
          display: block;
          color: #ffffff;
          font-size: 12px;
        }

        .submenu-user-header small {
          color: #a7aaad;
          font-size: 11px;
        }

        .submenu-divider {
          height: 1px;
          background: rgba(255, 255, 255, 0.08);
        }

        .submenu-logout-btn {
          color: #f87171 !important;
        }

        .submenu-logout-btn:hover {
          background: #dc2626 !important;
          color: #ffffff !important;
        }

        @media (max-width: 782px) {
          body.has-wp-admin-bar {
            padding-top: 46px !important;
          }

          .wp-admin-top-bar {
            height: 46px;
          }

          .admin-bar-link {
            padding: 0 8px;
            font-size: 12px;
          }

          .admin-bar-submenu {
            top: 46px;
          }
        }
      `}</style>
    </div>
  );
}
