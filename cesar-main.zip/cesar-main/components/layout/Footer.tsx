import {
  CircuitBoard,
  Facebook,
  Linkedin,
  Github,
  Youtube,
  Twitter,
  Instagram,
  Mail,
  Phone,
  MapPin,
  Clock,
} from "lucide-react";
import Link from "next/link";
import Container from "@/components/ui/Container";
import { prisma } from "@/lib/prisma";

const nav = [
  { label: "Inicio", url: "/" },
  { label: "Servicios", url: "/#servicios" },
  { label: "Portafolio", url: "/#proyectos" },
  { label: "Recursos", url: "/posts" },
  { label: "Sobre mí", url: "/#sobre-mi" },
  { label: "Contacto", url: "/#contacto" },
];

const serv = [
  { label: "Desarrollo Web", url: "/#servicios" },
  { label: "WordPress & CMS", url: "/#servicios" },
  { label: "Ciberseguridad", url: "/#servicios" },
  { label: "Cloud & DevOps", url: "/#servicios" },
  { label: "Soporte Técnico", url: "/#servicios" },
  { label: "Consultoría IT", url: "/#contacto" },
];

const res = [
  { label: "Blog & Artículos", url: "/posts" },
  { label: "Tutoriales", url: "/posts" },
  { label: "Guías Técnicas", url: "/posts" },
  { label: "Herramientas", url: "/posts" },
  { label: "Plantillas", url: "/posts" },
];

export default async function Footer() {
  let siteTitle = "TechLab";
  let footerDescription = "Laboratorio de innovación tecnológica, desarrollo de software y servicios en la nube.";
  let logoUrl = "";
  let footerCopyright = `© ${new Date().getFullYear()} TechLab. Todos los derechos reservados.`;
  let footerBottomText = "Términos y condiciones　|　Política de privacidad";
  let footerEmail = "contacto@techlab.com";
  let footerPhone = "+51 900 123 456";
  let footerAddress = "Lima, Perú";
  let footerSchedule = "Lun - Vie: 9:00 AM - 6:00 PM";
  let footerFacebook = "https://facebook.com";
  let footerTwitter = "https://twitter.com";
  let footerInstagram = "https://instagram.com";
  let footerLinkedin = "https://linkedin.com";
  let footerYoutube = "https://youtube.com";
  let footerGithub = "https://github.com";
  let footerShowSocial = true;
  let footerShowContact = true;
  let footerNavTitle = "NAVEGACIÓN";
  let footerServicesTitle = "SERVICIOS";
  let footerResourcesTitle = "RECURSOS";

  try {
    const settings = await prisma.siteSetting.findUnique({
      where: { id: "general" },
    });
    if (settings) {
      if (settings.siteTitle) siteTitle = settings.siteTitle;
      if (settings.footerDescription) footerDescription = settings.footerDescription;
      else if (settings.siteDescription) footerDescription = settings.siteDescription;
      if (settings.logoUrl) logoUrl = settings.logoUrl;
      if (settings.footerCopyright) footerCopyright = settings.footerCopyright.replace("%year%", new Date().getFullYear().toString()).replace("%sitename%", siteTitle);
      if (settings.footerBottomText) footerBottomText = settings.footerBottomText;
      if (settings.footerEmail) footerEmail = settings.footerEmail;
      if (settings.footerPhone) footerPhone = settings.footerPhone;
      else if (settings.whatsappNumber) footerPhone = settings.whatsappNumber;
      if (settings.footerAddress) footerAddress = settings.footerAddress;
      if (settings.footerSchedule) footerSchedule = settings.footerSchedule;
      if (settings.footerFacebook) footerFacebook = settings.footerFacebook;
      if (settings.footerTwitter) footerTwitter = settings.footerTwitter;
      if (settings.footerInstagram) footerInstagram = settings.footerInstagram;
      if (settings.footerLinkedin) footerLinkedin = settings.footerLinkedin;
      if (settings.footerYoutube) footerYoutube = settings.footerYoutube;
      if (settings.footerGithub) footerGithub = settings.footerGithub;
      if (settings.footerShowSocial !== undefined) footerShowSocial = settings.footerShowSocial;
      if (settings.footerShowContact !== undefined) footerShowContact = settings.footerShowContact;
      if (settings.footerNavTitle) footerNavTitle = settings.footerNavTitle;
      if (settings.footerServicesTitle) footerServicesTitle = settings.footerServicesTitle;
      if (settings.footerResourcesTitle) footerResourcesTitle = settings.footerResourcesTitle;
    }
  } catch {
    // Fallback
  }

  const socialLinks = [
    { icon: Facebook, url: footerFacebook, label: "Facebook" },
    { icon: Twitter, url: footerTwitter, label: "Twitter" },
    { icon: Instagram, url: footerInstagram, label: "Instagram" },
    { icon: Linkedin, url: footerLinkedin, label: "LinkedIn" },
    { icon: Youtube, url: footerYoutube, label: "YouTube" },
    { icon: Github, url: footerGithub, label: "GitHub" },
  ].filter((s) => s.url && s.url.trim() !== "");

  return (
    <footer id="sobre-mi" className="techlab-main-footer">
      <Container>
        <div className="footer-grid">
          {/* Marca y Descripción */}
          <div className="footer-brand">
            <div className="brand">
              {logoUrl ? (
                <img src={logoUrl} alt={siteTitle} className="footer-logo-img" style={{ maxHeight: "36px" }} />
              ) : (
                <>
                  <CircuitBoard />
                  <span>
                    <b>
                      {siteTitle.includes(" ") ? (
                        <>
                          {siteTitle.split(" ")[0]} <span>{siteTitle.split(" ").slice(1).join(" ")}</span>
                        </>
                      ) : siteTitle.toLowerCase() === "techlab" ? (
                        <>
                          Tech<span>Lab</span>
                        </>
                      ) : (
                        <span>{siteTitle}</span>
                      )}
                    </b>
                  </span>
                </>
              )}
            </div>
            <p className="footer-brand-desc">{footerDescription}</p>
            {footerShowSocial && socialLinks.length > 0 && (
              <div className="socials">
                {socialLinks.map(({ icon: Icon, url, label }, i) => (
                  <a
                    href={url}
                    key={i}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={label}
                    title={label}
                  >
                    <Icon />
                  </a>
                ))}
              </div>
            )}
          </div>

          {/* Enlaces de Navegación */}
          <FooterLinks title={footerNavTitle} links={nav} />
          <FooterLinks title={footerServicesTitle} links={serv} />
          <FooterLinks title={footerResourcesTitle} links={res} />

          {/* Información de Contacto */}
          {footerShowContact && (
            <div className="footer-contact-block">
              <h4>CONTACTO</h4>
              <ul className="contact">
                {footerEmail && (
                  <li>
                    <Mail /> {footerEmail}
                  </li>
                )}
                {footerPhone && (
                  <li>
                    <Phone /> {footerPhone}
                  </li>
                )}
                {footerAddress && (
                  <li>
                    <MapPin /> {footerAddress}
                  </li>
                )}
                {footerSchedule && (
                  <li>
                    <Clock /> {footerSchedule}
                  </li>
                )}
              </ul>
            </div>
          )}
        </div>

        {/* Copyright y Políticas */}
        <div className="copyright">
          <span>{footerCopyright}</span>
          <span>{footerBottomText}</span>
        </div>
      </Container>
    </footer>
  );
}

function FooterLinks({
  title,
  links,
}: {
  title: string;
  links: { label: string; url: string }[];
}) {
  return (
    <div>
      <h4>{title}</h4>
      <ul>
        {links.map((x, idx) => (
          <li key={idx}>
            <Link href={x.url}>{x.label}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
