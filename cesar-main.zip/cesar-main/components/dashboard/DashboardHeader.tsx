"use client";

import { useState, useRef, useEffect } from "react";
import Link from "next/link";
import {
  Menu,
  Search,
  Bell,
  UserCircle2,
  CheckCheck,
  MessageSquareQuote,
  FolderKanban,
  LineChart,
  Users,
  Sparkles,
  ExternalLink,
  Sun,
  Moon,
  X,
} from "lucide-react";
import type { SessionUser } from "@/lib/auth";

interface NotificationItem {
  id: string;
  type: "testimonio" | "proyecto" | "seo" | "usuario";
  title: string;
  description: string;
  time: string;
  href: string;
  read: boolean;
  icon: any;
  colorClass: string;
}

const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: "notif-1",
    type: "testimonio",
    title: "Nuevo Testimonio Recibido",
    description: "Carlos Mendoza dejó una reseña de 5 estrellas para TechLab.",
    time: "Hace 10 min",
    href: "/dashboard/testimonios",
    read: false,
    icon: MessageSquareQuote,
    colorClass: "green",
  },
  {
    id: "notif-2",
    type: "proyecto",
    title: "Proyecto Actualizado",
    description: "Se guardaron cambios en el caso de estudio 'Sistema de Reservas'.",
    time: "Hace 1 hora",
    href: "/dashboard/proyectos",
    read: false,
    icon: FolderKanban,
    colorClass: "cyan",
  },
  {
    id: "notif-3",
    type: "seo",
    title: "Diagnóstico SEO Completado",
    description: "Salud técnica al 94%. Mapa sitemap.xml y sub-sitemaps generados con éxito.",
    time: "Hace 3 horas",
    href: "/dashboard/seo",
    read: false,
    icon: LineChart,
    colorClass: "purple",
  },
  {
    id: "notif-4",
    type: "usuario",
    title: "Sesión de Administrador",
    description: "Inicio de sesión exitoso desde el panel administrativo.",
    time: "Hoy, 14:30",
    href: "/dashboard/usuarios",
    read: true,
    icon: Users,
    colorClass: "amber",
  },
];

export default function DashboardHeader({
  toggle,
  user,
  isCollapsed = false,
  theme = "dark",
  toggleTheme,
}: {
  toggle: () => void;
  user?: SessionUser | null;
  isCollapsed?: boolean;
  theme?: "dark" | "light";
  toggleTheme?: () => void;
}) {
  const displayRole = user?.role === "ADMIN" ? "Administrador" : user?.role || "Administrador";
  const displayName = user?.name || displayRole;
  const avatarImage = user?.avatar || user?.image;

  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);

  const notifRef = useRef<HTMLDivElement>(null);

  const unreadCount = notifications.filter((n) => !n.read).length;

  // Cerrar al hacer clic fuera
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setNotificationsOpen(false);
      }
    };
    if (notificationsOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [notificationsOpen]);

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const markItemAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
    setNotificationsOpen(false);
  };

  return (
    <header className="admin-header">
      <button
        className="admin-menu"
        onClick={toggle}
        aria-label={isCollapsed ? "Expandir barra lateral" : "Colapsar barra lateral"}
        title={isCollapsed ? "Expandir barra lateral" : "Colapsar barra lateral"}
      >
        <Menu />
      </button>

      <div className="admin-search">
        <Search />
        <input aria-label="Buscar" placeholder="Buscar..." />
        <kbd>⌘K</kbd>
      </div>

      <div className="admin-head-actions">
        {/* Switch Modo Claro / Modo Oscuro */}
        {toggleTheme && (
          <button
            type="button"
            className={`head-icon-btn theme-toggle-btn ${theme === "light" ? "is-light-mode" : ""}`}
            onClick={toggleTheme}
            aria-label={theme === "light" ? "Cambiar a Modo Oscuro" : "Cambiar a Modo Claro"}
            title={theme === "light" ? "Cambiar a Modo Oscuro" : "Cambiar a Modo Claro"}
          >
            {theme === "light" ? <Moon className="theme-moon-icon" /> : <Sun className="theme-sun-icon" />}
          </button>
        )}

        {/* Notificaciones (Ventana estilo YouTube) */}
        <div className="notification-dropdown-wrapper" ref={notifRef}>
          <button
            type="button"
            className={`head-icon-btn notification ${notificationsOpen ? "is-active" : ""}`}
            onClick={() => setNotificationsOpen(!notificationsOpen)}
            aria-label="Notificaciones"
            title="Notificaciones"
          >
            <Bell />
            {unreadCount > 0 && <i>{unreadCount}</i>}
          </button>

          {/* Ventana flotante de Notificaciones */}
          {notificationsOpen && (
            <div className="notifications-popover-panel">
              <div className="notif-popover-header">
                <div className="notif-header-title">
                  <Bell className="header-bell-ico" />
                  <h4>Notificaciones</h4>
                  {unreadCount > 0 && <span className="notif-badge-count">{unreadCount} nuevas</span>}
                </div>
                {unreadCount > 0 && (
                  <button
                    type="button"
                    className="btn-mark-all-read"
                    onClick={markAllAsRead}
                    title="Marcar todas como leídas"
                  >
                    <CheckCheck />
                    <span>Marcar leídas</span>
                  </button>
                )}
              </div>

              <div className="notif-items-list">
                {notifications.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.id}
                      href={item.href}
                      className={`notif-item-row ${!item.read ? "is-unread" : ""}`}
                      onClick={() => markItemAsRead(item.id)}
                    >
                      <div className={`notif-icon-circle ${item.colorClass}`}>
                        <Icon />
                      </div>
                      <div className="notif-content-area">
                        <div className="notif-row-top">
                          <b>{item.title}</b>
                          {!item.read && <span className="unread-neon-dot" />}
                        </div>
                        <p>{item.description}</p>
                        <span className="notif-time-stamp">{item.time}</span>
                      </div>
                    </Link>
                  );
                })}
              </div>

              <div className="notif-popover-footer">
                <Link
                  href="/dashboard/testimonios"
                  className="btn-view-all-notifs"
                  onClick={() => setNotificationsOpen(false)}
                >
                  <span>Ver actividades y testimonios</span>
                  <ExternalLink />
                </Link>
              </div>
            </div>
          )}
        </div>

        {/* Administrador Pill (Limpio sin flecha innecesaria) */}
        <div className="admin-user-pill" title={`${displayName} (${displayRole})`}>
          <div className="header-avatar-circle">
            {avatarImage ? (
              <img src={avatarImage} alt={displayName} />
            ) : (
              <UserCircle2 />
            )}
          </div>
          <span className="user-role-label">{displayName}</span>
        </div>
      </div>
    </header>
  );
}
