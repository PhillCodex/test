import type { LucideIcon } from "lucide-react";
export default function StatCard({ label, value, growth, icon: Icon, tone }: {label:string;value:string;growth:string;icon:LucideIcon;tone:string}){return <article className={`admin-card stat-card ${tone}`}><div><span>{label}</span><strong>{value}</strong><small><b>↑ {growth}</b> desde el mes pasado</small></div><i><Icon/></i></article>}
