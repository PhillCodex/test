"use client";

import { useState, useEffect } from "react";
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Loader2, TrendingUp, Users } from "lucide-react";

interface VisitPoint {
  date: string;
  fullDate: string;
  visits: number;
  uniqueIps: number;
}

export default function DashboardChart({
  initialData,
  totalPeriodVisits,
}: {
  initialData?: VisitPoint[];
  totalPeriodVisits?: number;
}) {
  const [period, setPeriod] = useState<string>("30");
  const [data, setData] = useState<VisitPoint[]>(initialData || []);
  const [loading, setLoading] = useState(false);
  const [totalVisits, setTotalVisits] = useState(totalPeriodVisits || 0);

  const fetchChartData = async (days: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/analytics?days=${days}`);
      const json = await res.json();
      if (json.success && Array.isArray(json.chartData)) {
        setData(json.chartData);
        setTotalVisits(json.stats?.totalPeriodVisits || 0);
      }
    } catch (e) {
      console.error("Error al cargar visitas:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!initialData || period !== "30") {
      fetchChartData(period);
    }
  }, [period]);

  const maxVisits = Math.max(...data.map((d) => d.visits), 10);

  return (
    <section className="admin-card chart-card">
      <div className="card-title">
        <div>
          <h2>VISITAS DEL SITIO</h2>
          <span className="chart-subtitle">
            {totalVisits} visitas registradas por IP en el periodo
          </span>
        </div>
        <div className="chart-controls">
          {loading && <Loader2 className="animate-spin chart-loader" />}
          <select
            value={period}
            onChange={(e) => setPeriod(e.target.value)}
            aria-label="Periodo"
            className="chart-period-select"
          >
            <option value="7">Últimos 7 días</option>
            <option value="14">Últimos 14 días</option>
            <option value="30">Últimos 30 días</option>
          </select>
        </div>
      </div>

      <div className="chart-wrap">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 14, right: 8, left: -16, bottom: 4 }}>
            <defs>
              <linearGradient id="visitsGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#16C96F" stopOpacity={0.35} />
                <stop offset="100%" stopColor="#16C96F" stopOpacity={0.0} />
              </linearGradient>
            </defs>
            <CartesianGrid vertical={false} stroke="rgba(255,255,255,0.06)" />
            <XAxis
              dataKey="date"
              interval={period === "7" ? 0 : period === "14" ? 1 : 4}
              tick={{ fill: "#94a3b8", fontSize: 11 }}
              axisLine={false}
              tickLine={false}
            />
            <YAxis
              domain={[0, Math.ceil(maxVisits * 1.15)]}
              tickFormatter={(v) => (v >= 1000 ? `${(v / 1000).toFixed(1)}K` : `${v}`)}
              tick={{ fill: "#94a3b8", fontSize: 11 }}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip
              content={({ active, payload, label }) => {
                if (active && payload && payload.length) {
                  const item = payload[0].payload as VisitPoint;
                  return (
                    <div className="custom-chart-tooltip">
                      <strong>{item.fullDate || label}</strong>
                      <div className="tooltip-item">
                        <span className="dot green" />
                        <span>Visitas totales: <b>{item.visits}</b></span>
                      </div>
                      <div className="tooltip-item">
                        <span className="dot cyan" />
                        <span>IPs únicas: <b>{item.uniqueIps}</b></span>
                      </div>
                    </div>
                  );
                }
                return null;
              }}
            />
            <Area
              type="monotone"
              dataKey="visits"
              stroke="#20df7b"
              strokeWidth={2.5}
              fill="url(#visitsGrad)"
              dot={{ r: 2.5, fill: "#20df7b", strokeWidth: 0 }}
              activeDot={{ r: 5, fill: "#16c96f", stroke: "#ffffff", strokeWidth: 2 }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </section>
  );
}
