export default function DashboardFooter(){return <footer className="admin-footer"><span>© 2026 TechLab · Panel de Control Profesional</span><span>Versión 1.4.0</span></footer>}
