"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  CircuitBoard,
  Home,
  FilePenLine,
  Files,
  Menu as MenuIcon,
  MessageSquareQuote,
  FolderKanban,
  Box,
  Users,
  Settings,
  ChevronDown,
  LogOut,
  X,
  ChevronRight,
  PanelLeftClose,
  PanelLeftOpen,
  LayoutGrid,
  LineChart,
  DatabaseBackup,
  Image as ImageIcon,
} from "lucide-react";
import { logoutAction } from "@/lib/actions/auth";
import type { SessionUser } from "@/lib/auth";

const items = [
  ["PÁGINAS", "/dashboard/paginas", Files],
  ["MEDIOS", "/dashboard/medios", ImageIcon],
  ["COMENTARIOS", "/dashboard/comentarios", MessageSquareQuote],
  ["MENÚS", "/dashboard/menus", MenuIcon],
  ["ELEMENTOR", "/dashboard/elementor", LayoutGrid],
  ["USUARIOS", "/dashboard/usuarios", Users],
  ["TESTIMONIOS", "/dashboard/testimonios", MessageSquareQuote],
  ["PROYECTOS", "/dashboard/proyectos", FolderKanban],
  ["SERVICIOS", "/dashboard/servicios", Box],
  ["SEO & META", "/dashboard/seo", LineChart],
  ["BACKUPS", "/dashboard/backups", DatabaseBackup],
  ["AJUSTES", "/dashboard/ajustes", Settings],
] as const;

export default function DashboardSidebar({
  open,
  close,
  isCollapsed = false,
  toggleCollapse,
  user,
}: {
  open: boolean;
  close: () => void;
  isCollapsed?: boolean;
  toggleCollapse?: () => void;
  user?: SessionUser | null;
}) {
  const path = usePathname();
  const router = useRouter();
  const [postDropdownOpen, setPostDropdownOpen] = useState(false);
  const [siteTitle, setSiteTitle] = useState<string>("TechLab");
  const [logoUrl, setLogoUrl] = useState<string>("");

  useEffect(() => {
    fetch("/api/settings")
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.settings) {
          if (data.settings.siteTitle) setSiteTitle(data.settings.siteTitle);
          if (data.settings.logoUrl) setLogoUrl(data.settings.logoUrl);
        }
      })
      .catch(() => {});
  }, []);

  const handleLogout = async () => {
    await logoutAction();
    router.push("/login");
    router.refresh();
  };

  const displayName = user?.name ? user.name.charAt(0).toUpperCase() + user.name.slice(1) : "Cesar";
  const displayRole = user?.role === "ADMIN" ? "Administrador" : user?.role || "Administrador";
  const avatarImage = user?.avatar || user?.image;

  const isPostSection =
    path.startsWith("/dashboard/posts") ||
    path === "/dashboard/categorias" ||
    path === "/dashboard/etiquetas";

  return (
    <aside className={`admin-sidebar ${open ? "is-open" : ""} ${isCollapsed ? "is-collapsed" : ""}`}>
      {/* Logo y Botón de Colapso */}
      <div className="admin-logo">
        <Link href="/dashboard" className="logo-brand-wrap" title="Ir al Dashboard">
          {logoUrl ? (
            <img src={logoUrl} alt={siteTitle} className="sidebar-logo-img" style={{ maxHeight: "28px", width: "auto" }} />
          ) : (
            <>
              <CircuitBoard />
              {!isCollapsed && (
                <b>
                  {(() => {
                    const title = siteTitle || "TechLab";
                    if (title.includes(" ")) {
                      const words = title.split(" ");
                      return (
                        <>
                          {words[0].toUpperCase()} <span>{words.slice(1).join(" ").toUpperCase()}</span>
                        </>
                      );
                    }
                    if (title.toLowerCase() === "techlab") {
                      return (
                        <>
                          TECH<span>LAB</span>
                        </>
                      );
                    }
                    return <span>{title.toUpperCase()}</span>;
                  })()}
                </b>
              )}
            </>
          )}
        </Link>

        {/* Botón cerrar en móvil */}
        <button className="mobile-close-btn" onClick={close} aria-label="Cerrar barra lateral">
          <X />
        </button>
      </div>

      {/* Navegación */}
      <nav>
        {/* INICIO */}
        <Link
          className={`nav-item-link ${path === "/dashboard" ? "active-home" : ""}`}
          href="/dashboard"
          onClick={close}
          data-tooltip="INICIO"
        >
          <Home />
          {!isCollapsed && <span>INICIO</span>}
        </Link>

        {/* POST Item: Si está colapsado es un botón de navegación directa con tooltip; si está expandido es un acordeón inline limpio */}
        {isCollapsed ? (
          <Link
            className={`nav-item-link ${isPostSection ? "active" : ""}`}
            href="/dashboard/posts"
            onClick={close}
            data-tooltip="POSTS / BLOG"
          >
            <FilePenLine />
          </Link>
        ) : (
          <div
            className={`nav-parent ${isPostSection ? "parent-active" : ""} ${postDropdownOpen ? "dropdown-open" : ""}`}
          >
            <div
              className="nav-parent-header"
              onClick={() => setPostDropdownOpen((v) => !v)}
            >
              <FilePenLine />
              <span>POST</span>
              <ChevronDown className="chevron-icon" />
            </div>

            {postDropdownOpen && (
              <div className="admin-subnav">
                <Link
                  href="/dashboard/posts"
                  className={path === "/dashboard/posts" ? "subnav-active" : ""}
                  onClick={close}
                >
                  Todos los Posts
                </Link>
                <Link
                  href="/dashboard/posts/nuevo"
                  className={path === "/dashboard/posts/nuevo" ? "subnav-active" : ""}
                  onClick={close}
                >
                  Agregar Nuevo
                </Link>
                <Link
                  href="/dashboard/categorias"
                  className={path === "/dashboard/categorias" ? "subnav-active" : ""}
                  onClick={close}
                >
                  CATEGORÍAS
                </Link>
                <Link
                  href="/dashboard/etiquetas"
                  className={path === "/dashboard/etiquetas" ? "subnav-active" : ""}
                  onClick={close}
                >
                  ETIQUETAS
                </Link>
              </div>
            )}
          </div>
        )}

        {/* Otros Items con Tooltip */}
        {items.map(([label, href, Icon]) => (
          <Link
            className={`nav-item-link ${path.startsWith(href) ? "active" : ""}`}
            href={href}
            key={href}
            onClick={close}
            data-tooltip={label}
          >
            <Icon />
            {!isCollapsed && <span>{label}</span>}
          </Link>
        ))}
      </nav>

      {/* Perfil del usuario inferior */}
      <div className="sidebar-profile-card" data-tooltip={displayName + " (" + displayRole + ")"}>
        <div className="user-avatar-circle">
          {avatarImage ? (
            <img src={avatarImage} alt={displayName} />
          ) : (
            <span className="avatar-initials">{displayName.charAt(0)}</span>
          )}
        </div>
        {!isCollapsed && (
          <div className="user-text-info">
            <b>{displayName}</b>
            <small>{displayRole}</small>
          </div>
        )}
        <button
          onClick={handleLogout}
          className="logout-square-btn"
          title="Cerrar sesión"
          aria-label="Cerrar sesión"
        >
          <LogOut />
        </button>
      </div>
    </aside>
  );
}
