import { Users, FileText, Files, MessageSquare, Mail, Folder, UserRound, ArrowRight } from "lucide-react";
import Link from "next/link";

interface SummaryData {
  usersCount: number;
  postsTotal: number;
  postsPublished: number;
  pagesCount: number;
  commentsCount: number;
  categoriesCount: number;
  projectsCount: number;
  servicesCount: number;
}

export function QuickSummary({ data }: { data?: SummaryData }) {
  const users = data?.usersCount ?? 0;
  const posts = data?.postsPublished ?? 0;
  const pages = data?.pagesCount ?? 0;
  const comments = data?.commentsCount ?? 0;
  const categories = data?.categoriesCount ?? 0;

  const summary = [
    [Users, "Usuarios registrados", users.toString(), "/dashboard/usuarios"],
    [FileText, "Posts publicados", posts.toString(), "/dashboard/posts"],
    [Files, "Páginas creadas", pages.toString(), "/dashboard/paginas"],
    [MessageSquare, "Comentarios", comments.toString(), "/dashboard/comentarios"],
    [Folder, "Categorías activas", categories.toString(), "/dashboard/categorias"],
  ] as const;

  return (
    <section className="admin-card list-card">
      <h2>RESUMEN RÁPIDO</h2>
      {summary.map(([Icon, label, num, href]) => (
        <div key={label}>
          <Icon />
          <span>{label}</span>
          <b>{num}</b>
          <Link href={href} className="summary-goto-link" title="Gestionar">
            <ArrowRight />
          </Link>
        </div>
      ))}
    </section>
  );
}

export function RecentActivity({ data }: { data?: SummaryData }) {
  const posts = data?.postsTotal ?? 0;
  const pages = data?.pagesCount ?? 0;
  const categories = data?.categoriesCount ?? 0;
  const comments = data?.commentsCount ?? 0;

  const activity = [
    [FileText, `Publicaciones en el sistema: ${posts} artículos creados`],
    [Files, `Páginas institucionales: ${pages} páginas configuradas`],
    [Folder, `Categorías taxonómicas: ${categories} categorías en uso`],
    [MessageSquare, `Comentarios e interacciones: ${comments} recibidos`],
    [UserRound, `Administración central de contenidos activa`],
  ] as const;

  return (
    <section className="admin-card activity-card">
      <h2>ESTADO DEL CONTENIDO</h2>
      {activity.map(([Icon, text], i) => (
        <div key={i}>
          <Icon />
          <span>{text}</span>
        </div>
      ))}
      <Link href="/dashboard/posts" className="view-activity-btn">
        Ver publicaciones　→
      </Link>
    </section>
  );
}

export function QuickStats({ data }: { data?: SummaryData }) {
  const posts = data?.postsTotal ?? 0;
  const pages = data?.pagesCount ?? 0;
  const categories = data?.categoriesCount ?? 0;
  const comments = data?.commentsCount ?? 0;

  const total = posts + pages + categories + comments || 1;
  const postsPct = Math.round((posts / total) * 100);
  const pagesPct = Math.round((pages / total) * 100);
  const catPct = Math.round((categories / total) * 100);
  const commPct = Math.max(0, 100 - (postsPct + pagesPct + catPct));

  return (
    <section className="admin-card quick-stats">
      <h2>DISTRIBUCIÓN DE CONTENIDO</h2>
      <div className="stats-progress-bar-wrap">
        <div className="stats-bar-seg green" style={{ width: `${Math.max(postsPct, 8)}%` }} title={`Posts: ${posts}`} />
        <div className="stats-bar-seg blue" style={{ width: `${Math.max(pagesPct, 8)}%` }} title={`Páginas: ${pages}`} />
        <div className="stats-bar-seg purple" style={{ width: `${Math.max(catPct, 8)}%` }} title={`Categorías: ${categories}`} />
        <div className="stats-bar-seg cyan" style={{ width: `${Math.max(commPct, 8)}%` }} title={`Comentarios: ${comments}`} />
      </div>
      <ul>
        <li>
          <i className="g" />
          Posts ({posts}) <b>{postsPct}%</b>
        </li>
        <li>
          <i className="b" />
          Páginas ({pages}) <b>{pagesPct}%</b>
        </li>
        <li>
          <i className="p" />
          Categorías ({categories}) <b>{catPct}%</b>
        </li>
        <li>
          <i className="c" />
          Comentarios ({comments}) <b>{commPct}%</b>
        </li>
      </ul>
      <div className="quick-stats-footer">
        <span>Total de Elementos</span>
        <strong>{posts + pages + categories + comments}</strong>
      </div>
    </section>
  );
}
