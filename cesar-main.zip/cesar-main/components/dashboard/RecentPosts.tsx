import Image from "next/image";
import Link from "next/link";
import { FileText } from "lucide-react";

interface RecentPostItem {
  id: string;
  title: string;
  slug: string;
  category?: string;
  featuredImage?: string | null;
  createdAt: string | Date;
  views?: number;
  status: string;
}

export default function RecentPosts({ posts = [] }: { posts?: RecentPostItem[] }) {
  return (
    <section className="admin-card recent-posts">
      <h2>PUBLICACIONES RECIENTES</h2>
      {posts.length === 0 ? (
        <div className="empty-recent-posts">
          <FileText />
          <p>No hay publicaciones recientes.</p>
        </div>
      ) : (
        posts.map((p, i) => {
          const timeString = new Date(p.createdAt).toLocaleDateString("es-ES", {
            day: "2-digit",
            month: "short",
          });
          return (
            <article key={p.id || p.slug || i}>
              <img
                src={p.featuredImage || "/images/hero-techlab.png"}
                alt=""
                width={64}
                height={48}
                style={{ objectFit: "cover", borderRadius: 4 }}
              />
              <div>
                <Link href={`/dashboard/posts/nuevo?edit=${p.id}`}>
                  <b>{p.title}</b>
                </Link>
                <div className="recent-post-meta">
                  <span className={`tag tag-${i % 3}`}>{p.category || "General"}</span>
                  <span className="post-views-count">{p.views || 0} visitas</span>
                </div>
              </div>
              <small>{timeString}</small>
            </article>
          );
        })
      )}
      <Link href="/dashboard/posts" className="view-all-link">
        Ver todos los posts　→
      </Link>
    </section>
  );
}
