"use client";

import { useState, useEffect } from "react";
import { usePathname } from "next/navigation";
import DashboardSidebar from "./DashboardSidebar";
import DashboardHeader from "./DashboardHeader";
import DashboardFooter from "./DashboardFooter";
import type { SessionUser } from "@/lib/auth";

export default function DashboardShell({
  children,
  user,
}: {
  children: React.ReactNode;
  user: SessionUser | null;
}) {
  const pathname = usePathname();
  const isElementor = pathname?.startsWith("/dashboard/elementor/editor") || pathname?.startsWith("/dashboard/elementor/builder");

  const [mobileOpen, setMobileOpen] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [theme, setTheme] = useState<"dark" | "light">("dark");

  useEffect(() => {
    const savedTheme = localStorage.getItem("techlab_admin_theme") as "dark" | "light" | null;
    if (savedTheme === "light" || savedTheme === "dark") {
      setTheme(savedTheme);
    }
  }, []);

  const toggleTheme = () => {
    const nextTheme = theme === "dark" ? "light" : "dark";
    setTheme(nextTheme);
    localStorage.setItem("techlab_admin_theme", nextTheme);
  };

  const toggleSidebar = () => {
    // En escritorio colapsa/expande a modo iconos; en móvil abre/cierra drawer
    if (typeof window !== "undefined" && window.innerWidth <= 800) {
      setMobileOpen((v) => !v);
    } else {
      setIsCollapsed((v) => !v);
    }
  };

  // Si estamos en el editor de Elementor, pantalla completa limpia sin sidebars ni headers del dashboard
  if (isElementor) {
    return (
      <div
        className="elementor-fullscreen-root"
        style={{
          width: "100vw",
          height: "100vh",
          overflow: "hidden",
          margin: 0,
          padding: 0,
          background: "#121212",
        }}
      >
        {children}
      </div>
    );
  }

  return (
    <div className={`admin-shell ${isCollapsed ? "is-collapsed" : ""} ${theme === "light" ? "theme-light" : ""}`} data-theme={theme}>
      <DashboardSidebar
        user={user}
        open={mobileOpen}
        isCollapsed={isCollapsed}
        close={() => setMobileOpen(false)}
        toggleCollapse={() => setIsCollapsed((v) => !v)}
      />

      {mobileOpen && (
        <button
          className="admin-overlay"
          onClick={() => setMobileOpen(false)}
          aria-label="Cerrar menú"
        />
      )}

      <div className="admin-main">
        <DashboardHeader
          user={user}
          toggle={toggleSidebar}
          isCollapsed={isCollapsed}
          theme={theme}
          toggleTheme={toggleTheme}
        />
        <div className="admin-content">{children}</div>
        <DashboardFooter />
      </div>
    </div>
  );
}
