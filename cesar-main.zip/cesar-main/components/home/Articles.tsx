import Link from "next/link";
import Container from "@/components/ui/Container";
import SectionTitle from "@/components/ui/SectionTitle";
import { prisma } from "@/lib/prisma";
import { ShieldCheck, Code2, Cloud, Terminal, FileText } from "lucide-react";

const icons = [ShieldCheck, Code2, Cloud, Terminal];

export default async function Articles() {
  let dbPosts: any[] = [];
  try {
    dbPosts = await prisma.post.findMany({
      where: { status: { in: ["Publicado", "PUBLICADO"] } },
      include: { category: true },
      orderBy: { createdAt: "desc" },
      take: 4,
    });
  } catch (error) {
    console.error("Error al cargar artículos en Home:", error);
  }

  // Fallback si la base de datos no tuviera registros
  const list = dbPosts.length > 0
    ? dbPosts.map((p, idx) => ({
        id: p.id,
        title: p.title,
        slug: p.slug,
        categoryName: p.category?.name || "Tecnología",
        date: new Date(p.createdAt).toLocaleDateString("es-ES", {
          day: "numeric",
          month: "short",
          year: "numeric",
        }),
        time: `${Math.max(3, Math.ceil((p.content?.length || 500) / 400))} min lectura`,
        featuredImage: p.featuredImage,
        kind: idx === 2 ? "devops" : idx % 2 === 0 ? "sec" : "dev",
      }))
    : [
        {
          id: "1",
          title: "5 prácticas esenciales para proteger tu sitio WordPress",
          slug: "5-practicas-esenciales-para-proteger-tu-sitio-wordpress",
          categoryName: "Seguridad",
          date: "12 May 2026",
          time: "8 min lectura",
          featuredImage: null,
          kind: "sec",
        },
        {
          id: "2",
          title: "¿Next.js o WordPress? Cuándo usar cada uno para tu negocio",
          slug: "nextjs-o-wordpress-cuando-usar-cada-uno",
          categoryName: "Desarrollo",
          date: "2 May 2026",
          time: "6 min lectura",
          featuredImage: null,
          kind: "dev",
        },
        {
          id: "3",
          title: "Guía básica de backups y recuperación ante desastres en Cloud",
          slug: "guia-basica-backups-recuperacion-desastres-cloud",
          categoryName: "DevOps",
          date: "25 Abr 2026",
          time: "5 min lectura",
          featuredImage: null,
          kind: "devops",
        },
        {
          id: "4",
          title: "Mejora el rendimiento y reduce latencia en tu servidor Linux",
          slug: "mejora-rendimiento-servidor-linux",
          categoryName: "Optimización",
          date: "18 Abr 2026",
          time: "7 min lectura",
          featuredImage: null,
          kind: "opt",
        },
      ];

  return (
    <Container>
      <section id="recursos" className="boxed">
        <SectionTitle
          title="ARTÍCULOS Y RECURSOS"
          link="/posts"
          label="Ir al blog →"
        />

        <div className="articles">
          {list.map((a, i) => {
            const Icon = icons[i % icons.length] || FileText;

            return (
              <Link
                href={`/posts/${a.slug}`}
                key={a.id || a.title}
                className="article-card-link"
              >
                <article className={`article ${a.kind}`}>
                  <div className="article-art">
                    {a.featuredImage ? (
                      <img
                        src={a.featuredImage}
                        alt={a.title}
                        className="article-bg-img"
                      />
                    ) : (
                      <Icon />
                    )}
                  </div>
                  <div className="article-overlay">
                    <span>{a.categoryName}</span>
                    <h3>{a.title}</h3>
                    <small>
                      {a.date} · {a.time}
                    </small>
                  </div>
                </article>
              </Link>
            );
          })}
        </div>
      </section>

      <style>{`
        .article-card-link {
          text-decoration: none;
          display: block;
          color: inherit;
        }
        .article-bg-img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          opacity: 0.35;
          transition: transform 0.3s ease, opacity 0.3s ease;
        }
        .article:hover .article-bg-img {
          transform: scale(1.05);
          opacity: 0.5;
        }
      `}</style>
    </Container>
  );
}
