"use client";

import { useState, useEffect } from "react";
import Container from "@/components/ui/Container";
import SectionTitle from "@/components/ui/SectionTitle";
import { services as fallbackServices } from "@/data/services";
import Stats from "./Stats";
import {
  CodeXml,
  Globe2,
  ShieldCheck,
  CloudCog,
  Headphones,
  Lightbulb,
  Box,
} from "lucide-react";

const ICON_MAP: Record<string, any> = {
  CodeXml,
  Globe2,
  ShieldCheck,
  CloudCog,
  Headphones,
  Lightbulb,
  Box,
};

interface ServiceItem {
  id?: string;
  title: string;
  text: string;
  iconName?: string;
  tone?: string;
  price?: string | null;
}

export default function Services() {
  const [list, setList] = useState<ServiceItem[]>(
    fallbackServices.map((s) => ({
      title: s.title,
      text: s.text,
      tone: s.tone,
    }))
  );

  useEffect(() => {
    const fetchServices = async () => {
      try {
        const res = await fetch("/api/services?status=PUBLICADO");
        const data = await res.json();
        if (data.success && data.services && data.services.length > 0) {
          setList(
            data.services.map((s: any, idx: number) => ({
              id: s.id,
              title: s.title,
              text: s.excerpt || "Solución tecnológica integral y escalable.",
              iconName: s.icon || "Box",
              tone: idx % 2 === 0 ? "blue" : "green",
              price: s.price,
            }))
          );
        }
      } catch (err) {
        console.error("Error al cargar servicios en el Home:", err);
      }
    };
    fetchServices();
  }, []);

  return (
    <Container>
      <section id="servicios" className="boxed">
        <SectionTitle
          title="SERVICIOS QUE IMPULSAN TU ÉXITO"
          link="#contacto"
          label="Ver todos los servicios"
        />
        <div className="services">
          {list.map((s, idx) => {
            const IconComponent = (s.iconName && ICON_MAP[s.iconName]) || (idx < fallbackServices.length ? fallbackServices[idx].icon : Box);
            return (
              <article className="service-card" key={s.id || s.title}>
                <IconComponent className={s.tone || "blue"} />
                <h3>{s.title}</h3>
                <p>{s.text}</p>
                {s.price && <span className="service-price-tag">{s.price}</span>}
                <a href="#contacto">
                  Ver más <span>→</span>
                </a>
              </article>
            );
          })}
        </div>
        <Stats />
      </section>

      <style jsx>{`
        .service-price-tag {
          display: inline-block;
          font-size: 11px;
          font-weight: 700;
          color: #16c96f;
          background: rgba(22, 201, 111, 0.12);
          border: 1px solid rgba(22, 201, 111, 0.3);
          padding: 2px 8px;
          border-radius: 4px;
          margin-bottom: 8px;
          width: fit-content;
        }
      `}</style>
    </Container>
  );
}
