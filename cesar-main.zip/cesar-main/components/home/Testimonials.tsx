"use client";

import { useState, useEffect } from "react";
import Container from "@/components/ui/Container";
import SectionTitle from "@/components/ui/SectionTitle";
import { testimonials as fallbackTestimonials } from "@/data/testimonials";

interface TestimonialItem {
  id?: string;
  name: string;
  role?: string | null;
  company?: string | null;
  avatar?: string | null;
  content: string;
  rating: number;
}

export default function Testimonials() {
  const [list, setList] = useState<TestimonialItem[]>(
    fallbackTestimonials.map((t) => ({
      name: t.name,
      role: t.role,
      content: t.quote,
      rating: 5,
      avatar: null,
    }))
  );

  useEffect(() => {
    const fetchPublishedTestimonials = async () => {
      try {
        const res = await fetch("/api/testimonials?status=PUBLICADO");
        const data = await res.json();
        if (data.success && data.testimonials && data.testimonials.length > 0) {
          setList(
            data.testimonials.map((item: any) => ({
              id: item.id,
              name: item.name,
              role: item.role || item.company || "Cliente",
              content: item.content,
              rating: item.rating || 5,
              avatar: item.avatar,
            }))
          );
        }
      } catch (err) {
        console.error("Error al cargar testimonios:", err);
      }
    };
    fetchPublishedTestimonials();
  }, []);

  return (
    <Container>
      <section className="boxed">
        <SectionTitle
          title="LO QUE DICEN MIS CLIENTES"
          link="#contacto"
          label="Ver más testimonios"
        />
        <div className="testimonials">
          {list.map((t, idx) => {
            const initials = t.name
              ? t.name
                  .split(" ")
                  .map((w) => w[0])
                  .slice(0, 2)
                  .join("")
                  .toUpperCase()
              : "CL";

            const starsString = "★".repeat(t.rating || 5) + "☆".repeat(Math.max(0, 5 - (t.rating || 5)));

            return (
              <article className="testimonial" key={t.id || idx}>
                <p>“{t.content}”</p>
                <div className="person">
                  {t.avatar ? (
                    <span className="person-avatar-img-wrapper">
                      <img src={t.avatar} alt={t.name} className="person-avatar-img" />
                    </span>
                  ) : (
                    <span>{initials}</span>
                  )}
                  <div>
                    <b>{t.name}</b>
                    <small>{t.role}</small>
                  </div>
                </div>
                <div className="stars" aria-label={`${t.rating} de 5 estrellas`}>
                  {starsString}
                </div>
              </article>
            );
          })}
        </div>
      </section>

      <style jsx>{`
        .person-avatar-img-wrapper {
          overflow: hidden;
          padding: 0 !important;
        }
        .person-avatar-img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          border-radius: 50%;
        }
      `}</style>
    </Container>
  );
}
