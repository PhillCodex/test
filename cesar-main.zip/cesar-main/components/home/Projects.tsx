"use client";

import { useState, useEffect } from "react";
import Container from "@/components/ui/Container";
import SectionTitle from "@/components/ui/SectionTitle";
import { projects as fallbackProjects } from "@/data/projects";
import {
  BookOpen,
  ShoppingBag,
  PanelsTopLeft,
  ChartNoAxesCombined,
  CalendarCheck,
  FolderKanban,
} from "lucide-react";

const icons = [BookOpen, ShoppingBag, PanelsTopLeft, ChartNoAxesCombined, CalendarCheck];

interface ProjectItem {
  id?: string;
  title: string;
  category?: { name: string } | null;
  categoryName?: string;
  kind?: string;
  featuredImage?: string | null;
}

export default function Projects() {
  const [list, setList] = useState<ProjectItem[]>(
    fallbackProjects.map((p) => ({
      title: p.title,
      categoryName: p.category,
      kind: p.kind,
    }))
  );

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        const res = await fetch("/api/projects?status=PUBLICADO");
        const data = await res.json();
        if (data.success && data.projects && data.projects.length > 0) {
          setList(
            data.projects.map((p: any, idx: number) => ({
              id: p.id,
              title: p.title,
              categoryName: p.category?.name || "Desarrollo Web",
              kind: idx % 2 === 0 ? "learn" : "shop",
              featuredImage: p.featuredImage,
            }))
          );
        }
      } catch (err) {
        console.error("Error al cargar proyectos en el Home:", err);
      }
    };
    fetchProjects();
  }, []);

  return (
    <Container>
      <section id="portafolio" className="boxed">
        <SectionTitle
          title="PROYECTOS DESTACADOS"
          link="#portafolio"
          label="Ver portafolio completo"
        />
        <div className="projects">
          {list.map((p, i) => {
            const Icon = icons[i % icons.length] || FolderKanban;
            return (
              <article className={`project ${p.kind || "learn"}`} key={p.id || p.title}>
                <div className="project-visual">
                  <div className="mini-browser">
                    <i />
                    <i />
                    <i />
                    <span />
                    <b />
                  </div>
                  {p.featuredImage ? (
                    <img src={p.featuredImage} alt={p.title} className="project-custom-thumb" />
                  ) : (
                    <Icon />
                  )}
                </div>
                <div>
                  <h3>{p.title}</h3>
                  <p>{p.categoryName || "Desarrollo Web"}</p>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      <style jsx>{`
        .project-custom-thumb {
          width: 100%;
          height: 100%;
          object-fit: cover;
          border-radius: 6px;
        }
      `}</style>
    </Container>
  );
}
