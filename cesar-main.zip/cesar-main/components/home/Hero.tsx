import Image from "next/image";
import Link from "next/link";
import Container from "@/components/ui/Container";
import { CheckCircle2, Play, Boxes, LockKeyhole, ShieldCheck, Headphones } from "lucide-react";

const benefits = [
  [Boxes, "Soluciones Personalizadas", "Diseñadas para tus necesidades"],
  [LockKeyhole, "Tecnología de Vanguardia", "Herramientas modernas y eficientes"],
  [ShieldCheck, "Seguridad Garantizada", "Protección y respaldo integral"],
  [Headphones, "Soporte Profesional", "Acompañamiento experto"],
] as const;

export default function Hero() {
  return <Container><section id="inicio" className="hero">
    <Image src="/images/hero-techlab.png" alt="Portátil con panel de analítica en un entorno tecnológico profesional" fill priority sizes="(max-width: 768px) 100vw, 1400px" />
    <div className="hero-shade" />
    <div className="hero-copy">
      <div className="eyebrow"><i /> Soluciones tecnológicas de alto impacto</div>
      <h1>TECNOLOGÍA<br />QUE <em>SÍ</em><br />PUEDES USAR</h1>
      <p>Creamos, optimizamos y protegemos sistemas digitales para hacer crecer tu negocio.</p>
      <ul>{["Rendimiento y seguridad", "Soporte experto 24/7", "Soluciones a medida"].map(item => <li key={item}><CheckCircle2 />{item}</li>)}</ul>
      <div className="hero-actions">
        <Link className="btn hero-primary" href="#servicios" aria-label="Explorar nuestros servicios">Explorar servicios <span>→</span></Link>
        <Link className="btn secondary" href="#portafolio"><Play /> Ver portafolio</Link>
      </div>
    </div>
    <div className="benefits">{benefits.map(([Icon,title,description]) => <div className="benefit" key={title}><Icon /><span><b>{title}</b><small>{description}</small></span></div>)}</div>
  </section></Container>;
}
